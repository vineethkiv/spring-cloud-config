# Prive microservice

Prive is a service that handles global information stored in Prive database such as tenants information.

## Environment variables

The environment variable assignments below are intended for desktop development only.

`PRIVE_MONGODB_URI=mongodb://username:pwd@localhost:27017`

Specifies the connection string for MongoDB. Read and write concern options should be specified here.
See [MongoDB documentation](https://docs.mongodb.com/manual/reference/connection-string/) for details.

`PRIVE_MONGODB_DB=prive`

Specifies the database this service uses.