package com.privemanagers.prive.db;

import org.bson.Document;

import com.privemanagers.db.exception.InvalidTenantName;
import com.privemanagers.model.common.entity.TenantServicesConfig;

/**
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
public interface ITenantMongoDBConnection {

	public Document getServiceConfigByTenantName(String inTenantName) throws InvalidTenantName;

	public void saveServicesConfigByTenantName(final String inTenantName,
			final TenantServicesConfig tenantServicesConfig) throws Exception;
}
