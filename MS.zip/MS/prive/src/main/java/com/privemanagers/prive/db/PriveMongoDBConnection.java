package com.privemanagers.prive.db;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.mongodb.Block;
import com.mongodb.client.MongoCollection;
import com.privemanagers.db.MongoDBConnection;

/**
 * @author nteck
 * @date : 21 Mar, 2017
 * @company Prive Financial
 */
@Repository
public class PriveMongoDBConnection implements IPriveMongoDBConnection {

	private final MongoDBConnection connection;
	private final String tenantsCollectionName;

	private MongoCollection<Document> tenantsCollection;

	@Autowired
	public PriveMongoDBConnection(
			final MongoDBConnection connection,
			@Value("${prive.mongodb.collection.tenants:missing-prive.mongodb.collection.tenants}") final String tenantsCollectionName) {
		this.connection = connection;
		this.tenantsCollectionName = tenantsCollectionName;
	}

	@PostConstruct
	public void init() {
		this.tenantsCollection = this.connection.database().getCollection(
				this.tenantsCollectionName);
	}

	public void drop() {
		this.tenantsCollection.drop();
	}

	@Override
	public List<Document> searchTenants(final Document criteria) {
		final List<Document> tenants = new ArrayList<Document>();

		this.tenantsCollection.find(criteria).forEach(new Block<Document>() {

			@Override
			public void apply(final Document document) {
				tenants.add(document);
			}

		});

		return tenants;
	}

}
