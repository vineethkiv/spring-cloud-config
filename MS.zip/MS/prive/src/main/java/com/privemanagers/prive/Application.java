package com.privemanagers.prive;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.privemanagers.api.ObjectIdSerializer;
import com.privemanagers.cc.config.ConcurrencyCommonDefaultConfiguration;
import com.privemanagers.db.MongoDBConfiguration;
import com.privemanagers.prive.adapter.MdcTaskDecorator;
import com.privemanagers.sc.configuration.SharedAutoConfiguration;

/**
 * @author nteck
 * @date : 21 Mar, 2017
 * @company Prive Financial
 */

@SpringBootApplication(scanBasePackages = "com.privemanagers")
@Import({ SharedAutoConfiguration.class, ConcurrencyCommonDefaultConfiguration.class })
public class Application implements MongoDBConfiguration {

	public static void main(final String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Value("${prive.mongodb.uri:missing-prive.mongodb.uri}")
	private String uri;

	@Value("${prive.mongodb.db:missing-prive.mongodb.db}")
	private String db;

	@Value("${prive.executor.core-pool-size}")
	private int corePoolSize;

	@Value("${prive.executor.max-pool-size}")
	private int maxPoolSize;

	@Override
	public String uri() {
		return this.uri;
	}

	@Override
	public String db() {
		return this.db;
	}

	/**
	 * Extract this out from DelegatingSecurityContextAsyncTaskExecutor
	 * initialization
	 *
	 * For monitoring endpoint defined under Controller
	 *
	 * @return
	 */
	@Bean(name = "threadPoolTaskExecutor")
	public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
		final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(this.corePoolSize);
		executor.setMaxPoolSize(this.maxPoolSize);

		executor.setTaskDecorator(new MdcTaskDecorator());

		executor.initialize();
		return executor;
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

		SimpleModule module = new SimpleModule("ObjectIdModule");
		module.addSerializer(ObjectId.class, new ObjectIdSerializer());
		mapper.registerModule(module);
		return mapper;
	}
}
