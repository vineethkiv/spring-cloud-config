package com.privemanagers.prive.adapter;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * AsyncConfig
 *
 * @author Matthew WONG
 * @date 20 Nov 2018
 * @company Prive Financial
 */
@Configuration
@EnableAsync
@Profile("!test")
public class AsyncConfig {

}
