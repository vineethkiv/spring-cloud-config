package com.privemanagers.prive.db;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.annotation.PostConstruct;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import com.privemanagers.db.MongoDBConnection;
import com.privemanagers.db.exception.InvalidTenantName;
import com.privemanagers.model.common.entity.TenantServicesConfig;

/**
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
@Repository
public class TenantMongoDBConnection implements ITenantMongoDBConnection {

	private final MongoDBConnection connection;
	private final String servicesConfigCollectionName;
	private ConcurrentMap<String, ConcurrentMap<String, MongoCollection<Document>>> collectionsPerTenant;

	private MongoCollection<Document> servicesConfigCollection;

	private ObjectMapper objectMapper;

	@Autowired
	public TenantMongoDBConnection(final MongoDBConnection connection,
			@Value("${prive.mongodb.collection.services_config:missing-prive.mongodb.collection.services_config}") final String servicesConfigCollectionName,
			ObjectMapper objectMapper) {
		this.connection = connection;
		this.servicesConfigCollectionName = servicesConfigCollectionName;
		this.objectMapper = objectMapper;
	}

	@PostConstruct
	protected void init() {
		this.collectionsPerTenant = new ConcurrentHashMap<>();
	}

	protected MongoCollection<Document> getCollection(final String tenantName, final String collectionName)
			throws InvalidTenantName {
		return this.connection.getCollection(tenantName, collectionName, this.collectionsPerTenant);
	}

	@Override
	public Document getServiceConfigByTenantName(String inTenantName) throws InvalidTenantName {
		this.servicesConfigCollection = this.getCollection(inTenantName, this.servicesConfigCollectionName);
		return this.servicesConfigCollection.find().first();
	}

	@Override
	public void saveServicesConfigByTenantName(final String inTenantName,
			final TenantServicesConfig tenantServicesConfig) throws Exception {
		this.servicesConfigCollection = this.getCollection(inTenantName, this.servicesConfigCollectionName);

		Document existingDocument = getServiceConfigByTenantName(inTenantName);

		String tenantServicesConfigJson = objectMapper.writeValueAsString(tenantServicesConfig);
		final Document servicesConfigDocument = Document.parse(tenantServicesConfigJson);

		// remove the document id if exists
		if (servicesConfigDocument.containsKey(MongoDBConnection.ID)) {
			servicesConfigDocument.remove(MongoDBConnection.ID);
		}

		if (null == existingDocument) {
			// insert
			servicesConfigCollection.insertOne(servicesConfigDocument);
		} else {
			// update
			servicesConfigDocument.append(MongoDBConnection.ID, existingDocument.getObjectId(MongoDBConnection.ID));

			servicesConfigCollection.updateOne(
					Filters.eq(MongoDBConnection.ID, existingDocument.getObjectId(MongoDBConnection.ID)),
					new Document("$set", servicesConfigDocument), new UpdateOptions().upsert(true));
		}
	}

}
