package com.privemanagers.prive.db;

import java.util.List;

import org.bson.Document;

/**
 * @author nteck
 * @date : 13 Apr, 2017
 * @company Prive Financial
 */
public interface IPriveMongoDBConnection {

	/**
	 * Return the list of tenants depending of the specified search criteria.
	 * 
	 * @param criteria
	 * @return
	 */
	public List<Document> searchTenants(final Document criteria);

}
