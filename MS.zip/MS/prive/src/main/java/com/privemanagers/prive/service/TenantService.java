package com.privemanagers.prive.service;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.privemanagers.db.exception.InvalidCollectionName;
import com.privemanagers.db.exception.InvalidTenantName;
import com.privemanagers.db.util.DocumentUtil;
import com.privemanagers.model.common.entity.TenantServicesConfig;
import com.privemanagers.prive.adapter.MethodLog;
import com.privemanagers.prive.db.ITenantMongoDBConnection;

/**
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
@Service
public class TenantService implements ITenantService {

	private final ITenantMongoDBConnection database;

	@Autowired
	public TenantService(final ITenantMongoDBConnection database) {
		this.database = database;
	}

	@Override
	@MethodLog
	public String getServicesConfigByTenantName(String inTenantName) throws InvalidCollectionName, InvalidTenantName {

		final Document servicesConfig = database.getServiceConfigByTenantName(inTenantName);
		if (servicesConfig != null) {
			return DocumentUtil.toString(servicesConfig);
		}

		return null;
	}

	@Override
	@Async("threadPoolTaskExecutor")
	@MethodLog
	public void saveServicesConfigByTenantNameAsync(final String inTenantName,
			final TenantServicesConfig tenantServicesConfig)
			throws InvalidCollectionName, InvalidTenantName, Exception {

		database.saveServicesConfigByTenantName(inTenantName, tenantServicesConfig);
	}

}
