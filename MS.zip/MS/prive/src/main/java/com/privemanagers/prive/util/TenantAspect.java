package com.privemanagers.prive.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.privemanagers.api.API;
import com.privemanagers.prive.adapter.TenantName;

/**
 * Tenant MDC info aspect to set the tenant information into MDC
 *
 * @author Matthew WONG
 * @date 20 Nov 2018
 * @company Prive Financial
 */
@Aspect
@Component
public class TenantAspect {

	private static final Logger logger = LoggerFactory.getLogger(TenantAspect.class);
	private final HttpServletRequest request;

	private static final List<String> POSSIBLE_TENANT_PARAM_NAMES = Arrays.asList("tenant", "inTenant");

	public TenantAspect(HttpServletRequest request) {
		this.request = request;
	}

	@Around("execution(* *(..)) && @annotation(com.privemanagers.prive.adapter.Tenant)")
	public Object around(final ProceedingJoinPoint joinPoint) throws Throwable {

		String tenant = null;

		// try to find the method parameter annotated with @TenantName, and get
		// value when found
		tenant = getTenantValueAnnotatedWithTenantName(joinPoint);

		// cannot find the method parameter annotated with @TenantName, search
		// by possible names
		if (StringUtils.isEmpty(tenant)) {
			tenant = getTenantValueWithPossibleParamNames(joinPoint, POSSIBLE_TENANT_PARAM_NAMES);
		}

		API.setMDC(tenant, request);

		try {
			final String method = request.getMethod();
			final String requestURI = request.getRequestURI();
			logger.info(MessageFormat.format("Processing request {0} at {1}", method, requestURI));
			return joinPoint.proceed();
		} finally {
			MDC.clear();
		}

	}

	/**
	 * Try to find the tenant value with possible method parameter names given
	 * 
	 * @param joinPoint
	 * @param possibleParamNames
	 * @return The Tenant string value. Returns null if not found.
	 */
	private String getTenantValueWithPossibleParamNames(JoinPoint joinPoint, List<String> possibleParamNames) {

		if (CollectionUtils.isEmpty(possibleParamNames)) {
			return null;
		}

		MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
		String[] parameterNames = methodSignature.getParameterNames();

		for (int i = 0; i < parameterNames.length; i++) {
			if (possibleParamNames.contains(parameterNames[i])) {
				return (String) joinPoint.getArgs()[i];
			}
		}

		return null;
	}

	/**
	 * Try to find the tenant value with method parameter which annotated
	 * with @Tenant
	 * 
	 * @param joinPoint
	 * @return The Tenant string value. Returns null if not found.
	 */
	private String getTenantValueAnnotatedWithTenantName(JoinPoint joinPoint) {

		final MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();

		final Method method = methodSignature.getMethod();
		final Annotation[][] paramAnnotations = method.getParameterAnnotations();

		for (int i = 0; i < paramAnnotations.length; i++) {
			final Annotation[] annotations = paramAnnotations[i];

			if (isContainAnnotationWithType(annotations, TenantName.class)) {
				return (String) joinPoint.getArgs()[i];
			}
		}

		return null;
	}

	private <T extends Annotation> boolean isContainAnnotationWithType(final Annotation[] annotations,
			final Class<T> clazz) {

		for (final Annotation annotation : annotations) {
			if (clazz.isAssignableFrom(annotation.getClass())) {
				return true;
			}
		}

		return false;
	}
}
