package com.privemanagers.prive;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.context.request.async.DeferredResult;

import com.privemanagers.api.EndPoints;
import com.privemanagers.db.exception.InvalidTenantName;
import com.privemanagers.model.prive.request.UpdateTenantServicesConfigRequest;
import com.privemanagers.prive.adapter.Tenant;
import com.privemanagers.prive.adapter.TenantName;
import com.privemanagers.prive.service.IPriveService;
import com.privemanagers.prive.service.ITenantService;

/**
 * @author nteck
 * @date : 21 Mar, 2017
 * @company Prive Financial
 */

@RestController
public class Controller {

	@Autowired
	private IPriveService priveService;

	@Autowired
	private ITenantService tenantService;

	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@PostMapping(value = EndPoints.PRIVE_1_TENANTS, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> searchTenants(@RequestBody final String body) {
		return new Callable<ResponseEntity<String>>() {
			@Override
			public ResponseEntity<String> call() throws Exception {
				final List<String> tenants = Controller.this.priveService.searchTenants(body);

				return new ResponseEntity<>(tenants.toString(), HttpStatus.OK);
			}
		};
	}

	@Tenant
	@PreAuthorize("hasCustomAuthority(#tenant)")
	@GetMapping(value = EndPoints.PRIVE_1_TENANTS_CONFIG, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public DeferredResult<ResponseEntity<String>> getTenantsConfig(
			@PathVariable("tenant") @TenantName final String tenant) {

		DeferredResult<ResponseEntity<String>> deferredResult = new DeferredResult<>();

		CompletableFuture.supplyAsync(() -> {
			try {
				String servicesConfig = tenantService.getServicesConfigByTenantName(tenant);
				return new ResponseEntity<>(servicesConfig, HttpStatus.OK);
			} catch(final InvalidTenantName itn) {
				return new ResponseEntity<>(itn.getMessage(), HttpStatus.NOT_FOUND);
			} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			} catch (final Exception e) {
				return new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}, threadPoolTaskExecutor).whenCompleteAsync((result, exception) -> deferredResult.setResult(result));

		return deferredResult;
	}

	@Tenant
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@PutMapping(value = EndPoints.PRIVE_1_TENANTS_CONFIG, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public void updateTenantServicesConfig(@PathVariable("tenant") @TenantName final String tenant,
			@RequestBody final UpdateTenantServicesConfigRequest updateTenantServicesConfigRequest) throws Exception {

		tenantService.saveServicesConfigByTenantNameAsync(tenant,
				updateTenantServicesConfigRequest.getServicesConfig());
	}
}
