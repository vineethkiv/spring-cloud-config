package com.privemanagers.prive.service;

import java.util.List;

/**
 * @author nteck
 * @date : 13 Apr, 2017
 * @company Prive Financial
 */
public interface IPriveService {

	/**
	 * Search tenants with specified criteria.
	 *
	 * @param criteria
	 * @return
	 */
	public List<String> searchTenants(final String criteria);

}
