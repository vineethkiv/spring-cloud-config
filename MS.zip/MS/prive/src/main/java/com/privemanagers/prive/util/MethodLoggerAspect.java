package com.privemanagers.prive.util;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Method logging aspect to use in service level
 *
 * @author Matthew WONG
 * @date 20 Nov 2018
 * @company Prive Financial
 */
@Aspect
@Order(Ordered.HIGHEST_PRECEDENCE - 1)
@Component
public class MethodLoggerAspect {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ObjectMapper objectMapper;

	@Around("execution(* *(..)) && @annotation(com.privemanagers.prive.adapter.MethodLog)")
	public Object around(ProceedingJoinPoint point) throws Throwable {
		long start = System.currentTimeMillis();

		try {
			String requestStr = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(point.getArgs());
			logger.info("[method:{}] begin \n method param:\n{}",
					MethodSignature.class.cast(point.getSignature()).getMethod().getName(), requestStr);
		} catch (JsonProcessingException e) {
			throw new IllegalArgumentException("invalid request, request cannot be parse to String");
		}

		Object result = point.proceed();

		logger.info("[method:{}], completed in {}ms",
				MethodSignature.class.cast(point.getSignature()).getMethod().getName(),
				System.currentTimeMillis() - start);

		if (logger.isDebugEnabled()) {
			String responseStr = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);
			logger.debug("response:\n{}", responseStr);
		}
		return result;
	}

}
