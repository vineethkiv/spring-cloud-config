package com.privemanagers.prive.service;

import com.privemanagers.db.exception.InvalidCollectionName;
import com.privemanagers.db.exception.InvalidTenantName;
import com.privemanagers.model.common.entity.TenantServicesConfig;

/**
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
public interface ITenantService {
	/**
	 * Get services config for specific tenant.
	 *
	 * @param inTenantName
	 * @return
	 * @throws InvalidTenantName
	 * @throws InvalidCollectionName
	 */
	public String getServicesConfigByTenantName(final String inTenantName)
			throws InvalidCollectionName, InvalidTenantName;

	/**
	 * Save services config for specific tenant asynchronously
	 *
	 * @param inTenantName
	 * @throws InvalidCollectionName
	 * @throws InvalidTenantName
	 */
	public void saveServicesConfigByTenantNameAsync(final String inTenantName,
			final TenantServicesConfig tenantServicesConfig) throws InvalidCollectionName, InvalidTenantName, Exception;
}
