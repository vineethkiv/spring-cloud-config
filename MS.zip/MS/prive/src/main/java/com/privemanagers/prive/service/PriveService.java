package com.privemanagers.prive.service;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.privemanagers.db.util.DocumentUtil;
import com.privemanagers.prive.db.IPriveMongoDBConnection;

/**
 * @author nteck
 * @date : 21 Mar, 2017
 * @company Prive Financial
 */
@Service
public class PriveService implements IPriveService {

	private final IPriveMongoDBConnection database;

	@Autowired
	public PriveService(final IPriveMongoDBConnection database) {
		this.database = database;
	}

	@Override
	public List<String> searchTenants(final String body) {
		final Document criteria = Document.parse(body);
		final List<Document> tenants = this.database.searchTenants(criteria);
		final List<String> res = new ArrayList<String>();

		for (final Document tenant : tenants) {
			res.add(DocumentUtil.toString(tenant));
		}

		return res;
	}

}
