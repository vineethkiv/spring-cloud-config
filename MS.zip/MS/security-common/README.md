# security-common jar

import this to enable spring security in your service, this will validate tokens on any incoming http requests, if extra permission is needed, check expression based access control (i.e. @PreAuthorize)


## Environment variables (already defined in application-sharaed.properties)

The environment variable assignments below are intended for desktop development only.

`prive.auth.public.cert.filename:public_key.cert`

the filename of the public_key stored under src/main/resources

### how to configure newly secured service (check quant for example)

add shared properties config to Application class:

add this annotation to the Application class
@Import(SharedAutoConfiguration.class)

add the following in application.properties:
`prive.resource.id=your_service_name`