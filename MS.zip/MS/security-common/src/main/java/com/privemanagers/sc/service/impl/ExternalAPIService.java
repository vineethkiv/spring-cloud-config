package com.privemanagers.sc.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.privemanagers.api.EndPoints;
import com.privemanagers.sc.service.IExternalAPIService;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * Service wrapper to get information from prive service
 *
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
@Service
public class ExternalAPIService implements IExternalAPIService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/** URI of the prive service */
	private final String priveServiceURI;

	@Autowired
	public ExternalAPIService(@Value("${prive.prive.uri:missing-prive.prive.uri}") final String priveServiceURI) {
		this.priveServiceURI = priveServiceURI;
	}

	@Override
	public ResponseEntity<String> getTenantConfig(String inTenantName) {

		ResponseEntity<String> res = null;
		try {

			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.priveServiceURI,
					EndPoints.PRIVE_1_TENANTS_CONFIG, inTenantName, null, HttpMethod.GET, null, false);
			if (response.getStatusCode().is2xxSuccessful()) {
				res = response;
			} else {
				this.logger.error(
						"Error occured when getting tenant config for tenant {}.\nHTTP status code={}.\nResponse body={}.",
						inTenantName, response.getStatusCode(), response.getBody());
			}

		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
			throw httpException;
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()
					+ " Error occured when getting tenant config for tenant: " + inTenantName + ".", e);
			throw e;
		}
		return res;

	}

}
