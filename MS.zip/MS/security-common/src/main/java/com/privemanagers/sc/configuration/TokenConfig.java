package com.privemanagers.sc.configuration;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtClaimsSetVerifier;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.util.FileCopyUtils;

import com.privemanagers.sc.util.JwtClaimVerifier;

/**
 * JWT related configuration
 *
 * @author William Zhang
 * @date 6 Dec 2017
 * @company Prive Financial
 */
@Configuration
public class TokenConfig {

	@Autowired
	JwtAccessTokenConverter jwtAccessTokenConverter;

	/**
	 * The file path to the public key of auth's private key. This is use to
	 * verify the signature of the token
	 */
	private final String verifierKeyFilePath;

	@Autowired
	public TokenConfig(
			@Value("${prive.auth.public.cert.filename:missing-auth.public.cert.filename}") String publicCert) {
		this.verifierKeyFilePath = publicCert;
	}

	@Bean
	@Qualifier("tokenStore")
	public TokenStore tokenStore() {
		return new JwtTokenStore(jwtAccessTokenConverter);
	}

	/**
	 * Define the custom JWT claim verifier
	 *
	 * @return
	 */
	@Bean
	public JwtClaimsSetVerifier customJwtClaimVerifier() {
		return new JwtClaimVerifier();
	}

	/**
	 * Define the jwt token converter with the public cert and claim verifier
	 *
	 * @return
	 */
	@Bean
	protected JwtAccessTokenConverter jwtAccessTokenConverter() {

		Resource resource = new ClassPathResource(verifierKeyFilePath);

		JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
		converter.setJwtClaimsSetVerifier(customJwtClaimVerifier());

		try {
			String publicKey = new String(FileCopyUtils.copyToByteArray(resource.getInputStream()));
			converter.setVerifierKey(publicKey);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return converter;
	}
}
