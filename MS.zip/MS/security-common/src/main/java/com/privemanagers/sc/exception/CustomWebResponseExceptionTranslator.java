package com.privemanagers.sc.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;

public class CustomWebResponseExceptionTranslator implements WebResponseExceptionTranslator<OAuth2Exception> {

	@Override
	public ResponseEntity<OAuth2Exception> translate(final Exception e) throws Exception {

		OAuth2Exception exception = OAuth2Exception.create(OAuth2Exception.ACCESS_DENIED, "401 Unauthorized");
		return new ResponseEntity<>(exception, HttpStatus.UNAUTHORIZED);
	}
}
