package com.privemanagers.sc.interceptor;

import org.springframework.web.servlet.AsyncHandlerInterceptor;

/**
 * Base class for request interceptor
 *
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
public abstract class AbstractBaseInterceptor implements AsyncHandlerInterceptor {

	/**
	 * Extract tenant id from the given URL
	 *
	 * @param inURL
	 * @return
	 */
	protected String extractTenantFromURL(String inURL) {
		final String[] pathArray = inURL.split("/");
		if (pathArray.length >= 4) {
			return pathArray[3];
		}
		return null;
	}

}
