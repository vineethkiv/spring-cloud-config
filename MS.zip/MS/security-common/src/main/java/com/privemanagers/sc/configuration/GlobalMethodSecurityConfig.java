package com.privemanagers.sc.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.GlobalMethodSecurityConfiguration;

import com.privemanagers.sc.expression.CustomMethodSecurityConfigHandler;

/**
 * @author William Zhang
 * @date 6 Dec 2017
 * @company Prive Financial
 *
 *          Use to enable spring expression based access control
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class GlobalMethodSecurityConfig extends GlobalMethodSecurityConfiguration {

	/**
	 * Create a custom expression handler to include custom expression based
	 * access control annotations (Custom method in {@link PreAuthorize} and
	 * {@link PostAuthorize} annotation)
	 */
	@Override
	protected MethodSecurityExpressionHandler createExpressionHandler() {
		return new CustomMethodSecurityConfigHandler();

	}

}
