package com.privemanagers.sc.util;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.token.store.JwtClaimsSetVerifier;

/**
 * JWT Token Verifier to verify the token claim
 *
 * @author Gavy Lau
 */
public class JwtClaimVerifier implements JwtClaimsSetVerifier {

	@Value("${prive.resource.id:missing-resource.id}")
	private String resourceID;

	private static final String ALL_RESOURCES = "J@gsH3maSh!pEps!m0_xi";

	/**
	 * Customizeable claim verifier, throws CustomInvalidTokenException if any
	 * of the verification fails
	 */
	@Override
	public void verify(Map<String, Object> claims) throws InvalidTokenException {
		try {
			this.verifyResources(claims);
		} catch (InvalidTokenException cite) {
			throw cite;
		}
	}

	/**
	 * Verify that the claims have access to the service resource. The current
	 * service resource is define in resourceID
	 *
	 * @param claims
	 * @throws CustomInvalidTokenException
	 */
	@SuppressWarnings("unchecked")
	private final void verifyResources(final Map<String, Object> claims) throws InvalidTokenException {
		boolean isAuthorized = false;

		List<String> resources = (List<String>) claims.get("resources");
		if (resources != null && !resources.isEmpty()) {
			for (String resource : resources) {
				if (resourceID.equalsIgnoreCase(resource) || ALL_RESOURCES.equalsIgnoreCase(resource)) {
					isAuthorized = true;
					break;
				}
			}
		}

		if (!isAuthorized) {
			throw new InvalidTokenException("user is not allowed to access the requested resource: " + resourceID);
		}
	}

}
