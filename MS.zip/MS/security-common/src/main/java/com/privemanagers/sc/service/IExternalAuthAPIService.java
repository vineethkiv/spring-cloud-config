package com.privemanagers.sc.service;

import org.springframework.security.oauth2.provider.OAuth2Authentication;

/**
 * Service wrapper to get information from auth service
 *
 * @author Gavy Lau
 */
public interface IExternalAuthAPIService {

	/**
	 * Get a string token from auth service based on the different set of input
	 *
	 * @param tenant
	 * @param inUsername
	 * @param inPassword
	 * @param inDeprecatedToken
	 * @return
	 */
	public String getOAuth2AuthenticationToken(final String tenant, final String inUsername, final String inPassword,
			final String inDeprecatedToken);

	/**
	 * Get {@link OAuth2Authentication} from auth service based on the different
	 * set of input. This is mainly used by scheule job
	 *
	 * @param tenant
	 * @param inUsername
	 * @param inPassword
	 * @param inDeprecatedToken
	 * @return
	 */
	public OAuth2Authentication getOAuth2Authentication(final String tenant, final String inUsername,
			final String inPassword, final String inDeprecatedToken);

}
