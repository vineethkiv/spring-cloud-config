package com.privemanagers.sc.configuration;

import org.springframework.context.annotation.PropertySource;
import org.springframework.util.ResourceUtils;

/**
 * Shared application resource default properties. Can be overridden by
 * application.properties in each service
 *
 * @author Gavy Lau
 */
@PropertySource(ResourceUtils.CLASSPATH_URL_PREFIX + "application-shared.properties")
public class SharedAutoConfiguration {

}
