package com.privemanagers.sc.util;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;

public class SecurityUtil {

	/**
	 * Extract the OAuth bearer token from a header.
	 *
	 * @param request
	 *            The request.
	 * @return The token, or null if no OAuth authorization header was supplied.
	 */
	public static String extractHeaderToken(HttpServletRequest request) {
		Enumeration<String> headers = request.getHeaders(HttpHeaders.AUTHORIZATION);
		while (headers.hasMoreElements()) { // typically there is only one (most
											// servers enforce that)
			String value = headers.nextElement();
			if ((value.toLowerCase().startsWith(OAuth2AccessToken.BEARER_TYPE.toLowerCase()))) {
				String authHeaderValue = value.substring(OAuth2AccessToken.BEARER_TYPE.length()).trim();
				// Add this here for the auth details later. Would be better to
				// change the signature of this method.
				request.setAttribute(OAuth2AuthenticationDetails.ACCESS_TOKEN_TYPE,
						value.substring(0, OAuth2AccessToken.BEARER_TYPE.length()).trim());
				int commaIndex = authHeaderValue.indexOf(',');
				if (commaIndex > 0) {
					authHeaderValue = authHeaderValue.substring(0, commaIndex);
				}
				return authHeaderValue;
			}
		}

		return null;
	}

	/**
	 * Extract the {@link OAuth2AccessToken} from Spring security context and
	 * return the bearer token
	 *
	 * @return
	 */
	public static String extractHeaderToken() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication instanceof OAuth2Authentication) {
			if (authentication.getDetails() instanceof OAuth2AuthenticationDetails) {
				return ((OAuth2AuthenticationDetails) authentication.getDetails()).getTokenValue();
			} else if (authentication.getDetails() instanceof OAuth2AccessToken) {
				return ((OAuth2AccessToken) authentication.getDetails()).getValue();
			}
		}
		return null;
	}

	private SecurityUtil() {
	};
}
