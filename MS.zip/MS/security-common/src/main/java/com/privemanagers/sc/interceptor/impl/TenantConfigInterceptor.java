package com.privemanagers.sc.interceptor.impl;

import javax.servlet.DispatcherType;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.servlet.ModelAndView;

import com.privemanagers.api.API;
import com.privemanagers.api.HeaderConstants;
import com.privemanagers.api.TenantContext;
import com.privemanagers.sc.interceptor.AbstractBaseInterceptor;
import com.privemanagers.sc.service.impl.ExternalAPIService;

/**
 * Request interceptor to ensure the tenant configuration is put into the
 * request header
 *
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
@Component
public class TenantConfigInterceptor extends AbstractBaseInterceptor {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ExternalAPIService externalAPIService;

	@Autowired
	private TenantContext tenantContext;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		/**
		 * since HandlerInterceptor fires up 2 threads per request and preHandle
		 * is called once per thread we will only handle the request if the
		 * DispatcherType is REQUEST, which is the main thread.
		 *
		 * more info here: https://jira.spring.io/browse/SPR-12608
		 */
		if (DispatcherType.ASYNC.equals(request.getDispatcherType())) {
			return true;
		}

		String tenantConfig = request.getHeader(HeaderConstants.PRIVE_TENANT_CONFIG);
		if (tenantConfig == null) {

			/*
			 * If tenant config is not found, attempt to get this from DB so
			 * that it can be populate into the request header
			 */
			final String tenantName = extractTenantFromURL(request.getRequestURI());
			if (tenantName == null) {
				return false;
			}
			try {
				ResponseEntity<String> tenantResponse = this.externalAPIService.getTenantConfig(tenantName);
				if (!tenantResponse.getStatusCode().is2xxSuccessful()) {
					this.logger.error(
							"Error occured when getting tenant config for tenant {}.\nHTTP status code={}.\nResponse body={}.",
							tenantName, tenantResponse.getStatusCode(), tenantResponse.getBody());
					return false;
				}
				tenantConfig = tenantResponse.getBody();
			} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
				response.setStatus(httpException.getStatusCode().value());
				this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
				return false;
			} catch (ResourceAccessException rae) {
				response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				this.logger.error("Error connecting to prive service", rae);
				return false;
			} catch (Exception e) {
				response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
				this.logger.error("Error occured when getting tenant config for tenant: " + tenantName + ".", e);
				return false;
			}

		}
		this.tenantContext.setServicesConfig(API.parseObject(tenantConfig));

		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// nothing to handle
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// nothing to handle
	}

	@Override
	public void afterConcurrentHandlingStarted(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// nothing to handle
	}

}
