package com.privemanagers.sc.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;
import org.springframework.security.oauth2.provider.error.OAuth2AuthenticationEntryPoint;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;

import com.privemanagers.api.EndPoints;
import com.privemanagers.sc.exception.CustomWebResponseExceptionTranslator;

/**
 * Server resource configuration to define with endpoint security
 *
 * @author William Zhang
 * @date 6 Dec 2017
 * @company Prive Financial
 */
@Configuration
@EnableResourceServer
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {

	@Value("${prive.resource.id:missing-resource.id}")
	private String resourceID;

	@Autowired
	TokenStore tokenStore;

	/**
	 * allow public access to /health and /error but all other /resourceID/*
	 * endpoints will require authentication
	 */
	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.csrf()
				.disable()
				.anonymous()
				.and()
				.authorizeRequests()
				.antMatchers(HttpMethod.GET, EndPoints.HEALTH)
				.permitAll()
				.antMatchers(EndPoints.ERROR + "/**")
				.permitAll()
				.antMatchers("/" + resourceID + "/**")
				.authenticated()
				.and()
				.exceptionHandling()
				.authenticationEntryPoint((request, response, e) -> {
					response.setStatus(HttpStatus.UNAUTHORIZED.value());
				});
	}

	/** Define your custom exception translator bean here */
	@Bean
	public WebResponseExceptionTranslator<OAuth2Exception> exceptionTranslator() {
		return new CustomWebResponseExceptionTranslator();
	}

	/**
	 * Inject your custom exception translator into the OAuth2
	 * {@link AuthenticationEntryPoint}.
	 *
	 * @return AuthenticationEntryPoint
	 */
	@Bean
	public AuthenticationEntryPoint authenticationEntryPoint() {
		final OAuth2AuthenticationEntryPoint entryPoint = new OAuth2AuthenticationEntryPoint();
		entryPoint.setExceptionTranslator(exceptionTranslator());
		return entryPoint;
	}

	/**
	 * Classic Spring Security stuff, defining how to handle
	 * {@link AccessDeniedException}s. Inject your custom exception translator
	 * into the OAuth2AccessDeniedHandler. (if you don't add this access denied
	 * exceptions may use a different format)
	 *
	 * @return AccessDeniedHandler
	 */
	@Bean
	public AccessDeniedHandler accessDeniedHandler() {
		final OAuth2AccessDeniedHandler handler = new OAuth2AccessDeniedHandler();
		handler.setExceptionTranslator(exceptionTranslator());
		return handler;
	}

	/**
	 * Add the token store defined in {@link TokenConfig} to the
	 * {@link ResourceServerConfigurerAdapter}
	 */
	@Override
	public void configure(ResourceServerSecurityConfigurer config) throws Exception {
		config.tokenStore(tokenStore).accessDeniedHandler(accessDeniedHandler()).authenticationEntryPoint(
				authenticationEntryPoint());
	}
}
