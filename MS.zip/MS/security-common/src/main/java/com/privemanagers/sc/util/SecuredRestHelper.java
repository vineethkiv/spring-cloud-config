package com.privemanagers.sc.util;

import java.net.URI;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;

import com.privemanagers.api.TenantContext;
import com.privemanagers.api.util.RestHelper;

/**
 * SecuredRestHelper with static methods, use this if don't like to new and
 * planned to not write unit test
 *
 * @author William Zhang
 * @date 20 Jan 2018
 * @company Prive Financial
 */
public class SecuredRestHelper extends RestHelper {

	/**
	 *
	 * sends a rest request based on the input
	 *
	 * @param uriString
	 * @param endpoint
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param tenantContext
	 * @param continuation
	 * @return ResponseEntity<String>
	 */
	public static ResponseEntity<String> sendRequest(final String uriString, final String endpoint, final String tenant,
			final String body, final HttpMethod httpMethod, final TenantContext tenantContext,
			final boolean continuation) {

		return RestHelper.sendRequest(uriString, endpoint, tenant, body, httpMethod, SecurityUtil.extractHeaderToken(),
				tenantContext, continuation);

	}

	/**
	 * makes async restful call using the given executor
	 *
	 * @param executor
	 * @param uri
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param tenantContext
	 * @param continuation
	 * @return ListenableFuture<ResponseEntity<String>>
	 */
	public static ListenableFuture<ResponseEntity<String>> sendRequest(final ThreadPoolTaskExecutor executor,
			final URI uri, final String tenant, final String body, final HttpMethod httpMethod,
			final TenantContext tenantContext, final boolean continuation) {

		return RestHelper.sendRequest(executor, uri, tenant, body, httpMethod, SecurityUtil.extractHeaderToken(),
				tenantContext, continuation);

	}

	/**
	 *
	 * sends a rest request based on the input
	 *
	 * @param uri
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param tenantContext
	 * @param continuation
	 * @return ResponseEntity<String>
	 */
	public static ResponseEntity<String> sendRequest(final URI uri, final String tenant, final String body,
			final HttpMethod httpMethod, final TenantContext tenantContext, final boolean continuation) {

		return RestHelper.sendRequest(uri, tenant, body, httpMethod, SecurityUtil.extractHeaderToken(), tenantContext,
				continuation);
	}
}
