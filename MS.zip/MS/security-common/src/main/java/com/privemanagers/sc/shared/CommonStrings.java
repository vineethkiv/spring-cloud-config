package com.privemanagers.sc.shared;

/**
 * Common string used by this service
 *
 * @author Gavy Lau
 */
public enum CommonStrings {

	HEADER_KEY_API_USERNAME("prive-api-username"),
	HEADER_KEY_API_PASSWORD("prive-api-password"),
	KEY_USERNAME("username"),
	KEY_PASSWORD("password"),
	BEARER_TOKEN_PREFIX("Bearer "),
	DEVELOPER_BYPASS_CHECK("chelski_849"),
	AUTHORIZATION("Authorization"),
	ACCESS_TOKEN("access_token"),
	CLIENT_SECRET("client_secret"),
	ACCESS_TOKEN_ONLY("accessTokenOnly"),
	TENANT("tenant");

	private String stringValue;

	CommonStrings(final String stringValue) {
		this.setStringValue(stringValue);
	}

	public final String getStringValue() {
		return stringValue;
	}

	protected void setStringValue(final String stringValue) {
		this.stringValue = stringValue;
	}

}
