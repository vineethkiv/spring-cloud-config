package com.privemanagers.sc.expression;

import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;

/**
 * Implementation of the custom method in {@link PreAuthorize} and
 * {@link PostAuthorize} annotation
 *
 * @author Gavy Lau
 */
public class CustomMethodSecurityExpressionRoot extends SecurityExpressionRoot
		implements MethodSecurityExpressionOperations {

	/** Admin role that have access to all tenant */
	private static final String ALL_TENANTS_ACCESS = "ROLE_ADMIN";

	private Object filterObject;
	private Object returnObject;

	public CustomMethodSecurityExpressionRoot(Authentication authentication) {
		super(authentication);
	}

	/**
	 * Defines a custom method for {@link PreAuthorize} and
	 * {@link PostAuthorize} annotation to check for authorities. This does a
	 * check with CustomUser.roles with the given inUserRole
	 *
	 * @param inUserRole
	 *            the role to check
	 * @return
	 */
	public boolean hasCustomAuthority(final String inUserRole) {
		return super.hasAnyAuthority(inUserRole, ALL_TENANTS_ACCESS);
	}

	@Override
	public void setFilterObject(Object filterObject) {
		this.filterObject = filterObject;
	}

	@Override
	public Object getFilterObject() {
		return this.filterObject;
	}

	@Override
	public void setReturnObject(Object returnObject) {
		this.returnObject = returnObject;
	}

	@Override
	public Object getReturnObject() {
		return this.returnObject;
	}

	@Override
	public Object getThis() {
		return this;
	}

}
