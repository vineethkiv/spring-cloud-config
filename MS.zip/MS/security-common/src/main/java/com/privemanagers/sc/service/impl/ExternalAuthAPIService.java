package com.privemanagers.sc.service.impl;

import java.net.URI;

import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.API;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.util.RestHelper;
import com.privemanagers.sc.service.IExternalAuthAPIService;
import com.privemanagers.sc.shared.CommonStrings;

@Service
public class ExternalAuthAPIService implements IExternalAuthAPIService {

	private static final Logger logger = LoggerFactory.getLogger(ExternalAuthAPIService.class);

	/** URI of the auth service */
	private final String authServiceURI;

	/** static secret for admin access */
	private final String clientSecret;

	@Autowired
	TokenStore tokenStore;

	private static final JsonBuilderFactory factory = API.makeJsonBuilderFactory();

	@Autowired
	public ExternalAuthAPIService(@Value("${prive.auth:missing-prive.auth}") final String authServiceURI,
			@Value("${prive.auth.admin.secret:missing-auth.admin.secret}") final String clientSecret) {
		this.authServiceURI = authServiceURI;
		this.clientSecret = clientSecret;
	}

	@Override
	public String getOAuth2AuthenticationToken(final String tenant, final String inUsername, final String inPassword,
			final String inDeprecatedToken) {

		logger.debug("calling {} to get oauth2token for user: {} oldtoken: {} tenant: {}",
				this.authServiceURI + EndPoints.AUTH_1_LOGIN, inUsername, inDeprecatedToken, tenant);

		String body = null;
		JsonObjectBuilder builder = factory.createObjectBuilder();
		builder.add(CommonStrings.TENANT.getStringValue(), tenant);

		if (inUsername == null && inPassword == null && inDeprecatedToken == null) {
			builder.add(CommonStrings.CLIENT_SECRET.getStringValue(), clientSecret);
		} else if (inUsername != null && inPassword != null) {
			builder.add(CommonStrings.KEY_USERNAME.getStringValue(), inUsername);
			builder.add(CommonStrings.KEY_PASSWORD.getStringValue(), inPassword);
		}
		body = builder.build().toString();

		final URI uri = UriComponentsBuilder.fromUriString(this.authServiceURI)
				.path(EndPoints.AUTH_1_LOGIN)
				.queryParam(CommonStrings.ACCESS_TOKEN_ONLY.getStringValue(), true)
				.build()
				.encode()
				.toUri();

		final ResponseEntity<String> response = RestHelper.sendRequest(uri, tenant, body, HttpMethod.POST,
				inDeprecatedToken, null, false);

		if (response.getStatusCode().is2xxSuccessful()) {
			JsonObject object = API.parseObject(response.getBody().toString());
			String token = object.getString(CommonStrings.ACCESS_TOKEN.getStringValue());
			if (token != null) {
				return token;
			} else {
				throw new HttpClientErrorException(response.getStatusCode());
			}
		} else {
			throw new HttpClientErrorException(response.getStatusCode());
		}
	}

	@Override
	public OAuth2Authentication getOAuth2Authentication(final String tenant, final String inUsername,
			final String inPassword, final String inDeprecatedToken) {
		String accessToken = this.getOAuth2AuthenticationToken(tenant, inUsername, inPassword, inDeprecatedToken);
		if (accessToken != null) {
			return createAuthenticationFromToken(accessToken);
		}
		return null;
	}

	/**
	 * Create {@link OAuth2Authentication} object from given string token
	 *
	 * @param accessToken
	 * @return
	 */
	private OAuth2Authentication createAuthenticationFromToken(final String accessToken) {
		if (accessToken != null) {
			OAuth2Authentication auth = tokenStore.readAuthentication(accessToken);
			auth.setAuthenticated(true);

			OAuth2AccessToken oauth2Token = tokenStore.readAccessToken(accessToken);
			auth.setDetails(oauth2Token);
			return auth;
		}
		return null;
	}
}
