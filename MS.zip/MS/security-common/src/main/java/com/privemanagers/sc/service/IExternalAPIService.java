package com.privemanagers.sc.service;

import org.springframework.http.ResponseEntity;

/**
 * Service wrapper to get information from prive service
 *
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
public interface IExternalAPIService {

	/**
	 * Get the tenant configuration from prive service
	 *
	 * @param inTenantName
	 * @return
	 */
	public ResponseEntity<String> getTenantConfig(String inTenantName);
}
