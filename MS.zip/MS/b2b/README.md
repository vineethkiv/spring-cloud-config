# B2B microservice

An adapter for busineses to use our microservices.

> _Important_. It is always preferred for businesses to conform to the individual published service API's.
However, some large customers may be constrained on the number and nature of the calls they can make.
>
> In these cases, _and these cases alone_, the b2b service exists to transform customer specific URL's
and actions into one or more of our native API calls.

## Environment variables

The environment variable assignments below are intended for desktop development only.

`PRIVE_ASSETS=http://localhost:8081`

The URI for the assets microservice.

`PRIVE_XASSETS=http://localhost:8089`

The URI for the xassets microservice.

`PRIVE_QUANT=http://localhost:8087`

The URI for the quant microservice.

`PRIVE_PRIVE_URI=http://localhost:8088`

The URI for the prive microservice.

`PRIVE_AUTH=http://localhost:8099`

The URI for the auth microservice. Remove when tenant legacy is removed.

`PRIVE_SKIPTOKENCHECK=chelski_849`

OPTIONAL developer bypass to skip the token check. Remove when tenant legacy is removed.


`PRIVE_OPT=http://localhost:8083`

The URI for the optimisier microservice.
