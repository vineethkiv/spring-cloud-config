package com.privemanagers.b2b.service.maintenance;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;

import org.junit.Test;

import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.maintenance.MaintenanceValidation;

/**
 * @author nteck
 * @date : 17 May, 2017
 * @company Prive Financial
 */
public class TestMaintenanceValidation {

	@Test
	public void testValidateName() {
		final MaintenanceValidation validation = new MaintenanceValidation();

		JsonObject json = Json.createObjectBuilder().build();
		assertFalse(validation.validateName(json));

		json = Json.createObjectBuilder().add(FieldName.NAME, "").build();
		assertFalse(validation.validateName(json));

		json = Json.createObjectBuilder().add(FieldName.NAME, "   ").build();
		assertFalse(validation.validateName(json));

		json = Json.createObjectBuilder().add(FieldName.NAME, "Test").build();
		assertTrue(validation.validateName(json));
	}

	@Test
	public void testValidateCurrency() {
		final MaintenanceValidation validation = new MaintenanceValidation();

		JsonObject json = Json.createObjectBuilder().build();
		assertFalse(validation.validateCurrency(json, FieldName.CURRENCY));

		json = Json.createObjectBuilder().add(FieldName.CURRENCY, "").build();
		assertFalse(validation.validateCurrency(json, FieldName.CURRENCY));

		json = Json.createObjectBuilder().add(FieldName.CURRENCY, "NOT_A_CURRENCY").build();
		assertFalse(validation.validateCurrency(json, FieldName.CURRENCY));

		json = Json.createObjectBuilder().add(FieldName.CURRENCY, "USD").build();
		assertTrue(validation.validateCurrency(json, FieldName.CURRENCY));
	}

	@Test
	public void testValidateWeight() {
		final MaintenanceValidation validation = new MaintenanceValidation();

		JsonObject json = Json.createObjectBuilder().build();
		assertFalse(validation.validateWeight(json));

		json = Json.createObjectBuilder().add(FieldName.WEIGHT, 0).build();
		assertFalse(validation.validateWeight(json));

		json = Json.createObjectBuilder().add(FieldName.WEIGHT, -42).build();
		assertFalse(validation.validateWeight(json));

		json = Json.createObjectBuilder().add(FieldName.WEIGHT, 100.0001).build();
		assertFalse(validation.validateWeight(json));

		json = Json.createObjectBuilder().add(FieldName.WEIGHT, 0.01).build();
		assertTrue(validation.validateWeight(json));

		json = Json.createObjectBuilder().add(FieldName.WEIGHT, 100).build();
		assertTrue(validation.validateWeight(json));
	}

	@Test
	public void testValidateTotalWeight() {
		final MaintenanceValidation validation = new MaintenanceValidation();

		assertFalse(validation.validateTotalWeight(new BigDecimal("-0.01")));
		assertFalse(validation.validateTotalWeight(new BigDecimal("100.000001")));
		assertFalse(validation.validateTotalWeight(new BigDecimal("-42")));
		assertFalse(validation.validateTotalWeight(new BigDecimal("12345")));
		assertTrue(validation.validateTotalWeight(BigDecimal.ZERO));
		assertTrue(validation.validateTotalWeight(BigDecimal.ONE));
		assertTrue(validation.validateTotalWeight(BigDecimal.TEN));
		assertTrue(validation.validateTotalWeight(new BigDecimal("100")));
	}

	@Test
	public void testValidateAllocation() {
		final MaintenanceValidation validation = new MaintenanceValidation();

		JsonArray allocation = Json.createArrayBuilder().build();
		JsonObject json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));

		json = Json.createObjectBuilder().build();
		assertFalse(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertTrue(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "")
						.add(FieldName.WEIGHT, 40).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, -1).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "").add(FieldName.ASSET_CODE_SCHEME, "SCHEME")
						.add(FieldName.ASSET_CURRENCY, "USD").add(FieldName.WEIGHT, 40).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE").add(FieldName.ASSET_CODE_SCHEME, "")
						.add(FieldName.ASSET_CURRENCY, "USD").add(FieldName.WEIGHT, 40).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));

		allocation = Json.createArrayBuilder()
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder().add(FieldName.ASSET_CODE, "CODE")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME").add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 80).build())
				.build();
		json = Json.createObjectBuilder().add(FieldName.ALLOCATION, allocation).build();
		assertFalse(validation.validateAllocation(json, "cash"));
	}

}
