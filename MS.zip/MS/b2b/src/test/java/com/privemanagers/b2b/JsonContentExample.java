package com.privemanagers.b2b;

import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;

import com.privemanagers.api.API;
import com.privemanagers.b2b.transaction.JsonArrayItem;
import com.privemanagers.b2b.transaction.JsonArrayNode;
import com.privemanagers.b2b.transaction.JsonObjectNode;
import com.privemanagers.b2b.transaction.JsonRoot;
import com.privemanagers.b2b.transaction.NamedJsonContent;

public class JsonContentExample {

	public static class Scenario extends NamedJsonContent {

		public Scenario(final String name) {
			super(name);
		}

		@Override
		public void build(JsonObjectBuilder builder, JsonBuilderFactory factory) {
			builder.add(this.name, "???");
		}

		@Override
		public void build(JsonArrayBuilder builder, JsonBuilderFactory factory) {
		}

	}

	public static void main(String[] args) {
		/*
		 * Describe the structure.
		 */
		JsonRoot response = new JsonRoot();

		JsonObjectNode c = new JsonObjectNode("current");
		response.include(c);
		c.include(new Scenario("crisis")).include(new Scenario("recovery"));

		response.include(new JsonObjectNode("proposed").include(
				new Scenario("crisis")).include(new Scenario("recovery")));

		JsonArrayNode b = new JsonArrayNode("benchmarks");
		response.include(b);

		b.include(new JsonArrayItem().include(new Scenario("crisis")).include(
				new Scenario("recovery")));
		b.include(new JsonArrayItem().include(new Scenario("crisis")).include(
				new Scenario("recovery")));

		/*
		 * Compose the JSON
		 */
		JsonBuilderFactory factory = API.makeJsonBuilderFactory();
		JsonObjectBuilder body = factory.createObjectBuilder();
		response.build(body, factory);

		System.out.println(body.build().toString());
	}

}
