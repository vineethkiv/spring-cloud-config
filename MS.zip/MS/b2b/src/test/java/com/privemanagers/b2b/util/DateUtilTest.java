package com.privemanagers.b2b.util;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;

import org.junit.Test;

import com.privemanagers.api.API;

/**
 * @author Kay Ip
 * @date 12 Mar 2018
 * @company Prive Financial
 */
public class DateUtilTest {

	private static final String DEFAULT_REQEUST_DATE = "2007-01-01";

	@Test
	public void testGetCommonEarliestDate() {
		String[] dateArr = new String[] { "20120803", "20110304", "20151102" };
		JsonArray test = createJsonArrayFromList(Arrays.asList(dateArr), "inception-date");

		String result = DateUtil.getCommonEarliestDate(test, DEFAULT_REQEUST_DATE);
		assertEquals("2015-11-02", result);
	}

	@Test
	public void testGetCommonEarliestDateDefaultDate() {
		String[] dateArr = new String[] { "19980101", "19990101", "20010101" };
		JsonArray test = createJsonArrayFromList(Arrays.asList(dateArr), "inception-date");

		String result = DateUtil.getCommonEarliestDate(test, DEFAULT_REQEUST_DATE);
		assertEquals(DEFAULT_REQEUST_DATE, result);
	}

	public JsonArray createJsonArrayFromList(List<String> dateList, String dateName) {
		final JsonBuilderFactory factory = API.makeJsonBuilderFactory();
		final JsonArrayBuilder jab = factory.createArrayBuilder();

		for (String date : dateList) {
			JsonObject jo = Json.createObjectBuilder().add(dateName, date).build();
			jab.add(jo);
		}
		return jab.build();
	}
}
