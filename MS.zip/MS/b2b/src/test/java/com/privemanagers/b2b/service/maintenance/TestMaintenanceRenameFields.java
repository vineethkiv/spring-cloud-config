package com.privemanagers.b2b.service.maintenance;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;

import org.junit.Test;

import com.privemanagers.b2b.field.FieldName;

/**
 * @author nteck
 * @date : 17 May, 2017
 * @company Prive Financial
 */
public class TestMaintenanceRenameFields {

	@Test
	public void testRenameModelPortfolioFields() {
		final MaintenanceRenameFields renameFields = new MaintenanceRenameFields();
		final JsonArray allocation = Json
				.createArrayBuilder()
				.add(Json.createObjectBuilder()
						.add(FieldName.ASSET_CODE, "CODE1")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME1")
						.add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build())
				.add(Json.createObjectBuilder()
						.add(FieldName.ASSET_CODE, "CODE2")
						.add(FieldName.ASSET_CODE_SCHEME, "SCHEME2")
						.add(FieldName.ASSET_CURRENCY, "USD")
						.add(FieldName.WEIGHT, 40).build()).build();
		final JsonObject mp = Json.createObjectBuilder()
				.add(FieldName.NAME, "P1").add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION, allocation).build();
		final String tenantName = "prive";
		final String modelref = "12345";
		final JsonObject mpRename = renameFields.renameModelPortfolioFields(mp,
				tenantName, modelref, FieldName.CFI_CODE_MODEL_PORTFOLIO);

		assertEquals(mp.getString(FieldName.NAME),
				mpRename.getJsonObject(FieldName.NAME).getString("en"));
		assertEquals(mp.getString(FieldName.CURRENCY),
				mpRename.getString(FieldName.CURRENCY));
		assertEquals(FieldName.CFI_CODE_MODEL_PORTFOLIO,
				mpRename.getString(FieldName.CFI_CODE));

		final JsonObject tenant = mpRename.getJsonObject(FieldName.TENANTS);
		assertNotNull(tenant);
		final JsonArray tenantCode = tenant.getJsonArray(tenantName);
		assertNotNull(tenantCode);
		assertTrue(tenantCode.size() == 1);
		final JsonObject code = tenantCode.getJsonObject(0);
		assertNotNull(code);
		assertEquals(tenantName, code.getString(FieldName.SCHEME));
		assertEquals(modelref, code.getString(FieldName.VALUE));

		final JsonArray allocationRename = mpRename
				.getJsonArray(FieldName.ALLOCATION);
		assertNotNull(allocationRename);
		assertEquals(allocation.size(), allocationRename.size());

		for (int i = 0; i < allocation.size(); i++) {
			assertEquals(
					allocation.getJsonObject(i).getString(FieldName.ASSET_CODE),
					allocationRename.getJsonObject(i)
							.getString(FieldName.VALUE));
			assertEquals(
					allocation.getJsonObject(i).getString(
							FieldName.ASSET_CODE_SCHEME), allocationRename
							.getJsonObject(i).getString(FieldName.SCHEME));
			assertEquals(
					allocation.getJsonObject(i).getString(
							FieldName.ASSET_CURRENCY), allocationRename
							.getJsonObject(i).getString(FieldName.CURRENCY));
			assertEquals(
					allocation.getJsonObject(i).getJsonNumber(FieldName.WEIGHT),
					allocationRename.getJsonObject(i).getJsonNumber(
							FieldName.WEIGHT));
		}

	}

}
