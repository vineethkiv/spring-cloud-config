package com.privemanagers.b2b.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;

import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.privemanagers.api.API;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.b2b.exception.AssetsNotFoundException;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.maintenance.MaintenanceRenameFields;
import com.privemanagers.b2b.service.maintenance.MaintenanceValidation;
import com.privemanagers.b2b.util.AlertUtil;

/**
 * @author nteck
 * @date : 23 May, 2017
 * @company Prive Financial
 */
public class TestMaintenanceService {

	@Mock
	private B2BExternalAPIService externalService;

	private final MaintenanceValidation validation = new MaintenanceValidation();

	private final MaintenanceRenameFields renameFields = new MaintenanceRenameFields();

	private MaintenanceService maintService;

	@Mock
	private MixpanelUtil mixpanelUtil;

	@Mock
	private AlertUtil alertUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		maintService = new MaintenanceService(this.externalService, this.validation, this.renameFields, "cash",
				this.mixpanelUtil, this.alertUtil);
	}

	@Test
	public void testCreateModelPortfolio() throws Exception {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100)
										.build())
								.build())
				.build();
		when(this.externalService.queryAssetsCodes(anyString(), any(JsonArray.class)))
				.thenReturn(Json.createArrayBuilder().build());
		when(this.externalService.queryAssetsCreate(anyString(), anyString())).thenReturn(ResponseEntity
				.ok(Json.createObjectBuilder().add(FieldName.ASSET_ID, new ObjectId().toString()).build().toString()));

		final ResponseEntity<String> response = maintService.createModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		final String body = response.getBody();
		final JsonObject json = API.parseObject(body);
		assertTrue(json.containsKey(FieldName.ASSET_ID));
	}

	@Test
	public void testCreateModelPortfolioBadRequest() {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100.0001)
										.build())
								.build())
				.build();

		final ResponseEntity<String> response = maintService.createModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testCreateModelPortfolioInternalServerError() {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100)
										.build())
								.build())
				.build();

		when(this.externalService.queryAssetsCreate(anyString(), anyString()))
				.thenReturn(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(""));

		final ResponseEntity<String> response = maintService.createModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	public void testCreateModelPortfolioNotFound() throws Exception {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100)
										.build())
								.build())
				.build();

		when(this.externalService.queryAssetsCodes(anyString(), any(JsonArray.class)))
				.thenReturn(Json.createArrayBuilder().build());
		when(this.externalService.queryAssetsCreate(anyString(), anyString()))
				.thenReturn(new ResponseEntity<String>("", HttpStatus.NOT_FOUND));

		ResponseEntity<String> response = maintService.createModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

		when(this.externalService.queryAssetsCodes(anyString(), any(JsonArray.class)))
				.thenThrow(new AssetsNotFoundException(Json.createArrayBuilder().build()));

		response = maintService.createModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
	}

	@Test
	public void testUpdateModelPortfolio() throws Exception {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100)
										.build())
								.build())
				.build();
		when(this.externalService.queryAssetCode(anyString(), any(JsonObject.class)))
				.thenReturn(Json.createObjectBuilder()
						.add(FieldName.ASSET_ID, "test")
						.add(FieldName.CFI_CODE, FieldName.CFI_CODE_MODEL_PORTFOLIO)
						.build());

		when(this.externalService.queryAssetsCodes(anyString(), any(JsonArray.class)))
				.thenReturn(Json.createArrayBuilder().build());
		when(this.externalService.queryAssetsUpdate(anyString(), anyString(), anyString()))
				.thenReturn(ResponseEntity.ok(""));

		final ResponseEntity<String> response = maintService.updateModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testUpdateModelPortfolioBadRequest() {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100.0001)
										.build())
								.build())
				.build();

		final ResponseEntity<String> response = maintService.updateModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testUpdateModelPortfolioInternalServerError() throws AssetsNotFoundException {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100)
										.build())
								.build())
				.build();

		when(this.externalService.queryAssetCode(anyString(), any(JsonObject.class)))
				.thenReturn(Json.createObjectBuilder().build());

		when(this.externalService.queryAssetsUpdate(anyString(), anyString(), anyString()))
				.thenReturn(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(""));

		final ResponseEntity<String> response = maintService.updateModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	public void testUpdateModelPortfolioNotFound() throws Exception {
		final String tenant = "prive";
		final String allocScheme = "ISIN";
		final String allocValue = "12345";
		final String allocCurrency = "HKD";
		final JsonObject asset = Json.createObjectBuilder()
				.add(FieldName.NAME, "Model Portfolio Test")
				.add(FieldName.CURRENCY, "USD")
				.add(FieldName.ALLOCATION,
						Json.createArrayBuilder()
								.add(Json.createObjectBuilder()
										.add(FieldName.ASSET_CODE_SCHEME, allocScheme)
										.add(FieldName.ASSET_CODE, allocValue)
										.add(FieldName.ASSET_CURRENCY, allocCurrency)
										.add(FieldName.WEIGHT, 100)
										.build())
								.build())
				.build();
		when(this.externalService.queryAssetCode(anyString(), any(JsonObject.class)))
				.thenReturn(Json.createObjectBuilder()
						.add(FieldName.ASSET_ID, "test")
						.add(FieldName.CFI_CODE, FieldName.CFI_CODE_MODEL_PORTFOLIO)
						.build());

		when(this.externalService.queryAssetsCodes(anyString(), any(JsonArray.class)))
				.thenReturn(Json.createArrayBuilder().build());

		when(this.externalService.queryAssetsUpdate(anyString(), anyString(), anyString()))
				.thenReturn(new ResponseEntity<String>("", HttpStatus.NOT_FOUND));

		ResponseEntity<String> response = maintService.updateModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

		when(this.externalService.queryAssetsCodes(anyString(), any(JsonArray.class)))
				.thenThrow(new AssetsNotFoundException(Json.createArrayBuilder().build()));

		response = maintService.updateModelPortfolio(tenant, "MPTest", asset.toString());

		assertNotNull(response);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
	}

	@Test
	public void testDeleteModelPortfolio() throws AssetsNotFoundException {
		when(this.externalService.queryAssetsDelete(anyString(), anyString())).thenReturn(ResponseEntity.ok(""));
		when(this.externalService.queryAssetCode(anyString(), any(JsonObject.class)))
				.thenReturn(Json.createObjectBuilder().add(FieldName.ASSET_ID, "test").build());

		final ResponseEntity<String> response = maintService.deleteModelPortfolio("prive", "MPTest");

		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testDeleteModelPortfolioNotFound() throws AssetsNotFoundException {
		when(this.externalService.queryAssetsDelete(anyString(), anyString()))
				.thenReturn(new ResponseEntity<String>("", HttpStatus.NOT_FOUND));
		when(this.externalService.queryAssetCode(anyString(), any(JsonObject.class)))
				.thenReturn(Json.createObjectBuilder().add(FieldName.ASSET_ID, "test").build());

		final ResponseEntity<String> response = maintService.deleteModelPortfolio("prive", "MPTest");

		assertNotNull(response);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
	}

	@Test
	public void testDeleteModelPortfolioInternalServerError() throws AssetsNotFoundException {
		when(this.externalService.queryAssetCode(anyString(), any(JsonObject.class)))
				.thenReturn(Json.createObjectBuilder().add(FieldName.ASSET_ID, "test").build());

		when(this.externalService.queryAssetsDelete(anyString(), anyString()))
				.thenReturn(new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR));

		final ResponseEntity<String> response = maintService.deleteModelPortfolio("prive", "MPTest");

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

}
