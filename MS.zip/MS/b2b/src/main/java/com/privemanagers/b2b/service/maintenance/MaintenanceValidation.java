package com.privemanagers.b2b.service.maintenance;

import java.math.BigDecimal;

import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.privemanagers.api.API;
import com.privemanagers.b2b.field.FieldName;

/**
 * @author nteck
 * @date : 17 May, 2017
 * @company Prive Financial
 */
@Component
public class MaintenanceValidation {

	private static final BigDecimal HUNDRED = new BigDecimal("100");

	public boolean validateName(final JsonObject asset) {
		return asset.containsKey(FieldName.NAME) && StringUtils.hasText(asset.getString(FieldName.NAME));
	}

	public boolean validateCurrency(final JsonObject asset, final String fieldName) {
		try {
			return asset.containsKey(fieldName) && API.validateCurrencyCode(asset.getString(fieldName));
		} catch (final IllegalArgumentException e) {
			return false;
		}

	}

	public boolean validateWeight(final JsonObject asset) {
		return asset.containsKey(FieldName.WEIGHT) && asset.getJsonNumber(FieldName.WEIGHT).doubleValue() > 0.0
				&& asset.getJsonNumber(FieldName.WEIGHT).doubleValue() <= 100.0;
	}

	public boolean validateTotalWeight(final BigDecimal totalWeight) {
		return totalWeight.compareTo(BigDecimal.ZERO) >= 0 && totalWeight.compareTo(HUNDRED) <= 0;
	}

	public boolean validateAllocation(final JsonObject asset, final String cashScheme) {
		final JsonArray allocation = asset.getJsonArray(FieldName.ALLOCATION);
		boolean isValid = false;

		if (allocation != null) {
			BigDecimal totalWeight = BigDecimal.ZERO;

			for (final JsonValue json : allocation) {
				final JsonObject holding = (JsonObject) json;
				isValid = holding.containsKey(FieldName.ASSET_CODE)
						&& StringUtils.hasText(holding.getString(FieldName.ASSET_CODE))
						&& holding.containsKey(FieldName.ASSET_CODE_SCHEME)
						&& StringUtils.hasText(holding.getString(FieldName.ASSET_CODE_SCHEME));
				if (!isValid) {
					break;
				}
				if (!cashScheme.equals(holding.getString(FieldName.ASSET_CODE_SCHEME))) {
					isValid &= this.validateCurrency(holding, FieldName.ASSET_CURRENCY);
				}
				isValid &= this.validateWeight(holding);

				if (!isValid) {
					break;
				} else {
					totalWeight = totalWeight.add(holding.getJsonNumber(FieldName.WEIGHT).bigDecimalValue());
				}
			}

			isValid &= this.validateTotalWeight(totalWeight);
		}

		return isValid;
	}

}
