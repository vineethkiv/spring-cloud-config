package com.privemanagers.b2b.transaction;

import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;

/**
 * A JSON array.
 *
 */
public class JsonArrayNode extends NamedJsonNode {

	public JsonArrayNode(final String name) {
		super(name);
	}

	@Override
	public void build(final JsonObjectBuilder builder, final JsonBuilderFactory factory) {
		final JsonArrayBuilder self = factory.createArrayBuilder();
		for (JsonContent content : this.list) {
			content.build(self, factory);
		}
		builder.add(this.name, self);
	}

	@Override
	public void build(final JsonArrayBuilder builder, final JsonBuilderFactory factory) {
		throw new UnsupportedOperationException();
	}

}
