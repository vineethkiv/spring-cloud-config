package com.privemanagers.b2b.service;

import org.springframework.http.ResponseEntity;

/**
 * @author nteck
 * @date : 12 May, 2017
 * @company Prive Financial
 */
public interface IMaintenanceService {

	/**
	 * Create a model portfolio with the given modelref.
	 *
	 * @param tenant
	 * @param modelref
	 * @param body
	 * @return
	 */
	public ResponseEntity<String> createModelPortfolio(final String tenant, final String modelref, final String body);

	/**
	 * Update the specified model porftfolio.
	 *
	 * @param tenant
	 * @param modelref
	 * @param body
	 * @return
	 */
	public ResponseEntity<String> updateModelPortfolio(final String tenant, final String modelref, final String body);

	/**
	 * Delete the specified model portfolio.
	 *
	 * @param tenant
	 * @param modelref
	 * @return
	 */
	public ResponseEntity<String> deleteModelPortfolio(final String tenant, final String modelref);

	/**
	 * Revise the historical allocation for the model portfolio at the given
	 * date.
	 *
	 * @param tenant
	 * @param modelref
	 * @param date
	 * @param body
	 * @return
	 */
	public ResponseEntity<String> reviseModelPortfolio(final String tenant, final String modelref, final String date,
			final String body);

	/**
	 * get the historical allocation for the model portfolio
	 *
	 * @param tenant
	 * @param modelref
	 * @return
	 */
	public ResponseEntity<String> getModelPortfolio(final String tenant, final String modelref, final String cfiCode,
			final boolean shouldIncludeSeries);

	/**
	 * Get exchange rate for the specified FX at the specified date.
	 *
	 * @param tenant
	 * @param date
	 * @param fxs
	 * @return
	 */
	public ResponseEntity<String> getFXs(final String tenant, final String date, final String fxs);

	/**
	 * Evict cache by this service
	 */
	public void evictCache();

}
