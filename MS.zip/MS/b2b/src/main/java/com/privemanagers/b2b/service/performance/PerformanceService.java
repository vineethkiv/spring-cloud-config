package com.privemanagers.b2b.service.performance;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.annotation.PostConstruct;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.api.API;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.ValueCurrencyType;
import com.privemanagers.api.config.tenant.TenantConfigEnum;
import com.privemanagers.api.config.tenant.TenantServiceConfigUtil;
import com.privemanagers.api.config.tenant.TenantServiceEnum;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.b2b.adapter.MdcTaskDecorator;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.controller.performance.model.PerformanceRequestV2;
import com.privemanagers.b2b.exception.AssetsNotFoundV1Exception;
import com.privemanagers.b2b.exception.AssetsNotFoundV2Exception;
import com.privemanagers.b2b.field.CalculationMethod;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.QuantAssetTransaction;
import com.privemanagers.b2b.service.QuantTransaction;
import com.privemanagers.b2b.service.common.QuantPortfolioTransactionV2;
import com.privemanagers.b2b.service.common.model.QuantPortfolioRequest;
import com.privemanagers.b2b.service.common.model.QuantTransactionPortfolio;
import com.privemanagers.b2b.service.external.AssetExternalService;
import com.privemanagers.b2b.service.external.XAssetExternalService;
import com.privemanagers.b2b.service.stress.StressTransformer;
import com.privemanagers.b2b.service.stress.model.Asset;
import com.privemanagers.b2b.service.stress.model.AssetCode;
import com.privemanagers.b2b.transaction.JsonRoot;
import com.privemanagers.b2b.util.PerformanceStressCommonUtil;
import com.privemanagers.b2b.util.PortfolioUtil;

/**
 * Performance service
 *
 * @author Kay Ip
 * @date 8 May 2018
 * @company Prive Financial
 */
@Service
public class PerformanceService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private MixpanelUtil mixpanelUtil;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private PerformanceValidator validator;

	@Autowired
	private PerformanceStressCommonUtil performanceUtil;

	@Autowired
	private PortfolioUtil portfolioUtil;

	@Autowired
	private StressTransformer transformer;

	@Autowired
	private TenantContext tenantContext;

	@Value("${prive.threads}")
	private int threads;

	@Value("${prive.cash-scheme}")
	private String cashScheme;

	@Value("${prive.default-rebalance-every}")
	private int defaultRebalanceEvery;

	@Value("${prive.quant}")
	private String quant;

	@Autowired
	private AssetExternalService assetExternalService;

	@Autowired
	private XAssetExternalService xAssetExternalService;

	private static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	private ThreadPoolTaskExecutor executor;

	@PostConstruct
	public void init() {
		executor = new ThreadPoolTaskExecutor();
		executor.setThreadNamePrefix("prive-");
		executor.setAllowCoreThreadTimeOut(false);
		executor.setCorePoolSize(threads);
		executor.setDaemon(true);
		executor.setTaskDecorator(new MdcTaskDecorator());
		executor.initialize();
	}

	/**
	 * Performance v2 main logic
	 *
	 * Flow:<br>
	 * 1. Validation<br>
	 * 2. Pre process portfolio<br>
	 * 3. Call assets<br>
	 * 4. Pre process before calling quant<br>
	 * 5. Call quant<br>
	 * 6. Build response<br>
	 *
	 * @param tenant
	 * @param request
	 * @return
	 * @throws JsonProcessingException
	 */
	public ResponseEntity<String> performance(final String tenant, PerformanceRequestV2 request, boolean isV1)
			throws JsonProcessingException, AssetsNotFoundV2Exception, AssetsNotFoundV1Exception {

		String requestStr = null;
		try {
			requestStr = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			throw new IllegalArgumentException("invalid request, request cannot be parse to String");
		}
		logger.info("body:\n{}", requestStr);

		mixpanelUtil.trackEvent(tenant, "b2b-performance", requestStr);

		validator.validateRequest(request);

		preProcessPortfolio(tenant, request.getCurrentPortfolio());

		/*
		 * Call assets to compose 2 types of results
		 *
		 * - all missing PortfolioItemV2 list (for create asset, compose
		 * response)
		 *
		 * - valid asset of portfolio, model (for calling quant)
		 *
		 * no common earliest date logic for performance, thus no need all asset
		 * list
		 *
		 */
		List<PortfolioItemV2> missingAssets = new ArrayList<>();

		List<QuantTransactionPortfolio> assetsForCP = new ArrayList<>();
		assetExternalService.queryAssetCodeForPortfolio(tenant, request.getCurrentPortfolio(), null, missingAssets,
				assetsForCP, transformer, CalculationMethod.INSTRUMENT);

		Asset assetForM = null;
		if (StringUtils.isNotBlank(request.getModel())) {
			List<AssetCode> modelAC = transformer.transformModelToList(tenant, request.getModel());
			String modelRequest = objectMapper.writeValueAsString(modelAC);
			List<Asset> modelAsset = assetExternalService.assetsCodesRequestV2(tenant, modelRequest);
			if (CollectionUtils.isEmpty(modelAsset)) {
				PortfolioItemV2 model = transformer.transformModelToPortfolioItem(tenant, request.getModel());
				missingAssets.add(model);
			} else {
				assetForM = modelAsset.get(0);
			}
		}

		// call main app to search and create missing assets if any
		if (!CollectionUtils.isEmpty(missingAssets)) {
			xAssetExternalService.searchAndCreateAssetRequest(missingAssets);
		}

		/**
		 * SLYAWS-12334 - showMissingAssets applied to v2 only
		 *
		 * citi wants v1 behavior to be no change
		 */
		if (isV1 && !CollectionUtils.isEmpty(missingAssets)) {
			throw new AssetsNotFoundV1Exception(transformer.transformToV1(missingAssets));
		}

		// throw exception or continue processing depending on tenant config
		final boolean showMissingAssets = TenantServiceConfigUtil.getConfigBooleanValue(tenantContext,
				TenantServiceEnum.B2B, TenantConfigEnum.SHOW_MISSING_ASSETS_INSTEAD_OF_EXCEPTION, false);
		if (!showMissingAssets && !CollectionUtils.isEmpty(missingAssets)) {
			throw new AssetsNotFoundV2Exception(missingAssets);
		}

		/*
		 * Prepare calling quant
		 */
		final List<QuantTransaction> transactions = new ArrayList<>();
		final JsonRoot root = new JsonRoot();
		final CountDownLatch latch = getCountDownLatch(assetsForCP, assetForM);

		final String currency = request.getReferenceCurrency();
		final ValueCurrencyType valueCurrency = performanceUtil.resolveValueCurrencyType(request.getValueCurrency());
		final List<String> statisticsList = transformer.transformStatistic(request.getStatistics());

		final LocalDate u = LocalDate.now().withDayOfMonth(1).minusMonths(1);
		final String until = u.format(STRING_TO_DATE);
		final String from = (u.minusMonths(request.getMonths())).format(STRING_TO_DATE);

		final int rebalanceEvery = TenantServiceConfigUtil.getConfigIntValue(tenantContext, TenantServiceEnum.B2B,
				TenantConfigEnum.REBALANCE_EVERY, defaultRebalanceEvery);

		/*
		 * call quant: current portfolio
		 */
		fireQuantPortfolioRequest(root, FieldName.CURRENT_PORTFOLIO, tenant, from, until, currency, valueCurrency,
				rebalanceEvery, assetsForCP, statisticsList, transactions, latch);

		/*
		 * call quant: model
		 */
		if (assetForM != null) {
			final String modelAssetID = assetForM.getAssetId();
			QuantAssetTransaction transaction = new QuantAssetTransaction(quant, tenant, modelAssetID, from, until,
					currency, latch, tenantContext, statisticsList);
			root.include(transaction.content(FieldName.MODEL));
			transaction.send(executor);
			transactions.add(transaction);
		}

		final boolean ok = performanceUtil.waitForResponses(latch, transactions);
		if (!ok) {
			return ResponseEntity.badRequest().body("");
		}

		// build response
		final JsonBuilderFactory factory = API.makeJsonBuilderFactory();
		final JsonObjectBuilder json = factory.createObjectBuilder();
		root.build(json, factory);
		JsonObject response = json.build();

		// SLYAWS-11750: append missing assets if there is any and config is
		// enabled
		if (showMissingAssets && !CollectionUtils.isEmpty(missingAssets)) {
			String missingAssetStr = objectMapper.writeValueAsString(missingAssets);
			response = performanceUtil.jsonObjectToBuilder(response)
					.add(FieldName.MISSING_ASSETS, API.parseArray(missingAssetStr))
					.build();
		}

		logger.debug(HttpStatus.OK.getReasonPhrase());
		return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(response.toString());
	}

	/**
	 * Execute Request to quant service
	 *
	 * @param root
	 * @param fieldName
	 * @param tenant
	 * @param from
	 * @param until
	 * @param currency
	 * @param valueCurrency
	 * @param rebalanceEvery
	 * @param assetsForPortfolio
	 * @param statisticsList
	 * @param latch
	 * @throws JsonProcessingException
	 */
	private void fireQuantPortfolioRequest(JsonRoot root, String fieldName, String tenant, String from, String until,
			String currency, ValueCurrencyType valueCurrency, Integer rebalanceEvery,
			List<QuantTransactionPortfolio> assetsForPortfolio, List<String> statisticsList, List<QuantTransaction> transactions, CountDownLatch latch)
			throws JsonProcessingException {

		QuantPortfolioRequest quantPortfolioRequest = new QuantPortfolioRequest(from, until, currency, rebalanceEvery,
				assetsForPortfolio, valueCurrency, statisticsList);
		String requestRecoveryCP = objectMapper.writeValueAsString(quantPortfolioRequest);
		QuantTransaction transaction = new QuantPortfolioTransactionV2(requestRecoveryCP, from, until, quant, latch,
				tenant, tenantContext);
		root.include(transaction.content(fieldName));
		transaction.send(executor);
		transactions.add(transaction);
	}

	/**
	 * Pre processing portfolio items before calling assets
	 *
	 * @param tenant
	 * @param portfolioItems
	 */
	private void preProcessPortfolio(String tenant, List<PortfolioItemV2> portfolioItems) {
		if (CollectionUtils.isEmpty(portfolioItems)) {
			return;
		}

		// map mic code if tenant enabled mapping config
		final boolean mapMicCode = TenantServiceConfigUtil.getConfigBooleanValue(tenantContext, TenantServiceEnum.B2B,
				TenantConfigEnum.MAP_MIC_CODE, false);
		logger.info("tenant:{} mapMicCode config:{}", tenant, mapMicCode);
		if (mapMicCode) {
			portfolioUtil.preProcessPortfolioMicCode(tenant, portfolioItems);
		}
	}

	/**
	 * Get count down latch according to number of quant transaction to be call
	 *
	 * @return
	 */
	private CountDownLatch getCountDownLatch(List<QuantTransactionPortfolio> assetsForCP, Asset assetForM) {
		int numberOfRequests = 0;
		if (!CollectionUtils.isEmpty(assetsForCP)) {
			numberOfRequests = numberOfRequests + 1;
		}
		if (assetForM != null) {
			numberOfRequests = numberOfRequests + 1;
		}
		return new CountDownLatch(numberOfRequests);
	}

}
