package com.privemanagers.b2b.controller.dual.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * quant dual series request object produced and sent by b2b
 *
 * @author wzhang
 * @date 30 Oct 2018
 * @company Prive Financial
 */
public class QuantDualSeriesRequest {
	private List<String> assets;

	@JsonProperty("benchmark-id")
	private String benchmarkID;

	@JsonProperty("ref-asset-id")
	private String refAssetID;

	@JsonProperty("price-frequency")
	private String priceFrequency;

	private String from;

	private String until;

	private Shift shift;

	public List<String> getAssets() {
		return assets;
	}

	public void setAssets(List<String> assets) {
		this.assets = assets;
	}

	public String getBenchmarkID() {
		return benchmarkID;
	}

	public void setBenchmarkID(String benchmarkID) {
		this.benchmarkID = benchmarkID;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getUntil() {
		return until;
	}

	public void setUntil(String until) {
		this.until = until;
	}

	public Shift getShift() {
		return shift;
	}

	public void setShift(Shift shift) {
		this.shift = shift;
	}

	public String getPriceFrequency() {
		return priceFrequency;
	}

	public void setPriceFrequency(String priceFrequency) {
		this.priceFrequency = priceFrequency;
	}

	public String getRefAssetID() {
		return refAssetID;
	}

	public void setRefAssetID(String refAssetID) {
		this.refAssetID = refAssetID;
	}
}
