package com.privemanagers.b2b.exception;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

/**
 * @author nteck
 * @date : 8 May, 2017
 * @company Prive Financial
 */
public class AssetsNotFoundException extends Exception {

	private static final String SCHEME = "scheme";
	private static final String VALUE = "value";
	private static final String CURRENCY = "currency";

	private static final String ASSET_CODE = "asset-code";
	private static final String ASSET_CODE_SCHEME = "asset-code-scheme";
	private static final String ASSET_CURRENCY = "asset-currency";

	private static final long serialVersionUID = 7572426060902389886L;

	private final JsonArray codesMissingAssets;

	public AssetsNotFoundException(final JsonArray codesMissingAssets) {
		super("Missing assets for the following codes:\n" + codesMissingAssets.toString());

		this.codesMissingAssets = codesMissingAssets;
	}

	public JsonArray getCodesMissingAssets() {
		return this.codesMissingAssets;
	}

	public static JsonArray renameFields(final JsonArray codes) {
		final JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

		for (final JsonValue jsonValue : codes) {
			final JsonObject code = (JsonObject) jsonValue;
			final String scheme = code.getString(SCHEME);
			final String value = code.getString(VALUE);
			final String currency = code.getString(CURRENCY, null);

			arrayBuilder.add(renameFields(scheme, value, currency));
		}

		return arrayBuilder.build();
	}

	public static JsonArray findMissingCodes(final JsonArray codes, final JsonArray assets) {
		final JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

		for (final JsonValue jsonCode : codes) {
			final JsonObject code = (JsonObject) jsonCode;
			final String scheme = code.getString(SCHEME);
			final String value = code.getString(VALUE);
			final String currency = code.getString(CURRENCY, null);

			boolean isFound = false;
			for (final JsonValue jsonAssets : assets) {
				final JsonObject asset = (JsonObject) jsonAssets;

				if (scheme.equals(asset.getString(SCHEME)) && value.equals(asset.getString(VALUE))
						&& (currency == null || currency.equals(asset.getString(CURRENCY)))) {
					isFound = true;
					break;
				}
			}

			if (!isFound) {
				final JsonObject missingAsset = renameFields(scheme, value, currency);

				arrayBuilder.add(missingAsset);
			}
		}

		return arrayBuilder.build();
	}

	private static JsonObject renameFields(final String scheme, final String value, final String currency) {
		final JsonObjectBuilder builder = Json.createObjectBuilder().add(ASSET_CODE_SCHEME, scheme).add(ASSET_CODE,
				value);

		if (currency != null) {
			builder.add(ASSET_CURRENCY, currency);
		}

		return builder.build();
	}
}
