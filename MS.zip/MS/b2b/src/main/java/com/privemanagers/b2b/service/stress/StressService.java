package com.privemanagers.b2b.service.stress;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.annotation.PostConstruct;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.api.API;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.ValueCurrencyType;
import com.privemanagers.api.config.tenant.TenantConfigEnum;
import com.privemanagers.api.config.tenant.TenantServiceConfigUtil;
import com.privemanagers.api.config.tenant.TenantServiceEnum;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.b2b.adapter.MdcTaskDecorator;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.controller.stress.model.StressRequestV2;
import com.privemanagers.b2b.exception.AssetsNotFoundV1Exception;
import com.privemanagers.b2b.exception.AssetsNotFoundV2Exception;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.B2BService;
import com.privemanagers.b2b.service.QuantAssetTransaction;
import com.privemanagers.b2b.service.QuantTransaction;
import com.privemanagers.b2b.service.common.CommonService;
import com.privemanagers.b2b.service.common.QuantPortfolioTransactionV2;
import com.privemanagers.b2b.service.common.model.QuantPortfolioRequest;
import com.privemanagers.b2b.service.common.model.QuantTransactionPortfolio;
import com.privemanagers.b2b.service.external.AssetExternalService;
import com.privemanagers.b2b.service.external.XAssetExternalService;
import com.privemanagers.b2b.service.stress.model.Asset;
import com.privemanagers.b2b.service.stress.model.AssetCode;
import com.privemanagers.b2b.transaction.JsonArrayNode;
import com.privemanagers.b2b.transaction.JsonObjectNode;
import com.privemanagers.b2b.transaction.JsonRoot;
import com.privemanagers.b2b.util.PerformanceStressCommonUtil;
import com.privemanagers.b2b.util.PortfolioUtil;

/**
 * Stress service
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@Service
public class StressService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private MixpanelUtil mixpanelUtil;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private StressValidator validator;

	@Autowired
	private PerformanceStressCommonUtil stressUtil;

	@Autowired
	private PortfolioUtil portfolioUtil;

	@Autowired
	private StressTransformer transformer;

	@Autowired
	private CommonService commonService;

	@Value("${prive.threads}")
	private int threads;

	@Value("${prive.cash-scheme}")
	private String cashScheme;

	@Value("${prive.default-rebalance-every}")
	private int defaultRebalanceEvery;

	@Value("${prive.quant}")
	private String quant;

	@Autowired
	private TenantContext tenantContext;

	@Autowired
	private AssetExternalService assetExternalService;

	@Autowired
	private XAssetExternalService xAssetExternalService;

	/**
	 * A specific thread pool for handling callbacks for the AsyncRestTemplate
	 * requests. Without this a new thread is created, then destroyed, for each
	 * async request.
	 */
	private ThreadPoolTaskExecutor executor;

	@PostConstruct
	public void init() {
		executor = new ThreadPoolTaskExecutor();
		executor.setThreadNamePrefix("prive-");
		executor.setAllowCoreThreadTimeOut(false);
		executor.setCorePoolSize(threads);
		executor.setDaemon(true);
		executor.setTaskDecorator(new MdcTaskDecorator());
		executor.initialize();
	}

	/**
	 * Stress v2 main logic
	 *
	 * Flow:<br>
	 * 1. Validation<br>
	 * 2. Pre process portfolio<br>
	 * 3. Call assets<br>
	 * 4. Pre process before calling quant<br>
	 * 5. Call quant<br>
	 * 6. Build response<br>
	 *
	 * @param tenant
	 * @param request
	 * @return
	 * @throws AssetsNotFoundV2Exception
	 * @throws JsonProcessingException
	 */
	public ResponseEntity<String> stress(final String tenant, StressRequestV2 request, boolean isV1)
			throws AssetsNotFoundV2Exception, JsonProcessingException, AssetsNotFoundV1Exception {

		String requestStr = null;
		try {
			requestStr = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			throw new IllegalArgumentException("invalid request, request cannot be parse to String");
		}
		logger.info("body:\n{}", requestStr);

		mixpanelUtil.trackEvent(tenant, "b2b-stress", requestStr);

		validator.validateRequest(request);

		if (request.getRorMethod() != request.getVolatilityMethod()) {
			logger.error("mismatch in calculation methods");
			throw new IllegalArgumentException();
		}

		// pre processing on portfolios
		preProcessPortfolio(tenant, request.getCurrentPortfolio());
		preProcessPortfolio(tenant, request.getProposedPortfolio());

		/*
		 * Call assets to compose 3 types of results
		 *
		 * - all valid Asset list (for getting common earliest date)
		 *
		 * - all missing PortfolioItemV2 list (for create asset, compose
		 * response)
		 *
		 * - valid asset per portfolio, benchmark, model (for calling quant)
		 *
		 */
		List<Asset> assets = new ArrayList<>();
		List<PortfolioItemV2> missingAssets = new ArrayList<>();

		List<QuantTransactionPortfolio> assetsForCP = new ArrayList<>();
		assetExternalService.queryAssetCodeForPortfolio(tenant, request.getCurrentPortfolio(), assets, missingAssets,
				assetsForCP, transformer, request.getRorMethod());

		List<QuantTransactionPortfolio> assetsForPP = new ArrayList<>();
		assetExternalService.queryAssetCodeForPortfolio(tenant, request.getProposedPortfolio(), assets, missingAssets,
				assetsForPP, transformer, request.getRorMethod());

		List<Asset> assetsForBM = new ArrayList<>();
		if (!CollectionUtils.isEmpty(request.getBenchmarks())) {
			for (String benchmark : request.getBenchmarks()) {
				List<AssetCode> benckmarkAC = transformer.transformBenchmarkToList(benchmark);
				String benckmarkRequest = objectMapper.writeValueAsString(benckmarkAC);
				List<Asset> benchmarkAsset = assetExternalService.assetsCodesRequestV2(tenant, benckmarkRequest);
				if (CollectionUtils.isEmpty(benchmarkAsset)) {
					missingAssets.add(transformer.transformBenchmarkToPortfolioItem(benchmark));
				} else {
					assets.add(benchmarkAsset.get(0));
					assetsForBM.add(benchmarkAsset.get(0));
				}
			}
		}

		Asset assetForM = null;
		if (StringUtils.isNotBlank(request.getModel())) {
			List<AssetCode> modelAC = transformer.transformModelToList(tenant, request.getModel());
			String modelRequest = objectMapper.writeValueAsString(modelAC);
			List<Asset> modelAsset = assetExternalService.assetsCodesRequestV2(tenant, modelRequest);
			if (CollectionUtils.isEmpty(modelAsset)) {
				PortfolioItemV2 model = transformer.transformModelToPortfolioItem(tenant, request.getModel());
				missingAssets.add(model);
			} else {
				assets.add(modelAsset.get(0));
				assetForM = modelAsset.get(0);
			}
		}

		// call main app to search and create missing assets if any
		if (!CollectionUtils.isEmpty(missingAssets)) {
			xAssetExternalService.searchAndCreateAssetRequest(missingAssets);
		}

		/**
		 * SLYAWS-12334 - showMissingAssets applied to v2 only
		 *
		 * citi wants v1 behavior to be no change
		 */
		if (isV1 && !CollectionUtils.isEmpty(missingAssets)) {
			throw new AssetsNotFoundV1Exception(transformer.transformToV1(missingAssets));
		}

		// throw exception or continue processing depending on tenant config
		final boolean showMissingAssets = TenantServiceConfigUtil.getConfigBooleanValue(tenantContext,
				TenantServiceEnum.B2B, TenantConfigEnum.SHOW_MISSING_ASSETS_INSTEAD_OF_EXCEPTION, false);
		if (!showMissingAssets && !CollectionUtils.isEmpty(missingAssets)) {
			throw new AssetsNotFoundV2Exception(missingAssets);
		}

		/*
		 * Prepare calling quant
		 */
		final List<QuantTransaction> transactions = new ArrayList<>();
		final JsonRoot root = new JsonRoot();
		QuantTransaction transaction = null;

		// check is use-earliest-common-date, if true, not backfill
		final boolean useEarliestCommonDate = request.getUseEarliestCommonDate() == null ? false
				: request.getUseEarliestCommonDate();
		logger.info("tenant:{} useEarliestCommonDate config:{}", tenant, useEarliestCommonDate);
		final boolean useLatestCommonDate = request.getUseLatestCommonDate() == null ? false
				: request.getUseLatestCommonDate();
		logger.info("tenant:{} useLatestCommonDate config:{}", tenant, useLatestCommonDate);

		final String[] crisis = commonService.preProcessDate(tenant, request.getCrisis(), assets, useEarliestCommonDate,
				useLatestCommonDate);
		final String[] recovery = commonService.preProcessDate(tenant, request.getRecovery(), assets,
				useEarliestCommonDate, useLatestCommonDate);

		final List<String> statisticsList = transformer.transformStatistic(request.getStatistics());
		final String currency = request.getReferenceCurrency();
		final ValueCurrencyType valueCurrency = stressUtil.resolveValueCurrencyType(request.getValueCurrency());
		final int rebalanceEvery = TenantServiceConfigUtil.getConfigIntValue(tenantContext, TenantServiceEnum.B2B,
				TenantConfigEnum.REBALANCE_EVERY, defaultRebalanceEvery);
		final CountDownLatch latch = getCountDownLatch(request, assetsForCP, assetsForPP, assetsForBM, assetForM);

		/*
		 * call quant: Current portfolio
		 */
		callQuantPortfolio(FieldName.CURRENT_PORTFOLIO, transactions, transaction, root, tenant, crisis, recovery,
				currency, valueCurrency, rebalanceEvery, assetsForCP, statisticsList, latch);

		/*
		 * call quant: Proposed portfolio
		 */
		callQuantPortfolio(FieldName.PROPOSED_PORTFOLIO, transactions, transaction, root, tenant, crisis, recovery,
				currency, valueCurrency, rebalanceEvery, assetsForPP, statisticsList, latch);

		/*
		 * call quant: Benchmarks
		 */
		if (!CollectionUtils.isEmpty(assetsForBM)) {
			final JsonArrayNode array = new JsonArrayNode(FieldName.BENCHMARKS);
			root.include(array);

			assetsForBM.forEach(assetBm -> {

				B2BService.JsonBenchmark bm = new B2BService.JsonBenchmark(assetBm.getValue());
				array.include(bm);

				callQuantAsset(bm, null, transactions, transaction, tenant, crisis, recovery, currency,
						assetBm.getAssetId(), statisticsList, latch);

			});

		}

		/*
		 * call quant: Model portfolio
		 */
		if (assetForM != null) {
			JsonObjectNode node = new JsonObjectNode(FieldName.MODEL);
			root.include(node);

			final String modelAssetID = assetForM.getAssetId();
			callQuantAsset(null, node, transactions, transaction, tenant, crisis, recovery, currency, modelAssetID,
					statisticsList, latch);
		}

		final boolean ok = stressUtil.waitForResponses(latch, transactions);
		if (!ok) {
			logger.warn("wait for async response is not ok");
			return ResponseEntity.badRequest().body("");
		}

		/*
		 * building response
		 */
		final JsonBuilderFactory factory = API.makeJsonBuilderFactory();
		final JsonObjectBuilder json = factory.createObjectBuilder();
		root.build(json, factory);
		JsonObject response = json.build();

		// SLYAWS-11750: append missing assets if there is any and config is
		// enabled
		if (showMissingAssets && !CollectionUtils.isEmpty(missingAssets)) {
			String missingAssetStr = objectMapper.writeValueAsString(missingAssets);
			response = stressUtil.jsonObjectToBuilder(response)
					.add(FieldName.MISSING_ASSETS, API.parseArray(missingAssetStr))
					.build();
		}

		logger.debug(HttpStatus.OK.getReasonPhrase());
		return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(response.toString());
	}

	/**
	 * Pre processing portfolio items before calling assets
	 *
	 * @param tenant
	 * @param portfolioItems
	 */
	private void preProcessPortfolio(String tenant, List<PortfolioItemV2> portfolioItems) {
		if (CollectionUtils.isEmpty(portfolioItems)) {
			return;
		}

		// map mic code if tenant enabled mapping config
		final boolean mapMicCode = TenantServiceConfigUtil.getConfigBooleanValue(tenantContext, TenantServiceEnum.B2B,
				TenantConfigEnum.MAP_MIC_CODE, false);
		logger.info("tenant:{} mapMicCode config:{}", tenant, mapMicCode);
		if (mapMicCode) {
			portfolioUtil.preProcessPortfolioMicCode(tenant, portfolioItems);
		}
	}

	/**
	 * For calling quant asset, in stress api, use by benchmark and model
	 *
	 * JsonBenchmark or JsonObjectNode to build the json.. legacy code
	 *
	 * @param bm
	 * @param node
	 * @param transaction
	 * @param tenant
	 * @param crisis
	 * @param recovery
	 * @param currency
	 * @param assetID
	 * @param statisticsList
	 * @param latch
	 * @throws JsonProcessingException
	 */
	private void callQuantAsset(B2BService.JsonBenchmark bm, JsonObjectNode node, List<QuantTransaction> transactions,
			QuantTransaction transaction, String tenant, String[] crisis, String[] recovery, String currency,
			String assetID, List<String> statisticsList, CountDownLatch latch) {

		callQuantAsset(bm, node, FieldName.CRISIS, transactions, transaction, tenant, crisis, currency, assetID,
				statisticsList, latch);
		callQuantAsset(bm, node, FieldName.RECOVERY, transactions, transaction, tenant, recovery, currency, assetID,
				statisticsList, latch);
	}

	private void callQuantAsset(B2BService.JsonBenchmark bm, JsonObjectNode node, String fieldname,
			List<QuantTransaction> transactions, QuantTransaction transaction, String tenant, String[] dateRange,
			String currency, String assetID, List<String> statisticsList, CountDownLatch latch) {

		if (dateRange == null) {
			return;
		}

		transaction = new QuantAssetTransaction(quant, tenant, assetID, dateRange[0], dateRange[1], currency, latch,
				tenantContext, statisticsList);
		if (bm != null) {
			bm.include(transaction.content(fieldname));
		} else {
			node.include(transaction.content(fieldname));
		}
		transaction.send(executor);
		transactions.add(transaction);
	}

	/**
	 * For calling quant portfolio, in stress api, use by benchmark and model
	 *
	 * @param nodeName
	 * @param transaction
	 * @param root
	 * @param tenant
	 * @param crisis
	 * @param recovery
	 * @param currency
	 * @param valueCurrency
	 * @param rebalanceEvery
	 * @param assetsForPortfolio
	 * @param statisticsList
	 * @param latch
	 * @throws JsonProcessingException
	 */
	private void callQuantPortfolio(String nodeName, List<QuantTransaction> transactions, QuantTransaction transaction,
			JsonRoot root, String tenant, String[] crisis, String[] recovery, String currency,
			ValueCurrencyType valueCurrency, Integer rebalanceEvery, List<QuantTransactionPortfolio> assetsForPortfolio,
			List<String> statisticsList, CountDownLatch latch) throws JsonProcessingException {

		if (CollectionUtils.isEmpty(assetsForPortfolio)) {
			logger.info("no code to call quant, return");
			return;
		}

		JsonObjectNode node = new JsonObjectNode(nodeName);
		root.include(node);

		fireQuantPortfolioRequest(transactions, transaction, node, FieldName.CRISIS, tenant, crisis, currency,
				valueCurrency, rebalanceEvery, assetsForPortfolio, statisticsList, latch);
		fireQuantPortfolioRequest(transactions, transaction, node, FieldName.RECOVERY, tenant, recovery, currency,
				valueCurrency, rebalanceEvery, assetsForPortfolio, statisticsList, latch);
	}

	/**
	 * Execute Request to quant service
	 *
	 * @param transaction
	 * @param node
	 * @param fieldName
	 * @param tenant
	 * @param dateRange
	 * @param currency
	 * @param valueCurrency
	 * @param rebalanceEvery
	 * @param assetsForPortfolio
	 * @param statisticsList
	 * @param latch
	 * @throws JsonProcessingException
	 */
	private void fireQuantPortfolioRequest(List<QuantTransaction> transactions, QuantTransaction transaction,
			JsonObjectNode node, String fieldName, String tenant, String[] dateRange, String currency,
			ValueCurrencyType valueCurrency, Integer rebalanceEvery, List<QuantTransactionPortfolio> assetsForPortfolio,
			List<String> statisticsList, CountDownLatch latch) throws JsonProcessingException {

		if (dateRange == null) {
			return;
		}

		QuantPortfolioRequest quantPortfolioRequest = new QuantPortfolioRequest(dateRange[0], dateRange[1], currency,
				rebalanceEvery, assetsForPortfolio, valueCurrency, statisticsList);
		String requestRecoveryCP = objectMapper.writeValueAsString(quantPortfolioRequest);
		transaction = new QuantPortfolioTransactionV2(requestRecoveryCP, dateRange[0], dateRange[1], quant, latch,
				tenant, tenantContext);

		node.include(transaction.content(fieldName));
		transaction.send(executor);
		transactions.add(transaction);
	}

	/**
	 * Get count down latch according to number of quant transaction to be call
	 *
	 * @param request
	 * @return
	 */
	private CountDownLatch getCountDownLatch(StressRequestV2 request, List<QuantTransactionPortfolio> assetsForCP,
			List<QuantTransactionPortfolio> assetsForPP, List<Asset> assetsForBM, Asset assetForM) {
		boolean emptyCurrentPortfolio = CollectionUtils.isEmpty(assetsForCP);
		boolean emptyRecovery = request.getRecovery() == null;
		boolean emptyProposedPortfolio = CollectionUtils.isEmpty(assetsForPP);
		boolean emptyModel = assetForM == null;
		boolean emptyBenchmarks = CollectionUtils.isEmpty(assetsForBM);

		int numberOfRequests = 0;
		int recoveryRequest = emptyRecovery ? 0 : 1;

		// current portfolio
		int currencyPortfolioRequest = emptyCurrentPortfolio ? 0 : 1;
		numberOfRequests += currencyPortfolioRequest;
		if (!emptyCurrentPortfolio) {
			numberOfRequests += recoveryRequest;
		}

		// proposed portfolio
		int proposedPortfolioRequest = emptyProposedPortfolio ? 0 : 1;
		numberOfRequests += proposedPortfolioRequest;
		if (!emptyProposedPortfolio) {
			numberOfRequests += recoveryRequest;
		}

		// benchmarks
		if (!emptyBenchmarks) {
			numberOfRequests += emptyRecovery ? assetsForBM.size() : assetsForBM.size() * 2;
		}

		// model
		numberOfRequests += emptyModel ? 0 : (emptyRecovery ? 1 : 2);
		return new CountDownLatch(numberOfRequests);
	}

}
