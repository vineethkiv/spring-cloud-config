package com.privemanagers.b2b.service.maintenance;

import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import org.springframework.stereotype.Component;

import com.privemanagers.api.API;
import com.privemanagers.b2b.field.FieldName;

/**
 * @author nteck
 * @date : 17 May, 2017
 * @company Prive Financial
 */
@Component
public class MaintenanceRenameFields {

	public final JsonObject renameModelPortfolioFields(final JsonObject model, final String tenant,
			final String modelref, final String cfiCode) {
		final JsonBuilderFactory factory = API.makeJsonBuilderFactory();
		final JsonObjectBuilder builder = factory.createObjectBuilder();

		this.createName(model.getString(FieldName.NAME), builder, factory);
		this.createCurrency(model.getString(FieldName.CURRENCY), builder);
		this.createCFICode(cfiCode, builder);
		this.createTenantCode(modelref, tenant, builder, factory);
		this.createAllocation(model.getJsonArray(FieldName.ALLOCATION), builder, factory);

		return builder.build();
	}

	protected void createName(final String name, final JsonObjectBuilder builder, final JsonBuilderFactory factory) {
		final JsonObject names = factory.createObjectBuilder().add("en", name).build();

		builder.add(FieldName.NAME, names);
	}

	protected void createCurrency(final String currency, final JsonObjectBuilder builder) {
		builder.add(FieldName.CURRENCY, currency);
	}

	protected void createCFICode(final String cfiCode, final JsonObjectBuilder builder) {
		builder.add(FieldName.CFI_CODE, cfiCode);
	}

	protected void createTenantCode(final String modelref, final String tenant, final JsonObjectBuilder builder,
			final JsonBuilderFactory factory) {
		final String scheme = API.getTenantCodeScheme(tenant);
		final JsonObject code = factory.createObjectBuilder()
				.add(FieldName.SCHEME, scheme)
				.add(FieldName.VALUE, modelref)
				.build();
		final JsonArray codes = factory.createArrayBuilder().add(code).build();
		final JsonObject tenantCode = factory.createObjectBuilder().add(tenant, codes).build();

		builder.add(FieldName.TENANTS, tenantCode);
	}

	protected void createAllocation(final JsonArray holdings, final JsonObjectBuilder builder,
			final JsonBuilderFactory factory) {
		final JsonArrayBuilder newHoldings = factory.createArrayBuilder();

		for (final JsonValue json : holdings) {
			final JsonObject holding = (JsonObject) json;

			final JsonObjectBuilder newHolding = factory.createObjectBuilder()
					.add(FieldName.VALUE, holding.getString(FieldName.ASSET_CODE))
					.add(FieldName.SCHEME, holding.getString(FieldName.ASSET_CODE_SCHEME));
			if (holding.containsKey(FieldName.ASSET_CURRENCY)) {
				newHolding.add(FieldName.CURRENCY, holding.getString(FieldName.ASSET_CURRENCY));
			}
			newHolding.add(FieldName.WEIGHT, holding.getJsonNumber(FieldName.WEIGHT));

			newHoldings.add(newHolding);
		}

		builder.add(FieldName.ALLOCATION, newHoldings);
	}

}
