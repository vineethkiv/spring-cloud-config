package com.privemanagers.b2b.controller.exception;

/**
 * enum to map error keys to messages in api-error.properties using
 * MessageSource
 *
 * @author wzhang
 * @date 1 Nov 2018
 * @company Prive Financial
 */
public enum ErrorCode {

	// generic error
	INVALID_REQUEST("invalidRequest"),

	// field validation errors
	FROM_DATE_NULL_EMPTY("fromDateMsg"),
	UNTIL_DATE_NULL_EMPTY("untilDateMsg"),
	ASSETS_ARRAY_NULL_EMPTY("assetsArrayMsg"),
	INVALID_ASSET_SCHEMA("invalidAssetSchema"),
	SHIFT_VALUES_NOT_NULL("nullShiftValues"),

	// request validation errors
	MISSING_BENCHMARK_AND_OR_SHIFT("missingBenchmarkShift"),
	MISSING_BENCHMARK_IN_SHIFT("missingBenchmarkInBenchmarkShift"),
	INVALID_DATE_RANGE("invalidDateRange");

	String code;

	ErrorCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	protected void setCode(String code) {
		this.code = code;
	}
}
