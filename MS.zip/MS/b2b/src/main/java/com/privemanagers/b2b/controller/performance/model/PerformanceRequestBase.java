package com.privemanagers.b2b.controller.performance.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Base request fields for performance api
 *
 * @author Kay Ip
 * @date 7 May 2018
 * @company Prive Financial
 */
public abstract class PerformanceRequestBase {

	@JsonProperty("reference-currency")
	private String referenceCurrency;

	@JsonProperty("value-currency")
	private String valueCurrency;

	private Integer months;

	private String model;

	private List<String> statistics;

	public String getReferenceCurrency() {
		return referenceCurrency;
	}

	public void setReferenceCurrency(String referenceCurrency) {
		this.referenceCurrency = referenceCurrency;
	}

	public String getValueCurrency() {
		return valueCurrency;
	}

	public void setValueCurrency(String valueCurrency) {
		this.valueCurrency = valueCurrency;
	}

	public Integer getMonths() {
		return months;
	}

	public void setMonths(Integer months) {
		this.months = months;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public List<String> getStatistics() {
		return statistics;
	}

	public void setStatistics(List<String> statistics) {
		this.statistics = statistics;
	}
}
