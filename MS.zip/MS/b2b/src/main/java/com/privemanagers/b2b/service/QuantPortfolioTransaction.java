package com.privemanagers.b2b.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;

import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.DataConstants;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.ValueCurrencyType;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.model.mds.AssetScheme;
import com.privemanagers.sc.util.SecuredRestHelper;

public class QuantPortfolioTransaction extends QuantTransaction {

	private final String currency;
	private final String from;
	private final String until;
	private final int rebalanceEvery;
	private final JsonBuilderFactory factory;
	private final List<JsonValue> assets;
	private final JsonArray portfolio;
	private final String cashScheme;
	private final ValueCurrencyType valueCurrency;
	private List<String> statisticsList;

	/** Month between from and until date */
	private final long monthBetween;

	public QuantPortfolioTransaction(final String baseURL, final String tenant, final String from, final String until,
			final String currency, final int rebalanceEvery, final JsonBuilderFactory factory,
			final List<JsonValue> assets, final JsonArray portfolio, final CountDownLatch latch,
			final String cashScheme, final ValueCurrencyType valueCurrency, final TenantContext tenantContext,
			final List<String> statisticsList) {
		super(latch, tenantContext);
		this.statisticsList = statisticsList;
		this.currency = currency;
		this.from = from;
		this.until = until;
		this.rebalanceEvery = rebalanceEvery;
		this.factory = factory;
		this.assets = assets;
		this.portfolio = portfolio;
		this.cashScheme = cashScheme;
		this.valueCurrency = valueCurrency;
		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseURL);
		builder.path(EndPoints.QUANT_1_SERIES);
		this.uri(builder.buildAndExpand(tenant).toUri());

		final LocalDate fromDate = LocalDate.parse(from);
		final LocalDate untilDate = LocalDate.parse(until);
		this.monthBetween = ChronoUnit.MONTHS.between(fromDate, untilDate);
	}

	@Override
	public void send(final ThreadPoolTaskExecutor executor) {
		final ListenableFuture<ResponseEntity<String>> future = SecuredRestHelper.sendRequest(executor, this.uri(),
				null, this.requestBody(), HttpMethod.POST, this.tenantContext(), true);

		future.addCallback(this);
	}

	/**
	 * Make the request body for the quant service.
	 *
	 * @return String
	 */
	private String requestBody() {

		final JsonObjectBuilder body = this.factory.createObjectBuilder();

		body.add(FieldName.CURRENCY, this.currency);

		if (this.valueCurrency != null) {
			body.add(ValueCurrencyType.FIELD, this.valueCurrency.name());
		}

		final JsonArrayBuilder portfolioToSend = this.factory.createArrayBuilder();

		// match assets and holdings in the portfolio to link the asset id and
		// its value.
		for (final JsonValue holdingJV : this.portfolio) {
			final JsonObject holding = (JsonObject) holdingJV;
			final String holdingScheme = holding.getString(FieldName.ASSET_CODE_SCHEME);
			final String holdingCurrency = holding.getString(FieldName.ASSET_CURRENCY, null);

			String holdingCode = holding.getString(FieldName.ASSET_CODE);
			if (AssetScheme.SYMBOL.toString().equals(holdingScheme)) {
				holdingCode = StringUtils.stripStart(holdingCode, "0");
			}

			for (final JsonValue assetJV : this.assets) {
				final JsonObject asset = (JsonObject) assetJV;

				if (Objects.equals(holdingScheme, asset.getString(FieldName.SCHEME))
						&& Objects.equals(holdingCode, asset.getString(FieldName.VALUE))) {
					boolean match = true;
					if (!this.cashScheme.equals(holdingScheme)) {
						match &= Objects.equals(holdingCurrency, asset.getString(FieldName.CURRENCY));
					}
					if (match) {
						final JsonObjectBuilder job = this.factory.createObjectBuilder();

						job.add(FieldName.ASSET_ID, asset.getString(FieldName.ASSET_ID));
						job.add(FieldName.VALUE, holding.get(FieldName.VALUE));

						portfolioToSend.add(job);
						break;
					}
				}
			}
		}

		body.add(FieldName.PORTFOLIO, portfolioToSend);

		body.add(FieldName.FROM, this.from);
		body.add(FieldName.UNTIL, this.until);

		body.add(FieldName.REBALANCE_EVERY, this.rebalanceEvery);

		body.add(FieldName.RELATIVE, 100);
		final JsonArrayBuilder stats = this.factory.createArrayBuilder();
		String[] statisticsArray = null;
		if (this.statisticsList != null) {
			statisticsArray = this.statisticsList.toArray(new String[this.statisticsList.size()]);
		}
		if (statisticsArray == null || statisticsArray.length == 0) {
			statisticsArray = QUANT_STATISTICS;
		}
		for (final String s : statisticsArray) {
			stats.add(s);
		}
		body.add(FieldName.STATISTICS, stats);

		return body.build().toString();
	}

	/**
	 * Dirty fix for SLYAWS-10934 to replace the return value by the
	 * annualized-return value. It should be a temporary fix as we planned to
	 * have a v2 of our APIs to retire the return field and include explicitly
	 * the annualized-return and cumulative-return fields.
	 *
	 * Hack again for SLYAWS-10948. We will need to display cum-return when the
	 * range is less than 1 year and ann-return when it's greater than 1 year
	 */
	@Override
	protected void constructStats(final String field, final JsonObjectBuilder stats, final JsonObject response) {
		if (response.containsKey(field)) {
			switch (field) {
			case DataConstants.STATISTIC_RETURN:
				if (this.monthBetween < 12) {
					stats.add(DataConstants.STATISTIC_RETURN, response.get(field));
				}
				break;
			case DataConstants.STATISTIC_ANNUALIZED_RETURN:
				if (this.monthBetween >= 12) {
					stats.add(DataConstants.STATISTIC_RETURN, response.get(field));
				}
				break;
			default:
				super.constructStats(field, stats, response);
			}
		}
	}

	/**
	 * @return the statisticsList
	 */
	public List<String> getStatisticsList() {
		return this.statisticsList;
	}

	/**
	 * @param statisticsList
	 *            the statisticsList to set
	 */
	public void setStatisticsList(final List<String> statisticsList) {
		this.statisticsList = statisticsList;
	}

}
