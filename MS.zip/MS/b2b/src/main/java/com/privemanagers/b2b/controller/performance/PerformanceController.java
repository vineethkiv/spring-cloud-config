package com.privemanagers.b2b.controller.performance;

import java.util.Map;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.privemanagers.api.API;
import com.privemanagers.b2b.controller.performance.model.PerformanceRequestV1;
import com.privemanagers.b2b.controller.performance.model.PerformanceRequestV2;
import com.privemanagers.b2b.service.performance.PerformanceService;
import com.privemanagers.b2b.service.performance.PerformanceTransformer;

/**
 * Performance api rest controller
 *
 * @author Kay Ip
 * @date 11 May 2018
 * @company Prive Financial
 */
@RestController
public class PerformanceController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private PerformanceService performanceService;

	@Autowired
	private PerformanceTransformer performanceTransformer;

	/**
	 * Performance api v2
	 *
	 * @param httpServletRequest
	 * @param tenant
	 * @param request
	 * @param header
	 * @return
	 */
	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = "/b2b/2/{tenant}/performance", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> performanceV2(final HttpServletRequest httpServletRequest,
			@PathVariable("tenant") final String tenant, @RequestBody PerformanceRequestV2 request,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, httpServletRequest);
			logger.info("{} {}\nheaders {}", httpServletRequest.getMethod(), httpServletRequest.getRequestURI(),
					header);

			final ResponseEntity<String> response = performanceService.performance(tenant, request, false);
			MDC.clear();
			return response;
		};
	}

	/**
	 * Performance api v1
	 *
	 * @param httpServletRequest
	 * @param tenant
	 * @param requestV1
	 * @param header
	 * @param statistics
	 * @return
	 */
	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = "/b2b/1/{tenant}/performance", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> performance(final HttpServletRequest httpServletRequest,
			@PathVariable("tenant") final String tenant, @RequestBody final PerformanceRequestV1 requestV1,
			@RequestHeader final Map<String, String> header,
			@RequestParam(value = "statistics", required = false) final String statistics) {
		return () -> {
			API.setMDC(tenant, httpServletRequest);
			logger.info("{} {}\nheaders {}", httpServletRequest.getMethod(), httpServletRequest.getRequestURI(),
					header);

			PerformanceRequestV2 requestV2 = performanceTransformer.transform(requestV1);
			final ResponseEntity<String> response = performanceService.performance(tenant, requestV2, true);
			MDC.clear();
			return response;
		};
	}
}
