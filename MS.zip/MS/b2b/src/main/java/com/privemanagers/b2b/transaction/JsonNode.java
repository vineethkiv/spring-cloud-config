package com.privemanagers.b2b.transaction;

import java.util.ArrayList;
import java.util.List;

/**
 * Content under which other content is included.
 *
 */
public abstract class JsonNode implements JsonContent {

	protected final List<JsonContent> list = new ArrayList<JsonContent>();

	/**
	 * Include the given content in this node.
	 * 
	 * @param content
	 * @return JsonNode
	 */
	public JsonNode include(final JsonContent content) {
		this.list.add(content);
		return this;
	}

}
