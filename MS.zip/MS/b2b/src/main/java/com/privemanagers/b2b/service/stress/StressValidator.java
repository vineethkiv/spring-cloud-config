package com.privemanagers.b2b.service.stress;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.privemanagers.api.API;
import com.privemanagers.b2b.controller.stress.model.DateRange;
import com.privemanagers.b2b.controller.stress.model.StressRequestV2;
import com.privemanagers.b2b.service.common.PerformanceStressCommonValidator;

/**
 * Stress api request validator
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@Component
public class StressValidator extends PerformanceStressCommonValidator {

	private static final int STRESS_REQUIRED_BENCHMARKS_NUMBER = 5;

	private static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	@Autowired
	public StressValidator(@Value("${prive.cash-scheme}") final String cashScheme) {
		super(cashScheme);
	}

	/**
	 * Validate stress request
	 *
	 * @param request
	 */
	public void validateRequest(StressRequestV2 request) {
		if (request == null) {
			throw new IllegalArgumentException();
		}

		if (!API.validateCurrencyCode(request.getReferenceCurrency())) {
			throw new IllegalArgumentException();
		}

		validateValueCurrencyType(request.getValueCurrency());

		validateDates(request.getCrisis());

		// SLYAWS-10319 recovery time is optional.
		if (request.getRecovery() != null) {
			validateDates(request.getRecovery());
		}

		validatePortfolio(request.getCurrentPortfolio());

		// SLYAWS-10334 proposed portfolio is optional.
		if (!CollectionUtils.isEmpty(request.getProposedPortfolio())) {
			validatePortfolio(request.getProposedPortfolio());
		}

		validateBenchmark(request.getBenchmarks());
	}

	private void validateDates(DateRange input) {
		if (input == null) {
			throw new IllegalArgumentException();
		}

		final LocalDate[] dates = new LocalDate[2];
		dates[0] = LocalDate.parse(input.getFrom(), STRING_TO_DATE);
		dates[1] = LocalDate.parse(input.getUntil(), STRING_TO_DATE);
		if (!dates[0].isBefore(dates[1])) {
			throw new IllegalArgumentException();
		}
	}

	private void validateBenchmark(List<String> benchmarks) {
		if (CollectionUtils.isEmpty(benchmarks)) {
			return;
		}

		if (benchmarks.isEmpty() || benchmarks.size() > STRESS_REQUIRED_BENCHMARKS_NUMBER) {
			throw new IllegalArgumentException();
		}
	}
}
