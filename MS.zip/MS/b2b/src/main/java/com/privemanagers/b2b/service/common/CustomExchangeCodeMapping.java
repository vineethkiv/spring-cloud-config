package com.privemanagers.b2b.service.common;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.privemanagers.b2b.exception.ExchangeMappingNotFoundException;
import com.privemanagers.model.mds.ExchangeMICCode;

/**
 * Exchange code mapping per tenant
 *
 * currently supports citi with xignite mapping only
 *
 * @author Kay Ip
 * @date 2 May 2018
 * @company Prive Financial
 */
public class CustomExchangeCodeMapping {

	/**
	 * Get exchange mapping according to tenant for specific country
	 *
	 * @param tenant
	 * @return
	 */
	public static Map<String, String> getTenantExchangeCodeMapping(String tenant) {
		if (!tenantExchangeCodeMap.containsKey(tenant)) {
			throw new ExchangeMappingNotFoundException(tenant);
		}
		return tenantExchangeCodeMap.get(tenant);
	}

	private static final String EMPTY_MIC = "";

	// mapping of citi and xignite exchange code
	private static final Map<String, String> citiMap;
	static {
		Map<String, String> map = new HashMap<>();
		map.put("SEHK", ExchangeMICCode.XHKG.toString());
		map.put("SES", ExchangeMICCode.XSES.toString());
		map.put("SESG", ExchangeMICCode.XSES.toString());
		map.put("HKEX", ExchangeMICCode.XHKG.toString());
		map.put("SGEX", ExchangeMICCode.XSES.toString());
		map.put("SHEX", ExchangeMICCode.XSHG.toString());
		map.put("SZ", ExchangeMICCode.XSHE.toString());
		map.put("SEUS", EMPTY_MIC);
		map.put("OTC", EMPTY_MIC);
		map.put("NASD", ExchangeMICCode.XNAS.toString());
		map.put("NYSE", ExchangeMICCode.XNYS.toString());
		map.put("AMEX", ExchangeMICCode.XNYS.toString());
		map.put("PAC", EMPTY_MIC);
		citiMap = Collections.unmodifiableMap(map);
	}

	// map of tenant and their exchange code mapping
	private static final Map<String, Map<String, String>> tenantExchangeCodeMap;
	static {
		Map<String, Map<String, String>> map = new HashMap<>();
		map.put("citi-hk", citiMap);
		map.put("citi-sg-gcg", citiMap);
		map.put("citi-sg-ipb", citiMap);
		map.put("citi-uk", citiMap);
		map.put("citi-us", citiMap);
		map.put("citi-tw", citiMap);
		map.put("citi-cn", citiMap);
		map.put("citi-kr", citiMap);
		map.put("citi-id", citiMap);
		map.put("citi-my", citiMap);
		map.put("citi-ph", citiMap);
		map.put("citi-th", citiMap);
		tenantExchangeCodeMap = Collections.unmodifiableMap(map);
	}

}
