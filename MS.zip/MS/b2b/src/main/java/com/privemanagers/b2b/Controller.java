package com.privemanagers.b2b;

import java.util.Map;
import java.util.concurrent.Callable;

import javax.json.Json;
import javax.json.JsonObject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.privemanagers.api.API;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.IB2BExternalAPIService;
import com.privemanagers.b2b.service.IB2BService;
import com.privemanagers.b2b.service.IMaintenanceService;

@RestController
public class Controller {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private IB2BService b2bService;

	@Autowired
	private IMaintenanceService maintenanceService;

	@Autowired
	private IB2BExternalAPIService externalService;

	@Autowired
	private MixpanelUtil mixpanelUtil;

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = "/b2b/1/{tenant}/projection", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> projection(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @RequestBody final String body,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}\nbody {}", request.getMethod(), request.getRequestURI(),
					header, body);
			final ResponseEntity<String> response = Controller.this.externalService.projection(tenant, body);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = "/b2b/1/{tenant}/models/{modelref}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> postModel(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @PathVariable("modelref") final String modelref,
			@RequestBody final String body, @RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}\nbody {}", request.getMethod(), request.getRequestURI(),
					header, body);
			final ResponseEntity<String> response = Controller.this.maintenanceService.createModelPortfolio(tenant,
					modelref, body);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PutMapping(value = "/b2b/1/{tenant}/models/{modelref}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> putModel(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @PathVariable("modelref") final String modelref,
			@RequestBody final String body, @RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}\nbody {}", request.getMethod(), request.getRequestURI(),
					header, body);
			final ResponseEntity<String> response = Controller.this.maintenanceService.updateModelPortfolio(tenant,
					modelref, body);
			MDC.clear();
			return response;
		};
	}

	/**
	 * UNDOCUMENTED ENDPOINT TO REVISE HISTORIC ALLOCATIONS.
	 */
	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PutMapping(value = "/b2b/1/{tenant}/models/{modelref}/{date}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> putModelDate(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @PathVariable("modelref") final String modelref,
			@PathVariable("date") final String date, @RequestBody final String body,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}\nbody {}", request.getMethod(), request.getRequestURI(),
					header, body);
			final ResponseEntity<String> response = Controller.this.maintenanceService.reviseModelPortfolio(tenant,
					modelref, date, body);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@DeleteMapping(value = "/b2b/1/{tenant}/models/{modelref}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> deleteModel(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @PathVariable("modelref") final String modelref,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}", request.getMethod(), request.getRequestURI(), header);
			final ResponseEntity<String> response = Controller.this.maintenanceService.deleteModelPortfolio(tenant,
					modelref);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = "/b2b/1/{tenant}/models/{modelref}/delete", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> deleteModelAlternative(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @PathVariable("modelref") final String modelref,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}", request.getMethod(), request.getRequestURI(), header);
			final ResponseEntity<String> response = Controller.this.maintenanceService.deleteModelPortfolio(tenant,
					modelref);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@GetMapping(value = "/b2b/1/{tenant}/models/{modelref}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> getModelPortfolio(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @PathVariable("modelref") final String modelref,
			@RequestParam(defaultValue = "false", required = false) final boolean series,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			logger.info("{} {}\nheaders {}", request.getMethod(), request.getRequestURI(), header);

			// TODO refactor to POJO
			final JsonObject code = Json.createObjectBuilder()
					.add(FieldName.SCHEME, API.getTenantCodeScheme(tenant))
					.add(FieldName.VALUE, modelref)
					.add(FieldName.CFI_CODE, FieldName.CFI_CODE_MODEL_PORTFOLIO)
					.build();

			mixpanelUtil.trackEvent(tenant, "b2b-getModelPortfolio", code.toString());

			final ResponseEntity<String> response = maintenanceService.getModelPortfolio(tenant, modelref,
					FieldName.CFI_CODE_MODEL_PORTFOLIO, series);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@GetMapping(value = "/b2b/1/{tenant}/models/evictCache", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(value = HttpStatus.ACCEPTED)
	public void evictModelPortfolioCache() {
		maintenanceService.evictCache();
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = "/b2b/2/{tenant}/optimise", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> optimise(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @RequestBody final String body,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {} headers {}", request.getMethod(), request.getRequestURI(), header);
			Controller.this.logger.info("{} {} body {}", request.getMethod(), request.getRequestURI(), body);
			final ResponseEntity<String> response = Controller.this.b2bService.optimise(tenant, body);
			MDC.clear();
			return response;
		};
	}

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@GetMapping(value = "/b2b/1/{tenant}/fx", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> fx(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant,
			@RequestParam(value = FieldName.DATE, required = false) final String date,
			@RequestParam(value = FieldName.FXS, required = true) final String fxs,
			@RequestHeader final Map<String, String> header) {
		return () -> {
			API.setMDC(tenant, request);
			Controller.this.logger.info("{} {}\nheaders {}", request.getMethod(), request.getRequestURI(), header);
			Controller.this.logger.info("fxs: {}\ndate: {}", fxs, date);
			final ResponseEntity<String> response = Controller.this.maintenanceService.getFXs(tenant, date, fxs);
			MDC.clear();
			return response;
		};

	}

}
