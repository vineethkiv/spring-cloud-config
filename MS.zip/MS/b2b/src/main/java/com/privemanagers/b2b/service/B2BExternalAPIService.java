package com.privemanagers.b2b.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.API;
import com.privemanagers.api.AsyncTransaction;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.PriceType;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.exception.GenericNotFoundException;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.b2b.exception.AssetsNotFoundException;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.model.asset.PriceDataType;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * @author nteck
 * @date : 22 May, 2017
 * @company Prive Financial
 */
@Service
public class B2BExternalAPIService implements IB2BExternalAPIService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * The base URL, comprising the host and port, for the assets microservice.
	 */
	private final String assets;
	private final String quant;

	private final TenantContext tenantContext;

	/**
	 * The number of threads for processing with the AsyncRestTemplate.
	 */
	private final int threads;

	/**
	 * The timeout duration, in seconds, for waiting for requests of other
	 * microservices.
	 */
	private final int timeout;

	/**
	 * A specific thread pool for handling callbacks for the AsyncRestTemplate
	 * requests. Without this a new thread is created, then destroyed, for each
	 * async request.
	 */
	private ThreadPoolTaskExecutor executor;

	private MixpanelUtil mixpanelUtil;

	@PostConstruct
	public void init() {
		this.executor = new ThreadPoolTaskExecutor();
		this.executor.setThreadNamePrefix("prive-");
		this.executor.setAllowCoreThreadTimeOut(false);
		this.executor.setCorePoolSize(this.threads);
		this.executor.setDaemon(true);
		this.executor.initialize();
	}

	@Autowired
	public B2BExternalAPIService(@Value("${prive.assets}") final String assets,
			@Value("${prive.quant}") final String quant, @Value("${prive.threads}") final int threads,
			@Value("${prive.timeout}") final int timeout, final TenantContext tenantContext,
			MixpanelUtil mixpanelUtil) {
		this.assets = assets;
		this.quant = quant;
		this.threads = threads;
		this.timeout = timeout;
		this.tenantContext = tenantContext;
		this.mixpanelUtil = mixpanelUtil;
	}

	@Override
	public JsonArray queryAssetsCodes(final String tenant, final JsonArray codes) throws Exception {
		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.assets, EndPoints.ASSETS_1_CODES,
				tenant, codes.toString(), HttpMethod.POST, this.tenantContext, true);

		JsonArray assets = null;
		if (response.getStatusCode().is2xxSuccessful()) {
			final String responseBody = response.getBody();
			assets = API.parseArray(responseBody);

			if (assets.size() != codes.size()) {
				throw new AssetsNotFoundException(AssetsNotFoundException.findMissingCodes(codes, assets));
			}
		} else {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		return assets;
	}

	@Override
	public JsonObject queryAssetCode(final String tenant, final JsonObject code) throws AssetsNotFoundException {

		final JsonArray tenantCode = Json.createArrayBuilder().add(code).build();

		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.assets, EndPoints.ASSETS_1_CODES,
				tenant, tenantCode.toString(), HttpMethod.POST, this.tenantContext, true);

		JsonObject asset = null;
		if (response.getStatusCode().is2xxSuccessful()) {
			final String responseBody = response.getBody();
			final JsonArray assets = API.parseArray(responseBody);

			if (assets != null && assets.size() == 1) {
				asset = assets.getJsonObject(0);
			}
		} else {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		return asset;
	}

	@Override
	public ResponseEntity<String> queryAssetsDelete(final String tenant, final String assetId) {
		ResponseEntity<String> res = null;
		final URI uri = UriComponentsBuilder.fromUriString(this.assets)
				.path(EndPoints.ASSETS_1_ASSET)
				.buildAndExpand(tenant, assetId)
				.encode()
				.toUri();
		try {
			// put the query
			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, null, HttpMethod.DELETE,
					this.tenantContext, true);

			if (response.getStatusCode().is2xxSuccessful()) {
				res = ResponseEntity.ok("");
			} else {
				this.logger.error(
						"Error occured when deleting assetid {} in tenant {}.\nHTTP status code={}.\nResponse body={}.",
						assetId, tenant, response.getStatusCode(), response.getBody());
			}
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			res = this.handleHttpError(httpException.getResponseBodyAsString(), httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error("Error occured when deleting assetid " + assetId + " in tenant " + tenant + ".", e);
			throw e;
		}

		return res;
	}

	@Override
	public ResponseEntity<String> queryAssetsUpdate(final String body, final String tenant, final String assetId) {
		ResponseEntity<String> res = null;
		final URI uri = UriComponentsBuilder.fromUriString(this.assets)
				.path(EndPoints.ASSETS_1_ASSET)
				.buildAndExpand(tenant, assetId)
				.encode()
				.toUri();
		try {
			// put the query
			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, body, HttpMethod.PUT,
					this.tenantContext, true);

			if (response.getStatusCode().is2xxSuccessful()) {
				res = ResponseEntity.ok("");
			} else {
				this.logger.error(
						"Error occured when updating assetid {} in tenant {}.\nHTTP status code={}.\nResponse body={}.\nAsset={}",
						assetId, tenant, response.getStatusCode(), response.getBody(), body);
			}
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			res = this.handleHttpError(httpException.getResponseBodyAsString(), httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error("Error occured when updating assetid " + assetId + " in tenant " + tenant + ".", e);
			throw e;
		}

		return res;
	}

	@Override
	public ResponseEntity<String> queryAssetsCreate(final String body, final String tenant) {
		ResponseEntity<String> res = null;

		try {
			// post the query
			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.assets,
					EndPoints.ASSETS_1_ASSET_CREATE, tenant, body, HttpMethod.POST, this.tenantContext, true);

			if (response.getStatusCode().is2xxSuccessful()) {
				res = ResponseEntity.ok("");
			} else {
				this.logger.error(
						"Error occured when creating asset in tenant {}.\nHTTP status code={}.\nResponse body={}.\nAsset={}",
						tenant, response.getStatusCode(), response.getBody(), body);
			}
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			res = this.handleHttpError(httpException.getResponseBodyAsString(), httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error("Error occured when creating asset in tenant " + tenant + ".", e);
			throw e;
		}

		return res;
	}

	private ResponseEntity<String> handleHttpError(final String body, final HttpStatus code) {
		ResponseEntity<String> res = null;

		if (code.is4xxClientError()) {
			if (code.equals(HttpStatus.NOT_FOUND)) {
				final JsonArray missingCodes = API.parseArray(body);
				res = new ResponseEntity<>(AssetsNotFoundException.renameFields(missingCodes).toString(),
						HttpStatus.NOT_FOUND);
			} else if (code.equals(HttpStatus.UNAUTHORIZED) || code.equals(HttpStatus.FORBIDDEN)) {
				res = new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			} else {
				res = ResponseEntity.badRequest().body("");
			}
		} else if (code.is5xxServerError()) {
			res = new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return res;
	}

	@Override
	public ResponseEntity<String> reviseModelPortfolio(final String tenant, final String assetid, final String date,
			final String body) {

		ResponseEntity<String> res = null;
		/*
		 * TODO formalise the URI.
		 */
		final URI uri = UriComponentsBuilder.fromUriString(this.assets)
				.path(EndPoints.ASSETS_1_ASSET + "/{date}")
				.buildAndExpand(tenant, assetid, date)
				.encode()
				.toUri();

		try {

			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, body, HttpMethod.PUT,
					null, false);

			if (response.getStatusCode().is2xxSuccessful()) {
				res = ResponseEntity.ok("");
			} else {
				this.logger.error(
						"Error occured when revising assetid {} in tenant {}.\nHTTP status code={}.\nResponse body={}.\nAsset={}",
						assetid, tenant, response.getStatusCode(), response.getBody(), body);
			}
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			res = this.handleHttpError(httpException.getResponseBodyAsString(), httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error("Error occured when revising asset {} for tenant {}: {}", assetid, tenant, e);
			throw e;
		}

		return res;
	}

	@Override
	public ResponseEntity<String> getTimeSeries(final String tenant, final String from, final String until,
			final String assetID) throws Exception {
		ResponseEntity<String> res = null;

		try {
			// post the query
			final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(this.assets)
					.path(EndPoints.ASSETS_1_ASSET_SERIES);
			builder.queryParam(FieldName.FROM, from);
			builder.queryParam(FieldName.UNTIL, until);
			builder.queryParam(PriceType.FIELD, PriceType.DAILY.name());
			builder.queryParam(com.privemanagers.model.common.FieldName.PRICE_DATA_TYPE,
					PriceDataType.ADJUSTED.toString());
			final URI uri = builder.buildAndExpand(tenant, assetID).encode().toUri();
			this.logger.debug("{}", uri);

			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, null, HttpMethod.GET,
					null, true);

			if (response == null || response.getBody().isEmpty()) {
				throw new GenericNotFoundException(assetID);
			}
			if (response.getStatusCode().is2xxSuccessful()) {
				res = response;
			} else {
				this.logger.error(
						"Error occured when getting time series data for tenant {}.\nHTTP status code={}.\nResponse body={}.\nAssetID={}",
						tenant, response.getStatusCode(), response.getBody(), assetID);
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			}
		} catch (final GenericNotFoundException gne) {
			this.logger.error(HttpStatus.BAD_REQUEST.getReasonPhrase(), gne);
			return new ResponseEntity<>("", HttpStatus.BAD_REQUEST);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			res = this.handleHttpError(httpException.getResponseBodyAsString(), httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return res;
	}

	@Override
	public ResponseEntity<String> projection(final String tenant, final String body) throws Exception {
		mixpanelUtil.trackEvent(tenant, "b2b-projection", body);
		ResponseEntity<String> res = null;

		try {
			// post the query
			final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.quant,
					EndPoints.QUANT_1_PROJECTION, tenant, body, HttpMethod.POST, this.tenantContext, true);

			if (response == null || response.getBody().isEmpty()) {
				throw new GenericNotFoundException(body);
			}
			if (response.getStatusCode().is2xxSuccessful()) {
				res = response;
			} else {
				this.logger.error(
						"Error occured when calculating projection for tenant {}.\nHTTP status code={}.\nResponse body={}.\nRequest body={}",
						tenant, response.getStatusCode(), response.getBody(), body);
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			}
		} catch (final GenericNotFoundException gne) {
			this.logger.error(HttpStatus.BAD_REQUEST.getReasonPhrase(), gne);
			return new ResponseEntity<>("", HttpStatus.BAD_REQUEST);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			res = this.handleHttpError(httpException.getResponseBodyAsString(), httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return res;
	}

	@Override
	public List<FXTransaction> getFXs(final String tenant, final List<String> fxs, final String date) throws Exception {
		final CountDownLatch latch = new CountDownLatch(fxs.size());
		final List<FXTransaction> transactions = new ArrayList<>(fxs.size());

		FXTransaction transaction = null;
		for (final String fx : fxs) {
			transaction = new FXTransaction(latch, this.tenantContext, this.assets, tenant, fx, date);
			transactions.add(transaction);

			transaction.send(this.executor);
		}

		this.waitForFXTransactionResponse(latch, transactions);

		return transactions;
	}

	private void waitForFXTransactionResponse(final CountDownLatch latch,
			final List<? extends AsyncTransaction> transactions) throws InterruptedException {
		try {
			latch.await(this.timeout, TimeUnit.SECONDS);
		} catch (final InterruptedException e) {
			this.logger.warn("Interrupted exception while waiting for FX transactions {}", e);
			throw e;
		}

		for (final AsyncTransaction transaction : transactions) {
			if (!HttpStatus.OK.equals(transaction.status())) {
				this.logger.warn("{} {}", transaction.status().getReasonPhrase(), transaction.uri());
			}

		}
	}
}
