package com.privemanagers.b2b.service.performance;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.privemanagers.api.API;
import com.privemanagers.b2b.controller.performance.model.PerformanceRequestV2;
import com.privemanagers.b2b.service.common.PerformanceStressCommonValidator;

/**
 * Performance api request validator
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@Component
public class PerformanceValidator extends PerformanceStressCommonValidator {

	@Autowired
	public PerformanceValidator(@Value("${prive.cash-scheme}") final String cashScheme) {
		super(cashScheme);
	}

	/**
	 * Validate stress request
	 *
	 * @param request
	 */
	public void validateRequest(PerformanceRequestV2 request) {
		if (request == null) {
			throw new IllegalArgumentException();
		}

		if (!API.validateCurrencyCode(request.getReferenceCurrency())) {
			throw new IllegalArgumentException();
		}

		validateMonths(request.getMonths());
		validateValueCurrencyType(request.getValueCurrency());
		validatePortfolio(request.getCurrentPortfolio());
		validateModel(request.getModel());
	}

	private void validateMonths(Integer months) {
		if (months < 3 || months > 200) {
			throw new IllegalArgumentException();
		}
	}

	private void validateModel(String model) {
		if (StringUtils.isEmpty(model)) {
			return;
		}
		// SLYAWS-10424 can be null but cannot be empty
		if (StringUtils.isBlank(model)) {
			throw new IllegalArgumentException();
		}
	}
}
