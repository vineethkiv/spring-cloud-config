package com.privemanagers.b2b.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.b2b.controller.exception.ErrorCode;
import com.privemanagers.b2b.controller.model.PortfolioItemV1;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.exception.AssetsNotFoundException;
import com.privemanagers.b2b.exception.AssetsNotFoundV1Exception;
import com.privemanagers.b2b.exception.AssetsNotFoundV2Exception;

/**
 * Controller advice for v2 api
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@ControllerAdvice("com.privemanagers.b2b.controller")
public class V2ControllerAdvice {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ReloadableResourceBundleMessageSource apiErrorMessageSource;

	@ExceptionHandler({ HttpMessageNotReadableException.class })
	public ResponseEntity<String> httpMessageNotReadableExceptionHandler(final HttpServletRequest request,
			HttpMessageNotReadableException hmnre) {

		this.logger.warn("{} {} {} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), request.getRemoteAddr(),
				request.getRequestURI(), hmnre.getMessage());

		return ResponseEntity.badRequest().body("");
	}

	@ExceptionHandler({ AssetsNotFoundV2Exception.class })
	public ResponseEntity<List<PortfolioItemV2>> missingAssetsExceptionHandler(AssetsNotFoundV2Exception ex)
			throws JsonProcessingException {
		String missingAssets = objectMapper.writeValueAsString(ex.getMissingAssets());
		logger.error("AssetsNotFoundV1Exception: {}", missingAssets);
		return new ResponseEntity<>(ex.getMissingAssets(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler({ AssetsNotFoundV1Exception.class })
	public ResponseEntity<List<PortfolioItemV1>> missingAssetsExceptionHandler(AssetsNotFoundV1Exception ex)
			throws JsonProcessingException {
		String missingAssets = objectMapper.writeValueAsString(ex.getMissingAssetsV1());
		logger.error("AssetsNotFoundV1Exception: {}", missingAssets);
		return new ResponseEntity<>(ex.getMissingAssetsV1(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler({ AssetsNotFoundException.class })
	public ResponseEntity<String> assestNotFoundExceptionHandler(AssetsNotFoundException anfe) {
		logger.error("AssetsNotFoundV1Exception: {}", anfe.getCodesMissingAssets());
		return new ResponseEntity<>(anfe.getCodesMissingAssets().toString(), HttpStatus.NOT_FOUND);
	}

	/**
	 * javax validation error handling
	 *
	 * @param httpServletRequest
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> methodArgumentNotValidExceptionHandler(HttpServletRequest httpServletRequest,
			MethodArgumentNotValidException ex) {
		logger.info("field validation error");

		logger.error("MethodArgumentNotValidException: {}", getBindingErrors(ex.getBindingResult()));
		return ResponseEntity.badRequest().body("");
	}

	private String getBindingErrors(BindingResult result) {
		if (result != null && result.getAllErrors() != null && !result.getAllErrors().isEmpty()) {
			List<String> errors = new ArrayList<>();
			for (ObjectError error : result.getAllErrors()) {
				if (error instanceof FieldError) {
					FieldError fieldError = (FieldError) error;
					errors.add(resolveErrorMessage(fieldError.getDefaultMessage(), null, fieldError.getField(),
							fieldError.getArguments()));
				} else {
					errors.add(resolveErrorMessage(error.getDefaultMessage(), null, null, error.getArguments()));
				}
			}
			return StringUtils.join(errors, ",");
		}
		return "field validation failed";
	}

	/**
	 * resolve error message with error code and locale
	 *
	 * @param locale
	 * @param code
	 * @param arguments
	 * @return
	 */
	private String resolveErrorMessage(String code, Locale locale, String fieldName, Object... arguments) {
		String errorMessage = apiErrorMessageSource.getMessage(code, arguments, locale);
		if (ErrorCode.INVALID_ASSET_SCHEMA.getCode().equalsIgnoreCase(code)) {
			errorMessage = errorMessage + " in " + fieldName;
		}
		if (StringUtils.isBlank(errorMessage)) {
			logger.warn("message not found for code:{}", code);
		}
		return errorMessage;
	}
}
