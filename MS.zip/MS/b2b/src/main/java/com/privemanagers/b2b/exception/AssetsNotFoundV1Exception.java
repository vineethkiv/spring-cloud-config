package com.privemanagers.b2b.exception;

import java.util.List;

import com.privemanagers.b2b.controller.model.PortfolioItemV1;

/**
 * Asset not found exception v1
 * 
 * no business logic here and accepting PortfolioItemV1 instead of Json array
 *
 * @author Kay Ip
 * @date 14 May 2018
 * @company Prive Financial
 */
public class AssetsNotFoundV1Exception extends Exception {

	private static final long serialVersionUID = 6503240419450499280L;

	private List<PortfolioItemV1> missingAssetsV1;

	public AssetsNotFoundV1Exception(final List<PortfolioItemV1> assetCodesV1) {
		this.missingAssetsV1 = assetCodesV1;
	}

	public List<PortfolioItemV1> getMissingAssetsV1() {
		return missingAssetsV1;
	}

	public void setMissingAssetsV1(List<PortfolioItemV1> missingAssetsV1) {
		this.missingAssetsV1 = missingAssetsV1;
	}

}
