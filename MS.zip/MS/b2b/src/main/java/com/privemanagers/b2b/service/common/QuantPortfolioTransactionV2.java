package com.privemanagers.b2b.service.common;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.CountDownLatch;

import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.DataConstants;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.b2b.service.QuantTransaction;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * This sender class contains async logic for calling quant transaction ONLY
 * 
 * Request json should be pass from caller, logic to compose the request json
 * should NOT be in this class
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class QuantPortfolioTransactionV2 extends QuantTransaction {

	/** Month between from and until date */
	private long monthBetween;

	// request calling quant
	private String request;

	public QuantPortfolioTransactionV2(String request, String from, String until, final String baseURL,
			final CountDownLatch latch, final String tenant, final TenantContext tenantContext) {
		super(latch, tenantContext);
		this.request = request;

		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseURL);
		builder.path(EndPoints.QUANT_1_SERIES);
		this.uri(builder.buildAndExpand(tenant).toUri());

		final LocalDate fromDate = LocalDate.parse(from);
		final LocalDate untilDate = LocalDate.parse(until);
		this.monthBetween = ChronoUnit.MONTHS.between(fromDate, untilDate);
	}

	@Override
	public void send(final ThreadPoolTaskExecutor executor) {
		final ListenableFuture<ResponseEntity<String>> future = SecuredRestHelper.sendRequest(executor, this.uri(),
				null, request, HttpMethod.POST, this.tenantContext(), true);

		future.addCallback(this);
	}

	/**
	 * Dirty fix for SLYAWS-10934 to replace the return value by the
	 * annualized-return value. It should be a temporary fix as we planned to
	 * have a v2 of our APIs to retire the return field and include explicitly
	 * the annualized-return and cumulative-return fields.
	 *
	 * Hack again for SLYAWS-10948. We will need to display cum-return when the
	 * range is less than 1 year and ann-return when it's greater than 1 year
	 */
	@Override
	protected void constructStats(final String field, final JsonObjectBuilder stats, final JsonObject response) {
		if (response.containsKey(field)) {
			switch (field) {
			case DataConstants.STATISTIC_RETURN:
				if (this.monthBetween < 12) {
					stats.add(DataConstants.STATISTIC_RETURN, response.get(field));
				}
				break;
			case DataConstants.STATISTIC_ANNUALIZED_RETURN:
				if (this.monthBetween >= 12) {
					stats.add(DataConstants.STATISTIC_RETURN, response.get(field));
				}
				break;
			default:
				super.constructStats(field, stats, response);
			}
		}
	}

}
