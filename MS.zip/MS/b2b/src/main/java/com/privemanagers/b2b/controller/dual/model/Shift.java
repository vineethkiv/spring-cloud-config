package com.privemanagers.b2b.controller.dual.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.privemanagers.model.quant.ShiftType;

/**
 * sensitivity analysis object being used in dual series requests to define the
 * type of sensitivity and its values
 *
 * @author wzhang
 * @date 25 Oct 2018
 * @company Prive Financial
 */
public class Shift {

	private ShiftType type;

	@NotNull(message = "nullShiftValues")
	@NotEmpty(message = "nullShiftValues")
	private List<Double> values;

	public ShiftType getType() {
		return type;
	}

	public void setType(ShiftType type) {
		this.type = type;
	}

	public List<Double> getValues() {
		return values;
	}

	public void setValues(List<Double> values) {
		this.values = values;
	}
}
