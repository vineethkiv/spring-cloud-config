package com.privemanagers.b2b.util;

/**
 * @author William Zhang
 * @date 1 Dec 2017
 * @company Prive Financial
 */
public enum PortfolioField {
	NAME("name"),
	SCHEME("scheme"),
	VALUE("value"),
	CURRENCY("currency"),
	ALLOCATION("allocation"),
	EFFECTIVE_WEIGHT("effective-weight"),
	WEIGHT("weight"),
	ASSET_CODE("asset-code"),
	ASSET_CODES("asset-codes"),
	ASSET_CODE_SCHEME("asset-code-scheme"),
	ISIN("isin"),
	TENANT_CODE("tenant-code"),
	TYPE("type"),
	CFI_CODE("cfi-code"),
	ID("_id"),
	ASSET_ID("asset-id"),
	INCEPTION_DATE("inception-date");

	private String fieldName;

	PortfolioField(final String fieldName) {
		this.setFieldName(fieldName);
	}

	public static boolean shouldExclude(String fieldName) {
		return (fieldName.equalsIgnoreCase(ID.fieldName) || fieldName.equalsIgnoreCase(ASSET_ID.fieldName));
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		if (SCHEME == this)
			return ASSET_CODE_SCHEME.fieldName;
		if (VALUE == this)
			return ASSET_CODE.fieldName;
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public boolean isFieldForArray() {
		return ALLOCATION == this || ASSET_CODES == this;
	}

	public static PortfolioField toPortfolioField(String fieldName) {
		for (PortfolioField field : values()) {
			if (field.fieldName.equalsIgnoreCase(fieldName)) {
				return field;
			}
		}
		return null;
	}

}
