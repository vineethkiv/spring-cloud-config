package com.privemanagers.b2b.service.common;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.privemanagers.api.API;
import com.privemanagers.b2b.controller.stress.model.DateRange;
import com.privemanagers.b2b.service.external.AssetExternalService;
import com.privemanagers.b2b.service.external.model.AssetPriceResponse;
import com.privemanagers.b2b.service.stress.model.Asset;
import com.privemanagers.b2b.util.DateUtil;
import com.privemanagers.b2b.util.PerformanceStressCommonUtil;

/**
 * @author wzhang
 * @date 9 Nov 2018
 * @company Prive Financial
 */
@Service
public class CommonService implements ICommonService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private AssetExternalService assetExternalService;

	@Autowired
	private PerformanceStressCommonUtil stressUtil;

	@Override
	public String[] preProcessDate(String tenant, DateRange dateRange, List<Asset> assets,
			boolean useEarliestCommonDate, boolean useLatestCommonDate) {
		if (dateRange == null) {
			return null;
		}

		String[] dateRangeArr = new String[] { stressUtil.formatDate(dateRange.getFrom()),
				stressUtil.formatDate(dateRange.getUntil()) };

		// check is use-earliest-common-date, if true, not backfill
		if (useEarliestCommonDate) {
			dateRangeArr[0] = DateUtil.getCommonEarliestDate(assets, dateRangeArr[0]);
			logger.info("common earliest date is updated to {}", dateRangeArr[0]);
		}

		if (useLatestCommonDate) {
			LocalDate latestDate = API.date(dateRangeArr[1]);
			for (Asset a : assets) {
				AssetPriceResponse priceResponse = assetExternalService.queryLatestPrice(tenant, a.getAssetId(), null);
				if (priceResponse == null || priceResponse.getPrice() == null
						|| priceResponse.getPrice().getLocalDate() == null) {
					continue;
				}
				LocalDate assetLatestDate = API.date(priceResponse.getPrice().getLocalDate().toString(),
						API.STRING_TO_DATE_NON_DASH);
				if (assetLatestDate.isBefore(latestDate)) {
					latestDate = assetLatestDate;
				}
			}
			dateRangeArr[1] = latestDate.format(DateUtil.requestDateTimeFormat);
			logger.info("common latest date is updated to {}", dateRangeArr[1]);
		}
		return dateRangeArr;
	}

}
