package com.privemanagers.b2b.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.concurrent.CountDownLatch;

import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import com.privemanagers.api.AsyncTransaction;
import com.privemanagers.api.DataConstants;
import com.privemanagers.api.TenantContext;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.transaction.JsonContent;
import com.privemanagers.b2b.transaction.NamedJsonContent;

public abstract class QuantTransaction extends AsyncTransaction {

	/**
	 * The required Quant service statistics.
	 */
	public static final String[] QUANT_STATISTICS = { DataConstants.STATISTIC_RETURN,
			DataConstants.STATISTIC_VOLATILITY, DataConstants.STATISTIC_SHARPE, DataConstants.STATISTIC_COUNT_LOSSES,
			DataConstants.STATISTIC_MEAN_LOSS, DataConstants.STATISTIC_COUNT_GAINS, DataConstants.STATISTIC_MEAN_GAIN,
			DataConstants.STATISTIC_MAX_RETURN, DataConstants.STATISTIC_MIN_RETURN, DataConstants.STATISTIC_MAX_DRAWUP,
			DataConstants.STATISTIC_MAX_DRAWDOWN, DataConstants.STATISTIC_ANNUALIZED_RETURN };

	/**
	 * The returned fields.
	 */
	public static final String[] FIELDS = { DataConstants.STATISTIC_RETURN, DataConstants.STATISTIC_VOLATILITY,
			DataConstants.STATISTIC_SHARPE, DataConstants.STATISTIC_COUNT_LOSSES, DataConstants.STATISTIC_MEAN_LOSS,
			DataConstants.STATISTIC_COUNT_GAINS, DataConstants.STATISTIC_MEAN_GAIN, DataConstants.STATISTIC_MAX_RETURN,
			DataConstants.STATISTIC_MIN_RETURN, DataConstants.STATISTIC_MAX_DRAWUP_RELATIVE,
			DataConstants.STATISTIC_MAX_DRAWUP_FROM, DataConstants.STATISTIC_MAX_DRAWUP_UNTIL,
			DataConstants.STATISTIC_MAX_DRAWDOWN_RELATIVE, DataConstants.STATISTIC_MAX_DRAWDOWN_FROM,
			DataConstants.STATISTIC_MAX_DRAWDOWN_UNTIL, DataConstants.STATISTIC_ANNUALIZED_RETURN,
			DataConstants.STATISTIC_NEGATIVE_VOLATILITY, DataConstants.STATISTIC_ANNUALIZED_NEGATIVE_VOLATILITY,
			DataConstants.STATISTIC_YIELD_TO_MATURITY, DataConstants.STATISTIC_YIELD_TO_WORST,
			DataConstants.STATISTIC_YIELD_TO_CALL, DataConstants.STATISTIC_EFFECTIVE_DURATION };
	/**
	 * To parse date parameters of the form YYYY-MM to local dates.
	 */
	private static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	public QuantTransaction(final CountDownLatch latch, final TenantContext tenantContext) {
		super(latch, tenantContext);
	}

	/**
	 * Return the JSON content with the given name.
	 *
	 * @param name
	 * @return JsonContent
	 */
	public JsonContent content(final String name) {

		return new NamedJsonContent(name) {

			@Override
			public void build(final JsonObjectBuilder builder, final JsonBuilderFactory factory) {
				final JsonObject response = QuantTransaction.this.body();

				if (response != null) {
					final JsonObjectBuilder self = factory.createObjectBuilder();
					/*
					 * The relative time series.
					 */
					if (response.containsKey(FieldName.RELATIVE)) {
						final JsonArrayBuilder array = factory.createArrayBuilder();
						for (final JsonValue x : response.getJsonArray(FieldName.RELATIVE)) {
							final JsonObjectBuilder element = factory.createObjectBuilder();
							final JsonObject o = (JsonObject) x;
							element.add("month", QuantTransaction.this.fullDate(o.getString("month")));
							element.add(FieldName.VALUE, o.get(FieldName.VALUE));
							array.add(element);
						}
						self.add("series", array);
					}
					/*
					 * The statistics.
					 */
					final JsonObjectBuilder stats = factory.createObjectBuilder();
					for (final String field : FIELDS) {
						QuantTransaction.this.constructStats(field, stats, response);
					}
					self.add(FieldName.STATISTICS, stats);
					/*
					 * Build.
					 */
					builder.add(this.name, self);
				}
			}

			@Override
			public void build(final JsonArrayBuilder builder, final JsonBuilderFactory factory) {
			}
		};
	}

	/**
	 * Full dates are returned by b2b. TODO this should be a configuration for
	 * each tenant.
	 *
	 * @param source
	 * @return String
	 */
	private String fullDate(final String source) {
		LocalDate date = LocalDate.parse(source, STRING_TO_DATE);
		date = date.plusMonths(1).minusDays(1);
		return date.format(STRING_TO_DATE);
	}

	/**
	 * Construct the statistics responses. Can handle custom logic here.
	 *
	 * @param stats
	 * @param response
	 */
	protected void constructStats(final String field, final JsonObjectBuilder stats, final JsonObject response) {
		if (response.containsKey(field)) {
			switch (field) {
			case "max-drawup-from":
			case "max-drawup-until":
			case "max-drawdown-from":
			case "max-drawdown-until":
				stats.add(field, QuantTransaction.this.fullDate(response.getString(field)));
				break;
			default:
				stats.add(field, response.get(field));
			}
		}
	}
}
