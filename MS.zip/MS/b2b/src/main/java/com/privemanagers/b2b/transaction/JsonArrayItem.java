package com.privemanagers.b2b.transaction;

import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;

/**
 * An object in a JSON array.
 *
 */
public class JsonArrayItem extends JsonNode {

	@Override
	public void build(final JsonObjectBuilder builder, final JsonBuilderFactory factory) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void build(final JsonArrayBuilder builder, final JsonBuilderFactory factory) {
		final JsonObjectBuilder self = factory.createObjectBuilder();
		for (JsonContent content : this.list) {
			content.build(self, factory);
		}
		builder.add(self);
	}

}
