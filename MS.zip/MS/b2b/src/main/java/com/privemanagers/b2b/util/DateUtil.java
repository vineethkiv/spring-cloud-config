package com.privemanagers.b2b.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.privemanagers.b2b.service.stress.model.Asset;

/**
 * @author Kay Ip
 * @date 12 Mar 2018
 * @company Prive Financial
 */
public class DateUtil {

	private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);

	public static final DateTimeFormatter inceptionDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd");
	public static final DateTimeFormatter requestDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	public static final DateTimeFormatter requestDateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	/**
	 * Get the common earliest inception date amoung assets
	 *
	 * Cannot earlier than request date
	 *
	 * @param assets
	 * @return
	 */
	public static String getCommonEarliestDate(JsonArray assets, String requestDateStr) {
		// suppose request date is valid, not doing validation here
		LocalDate requestDate = parseStringToDate(requestDateStr, requestDateFormat);

		LocalDate earliestDate = requestDate;
		for (JsonValue asset : assets) {
			JsonObject a = (JsonObject) asset;
			if (!a.containsKey("inception-date")) {
				continue;
			}

			String inceptionDateStr = a.getString("inception-date");
			LocalDate inceptionDate = parseStringToDate(inceptionDateStr, inceptionDateFormat);
			if (inceptionDate == null) {
				logger.warn("inceptionDate:{} is invalid, skipped", inceptionDateStr);
				continue;
			}
			if (inceptionDate.isAfter(earliestDate)) {
				earliestDate = inceptionDate;
			}
		}

		LocalDate resultDate = earliestDate.isBefore(requestDate) ? requestDate : earliestDate;
		return requestDateFormat.format(resultDate);
	}

	public static String getCommonEarliestDate(List<Asset> assets, String requestDateStr) {
		// suppose request date is valid, not doing validation here
		LocalDate requestDate = parseStringToDate(requestDateStr, requestDateFormat);

		LocalDate earliestDate = requestDate;
		for (Asset a : assets) {
			if (StringUtils.isBlank(a.getInceptionDate())) {
				continue;
			}

			LocalDate inceptionDate = parseStringToDate(a.getInceptionDate(), inceptionDateFormat);
			if (inceptionDate == null) {
				logger.warn("inceptionDate:{} is invalid, skipped", a.getInceptionDate());
				continue;
			}
			if (inceptionDate.isAfter(earliestDate)) {
				earliestDate = inceptionDate;
			}
		}

		LocalDate resultDate = earliestDate.isBefore(requestDate) ? requestDate : earliestDate;
		return requestDateFormat.format(resultDate);
	}

	private static LocalDate parseStringToDate(String dateSt, DateTimeFormatter format) {
		try {
			return LocalDate.parse(dateSt, format);
		} catch (DateTimeParseException e) {
			logger.warn("cannot parse date string:{}, skipped", dateSt);
			throw e;
		}
	}
}
