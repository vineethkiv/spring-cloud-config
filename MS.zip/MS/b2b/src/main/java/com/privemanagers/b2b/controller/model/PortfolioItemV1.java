package com.privemanagers.b2b.controller.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Portfolio item
 *
 * SLYAWS-11740 multi asset identifier represents 1 asset
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortfolioItemV1 {

	@JsonProperty("asset-code")
	private String assetCode;

	@JsonProperty("asset-code-scheme")
	private String assetCodeScheme;

	@JsonProperty("asset-currency")
	private String currency;

	private BigDecimal value;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public String getAssetCodeScheme() {
		return assetCodeScheme;
	}

	public void setAssetCodeScheme(String assetCodeScheme) {
		this.assetCodeScheme = assetCodeScheme;
	}
}
