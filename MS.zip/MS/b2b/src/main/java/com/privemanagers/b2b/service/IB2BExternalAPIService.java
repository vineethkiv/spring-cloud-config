package com.privemanagers.b2b.service;

import java.util.List;

import javax.json.JsonArray;
import javax.json.JsonObject;

import org.springframework.http.ResponseEntity;

import com.privemanagers.b2b.exception.AssetsNotFoundException;

/**
 * @author nteck
 * @date : 22 May, 2017
 * @company Prive Financial
 */
public interface IB2BExternalAPIService {

	/**
	 * Query the assets service to delete the specified asset.
	 *
	 * @param tenant
	 * @param assetId
	 * @return
	 * @throws Exception
	 */
	public ResponseEntity<String> queryAssetsDelete(final String tenant, final String assetId) throws Exception;

	/**
	 * Query the assets service to update the specified asset.
	 *
	 * @param body
	 * @param tenant
	 * @param assetId
	 * @return
	 */
	public ResponseEntity<String> queryAssetsUpdate(final String body, final String tenant, final String assetId)
			throws Exception;

	/**
	 * Query the assets service to create an asset.
	 *
	 * @param body
	 * @param tenant
	 * @return
	 * @throws Exception
	 */
	public ResponseEntity<String> queryAssetsCreate(final String body, final String tenant) throws Exception;

	/**
	 * Query the assets service with the specified code to get the associated
	 * asset.
	 *
	 * @param tenant
	 * @param asset
	 * @return
	 * @throws Exception
	 */
	public JsonObject queryAssetCode(final String tenant, final JsonObject code) throws Exception;

	/**
	 * Query the assets service with specified codes to get their associated
	 * assets. If some assets are not found, throw
	 * {@link AssetsNotFoundException}.
	 *
	 * @param tenant
	 * @param codes
	 * @return
	 * @throws Exception
	 */
	public JsonArray queryAssetsCodes(final String tenant, final JsonArray codes) throws Exception;

	/**
	 * Ask the assets service to make an historical revision to the model
	 * portfolio allocation.
	 *
	 * @param tenant
	 * @param assetid
	 * @param date
	 * @param body
	 * @return
	 */
	public ResponseEntity<String> reviseModelPortfolio(final String tenant, final String assetid, final String date,
			final String body);

	/**
	 * call the quant service to get the projection series.
	 *
	 * @param tenant
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public ResponseEntity<String> projection(final String tenant, final String body) throws Exception;

	/**
	 * Get multiple FXs rate asynchronously.
	 *
	 * @param tenant
	 * @param fxs
	 * @param date
	 * @return
	 */
	public List<FXTransaction> getFXs(final String tenant, final List<String> fxs, final String date) throws Exception;

	/**
	 * get tune series data for an asset over a period of time
	 *
	 * @param tenant
	 * @param from
	 * @param until
	 * @param assetID
	 * @return
	 * @throws Exception
	 */
	public ResponseEntity<String> getTimeSeries(String tenant, String from, String until, String assetID)
			throws Exception;

}
