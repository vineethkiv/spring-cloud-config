package com.privemanagers.b2b.controller.dual.model;

import java.util.List;

import javax.validation.GroupSequence;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.b2b.controller.dual.model.validator.DualSeriesRequestValid;
import com.privemanagers.validation.CustomGroup;

/**
 * b2b dual series request object
 *
 * use @GroupSequence to define orders in validation logic, validate the fields
 * first before verifying the class using the custom validator, so the order
 * here matters
 *
 * use @ValidDualSeriesRequest to define the group that the custom validator
 * belongs to
 *
 * @author wzhang
 * @date 25 Oct 2018
 * @company Prive Financial
 */
@GroupSequence({ DualSeriesRequest.class, CustomGroup.class })
@DualSeriesRequestValid(groups = CustomGroup.class)
public class DualSeriesRequest {

	@Valid
	private AssetIdentifier benchmark;

	@NotNull(message = "fromDateMsg")
	@NotEmpty(message = "fromDateMsg")
	private String from;

	@NotNull(message = "untilDateMsg")
	@NotEmpty(message = "untilDateMsg")
	private String until;

	@NotNull(message = "assetsArrayMsg")
	@NotEmpty(message = "assetsArrayMsg")
	@Valid
	private List<AssetIdentifier> assets;

	@Valid
	private Shift shift;

	@JsonProperty(value = "use-earliest-common-date", defaultValue = "false")
	private boolean useEarliestCommonDate;

	@JsonProperty(value = "use-latest-common-date", defaultValue = "false")
	private boolean useLatestCommonDate;

	public AssetIdentifier getBenchmark() {
		return benchmark;
	}

	public void setBenchmark(AssetIdentifier benchmark) {
		this.benchmark = benchmark;
	}

	public List<AssetIdentifier> getAssets() {
		return assets;
	}

	public void setAssets(List<AssetIdentifier> assets) {
		this.assets = assets;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getUntil() {
		return until;
	}

	public void setUntil(String until) {
		this.until = until;
	}

	public Shift getShift() {
		return shift;
	}

	public void setShift(Shift shift) {
		this.shift = shift;
	}

	public boolean getUseEarliestCommonDate() {
		return useEarliestCommonDate;
	}

	public void setUseEarliestCommonDate(Boolean useEarliestCommonDate) {
		this.useEarliestCommonDate = useEarliestCommonDate;
	}

	public boolean getUseLatestCommonDate() {
		return useLatestCommonDate;
	}

	public void setUseLatestCommonDate(Boolean useLatestCommonDate) {
		this.useLatestCommonDate = useLatestCommonDate;
	}

}
