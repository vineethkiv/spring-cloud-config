package com.privemanagers.b2b.service.performance;

import java.util.List;

import org.springframework.stereotype.Component;

import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.controller.performance.model.PerformanceRequestV1;
import com.privemanagers.b2b.controller.performance.model.PerformanceRequestV2;
import com.privemanagers.b2b.service.common.PerformanceStressCommonTransformer;

/**
 * Performance Request transformer
 *
 * @author Kay Ip
 * @date 10 May 2018
 * @company Prive Financial
 */
@Component
public class PerformanceTransformer extends PerformanceStressCommonTransformer {

	/**
	 * Transform v1 request to v2 request
	 *
	 * @param v1
	 * @return
	 */
	public PerformanceRequestV2 transform(PerformanceRequestV1 v1) {
		if (v1 == null) {
			return null;
		}

		PerformanceRequestV2 v2 = new PerformanceRequestV2();
		v2.setMonths(v1.getMonths());
		v2.setModel(v1.getModel());
		v2.setReferenceCurrency(v1.getReferenceCurrency());
		v2.setStatistics(v1.getStatistics());
		v2.setValueCurrency(v1.getValueCurrency());
		List<PortfolioItemV2> currentPortfolio = transform(v1.getCurrentPortfolio());
		v2.setCurrentPortfolio(currentPortfolio);
		return v2;
	}

}
