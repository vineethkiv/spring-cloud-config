package com.privemanagers.b2b.txn;

import java.util.concurrent.CountDownLatch;

import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.QuantTransaction;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * @author Vineeth Kiv
 *
 */
public class QuantPortfolioSeriesTransaction extends QuantTransaction {

	private final String currency;
	private final String from;
	private final String until;
	private final int rebalanceEvery;
	private final JsonBuilderFactory factory;
	private final JsonArray portfolio;

	public QuantPortfolioSeriesTransaction(final String baseURL, final String tenant, final String from,
			final String until, final String currency, final int rebalanceEvery, final JsonBuilderFactory factory,
			final JsonArray portfolio, final CountDownLatch latch, TenantContext tenantContext) {
		super(latch, tenantContext);
		this.currency = currency;
		this.from = from;
		this.until = until;
		this.rebalanceEvery = rebalanceEvery;
		this.factory = factory;
		this.portfolio = portfolio;

		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseURL);
		builder.path(EndPoints.QUANT_1_SERIES);
		this.uri(builder.buildAndExpand(tenant).toUri());
	}

	@Override
	public void send(final ThreadPoolTaskExecutor executor) {
		final ListenableFuture<ResponseEntity<String>> future = SecuredRestHelper.sendRequest(executor, this.uri(),
				null, this.requestBody(), HttpMethod.POST, this.tenantContext(), true);
		future.addCallback(this);
	}

	/**
	 * Make the request body for the quant service.
	 * 
	 * @return String
	 */
	private String requestBody() {

		final JsonObjectBuilder statObj = this.factory.createObjectBuilder();
		statObj.add(FieldName.PORTFOLIO, reduceCashToZero(this.portfolio));
		statObj.add(FieldName.FROM, this.from);
		statObj.add(FieldName.UNTIL, this.until);
		statObj.add(FieldName.CURRENCY, this.currency);
		statObj.add(FieldName.REBALANCE_EVERY, this.rebalanceEvery);
		statObj.add(FieldName.RELATIVE, 100);
		final JsonArrayBuilder stats = this.factory.createArrayBuilder();
		stats.add(FieldName.ANNUALIZED_RETURN);
		stats.add(FieldName.SHARPE);
		stats.add(FieldName.VOLATILITY);
		statObj.add(FieldName.STATISTICS, stats);

		return statObj.build().toString();

	}

	/**
	 * Stress test do not accept cash till date. Reduce the cash value to 0 in
	 * the portfolio. Filtering cash completely from request will throw error
	 * for cash only accounts.
	 * 
	 * This function has to be removed when stress start accepting cash.
	 * 
	 * @param portfolio
	 * @return
	 */
	private JsonArray reduceCashToZero(final JsonArray portfolio) {

		final JsonArrayBuilder finalArray = this.factory.createArrayBuilder();

		portfolio.stream().map(h -> (JsonObject) h).forEach(h -> {
			final JsonObjectBuilder finalPortfolio = this.factory.createObjectBuilder();
			finalPortfolio.add("asset-id", h.getString("asset-id"));

			if (h.containsKey("cash-code")) {
				finalPortfolio.add("value", 0.0);
			} else {
				finalPortfolio.add("value", h.getJsonNumber("value").doubleValue());
			}
			finalPortfolio.add("frozen", h.getJsonNumber("frozen").doubleValue());

			finalArray.add(finalPortfolio);

		});

		return finalArray.build();

	}

}
