package com.privemanagers.b2b.txn;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.AsyncTransaction;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * @author Vineeth Kiv
 *
 */
public class OptTransaction extends AsyncTransaction {

	private final String opt;
	private final String endPoint;
	private final String tenant;
	private final JsonBuilderFactory factory;

	private final String sessionCurrency;
	private final JsonArray fitness;
	private final JsonArray goals;
	private final JsonObject goal;
	private final JsonArray eligibleAssets;
	private final JsonArray preferredCurrencies;
	private final JsonArray preferredAssets;
	private final boolean checkForReference;

	// private final JsonArray portfolio;
	private final JsonArray proposedGoals;

	private final JsonArray concentrationThreshold;

	private final List<JsonObject> fxData;

	private final int riskProfile;

	private final double expectedReturn;

	private final String from;
	private final String until;

	private final String modelTier;

	public OptTransaction(final String opt, final String endPoint, final String tenant, final CountDownLatch latch,
			final JsonBuilderFactory factory, final String sessionCurrency, final JsonArray fitness,
			final JsonArray goals, final JsonArray proposedGoals, final JsonArray eligibleAssets,
			final JsonArray preferredCurrencies, final JsonArray preferredAssets, final boolean checkForReference,
			final JsonArray concentrationThreshold, final TenantContext tenantContext, final List<JsonObject> fxData,
			final int riskProfile, final double expectedReturn, final String from, final String until,
			final String modelTier) {

		super(latch, tenantContext);
		this.opt = opt;
		this.endPoint = endPoint;
		this.tenant = tenant;
		this.factory = factory;
		this.sessionCurrency = sessionCurrency;
		this.fitness = fitness;
		this.goals = goals;
		this.eligibleAssets = eligibleAssets;
		this.preferredAssets = preferredAssets;
		this.preferredCurrencies = preferredCurrencies;
		this.proposedGoals = proposedGoals;
		this.checkForReference = checkForReference;
		this.concentrationThreshold = concentrationThreshold;

		this.fxData = fxData;

		this.riskProfile = riskProfile;

		this.expectedReturn = expectedReturn;

		this.from = from;
		this.until = until;

		this.modelTier = modelTier;

		this.goal = goals.stream().map(o -> (JsonObject) o).filter(p -> p.getBoolean(FieldName.OPTIMISE, false))
				.findFirst().get();

	}

	/**
	 * Send the request using the given executor to handle the async response.
	 * 
	 * @param executor
	 */
	@Override
	public void send(ThreadPoolTaskExecutor executor) {

		final URI uri = UriComponentsBuilder.fromUriString(this.opt).path(this.endPoint).buildAndExpand(tenant).encode()
				.toUri();

		final ListenableFuture<ResponseEntity<String>> future = SecuredRestHelper.sendRequest(executor, uri,
				this.tenant, this.requestBody(), HttpMethod.POST, this.tenantContext(), true);

		future.addCallback(this);

	}

	/**
	 * Build the request body for opt transaction.
	 * 
	 * @return
	 */
	private String requestBody() {

		if (EndPoints.OPT_1_OPTIMISE.equals(this.endPoint)) {
			return optimiseRequestBody();
		} else if (EndPoints.OPT_1_FITNESS.equals(this.endPoint)) {
			return fitnessRequestBody();
		}
		return "";

	}

	/**
	 * Build the optimise request body.
	 * 
	 * @return
	 */
	private String optimiseRequestBody() {

		final JsonObjectBuilder optmimiseBody = this.factory.createObjectBuilder();
		this.commonRequestObj(optmimiseBody);
		/*
		 * final JsonArrayBuilder eAsset = this.factory.createArrayBuilder();
		 * this.eligibleAssets.stream().map(o -> (JsonObject) o).forEach(asset
		 * -> { eAsset.add(asset.getString(FieldName.ASSET_ID)); });
		 */

		optmimiseBody.add(FieldName.ASSETS, this.eligibleAssets);
		optmimiseBody.add(FieldName.GOALS, this.goals);
		return optmimiseBody.build().toString();

	}

	/**
	 * Build the fitness request body.
	 * 
	 * @return
	 */
	private String fitnessRequestBody() {

		final JsonObjectBuilder fitnessBody = this.factory.createObjectBuilder();
		this.commonRequestObj(fitnessBody);

		if (this.checkForReference && null != this.proposedGoals) {
			fitnessBody.add(FieldName.GOALS, this.proposedGoals);

		} else {

			fitnessBody.add(FieldName.GOALS, this.goals);

		}

		return fitnessBody.build().toString();

	}

	/**
	 * Mapping common opt request fields.
	 * 
	 * @param body
	 */
	private void commonRequestObj(final JsonObjectBuilder body) {

		final JsonObjectBuilder session = this.factory.createObjectBuilder();

		if (this.riskProfile > 0) {
			session.add("risk-profile", this.riskProfile);
		}

		if (this.preferredCurrencies != null) {
			session.add(FieldName.PREFERRED_CURRENCIES, this.preferredCurrencies);
		}
		if (this.preferredAssets != null) {
			session.add(FieldName.PREFERRED_ASSETS, this.preferredAssets);
		}

		if (this.checkForReference && null != this.goal.getJsonArray(FieldName.PORTFOLIO)
				&& !this.goal.getJsonArray(FieldName.PORTFOLIO).isEmpty()) {
			session.add("base-portfolio", this.goal.getJsonArray(FieldName.PORTFOLIO));
		}

		if (this.checkForReference && null != this.goal.getJsonArray("holdings")
				&& !this.goal.getJsonArray("holdings").isEmpty()) {
			JsonArray sortedBase = this.sortJsonArray(this.goal.getJsonArray("holdings"), "asset-id");
			session.add("base-portfolio", sortedBase);
		}

		if (this.concentrationThreshold != null && !this.concentrationThreshold.isEmpty()) {

			JsonArray sortedConcentration = this.sortJsonArray(this.concentrationThreshold, "category");
			session.add(FieldName.CONCENTRATION_THRESHOLDS, sortedConcentration);
		}

		if (this.fxData != null && !this.fxData.isEmpty()) {
			session.add("fx-data", fxData(this.fxData));
		}

		if (this.expectedReturn > 0.0) {
			session.add("expected-return", this.expectedReturn);
		}

		session.add(FieldName.CURRENCY, this.sessionCurrency);
		session.add("from", this.from);
		session.add("until", this.until);
		
		if (this.modelTier != null && !this.modelTier.isEmpty()) {
			session.add("model-tier", this.modelTier);
		}

		body.add(FieldName.SESSION, session);
		body.add(FieldName.FITNESS, this.fitness);
	}

	/**
	 * Retrun the goal details
	 * 
	 * @return
	 */
	public JsonObject goal() {
		return this.goal;
	}

	public JsonArray goals() {
		return this.goals;
	}

	public JsonArray proposedGoals() {
		return this.proposedGoals;
	}

	private JsonArray fxData(final List<JsonObject> fxData) {

		final JsonArrayBuilder jab = this.factory.createArrayBuilder();

		fxData.forEach(fx -> {
			jab.add(fx);
		});

		return jab.build();

	}

	private JsonArray sortJsonArray(final JsonArray input, final String key) {

		JsonArrayBuilder jab = this.factory.createArrayBuilder();

		List<JsonObject> jsonValues = new ArrayList<>(input.size());

		for (int i = 0; i < input.size(); i++) {
			jsonValues.add(input.getJsonObject(i));
		}

		Collections.sort(jsonValues, new Comparator<JsonObject>() {

			@Override
			public int compare(JsonObject a, JsonObject b) {
				String valA = new String();
				String valB = new String();

				try {
					valA = a.getString(key);
					valB = b.getString(key);
				} catch (JsonException e) {
				}

				return valA.compareTo(valB);
			}

		});

		for (int i = 0; i < input.size(); i++) {
			jab.add(jsonValues.get(i));
		}

		return jab.build();

	}

}
