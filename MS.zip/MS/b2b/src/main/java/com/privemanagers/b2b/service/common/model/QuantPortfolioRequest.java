package com.privemanagers.b2b.service.common.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.api.ValueCurrencyType;

/**
 * QuantPortfolioRequest
 * 
 * Contains similar fields as QuantPortfolioTransaction(v1), it is a pure POJO,
 * NO api calling logics here
 *
 * Pass this Object to QuantPortfolioTransactionV2
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class QuantPortfolioRequest implements Serializable {

	private static final long serialVersionUID = 164936136163323074L;

	private String currency;

	private String from;

	private String until;

	@JsonProperty("rebalance-every")
	private Integer rebalanceEvery;

	private List<QuantTransactionPortfolio> portfolio;

	private String cashScheme;

	@JsonProperty("value-currency")
	private ValueCurrencyType valueCurrency;

	private List<String> statistics;

	// default to 100 according to QuantPortfolioTransaction requestBody()
	private Integer relative = 100;

	public QuantPortfolioRequest(final String from, final String until, final String currency, final int rebalanceEvery,
			final List<QuantTransactionPortfolio> portfolio, final ValueCurrencyType valueCurrency,
			final List<String> statistics) {
		this.statistics = statistics;
		this.currency = currency;
		this.from = from;
		this.until = until;
		this.rebalanceEvery = rebalanceEvery;
		this.portfolio = portfolio;
		this.valueCurrency = valueCurrency;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getUntil() {
		return until;
	}

	public void setUntil(String until) {
		this.until = until;
	}

	public Integer getRebalanceEvery() {
		return rebalanceEvery;
	}

	public void setRebalanceEvery(Integer rebalanceEvery) {
		this.rebalanceEvery = rebalanceEvery;
	}

	public List<QuantTransactionPortfolio> getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(List<QuantTransactionPortfolio> portfolio) {
		this.portfolio = portfolio;
	}

	public String getCashScheme() {
		return cashScheme;
	}

	public void setCashScheme(String cashScheme) {
		this.cashScheme = cashScheme;
	}

	public ValueCurrencyType getValueCurrency() {
		return valueCurrency;
	}

	public void setValueCurrency(ValueCurrencyType valueCurrency) {
		this.valueCurrency = valueCurrency;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public List<String> getStatistics() {
		return statistics;
	}

	public void setStatistics(List<String> statistics) {
		this.statistics = statistics;
	}

	public Integer getRelative() {
		return relative;
	}

	public void setRelative(Integer relative) {
		this.relative = relative;
	}

}
