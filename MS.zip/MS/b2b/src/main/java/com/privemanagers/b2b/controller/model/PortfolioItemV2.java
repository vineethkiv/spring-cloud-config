package com.privemanagers.b2b.controller.model;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Portfolio item
 * 
 * SLYAWS-11740 multi asset identifier represents 1 asset
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class PortfolioItemV2 {

	@JsonProperty("asset-identifier")
	List<PortfolioAssetIdentifier> assetIdentifiers;

	@JsonProperty("asset-currency")
	private String currency;

	private BigDecimal value;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public List<PortfolioAssetIdentifier> getAssetIdentifiers() {
		return assetIdentifiers;
	}

	public void setAssetIdentifiers(List<PortfolioAssetIdentifier> assetIdentifiers) {
		this.assetIdentifiers = assetIdentifiers;
	}
}
