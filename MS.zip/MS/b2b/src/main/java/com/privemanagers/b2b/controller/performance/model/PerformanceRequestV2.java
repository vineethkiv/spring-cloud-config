package com.privemanagers.b2b.controller.performance.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;

/**
 * Performance api v2 request
 *
 * @author Kay Ip
 * @date 8 May 2018
 * @company Prive Financial
 */
public class PerformanceRequestV2 extends PerformanceRequestBase {
    @JsonProperty("current-portfolio")
    private List<PortfolioItemV2> currentPortfolio;

    public List<PortfolioItemV2> getCurrentPortfolio() {
        return currentPortfolio;
    }

    public void setCurrentPortfolio(List<PortfolioItemV2> currentPortfolio) {
        this.currentPortfolio = currentPortfolio;
    }
}
