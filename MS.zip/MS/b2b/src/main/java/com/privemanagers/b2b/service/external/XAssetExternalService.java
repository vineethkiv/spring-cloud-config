package com.privemanagers.b2b.service.external;

import java.net.URI;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.util.RestHelper;
import com.privemanagers.b2b.controller.model.PortfolioAssetIdentifier;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.model.mds.AssetScheme;
import com.privemanagers.sc.service.impl.ExternalAuthAPIService;

/**
 * Service for calling xasset ms
 *
 * @author Kay Ip
 * @date 10 May 2018
 * @company Prive Financial
 */
@Service
public class XAssetExternalService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${prive.xassets}")
	private String xasseturi;

	@Autowired
	private ExternalAuthAPIService externalAuthAPIService;

	@Autowired
	private TenantContext tenantContext;

	/**
	 * Loop through the array and determine if the system can attempt to create
	 * asset on the fly. This would require (isin or symbol) and currency for
	 * eligible asset
	 *
	 * @param missingAssets
	 */
	public void searchAndCreateAssetRequest(List<PortfolioItemV2> missingAssets) {

		if (CollectionUtils.isEmpty(missingAssets)) {
			return;
		}
		logger.info("begin search and create asset");

		for (PortfolioItemV2 missingAsset : missingAssets) {
			String currency = missingAsset.getCurrency();
			if (StringUtils.isBlank(currency)) {
				logger.info("empty currency, skipped, not calling searchAndCreateAssetRequest");
				continue;
			}

			boolean assetIdentifierCalled = false;

			// symbol takes priority
			for (PortfolioAssetIdentifier assetIdentifier : missingAsset.getAssetIdentifiers()) {
				String identifier = assetIdentifier.getAssetCode();
				String scheme = assetIdentifier.getAssetCodeScheme();

				if (StringUtils.isBlank(identifier) || !scheme.equalsIgnoreCase(AssetScheme.SYMBOL.toString())) {
					continue;
				}

				assetIdentifierCalled = true;
				logger.info("search and create asset by symbol");

				String[] symbol = identifier.split("\\.");
				if (symbol.length != 2) {
					logger.warn("invalid symbol:{}, skipped", identifier);
					continue;
				}

				final URI requestURI = UriComponentsBuilder.fromUriString(xasseturi)
						.path(EndPoints.XASSETS_1_SEARCH_CREATE_BY_SYMBOL)
						.queryParam(AssetScheme.SYMBOL.toString().toLowerCase(), symbol[0])
						.queryParam("mic", symbol[1])
						.queryParam("currency", currency)
						.build()
						.encode()
						.toUri();
				searchAndCreateAssetRequest(requestURI, identifier, AssetScheme.SYMBOL.toString().toUpperCase(),
						currency);
			}

			if (assetIdentifierCalled) {
				continue;
			}

			// if asserIdentifier don't have symbol, call using ISIN
			for (PortfolioAssetIdentifier assetIdentifier : missingAsset.getAssetIdentifiers()) {
				String identifier = assetIdentifier.getAssetCode();
				String scheme = assetIdentifier.getAssetCodeScheme();

				if (StringUtils.isBlank(identifier) || !scheme.equalsIgnoreCase(AssetScheme.ISIN.toString())) {
					continue;
				}

				logger.info("search and create asset by isin");

				final URI requestURI = UriComponentsBuilder.fromUriString(xasseturi)
						.path(EndPoints.XASSETS_1_SEARCH_CREATE)
						.queryParam(AssetScheme.ISIN.toString().toLowerCase(), identifier)
						.queryParam("currency", currency)
						.build()
						.encode()
						.toUri();

				searchAndCreateAssetRequest(requestURI, identifier, AssetScheme.ISIN.toString().toUpperCase(),
						currency);
			}

		}
		logger.info("completed search and create asset");
	}

	/**
	 * Fire a call to xasset for creating a new asset using the given isin and
	 * currency
	 *
	 * @param requestURI
	 * @param identifier
	 * @param identifierType
	 * @param currency
	 */
	private void searchAndCreateAssetRequest(URI requestURI, String identifier, String identifierType,
			String currency) {

		if (StringUtils.isBlank(identifier) || StringUtils.isBlank(currency)) {
			return;
		}

		logger.info("Calling xasset to create asset with identifier {}  identifierType {} currency {}", identifier,
				identifierType, currency);

		final String adminToken = externalAuthAPIService.getOAuth2AuthenticationToken("admin", null, null, null);

		try {
			if (adminToken == null) {
				logger.error(
						"Error getting admin token for searchAndCreateAssetRequest identifierType {} identifierType {} currency {}",
						identifier, identifierType, currency);
				throw new Exception("Error getting admin token for searchAndCreateAssetRequest");
			}

			logger.info("Firing call to xasset: {}", requestURI);

			final ResponseEntity<String> response = RestHelper.sendRequest(requestURI, null, null, HttpMethod.GET,
					adminToken, tenantContext, true);

			if (!response.getStatusCode().is2xxSuccessful()) {
				logger.error("Error calling xasset statusCode={} with URL: {}", response.getStatusCodeValue(),
						requestURI);
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}
}
