package com.privemanagers.b2b.controller.dual.model.validator;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * interface to indicate a valid b2b dual series request validated
 * by @DualSeriesRequestValidator
 *
 * @author wzhang
 * @date 25 Oct 2018
 * @company Prive Financial
 */
@Documented
@Constraint(validatedBy = DualSeriesRequestValidator.class)
@Target({ ElementType.TYPE, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface DualSeriesRequestValid {

	/**
	 * returns the default key for creating error messages in case the
	 * constraint is violated
	 */
	String message() default "invalidRequest";

	/**
	 * an attribute groups that allows the specification of validation groups,
	 * to which this constraint belongs. This must default to an empty array of
	 * type Class<?>.
	 */
	Class<?>[] groups() default {};

	/**
	 * an attribute payload that can be used by clients of the Bean Validation
	 * API to assign custom payload objects to a constraint. This attribute is
	 * not used by the API itself.
	 */
	Class<? extends Payload>[] payload() default {};
}
