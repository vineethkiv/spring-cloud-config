package com.privemanagers.b2b.adapter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.privemanagers.api.EndPoints;
import com.privemanagers.sc.interceptor.impl.TenantConfigInterceptor;

/**
 * @author sroelens
 * @date 3 Jul 2017
 * @company Prive Financial
 */
@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {

	@Autowired
	TenantConfigInterceptor tenantConfigInterceptor;

	@Value("${prive.resource.id:missing-resource.id}")
	private String resourceID;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {

		registry.addInterceptor(tenantConfigInterceptor)
				.addPathPatterns("/" + resourceID + "/**")
				.excludePathPatterns(EndPoints.ERROR + "/**", EndPoints.HEALTH);
	}

	@Bean
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasename("classpath:api-error");
		messageSource.setDefaultEncoding("UTF-8");
		return messageSource;
	}
}
