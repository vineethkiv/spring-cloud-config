package com.privemanagers.b2b.service.stress.model;

/**
 * asset code
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class AssetCode {
    private String scheme;
    private String value;
    private String currency;

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
