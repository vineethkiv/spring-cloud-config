package com.privemanagers.b2b.service.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.privemanagers.api.API;
import com.privemanagers.b2b.controller.model.PortfolioAssetIdentifier;
import com.privemanagers.b2b.controller.model.PortfolioItemV1;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.service.QuantTransaction;
import com.privemanagers.b2b.service.common.model.QuantTransactionPortfolio;
import com.privemanagers.b2b.service.stress.model.Asset;
import com.privemanagers.b2b.service.stress.model.AssetCode;
import com.privemanagers.model.mds.AssetScheme;

/**
 * Common transformation for performance and stress
 *
 * @author Kay Ip
 * @date 10 May 2018
 * @company Prive Financial
 */
public class PerformanceStressCommonTransformer {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * Transform PortfolioItemV1 to PortfolioItemV2
	 *
	 * @param v1List
	 * @return
	 */
	public List<PortfolioItemV2> transform(List<PortfolioItemV1> v1List) {
		if (CollectionUtils.isEmpty(v1List)) {
			return null;
		}

		List<PortfolioItemV2> v2List = new ArrayList<>();
		for (PortfolioItemV1 itemV1 : v1List) {
			v2List.add(transform(itemV1));
		}
		return v2List;
	}

	private PortfolioItemV2 transform(PortfolioItemV1 v1) {
		if (v1 == null) {
			return null;
		}

		PortfolioAssetIdentifier identifier = new PortfolioAssetIdentifier();
		identifier.setAssetCode(v1.getAssetCode());
		identifier.setAssetCodeScheme(v1.getAssetCodeScheme());

		List<PortfolioAssetIdentifier> identifiers = new ArrayList<>();
		identifiers.add(identifier);

		PortfolioItemV2 v2 = new PortfolioItemV2();
		v2.setAssetIdentifiers(identifiers);
		v2.setCurrency(v1.getCurrency());
		v2.setValue(v1.getValue());
		return v2;
	}

	/**
	 * Transform PortfolioItemV2 to PortfolioItemV1
	 *
	 * @param v2List
	 * @return
	 */
	public List<PortfolioItemV1> transformToV1(List<PortfolioItemV2> v2List) {
		if (CollectionUtils.isEmpty(v2List)) {
			return null;
		}

		List<PortfolioItemV1> v1List = new ArrayList<>();
		for (PortfolioItemV2 itemV2 : v2List) {
			v1List.add(transformToV1(itemV2));
		}
		return v1List;
	}

	private PortfolioItemV1 transformToV1(PortfolioItemV2 v2) {
		if (v2 == null) {
			return null;
		}

		if (CollectionUtils.isEmpty(v2.getAssetIdentifiers())) {
			return null;
		}

		PortfolioItemV1 v1 = new PortfolioItemV1();
		v1.setAssetCode(v2.getAssetIdentifiers().get(0).getAssetCode());
		v1.setAssetCodeScheme(v2.getAssetIdentifiers().get(0).getAssetCodeScheme());
		v1.setCurrency(v2.getCurrency());
		// DO NOT set value here, as the missing asset response don't show value
		return v1;
	}

	public List<AssetCode> transform(PortfolioItemV2 item) {
		if (CollectionUtils.isEmpty(item.getAssetIdentifiers())) {
			logger.debug("portfolio assets is empty, do not find missing code");
			return null;
		}

		List<AssetCode> assetCodes = new ArrayList<>();
		for (PortfolioAssetIdentifier assetIdentifier : item.getAssetIdentifiers()) {
			AssetCode assetCode = new AssetCode();
			assetCode.setCurrency(item.getCurrency());
			assetCode.setScheme(assetIdentifier.getAssetCodeScheme());

			String codeValue = assetIdentifier.getAssetCode();
			if (AssetScheme.SYMBOL.toString().equals(assetIdentifier.getAssetCodeScheme())) {
				codeValue = StringUtils.strip(codeValue, "0");
			}
			assetCode.setValue(codeValue);

			assetCodes.add(assetCode);
		}
		return assetCodes;
	}

	public AssetCode transformBenchmark(String benchmark) {
		AssetCode assetCode = new AssetCode();
		assetCode.setValue(benchmark);
		assetCode.setScheme(AssetScheme.PRIVE.toString());
		return assetCode;
	}

	public List<AssetCode> transformBenchmarkToList(String benchmark) {
		List<AssetCode> list = new ArrayList<>();
		list.add(transformBenchmark(benchmark));
		return list;
	}

	public List<AssetCode> transformBenchmarks(List<String> benchmarks) {
		List<AssetCode> assetCodes = new ArrayList<>();
		for (String benchmark : benchmarks) {
			assetCodes.add(transformBenchmark(benchmark));
		}
		return assetCodes;
	}

	public AssetCode transformModel(String tenant, String model) {
		AssetCode assetCode = new AssetCode();
		assetCode.setValue(model);
		assetCode.setScheme(API.getTenantCodeScheme(tenant));
		return assetCode;
	}

	public List<AssetCode> transformModelToList(String tenant, String model) {
		List<AssetCode> list = new ArrayList<>();
		list.add(transformModel(tenant, model));
		return list;
	}

	public List<String> transformStatistic(List<String> from) {
		// use default statistic if user input is empty
		if (CollectionUtils.isEmpty(from)) {
			return Arrays.asList(QuantTransaction.QUANT_STATISTICS);
		}

		return from;
	}

	public PortfolioItemV2 transformModelToPortfolioItem(String tenant, String model) {
		return transform(API.getTenantCodeScheme(tenant), model);
	}

	public PortfolioItemV2 transformBenchmarkToPortfolioItem(String model) {
		return transform(AssetScheme.PRIVE.toString(), model);
	}

	public PortfolioItemV2 transform(String scheme, String value) {
		PortfolioAssetIdentifier identifier = new PortfolioAssetIdentifier();
		identifier.setAssetCode(value);
		identifier.setAssetCodeScheme(scheme);

		List<PortfolioAssetIdentifier> list = new ArrayList<>();
		list.add(identifier);
		PortfolioItemV2 item = new PortfolioItemV2();
		item.setAssetIdentifiers(list);
		return item;
	}

	public QuantTransactionPortfolio transform(Asset a, PortfolioItemV2 item, String cashScheme) {
		if (a == null) {
			return null;
		}

		if (!cashScheme.equals(a.getScheme())) {
			if (!item.getCurrency().equals(a.getCurrency())) {
				return null;
			}
		}

		QuantTransactionPortfolio to = new QuantTransactionPortfolio();
		to.setAssetId(a.getAssetId());
		to.setValue(item.getValue());
		return to;
	}
	
	public QuantTransactionPortfolio transformToBenchmarkId(Asset a, PortfolioItemV2 item, String cashScheme) {
		if (a == null) {
			return null;
		}

		QuantTransactionPortfolio to = new QuantTransactionPortfolio();
		to.setAssetId(a.getBenchmarkId());
		to.setValue(item.getValue());
		return to;
	}
}
