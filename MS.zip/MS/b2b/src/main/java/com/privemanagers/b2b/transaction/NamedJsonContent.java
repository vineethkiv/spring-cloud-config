package com.privemanagers.b2b.transaction;

/**
 * Content which is named.
 *
 */
public abstract class NamedJsonContent implements JsonContent {

	protected final String name;

	public NamedJsonContent(final String name) {
		this.name = name;
	}

}
