package com.privemanagers.b2b.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.privemanagers.api.API;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.b2b.exception.AssetsNotFoundException;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.maintenance.MaintenanceRenameFields;
import com.privemanagers.b2b.service.maintenance.MaintenanceValidation;
import com.privemanagers.b2b.util.AlertUtil;
import com.privemanagers.b2b.util.ModelPortfolioResponseMapper;

/**
 * @author nteck
 * @date : 12 May, 2017
 * @company Prive Financial
 */
@Service
@CacheConfig(cacheNames = "modelPortfolio")
public class MaintenanceService implements IMaintenanceService {

	private static final DateTimeFormatter DATE_TO_STRING = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private final IB2BExternalAPIService externalService;

	private final MaintenanceValidation validation;

	private final MaintenanceRenameFields renameFields;

	private final String cashScheme;

	private final MixpanelUtil mixpanelUtil;

	private final AlertUtil alertUtil;

	private static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	@Autowired
	public MaintenanceService(final IB2BExternalAPIService externalService, final MaintenanceValidation validation,
			final MaintenanceRenameFields renameFields, @Value("${prive.cash-scheme}") final String cashScheme,
			MixpanelUtil mixpanelUtil, AlertUtil alertUtil) {
		this.externalService = externalService;
		this.validation = validation;
		this.renameFields = renameFields;
		this.cashScheme = cashScheme;
		this.mixpanelUtil = mixpanelUtil;
		this.alertUtil = alertUtil;
	}

	@Override
	public ResponseEntity<String> createModelPortfolio(final String tenant, final String modelref, final String body) {
		try {
			final JsonObject model = API.parseObject(body);

			// validation
			try {

				if (model == null || !this.validation.validateName(model)
						|| !this.validation.validateCurrency(model, FieldName.CURRENCY)
						|| !this.validation.validateAllocation(model, this.cashScheme)) {
					this.logger.warn("{} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), body);
					return ResponseEntity.badRequest().body("");
				}

			} catch (final Exception e) {
				this.logger.warn("{} {} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), e, body);
				return ResponseEntity.badRequest().body("");
			}

			mixpanelUtil.trackEvent(tenant, "b2b-createModelPortfolio", body);

			// fields renaming
			final JsonObject newModel = this.renameFields.renameModelPortfolioFields(model, tenant, modelref,
					FieldName.CFI_CODE_MODEL_PORTFOLIO);

			// check if this asset already exists from assets API
			final JsonObject code = Json.createObjectBuilder()
					.add(FieldName.SCHEME, API.getTenantCodeScheme(tenant))
					.add(FieldName.VALUE, modelref)
					.build();
			final JsonObject asset = this.externalService.queryAssetCode(tenant, code);

			// asset already exists, can't create it
			if (asset != null) {
				this.logger.warn("{} {}\n{} Already exists", HttpStatus.BAD_REQUEST.getReasonPhrase(), body, code);
				return ResponseEntity.badRequest().body("");
			}

			return this.externalService.queryAssetsCreate(newModel.toString(), tenant);
		} catch (final AssetsNotFoundException anfe) {
			this.logger.error(HttpStatus.NOT_FOUND.getReasonPhrase(), anfe);
			return new ResponseEntity<String>(anfe.getCodesMissingAssets().toString(), HttpStatus.NOT_FOUND);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public ResponseEntity<String> updateModelPortfolio(final String tenant, final String modelref, final String body) {
		try {
			final JsonObject model = API.parseObject(body);

			// validation
			try {

				if (model == null || !this.validation.validateName(model)
						|| !this.validation.validateCurrency(model, FieldName.CURRENCY)
						|| !this.validation.validateAllocation(model, this.cashScheme)) {
					this.logger.warn("{} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), body);
					return ResponseEntity.badRequest().body("");
				}

			} catch (final Exception e) {
				this.logger.warn("{} {} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), e, body);
				return ResponseEntity.badRequest().body("");
			}

			mixpanelUtil.trackEvent(tenant, "b2b-updateModelPortfolio", body);

			// fields renaming
			final JsonObject newModel = this.renameFields.renameModelPortfolioFields(model, tenant, modelref,
					FieldName.CFI_CODE_MODEL_PORTFOLIO);

			// get the asset from assets API
			final JsonObject code = Json.createObjectBuilder()
					.add(FieldName.SCHEME, API.getTenantCodeScheme(tenant))
					.add(FieldName.VALUE, modelref)
					.add(FieldName.CFI_CODE, FieldName.CFI_CODE_MODEL_PORTFOLIO)
					.build();
			final JsonObject asset = this.externalService.queryAssetCode(tenant, code);

			// check if asset exists
			if (asset == null) {
				throw new AssetsNotFoundException(
						AssetsNotFoundException.renameFields(Json.createArrayBuilder().add(code).build()));
			}

			final String modelId = asset.getString(FieldName.ASSET_ID);

			return this.externalService.queryAssetsUpdate(newModel.toString(), tenant, modelId);
		} catch (final AssetsNotFoundException anfe) {
			this.logger.error(HttpStatus.NOT_FOUND.getReasonPhrase(), anfe);
			return new ResponseEntity<String>(anfe.getCodesMissingAssets().toString(), HttpStatus.NOT_FOUND);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<String> deleteModelPortfolio(final String tenant, final String modelref) {
		try {
			final JsonObject code = Json.createObjectBuilder()
					.add(FieldName.SCHEME, API.getTenantCodeScheme(tenant))
					.add(FieldName.VALUE, modelref)
					.build();

			mixpanelUtil.trackEvent(tenant, "b2b-deleteModelPortfolio", code.toString());

			final JsonObject asset = this.externalService.queryAssetCode(tenant, code);

			// check if asset exists
			if (asset == null) {
				throw new AssetsNotFoundException(
						AssetsNotFoundException.renameFields(Json.createArrayBuilder().add(code).build()));
			}

			final String modelId = asset.getString(FieldName.ASSET_ID);

			return this.externalService.queryAssetsDelete(tenant, modelId);
		} catch (final AssetsNotFoundException anfe) {
			this.logger.error(HttpStatus.BAD_REQUEST.getReasonPhrase(), anfe);
			return ResponseEntity.badRequest().body("");
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<String> reviseModelPortfolio(final String tenant, final String modelref, final String date,
			final String body) {
		try {

			final JsonObject model = API.parseObject(body);

			/*
			 * Validation.
			 */
			try {

				if (model == null || !this.validation.validateName(model)
						|| !this.validation.validateCurrency(model, FieldName.CURRENCY)
						|| !this.validation.validateAllocation(model, this.cashScheme)) {
					this.logger.warn("{} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), body);
					return ResponseEntity.badRequest().body("");
				}

			} catch (final Exception e) {
				this.logger.warn("{} {} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), e, body);
				return ResponseEntity.badRequest().body("");
			}

			mixpanelUtil.trackEvent(tenant, "b2b-reviseModelPortfolio", body);

			/*
			 * Rename fields in the model to be consistent with the assets
			 * service.
			 */
			final JsonObject newModel = this.renameFields.renameModelPortfolioFields(model, tenant, modelref,
					FieldName.CFI_CODE_MODEL_PORTFOLIO);
			/*
			 * Get the asset id for the model portfolio.
			 */
			final JsonObject code = Json.createObjectBuilder()
					.add(FieldName.SCHEME, API.getTenantCodeScheme(tenant))
					.add(FieldName.VALUE, modelref)
					.add(FieldName.CFI_CODE, FieldName.CFI_CODE_MODEL_PORTFOLIO)
					.build();
			final JsonObject asset = this.externalService.queryAssetCode(tenant, code);
			if (asset == null) {
				throw new AssetsNotFoundException(
						AssetsNotFoundException.renameFields(Json.createArrayBuilder().add(code).build()));
			}

			final String modelId = asset.getString(FieldName.ASSET_ID);

			return this.externalService.reviseModelPortfolio(tenant, modelId, date, newModel.toString());

		} catch (final AssetsNotFoundException anfe) {
			this.logger.error(HttpStatus.NOT_FOUND.getReasonPhrase(), anfe);
			return new ResponseEntity<String>(anfe.getCodesMissingAssets().toString(), HttpStatus.NOT_FOUND);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Cacheable(unless = "#result.statusCodeValue != 200")
	public ResponseEntity<String> getModelPortfolio(final String tenant, final String modelref, final String cfiCode,
			final boolean shouldIncludeSeries) {

		logger.info("begin getModelPortfolio:{}", modelref);

		try {
			final JsonObject code = Json.createObjectBuilder()
					.add(FieldName.SCHEME, API.getTenantCodeScheme(tenant))
					.add(FieldName.VALUE, modelref)
					.add(FieldName.CFI_CODE, cfiCode)
					.build();

			final JsonObject response = this.externalService.queryAssetCode(tenant, code);
			if (response == null) {
				throw new AssetsNotFoundException(
						AssetsNotFoundException.renameFields(Json.createArrayBuilder().add(code).build()));
			}
			String tenantScheme = tenant;
			if (tenant.contains("-")) {
				tenantScheme = tenant.split("-")[0];
			}

			final JsonObjectBuilder builder = ModelPortfolioResponseMapper
					.mapModelPortfolioObjectToObjectBuilder(response, tenantScheme);

			if (shouldIncludeSeries) {
				/*
				 * no need to use inception-date after assets migration, when
				 * sync MP from monolith, all prices of that MP will be removed,
				 * no junk price date anymore
				 */
				String from = "1900-01-01";
				final String assetID = response.getString(FieldName.ASSET_ID);
				final LocalDate u = LocalDate.now();
				final String until = u.format(STRING_TO_DATE);
				ResponseEntity<String> timeSeriesResponse = this.externalService.getTimeSeries(tenant, from, until,
						assetID);

				if (timeSeriesResponse != null) {
					JsonArrayBuilder pricesArray = ModelPortfolioResponseMapper
							.parseTimeSeries(timeSeriesResponse.getBody());

					// SLYAWS-12618 last NAV zero value check
					boolean lastNavZero = ModelPortfolioResponseMapper.checkLastRecord(timeSeriesResponse.getBody());
					if (lastNavZero) {
						alertUtil.logGetModelPortfolioLastNavZero(tenant, modelref);
						throw new IllegalStateException("last price value is 0 for " + modelref);
					}

					if (pricesArray != null) {
						builder.add(FieldName.SERIES, pricesArray);
					}
				}
			}

			logger.info("completed getModelPortfolio:{}", modelref);

			return new ResponseEntity<String>(builder.build().toString(), HttpStatus.OK);
		} catch (final AssetsNotFoundException anfe) {
			this.logger.error(HttpStatus.BAD_REQUEST.getReasonPhrase(), anfe);
			return new ResponseEntity<String>("", HttpStatus.BAD_REQUEST);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<String> getFXs(final String tenant, final String date, final String fxs) {
		try {

			/*
			 * Validation
			 */
			final String fxDate = date != null ? date : LocalDate.now().format(DATE_TO_STRING);

			if ((fxDate != null && API.date(fxDate, DATE_TO_STRING) == null) || !StringUtils.hasText(fxs)) {
				return ResponseEntity.badRequest().build();
			}

			final List<String> fxList = API.list(fxs);
			for (final String fx : fxList) {
				if (!API.validateISOCurrencyPair(fx)) {
					return ResponseEntity.badRequest().build();
				}
			}

			final JsonObject requestJson = Json.createObjectBuilder().add("date", fxDate).add("fxs", fxs).build();
			mixpanelUtil.trackEvent(tenant, "b2b-getFXs", requestJson.toString());

			/*
			 * Get FXs
			 */
			final List<FXTransaction> transactions = this.externalService.getFXs(tenant, API.list(fxs), fxDate);

			/*
			 * Build response
			 */
			final JsonBuilderFactory factory = API.makeJsonBuilderFactory();
			final JsonArrayBuilder arrayBuilder = factory.createArrayBuilder();
			JsonObjectBuilder oBuilder = null;

			for (final FXTransaction transaction : transactions) {
				oBuilder = factory.createObjectBuilder();

				oBuilder.add(FieldName.FX, transaction.getCurrencyPair());

				// Only add fxrate from successful request
				if (HttpStatus.OK.equals(transaction.status())) {
					oBuilder.add(FieldName.FX_RATE, transaction.body().get(FieldName.FX_RATE));
				}

				arrayBuilder.add(oBuilder.build());
			}

			oBuilder = factory.createObjectBuilder();
			oBuilder.add(FieldName.DATE, fxDate);
			oBuilder.add(FieldName.FXS, arrayBuilder.build());

			return ResponseEntity.ok(oBuilder.build().toString());
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {
			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	@CacheEvict(allEntries = true)
	public void evictCache() {
		logger.info("Evicting all MP cache");
	}
}
