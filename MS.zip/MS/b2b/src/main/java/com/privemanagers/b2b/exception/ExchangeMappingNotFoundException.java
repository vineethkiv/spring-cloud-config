package com.privemanagers.b2b.exception;

/**
 * ExchangeMappingNotFoundException
 * 
 * exchange mapping not found for specific tenant, either missing update mapping
 * or tenant config MAP-MIC-CODE should not be enabled
 *
 * @author Kay Ip
 * @date 2 May 2018
 * @company Prive Financial
 */
public class ExchangeMappingNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 2333194544669391270L;

	String tenant;

	public ExchangeMappingNotFoundException(String tenant) {
		this.tenant = tenant;
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}
}
