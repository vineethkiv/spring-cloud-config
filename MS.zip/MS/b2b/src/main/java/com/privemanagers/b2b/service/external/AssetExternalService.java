package com.privemanagers.b2b.service.external;

import java.io.IOException;
import java.net.URI;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.json.JsonNumber;
import javax.json.JsonObject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.api.API;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.config.tenant.TenantConfigEnum;
import com.privemanagers.api.config.tenant.TenantServiceConfigUtil;
import com.privemanagers.api.config.tenant.TenantServiceEnum;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.field.CalculationMethod;
import com.privemanagers.b2b.service.common.CustomCurrencyMapping;
import com.privemanagers.b2b.service.common.PerformanceStressCommonTransformer;
import com.privemanagers.b2b.service.common.model.QuantTransactionPortfolio;
import com.privemanagers.b2b.service.external.model.AssetPriceResponse;
import com.privemanagers.b2b.service.stress.model.Asset;
import com.privemanagers.b2b.service.stress.model.AssetCode;
import com.privemanagers.model.asset.PriceDataType;
import com.privemanagers.model.common.FieldName;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * Service for calling asset ms
 *
 * @author Kay Ip
 * @date 10 May 2018
 * @company Prive Financial
 */
@Service
public class AssetExternalService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private static final DateTimeFormatter DATE_TO_STRING = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	@Value("${prive.assets}")
	private String assets;

	@Value("${prive.cash-scheme}")
	private String cashScheme;

	@Autowired
	private TenantContext tenantContext;

	@Autowired
	private ObjectMapper objectMapper;

	private static final DateTimeFormatter priceDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	/**
	 * query asset price
	 *
	 * @param tenant
	 * @param assetId
	 * @param date
	 * @return
	 */
	public AssetPriceResponse queryLatestPrice(String tenant, String assetId, LocalDate date) {
		String formattedDate = date == null ? null : date.format(priceDateFormat);
		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(assets)
				.path(EndPoints.ASSETS_1_ASSET_PRICE);
		builder.queryParam("date", formattedDate);
		builder.queryParam(FieldName.PRICE_DATA_TYPE, PriceDataType.ADJUSTED);
		final URI uri = builder.buildAndExpand(tenant, assetId).encode().toUri();

		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, null, HttpMethod.GET,
				tenantContext, true);

		if (!response.getStatusCode().is2xxSuccessful()) {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		final String responseBody = response.getBody();

		try {
			return objectMapper.readValue(responseBody, new TypeReference<AssetPriceResponse>() {
			});
		} catch (IOException e) {
			logger.error("failed to parse asset from string response");
		}
		return null;
	}

	/**
	 * query asset code to check is it valid
	 *
	 * if valid, add to quant request
	 *
	 * if invalid, add to missing asset
	 *
	 * SLYAWS-11742 map currency to let missing asset have one more change to call
	 * again if the portfolio item currency exists in tenant currency map. NOTE: it
	 * supports recall 1 time only, if there is chain mapping, need update logic to
	 * recursive
	 *
	 * @param tenant
	 * @param items
	 * @param assets
	 * @param missingAssets
	 * @param assetsForPortfolio
	 */
	public void queryAssetCodeForPortfolio(String tenant, List<PortfolioItemV2> items, List<Asset> assets,
			List<PortfolioItemV2> missingAssets, List<QuantTransactionPortfolio> assetsForPortfolio,
			PerformanceStressCommonTransformer transformer, CalculationMethod calculationMethod) {

		if (CollectionUtils.isEmpty(items)) {
			return;
		}

		final boolean mapCurrency = TenantServiceConfigUtil.getConfigBooleanValue(tenantContext, TenantServiceEnum.B2B,
				TenantConfigEnum.MAP_CURRENCY, false);
		logger.info("tenant:{} mapCurrency config:{}", tenant, mapCurrency);

		String currencyToRecall = null;
		Map<String, String> currencyMap = null;
		if (mapCurrency) {
			currencyMap = CustomCurrencyMapping.getTenantCurrencyMapping(tenant);
			currencyToRecall = StringUtils.join(new ArrayList<>(currencyMap.keySet()), "|");
		}

		List<PortfolioItemV2> recallList = new ArrayList<>();
		for (PortfolioItemV2 item : items) {
			Asset validCode = queryToGetCorrectAsset(tenant, item, transformer);
			if (validCode == null) {
				if (mapCurrency && currencyToRecall.contains(item.getCurrency())) {
					logger.debug("item currency:{}, value:{} added to recall list", item.getCurrency(),
							item.getValue());
					// prepare to recall
					recallList.add(item);
				} else {
					missingAssets.add(item);
				}
			} else {
				if (assets != null) {
					assets.add(validCode);
				}
				if (calculationMethod == CalculationMethod.ASSET_CLASS) {
					PortfolioItemV2 benchmarkItem = item;
					Asset benchmark = assetDetailsRequest(tenant, validCode.getBenchmarkId());

					if (benchmark != null && !benchmark.getCurrency().equals(validCode.getCurrency())) {
						benchmarkItem.setCurrency(benchmark.getCurrency());
						double fxRate = fxRateRequest(tenant, validCode.getCurrency(), benchmark.getCurrency(), null);
						benchmarkItem.setValue(item.getValue().multiply(API.toBigDecimal(fxRate, 4)));
					}

					assetsForPortfolio.add(transformer.transformToBenchmarkId(validCode, benchmarkItem, cashScheme));
				} else {
					assetsForPortfolio.add(transformer.transform(validCode, item, cashScheme));
				}
			}
		}

		if (!mapCurrency || CollectionUtils.isEmpty(recallList)) {
			return;
		}

		logger.info("calling the second time for asset code for currency mapping");

		for (PortfolioItemV2 item : recallList) {
			// use secondary currency to call again
			PortfolioItemV2 newItem = new PortfolioItemV2();
			BeanUtils.copyProperties(item, newItem);
			newItem.setCurrency(currencyMap.get(item.getCurrency()));

			Asset validCode = queryToGetCorrectAsset(tenant, newItem, transformer);
			if (validCode == null) {
				// not newItem, we need to add user input for missing asset
				missingAssets.add(item);
			} else {
				if (assets != null) {
					assets.add(validCode);
				}
				assetsForPortfolio.add(transformer.transform(validCode, newItem, cashScheme));
				if (calculationMethod == CalculationMethod.ASSET_CLASS) {
					assetsForPortfolio.add(transformer.transformToBenchmarkId(validCode, newItem, cashScheme));
				} else {
					assetsForPortfolio.add(transformer.transform(validCode, newItem, cashScheme));
				}
			}
		}
	}

	/**
	 * input is 1 asset with different scheme, one of them should be valid
	 *
	 * Calling assets to see any response and return any one which exist in our DB
	 * if any
	 *
	 * If no asset can be found, all different scheme variations will call create
	 * asset
	 *
	 * @param tenant
	 * @param item
	 * @return
	 */
	private Asset queryToGetCorrectAsset(String tenant, PortfolioItemV2 item,
			PerformanceStressCommonTransformer transformer) {
		List<AssetCode> assetCodes = transformer.transform(item);
		logger.info("start to query asset for in {} scheme", assetCodes.size());

		String codesRequestStr = null;
		try {
			codesRequestStr = objectMapper.writeValueAsString(assetCodes);
		} catch (JsonProcessingException e) {
			logger.error("failed to parse assetCode:{} to query", assetCodes);
		}
		final List<Asset> assetsOfPortfolio = assetsCodesRequestV2(tenant, codesRequestStr);

		if (CollectionUtils.isEmpty(assetsOfPortfolio)) {
			logger.info("no asset can be found for portfolio item");
			return null;
		}

		return assetsOfPortfolio.get(0);
	}

	/**
	 * Query assets service to get assets id from codes.
	 *
	 * @param tenant
	 * @param body
	 * @return
	 */
	public List<Asset> assetsCodesRequestV2(final String tenant, final String body) {
		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(assets, EndPoints.ASSETS_1_CODES, tenant,
				body, HttpMethod.POST, this.tenantContext, true);

		if (!response.getStatusCode().is2xxSuccessful()) {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		final String responseBody = response.getBody();
		try {
			return objectMapper.readValue(responseBody, new TypeReference<List<Asset>>() {
			});
		} catch (IOException e) {
			logger.error("failed to parse asset from string response");
		}
		return null;
	}

	/**
	 * Query assets service to get asset details from id.
	 *
	 * @param tenant
	 * @param assetId
	 * @return
	 */
	public Asset assetDetailsRequest(final String tenant, final String assetId) {

		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(this.assets)
				.path(EndPoints.ASSETS_1_ASSET);
		final URI uri = builder.buildAndExpand(tenant, assetId).encode().toUri();
		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, null, HttpMethod.GET, null,
				true);

		if (!response.getStatusCode().is2xxSuccessful()) {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		try {
			return objectMapper.readValue(response.getBody(), new TypeReference<Asset>() {
			});
		} catch (IOException e) {
			logger.error("failed to parse asset from string response");
		}

		return null;
	}

	/**
	 * Query assets service to get FX details from currency pair.
	 *
	 * @param tenant
	 * @param currency1
	 * @param currency2
	 * @param requestDate
	 * @return
	 */
	public Double fxRateRequest(String tenant, String currency1, String currency2, String requestDate) {
		Double fxrate = null;

		final String fxDate = requestDate != null ? requestDate : LocalDate.now().format(DATE_TO_STRING);

		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(this.assets)
				.path(EndPoints.ASSETS_1_CURRENCY_CONVERSION);
		builder.queryParam("date", fxDate);

		String isoCurrencyPair = currency1 + currency2;
		final URI uri = builder.buildAndExpand(tenant, isoCurrencyPair).encode().toUri();

		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(uri, tenant, null, HttpMethod.GET, null,
				true);

		if (response.getStatusCode().is2xxSuccessful()) {
			final String responseBody = response.getBody();
			JsonObject responseObject = API.parseObject(responseBody);
			final JsonNumber jsonFx = responseObject.getJsonNumber("fx-rate");

			if (jsonFx == null) {
				throw new RuntimeException(String.format(
						"Issue while fetching fxrate from assets service (isoCurrencyPair,requestDate) = (%s,%s)",
						isoCurrencyPair, fxDate));
			} else {
				fxrate = jsonFx.doubleValue();
			}
		}

		return fxrate;
	}

}
