package com.privemanagers.b2b.controller.dual;

import java.util.Map;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.api.API;
import com.privemanagers.api.EndPoints;
import com.privemanagers.b2b.controller.dual.model.DualSeriesRequest;
import com.privemanagers.b2b.service.B2BService;

/**
 * @author wzhang
 * @date 26 Oct 2018
 * @company Prive Financial
 */
@RestController
public class DualSeriesController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private B2BService b2bService;

	@Autowired
	private ObjectMapper objectMapper;

	@PreAuthorize("hasCustomAuthority(#tenant)")
	@PostMapping(value = EndPoints.B2B_1_DUAL_SERIES, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Callable<ResponseEntity<String>> dualSeries(final HttpServletRequest request,
			@PathVariable("tenant") final String tenant, @Validated @RequestBody final DualSeriesRequest body,
			@RequestHeader final Map<String, String> header) {

		return () -> {
			API.setMDC(tenant, request);
			String requestBodyStr = objectMapper.writeValueAsString(body);
			logger.info("{} {}\nheaders {}\nbody {}", request.getMethod(), request.getRequestURI(), header,
					requestBodyStr);

			final ResponseEntity<String> response = b2bService.dualSeries(tenant, body);
			MDC.clear();
			return response;
		};
	}
}
