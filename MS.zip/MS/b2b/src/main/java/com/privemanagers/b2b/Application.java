package com.privemanagers.b2b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.cc.config.ConcurrencyCommonDefaultConfiguration;
import com.privemanagers.sc.configuration.SharedAutoConfiguration;

@SpringBootApplication(scanBasePackages = "com.privemanagers")
@Import({ SharedAutoConfiguration.class, ConcurrencyCommonDefaultConfiguration.class })
@EnableCaching
public class Application {

	public static final String RESOURCE_ID = "b2b";

	public static void main(final String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public ObjectMapper objectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper;
	}

}
