package com.privemanagers.b2b.service.common;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.privemanagers.api.API;
import com.privemanagers.api.ValueCurrencyType;
import com.privemanagers.b2b.controller.model.PortfolioAssetIdentifier;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;

/**
 * Common validation for Performance and stress request
 *
 * @author Kay Ip
 * @date 10 May 2018
 * @company Prive Financial
 */
public class PerformanceStressCommonValidator {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private final String cashScheme;

	public PerformanceStressCommonValidator(String cashScheme) {
		this.cashScheme = cashScheme;
	}

	public void validatePortfolio(List<PortfolioItemV2> portfolioItems) {
		if (CollectionUtils.isEmpty(portfolioItems)) {
			throw new IllegalArgumentException();
		}

		for (final PortfolioItemV2 holding : portfolioItems) {
			if (holding.getValue() == null || holding.getValue().compareTo(BigDecimal.ZERO) < 0) {
				throw new IllegalArgumentException();
			}

			List<PortfolioAssetIdentifier> identifiers = holding.getAssetIdentifiers();
			for (PortfolioAssetIdentifier identifier : identifiers) {
				if (StringUtils.isBlank(identifier.getAssetCode())) {
					throw new IllegalArgumentException();
				}
				if (StringUtils.isBlank(identifier.getAssetCodeScheme())) {
					throw new IllegalArgumentException();
				}
				if (!cashScheme.equals(identifier.getAssetCodeScheme())) {
					if (holding.getCurrency() == null || !API.validateCurrencyCode(holding.getCurrency())) {
						throw new IllegalArgumentException();
					}
				}
			}
		}
	}

	public void validateValueCurrencyType(String valueCurrencyStr) {
		if (StringUtils.isBlank(valueCurrencyStr)) {
			return;
		}

		boolean valid = EnumUtils.isValidEnum(ValueCurrencyType.class, valueCurrencyStr.toUpperCase());
		if (!valid) {
			logger.warn("value-currency:{} is invalid", valueCurrencyStr);
			throw new IllegalArgumentException();
		}
	}

}
