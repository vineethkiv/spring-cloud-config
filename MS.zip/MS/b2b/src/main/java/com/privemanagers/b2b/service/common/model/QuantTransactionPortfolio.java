package com.privemanagers.b2b.service.common.model;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Quant transaction portfolio, part of QuantPortfolioRequest
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class QuantTransactionPortfolio {
    @JsonProperty("asset-id")
    private String assetId;
    private BigDecimal value;

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }
}