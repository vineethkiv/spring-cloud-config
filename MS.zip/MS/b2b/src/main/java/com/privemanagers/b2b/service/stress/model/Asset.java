package com.privemanagers.b2b.service.stress.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Asset
 *
 * @author Kay Ip
 * @date 6 Feb 2018
 * @company Prive Financial
 */
public class Asset {
	@JsonProperty("asset-id")
	private String assetId;
	private Map<String, String> name;
	@JsonProperty("cfi-code")
	private String cfiCode;
	private String type;
	private String region;
	private String assetclass;
	private String sector;
	private String scheme;
	private String value;
	private String currency;
	@JsonProperty("inception-date")
	private String inceptionDate;
	
	@JsonProperty("benchmark-id")
	private String benchmarkId;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAssetclass() {
		return assetclass;
	}

	public void setAssetclass(String assetclass) {
		this.assetclass = assetclass;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public Map<String, String> getName() {
		return name;
	}

	public void setName(Map<String, String> name) {
		this.name = name;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getCfiCode() {
		return cfiCode;
	}

	public void setCfiCode(String cfiCode) {
		this.cfiCode = cfiCode;
	}

	public String getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(String inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public String getBenchmarkId() {
		return benchmarkId;
	}

	public void setBenchmarkId(String benchmarkId) {
		this.benchmarkId = benchmarkId;
	}
	
}
