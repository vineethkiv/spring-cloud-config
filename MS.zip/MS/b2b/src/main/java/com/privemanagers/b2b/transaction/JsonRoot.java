package com.privemanagers.b2b.transaction;

import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;

/**
 * The root of the JSON structure.
 *
 */
public class JsonRoot extends JsonNode {

	@Override
	public void build(final JsonObjectBuilder builder, final JsonBuilderFactory factory) {
		for (JsonContent content : this.list) {
			content.build(builder, factory);
		}
	}

	@Override
	public void build(final JsonArrayBuilder builder, final JsonBuilderFactory factory) {
		for (JsonContent content : this.list) {
			content.build(builder, factory);
		}
	}

}
