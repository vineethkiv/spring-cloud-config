package com.privemanagers.b2b.controller.stress.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Base request fields for stress api
 *
 * @author Kay Ip
 * @date 7 May 2018
 * @company Prive Financial
 */
public abstract class StressRequestBase {

	@JsonProperty("reference-currency")
	private String referenceCurrency;

	@JsonProperty("value-currency")
	private String valueCurrency;

	private String model;

	private DateRange crisis;

	private DateRange recovery;

	private List<String> statistics;

	private List<String> benchmarks;

	@JsonProperty("use-earliest-common-date")
	private Boolean useEarliestCommonDate;

	@JsonProperty("use-latest-common-date")
	private Boolean useLatestCommonDate;

	public String getReferenceCurrency() {
		return referenceCurrency;
	}

	public void setReferenceCurrency(String referenceCurrency) {
		this.referenceCurrency = referenceCurrency;
	}

	public String getValueCurrency() {
		return valueCurrency;
	}

	public void setValueCurrency(String valueCurrency) {
		this.valueCurrency = valueCurrency;
	}

	public DateRange getCrisis() {
		return crisis;
	}

	public void setCrisis(DateRange crisis) {
		this.crisis = crisis;
	}

	public DateRange getRecovery() {
		return recovery;
	}

	public void setRecovery(DateRange recovery) {
		this.recovery = recovery;
	}

	public List<String> getStatistics() {
		return statistics;
	}

	public void setStatistics(List<String> statistics) {
		this.statistics = statistics;
	}

	public List<String> getBenchmarks() {
		return benchmarks;
	}

	public void setBenchmarks(List<String> benchmarks) {
		this.benchmarks = benchmarks;
	}

	public Boolean getUseEarliestCommonDate() {
		return useEarliestCommonDate;
	}

	public void setUseEarliestCommonDate(Boolean useEarliestCommonDate) {
		this.useEarliestCommonDate = useEarliestCommonDate;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Boolean getUseLatestCommonDate() {
		return useLatestCommonDate;
	}

	public void setUseLatestCommonDate(Boolean useLatestCommonDate) {
		this.useLatestCommonDate = useLatestCommonDate;
	}
}
