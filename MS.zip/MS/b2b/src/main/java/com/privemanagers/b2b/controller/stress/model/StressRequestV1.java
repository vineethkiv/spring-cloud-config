package com.privemanagers.b2b.controller.stress.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.b2b.controller.model.PortfolioItemV1;

/**
 * Stress api v1 request
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class StressRequestV1 extends StressRequestBase {

    @JsonProperty("current-portfolio")
    private List<PortfolioItemV1> currentPortfolio;

    @JsonProperty("proposed-portfolio")
    private List<PortfolioItemV1> proposedPortfolio;

    public List<PortfolioItemV1> getCurrentPortfolio() {
        return currentPortfolio;
    }

    public void setCurrentPortfolio(List<PortfolioItemV1> currentPortfolio) {
        this.currentPortfolio = currentPortfolio;
    }

    public List<PortfolioItemV1> getProposedPortfolio() {
        return proposedPortfolio;
    }

    public void setProposedPortfolio(List<PortfolioItemV1> proposedPortfolio) {
        this.proposedPortfolio = proposedPortfolio;
    }
}
