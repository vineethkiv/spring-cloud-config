package com.privemanagers.b2b.service.common;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.privemanagers.b2b.exception.ExchangeMappingNotFoundException;

/**
 * Currency code mapping per tenant
 *
 * @author Kay Ip
 * @date 7 May 2018
 * @company Prive Financial
 */
public class CustomCurrencyMapping {

	/**
	 * Get currency mapping according to tenant
	 *
	 * @param tenant
	 * @return
	 */
	public static Map<String, String> getTenantCurrencyMapping(String tenant) {
		if (!tenantCurrencyMap.containsKey(tenant)) {
			throw new ExchangeMappingNotFoundException(tenant);
		}
		return tenantCurrencyMap.get(tenant);
	}

	// mapping of citi currency code
	private static final Map<String, String> citiMap;
	static {
		Map<String, String> map = new HashMap<>();
		map.put("CNH", "CNY");
		map.put("CNY", "CNH");
		citiMap = Collections.unmodifiableMap(map);
	}

	// map of tenant and their currency code mapping
	private static final Map<String, Map<String, String>> tenantCurrencyMap;
	static {
		Map<String, Map<String, String>> map = new HashMap<>();
		map.put("citi-hk", citiMap);
		map.put("citi-sg-gcg", citiMap);
		map.put("citi-sg-ipb", citiMap);
		map.put("citi-uk", citiMap);
		map.put("citi-tw", citiMap);
		map.put("citi-cn", citiMap);
		map.put("citi-kr", citiMap);
		tenantCurrencyMap = Collections.unmodifiableMap(map);
	}

}
