package com.privemanagers.b2b.service.common;

import java.util.List;

import com.privemanagers.b2b.controller.stress.model.DateRange;
import com.privemanagers.b2b.service.stress.model.Asset;

/**
 * common service to contain all the shared util helper methods
 *
 * @author wzhang
 * @date 9 Nov 2018
 * @company Prive Financial
 */
public interface ICommonService {

	/**
	 * pre process date
	 *
	 * @param dateRange
	 * @param assets
	 * @param useEarliestCommonDate
	 * @return
	 */
	public String[] preProcessDate(String tenant, DateRange dateRange, List<Asset> assets,
			boolean useEarliestCommonDate, boolean useLatestCommonDate);
}
