package com.privemanagers.b2b.controller.performance.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.b2b.controller.model.PortfolioItemV1;

/**
 * Performance api v1 request
 *
 * @author Kay Ip
 * @date 8 May 2018
 * @company Prive Financial
 */
public class PerformanceRequestV1 extends PerformanceRequestBase {

    @JsonProperty("current-portfolio")
    private List<PortfolioItemV1> currentPortfolio;

    public List<PortfolioItemV1> getCurrentPortfolio() {
        return currentPortfolio;
    }

    public void setCurrentPortfolio(List<PortfolioItemV1> currentPortfolio) {
        this.currentPortfolio = currentPortfolio;
    }
}
