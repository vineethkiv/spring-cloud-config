package com.privemanagers.b2b.transaction;

import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;

/**
 * Anything that can be included in a JSON structure.
 *
 */
public interface JsonContent {

	/**
	 * Build this content into the given object.
	 * 
	 * @param builder
	 * @param factory
	 */
	public void build(JsonObjectBuilder builder, JsonBuilderFactory factory);

	/**
	 * Build this content into the given array.
	 * 
	 * @param builder
	 * @param factory
	 */
	public void build(JsonArrayBuilder builder, JsonBuilderFactory factory);

}
