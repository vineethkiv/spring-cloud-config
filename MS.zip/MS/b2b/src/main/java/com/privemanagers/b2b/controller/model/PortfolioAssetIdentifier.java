package com.privemanagers.b2b.controller.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Asset Identifier
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class PortfolioAssetIdentifier {

	@JsonProperty("asset-code")
	private String assetCode;

	@JsonProperty("asset-code-scheme")
	private String assetCodeScheme;

	public String getAssetCode() {
		return assetCode;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public String getAssetCodeScheme() {
		return assetCodeScheme;
	}

	public void setAssetCodeScheme(String assetCodeScheme) {
		this.assetCodeScheme = assetCodeScheme;
	}
}
