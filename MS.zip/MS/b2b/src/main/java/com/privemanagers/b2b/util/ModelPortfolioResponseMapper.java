package com.privemanagers.b2b.util;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import org.springframework.util.CollectionUtils;

import com.privemanagers.api.API;
import com.privemanagers.b2b.field.FieldName;

/**
 * Standard Utils to map a JSON String to a response object
 *
 * @author William Zhang
 * @date 16 Nov 2017
 * @company Prive Financial
 */
public final class ModelPortfolioResponseMapper {

	private static final DateTimeFormatter ASSETS_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");
	private static final DateTimeFormatter TIME_SERIES_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	/**
	 * Map the given JSON String to a Model Portfolio response structure
	 *
	 * @param inJsonString
	 * @param inTenantScheme
	 * @return
	 */
	public static String mapModelPortfolioObject(final String inJsonString, final String inTenantScheme) {
		final JsonObject document = API.parseObject(inJsonString);
		final JsonObjectBuilder builder = mapModelPortfolioObjectToObjectBuilder(document, inTenantScheme);
		if (builder != null) {
			return builder.build().toString();
		}
		return null;
	}

	public static JsonArrayBuilder parseTimeSeries(final String inJsonString) throws ParseException {

		final JsonBuilderFactory jsonBuilderFactory = API.makeJsonBuilderFactory();
		final JsonArrayBuilder pricesArray = jsonBuilderFactory.createArrayBuilder();

		final JsonObject document = API.parseObject(inJsonString);
		final JsonArray prices = document.getJsonArray(FieldName.PRICES);
		if (CollectionUtils.isEmpty(prices)) {
			return pricesArray;
		}
		for (final JsonValue price : prices) {
			final JsonObjectBuilder element = jsonBuilderFactory.createObjectBuilder();
			final JsonObject priceObject = (JsonObject) price;

			element.add(FieldName.MONTH, parseIntDate(API.getIntValue(priceObject, FieldName.LOCAL_DATE)));
			element.add(FieldName.VALUE, API.getDoubleValue(priceObject, FieldName.CLOSE_PX));
			pricesArray.add(element);
		}
		return pricesArray;

	}

	/**
	 * SLYAWS-12618 is last NAV value equals to 0
	 *
	 * @param inJsonString
	 * @throws ParseException
	 */
	public static boolean checkLastRecord(final String inJsonString) {
		final JsonObject document = API.parseObject(inJsonString);
		final JsonArray prices = document.getJsonArray(FieldName.PRICES);
		if (CollectionUtils.isEmpty(prices)) {
			return false;
		}

		JsonObject lastItem = prices.getJsonObject(prices.size() - 1);
		Double value = lastItem.getJsonNumber(FieldName.CLOSE_PX).doubleValue();
		return Double.valueOf(0d).equals(value);
	}

	private static String parseIntDate(final int inDate) {
		LocalDate date = LocalDate.parse(String.valueOf(inDate), ASSETS_FORMAT);
		String formatedDate = TIME_SERIES_FORMAT.format(date);
		return formatedDate;

	}

	/**
	 * Map the given JSON String to a Model Portfolio response structure
	 *
	 * @param document
	 * @param inTenantScheme
	 * @return
	 */
	public static JsonObjectBuilder mapModelPortfolioObjectToObjectBuilder(final JsonObject document,
			final String inTenantScheme) {

		if (document != null) {
			final JsonBuilderFactory jsonBuilderFactory = API.makeJsonBuilderFactory();
			final JsonObjectBuilder builder = jsonBuilderFactory.createObjectBuilder();

			for (String attributeKey : document.keySet()) {
				if (!PortfolioField.shouldExclude(attributeKey)) {
					try {
						final PortfolioField portfolioField = PortfolioField
								.toPortfolioField(attributeKey.toUpperCase());
						String writeKey = attributeKey;
						if (portfolioField != null) {
							writeKey = portfolioField.getFieldName();
						}
						document.get(attributeKey).getValueType();
						final JsonValue jsonValue = document.get(attributeKey);
						switch (jsonValue.getValueType()) {
						case STRING:
							addStringValue(writeKey, document.getString(attributeKey), builder);
							break;
						case NUMBER:
							addNumberValue(writeKey, document.getJsonNumber(attributeKey), builder);
							break;
						case OBJECT:
							addObjectValue(writeKey, document.getJsonObject(attributeKey), builder);
							break;
						case ARRAY:
							if (portfolioField != null) {
								final JsonArray jsonArray = document.getJsonArray(attributeKey);
								addArrayValue(writeKey, jsonArray, builder, jsonBuilderFactory, inTenantScheme);
							}
							break;
						default:
							break;
						}
					} catch (Exception e) {
						throw e;
					}
				}
			}
			return builder;
		}
		return null;
	}

	private static void addStringValue(final String inKey, final String inValue,
			final JsonObjectBuilder inObjectBuilder) {
		inObjectBuilder.add(inKey, inValue);
	}

	private static void addObjectValue(final String inKey, final JsonObject inValue,
			final JsonObjectBuilder inObjectBuilder) {
		inObjectBuilder.add(inKey, inValue);
	}

	private static void addNumberValue(final String inKey, final JsonNumber inValue,
			final JsonObjectBuilder inObjectBuilder) {
		if (inValue.isIntegral()) {
			inObjectBuilder.add(inKey, inValue.intValue());
		} else {
			inObjectBuilder.add(inKey, inValue.doubleValue());
		}
	}

	private static void addAssetScheme(final JsonObject inJsonObject, final String inTenantScheme,
			final JsonObjectBuilder inBuilder) {
		final String scheme = inJsonObject.getString(PortfolioField.SCHEME.toString().toLowerCase());
		if (scheme != null) {
			final String schemeValue = inJsonObject.getString(PortfolioField.VALUE.toString().toLowerCase());
			if ((scheme.equalsIgnoreCase(PortfolioField.ISIN.getFieldName()))) {
				inBuilder.add(PortfolioField.ISIN.getFieldName(), schemeValue);
			} else if ((scheme.equalsIgnoreCase(inTenantScheme))) {
				inBuilder.add(PortfolioField.TENANT_CODE.getFieldName(), schemeValue);
			}
		}
	}

	private static void addArrayValue(final String inKey, final JsonArray inJsonArray,
			final JsonObjectBuilder inObjectBuilder, final JsonBuilderFactory inJsonBuilderFactory,
			final String inTenantScheme) {
		final JsonArrayBuilder arrayBuilder = inJsonBuilderFactory.createArrayBuilder();
		for (int i = 0; i < inJsonArray.size(); i++) {
			final JsonObject object = inJsonArray.getJsonObject(i);
			final JsonObjectBuilder nestedBuilder = inJsonBuilderFactory.createObjectBuilder();

			for (String attributeKey : object.keySet()) {
				if (!PortfolioField.shouldExclude(attributeKey)) {
					try {
						final PortfolioField portfolioField = PortfolioField
								.toPortfolioField(attributeKey.toUpperCase());

						final JsonValue jsonValue = object.get(attributeKey);
						switch (jsonValue.getValueType()) {
						case STRING:
							addStringValue(attributeKey, object.getString(attributeKey), nestedBuilder);
							break;
						case NUMBER:
							addNumberValue(attributeKey, object.getJsonNumber(attributeKey), nestedBuilder);
							break;
						case OBJECT:
							addObjectValue(attributeKey, object.getJsonObject(attributeKey), nestedBuilder);
							break;
						case ARRAY:
							if (portfolioField != null
									&& attributeKey.equalsIgnoreCase(PortfolioField.ASSET_CODES.getFieldName())) {
								final JsonArray jsonArray = object.getJsonArray(attributeKey);
								for (int j = 0; j < jsonArray.size(); j++) {
									JsonObject arrayObject = jsonArray.getJsonObject(j);
									addAssetScheme(arrayObject, inTenantScheme, nestedBuilder);
								}
							}
							break;
						default:
							break;
						}
					} catch (Exception e) {
						throw e;
					}
				}
			}
			arrayBuilder.add(nestedBuilder);
		}
		inObjectBuilder.add(inKey, arrayBuilder);
	}
}
