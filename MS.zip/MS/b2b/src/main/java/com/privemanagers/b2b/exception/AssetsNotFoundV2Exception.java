package com.privemanagers.b2b.exception;

import java.util.List;

import com.privemanagers.b2b.controller.model.PortfolioItemV2;

/**
 * Asset not found exception v2
 * 
 * no business logic here and accepting PortfolioItemV2 instead of Json array
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class AssetsNotFoundV2Exception extends Exception {

	private static final long serialVersionUID = 7572426060902389886L;

	private List<PortfolioItemV2> missingAssets;

	public AssetsNotFoundV2Exception(final List<PortfolioItemV2> assetCodes) {
		this.missingAssets = assetCodes;
	}

	public List<PortfolioItemV2> getMissingAssets() {
		return missingAssets;
	}

	public void setMissingAssets(List<PortfolioItemV2> missingAssets) {
		this.missingAssets = missingAssets;
	}
}
