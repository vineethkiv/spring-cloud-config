package com.privemanagers.b2b.field;

/**
 * @author nteck
 * @date : 20 Apr, 2017
 * @company Prive Financial
 */
public final class FieldName {

	public static final String MONTHS = "months";
	public static final String MISSING_ASSETS = "missing-assets";
	public static final String PORTFOLIO = "portfolio";
	public static final String CURRENT_PORTFOLIO = "current-portfolio";
	public static final String PROPOSED_PORTFOLIO = "proposed-portfolio";
	public static final String MODEL = "model";
	public static final String ASSET_ID = "asset-id";
	public static final String FROM = "from";
	public static final String UNTIL = "until";
	public static final String REBALANCE_EVERY = "rebalance-every";
	public static final String RELATIVE = "relative";
	public static final String STATISTICS = "statistics";
	public static final String CRISIS = "crisis";
	public static final String RECOVERY = "recovery";
	public static final String BENCHMARKS = "benchmarks";
	public static final String BENCHMARK = "benchmark";
	public static final String USE_EARLIEST_COMMON_DATE = "use-earliest-common-date";

	public static final String REFERENCE_CURRENCY = "reference-currency";
	public static final String ASSET_CODE = "asset-code";
	public static final String ASSET_CODE_SCHEME = "asset-code-scheme";
	public static final String ASSET_CURRENCY = "asset-currency";
	public static final String ASSET_PRICE = "price";
	public static final String CASH_CODE = "cash-code";

	public static final String ASSET_MIN_INVESTMENT = "min-investment";
	public static final String ASSET_MIN_SUB_INVESTMENT = "min_subsequent_subscription_amt";
	public static final String ASSET_MIN_REDEMPTION_UNITS = "min-redemption-units";
	public static final String ASSET_MIN_REDEMPTION_HOLDING_UNITS = "min-redemption-holding-units";

	public static final String NAME = "name";
	public static final String ALLOCATION = "allocation";
	public static final String WEIGHT = "weight";
	public static final String SCHEME = "scheme";
	public static final String VALUE = "value";
	public static final String AMOUNT = "amount";
	public static final String CURRENCY = "currency";
	public static final String CFI_CODE = "cfi-code";
	public static final String TENANTS = "tenants";

	public static final String DATE = "date";
	public static final String FX = "fx";
	public static final String FXS = "fxs";
	public static final String FX_RATE = "fx-rate";
	public static final String INCEPTION_DATE = "inception-date";
	public static final String LOCAL_DATE = "local-date";
	public static final String PRICES = "prices";
	public static final String CLOSE_PX = "close-px";
	public static final String SERIES = "series";
	public static final String MONTH = "month";

	public static final String CFI_CODE_MODEL_PORTFOLIO = "TBXXXX";

	// opt
	public static final String ID = "id";
	public static final String GOAL = "goal";
	public static final String GOALS = "goals";
	public static final String GOAL_ID = "goal-id";
	public static final String ASSETS = "assets";
	public static final String CUSTOM = "custom";
	public static final String FITNESS = "fitness";
	public static final String FROZEN = "frozen";
	public static final String SESSION = "session";
	public static final String SESSION_ID = "session-id";
	public static final String FUNCTION = "function";
	public static final String VALUE_IS_WEIGHT = "value-is-weight";
	public static final String RETURN_AS_WEIGHT = "return-as-weight";
	public static final String PREFERRED_ASSETS = "preferred-assets";
	public static final String PROPOSED_HOLDINGS = "proposed-holdings";
	public static final String PROPOSED_TRANSACTIONS = "proposed-transactions";
	public static final String REBALANCE_STATUS = "rebalance-status";
	public static final String OPTIMISE = "optimise";
	public static final String RETURN = "return";
	public static final String VOLATILITY = "volatility";
	public static final String SHARPE = "sharpe";
	public static final String TOTAL_FITNESS_SCORE = "total-fitness-score";
	public static final String SCORE = "score";
	public static final String CURRENT_GOALS = "current-goals";
	public static final String PROPOSED_GOALS = "proposed-goals";
	public static final String ASSET_TYPE = "asset-type";
	public static final String ACCOUNT_ID = "account-id";
	public static final String PREFERRED_CURRENCIES = "preferred-currencies";
	public static final String REFERENCE_PORTFOLIO = "reference-portfolio";
	public static final String CONCENTRATION_THRESHOLDS = "concentration-thresholds";
	public static final String MODEL_PORTFOLIO = "model-portfolio";
	public static final String ANNUALIZED_RETURN = "annualized-return";
	public static final String RISK = "risk";
	public static final String ELIGIBLE_CASH = "eligible-cash";

	// Field name used to build rebalancer ms request/response json
	public static final String REBALANCER_RESP_HOLDINGS = "targetHoldings";
	public static final String REBALANCER_RESP_POSITIONS = "positions";
	public static final String REBALANCER_ASSET_TYPE = "assetType";
	public static final String REBALANCER_ASSET_ID = "assetId";
	public static final String REBALANCER_ASSET_CCY = "currency";
	public static final String REBALANCER_SCHEME = "scheme";
	public static final String REBALANCER_VFUND_ID = "vFundID";
	public static final String REBALANCER_ACCOUNT_ID = "subAccountID";
	public static final String REBALANCER_VALUE = "value";

	public static final String REBALANCER_MIN_HOLDING_QTY = "minHoldingQty";
	public static final String REBALANCER_MIN_SELL_QTY = "minSellQty";
	public static final String REBALANCER_MIN_INITIAL_BUY_VALUE = "minInitialBuyValue";
	public static final String REBALANCER_MIN_SUBSEQUENT_BUY_VALUE = "minSubsequentBuyValue";

	public static final String REBALANCER_TRANSACTIONS = "orders";
	public static final String REBALANCER_ASSIGNMENTS = "assignment";
	public static final String REBALANCER_ACTION_ORDER = "side";
	public static final String REBALANCER_ACTION_ASSIGN = "direction";

	public static final String HEADER_KEY_API_USERNAME = "prive-api-username";
	public static final String HEADER_KEY_API_PASSWORD = "prive-api-password"; // NOSONAR
	public static final String KEY_USERNAME = "username";
	public static final String KEY_PASSWORD = "password"; // NOSONAR
	public static final String BEARER_TOKEN_PREFIX = "Bearer ";
	public static final String DEVELOPER_BYPASS_CHECK = "chelski_849";
	public static final String AUTHORIZATION = "Authorization";
	public static final String ACCESS_TOKEN = "access-token";

	// dual
	public static final String BENCHMARK_ID = "benchmark-id";

	private FieldName() {

	}

}
