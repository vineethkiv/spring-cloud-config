package com.privemanagers.b2b.service.external.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

/**
 * response for asset ms get price
 *
 * @author Kay Ip
 * @date 11 Jun 2018
 * @company Prive Financial
 */
public class AssetPriceResponse {
	@JsonProperty("asset-id")
	private String assetId;
	private String currency;
	private TimeSeries price;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public TimeSeries getPrice() {
		return price;
	}

	public void setPrice(TimeSeries price) {
		this.price = price;
	}

	public class TimeSeries {
		@JsonProperty("local-date")
		private Integer localDate;

		@JsonProperty("close-px")
		private BigDecimal closePx;

		public Integer getLocalDate() {
			return localDate;
		}

		public void setLocalDate(Integer localDate) {
			this.localDate = localDate;
		}

		public BigDecimal getClosePx() {
			return closePx;
		}

		public void setClosePx(BigDecimal closePx) {
			this.closePx = closePx;
		}
	}
}
