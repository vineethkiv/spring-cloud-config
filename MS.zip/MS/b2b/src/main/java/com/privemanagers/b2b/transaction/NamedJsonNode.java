package com.privemanagers.b2b.transaction;

/**
 * A structure which is named.
 *
 */
public abstract class NamedJsonNode extends JsonNode {

	protected final String name;

	public NamedJsonNode(final String name) {
		this.name = name;
	}

}
