package com.privemanagers.b2b.util;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.privemanagers.b2b.controller.model.PortfolioAssetIdentifier;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.service.common.CustomExchangeCodeMapping;
import com.privemanagers.model.mds.AssetScheme;

/**
 * Portfolio Util
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@Component
public class PortfolioUtil {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * SLYAWS-11741 do exchange mapping
	 *
	 * if code scheme is symbol, map mic code according to tenant
	 *
	 * @param tenant
	 * @param portfolioItems
	 */
	public void preProcessPortfolioMicCode(String tenant, List<PortfolioItemV2> portfolioItems) {
		logger.info("begin portfolio mic code mapping process");
		Map<String, String> exchangeMap = CustomExchangeCodeMapping.getTenantExchangeCodeMapping(tenant);
		for (PortfolioItemV2 item : portfolioItems) {
			List<PortfolioAssetIdentifier> identifiers = item.getAssetIdentifiers();
			for (PortfolioAssetIdentifier identifier : identifiers) {
				if (!AssetScheme.SYMBOL.toString().equals(identifier.getAssetCodeScheme())) {
					logger.debug("code scheme:{} is not symbol, skip to next assetIdentifier",
							identifier.getAssetCodeScheme());
					continue;
				}

				String[] symbolCodeAndMic = identifier.getAssetCode().split("\\.");
				if (symbolCodeAndMic.length != 2) {
					logger.debug("format of symbol:{} is invalid, cannot extract mic code, skip to next",
							identifier.getAssetCode());
					continue;
				}
				String inputMic = symbolCodeAndMic[1];
				if (!exchangeMap.containsKey(inputMic)) {
					logger.debug("no mapping for mic:{}, skip to next", inputMic);
					continue;
				}

				String mappedMic = exchangeMap.get(inputMic);
				String processedSymbolAndMic = symbolCodeAndMic[0];
				/*
				 * empty mapped mic means xignite no need mic code for that
				 * symbol e.g. input "GOOG.NASD", xignite needs "GOOG" only
				 */
				if (StringUtils.isNotBlank(mappedMic)) {
					processedSymbolAndMic = processedSymbolAndMic.concat(".").concat(mappedMic);
				}
				identifier.setAssetCode(processedSymbolAndMic);
			}
		}
		logger.info("completed portfolio mic code mapping process");
	}
}
