package com.privemanagers.b2b.service;

import java.util.concurrent.CountDownLatch;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.StringUtils;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.AsyncTransaction;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.sc.util.SecuredRestHelper;

/**
 * @author nteck
 * @date 19 Dec 2017
 * @company Prive Financial
 */
public class FXTransaction extends AsyncTransaction {

	private final String currencyPair;
	private final String date;

	public FXTransaction(final CountDownLatch latch, final TenantContext tenantContext, final String baseURL,
			final String tenant, final String currencyPair, final String date) {
		super(latch, tenantContext);
		this.currencyPair = currencyPair;
		this.date = date;

		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseURL)
				.path(EndPoints.ASSETS_1_CURRENCY_CONVERSION);

		if (StringUtils.hasText(this.date)) {
			builder.queryParam(FieldName.DATE, this.date);
		}

		this.uri(builder.buildAndExpand(tenant, this.currencyPair).toUri());
	}

	@Override
	public void send(final ThreadPoolTaskExecutor executor) {
		final ListenableFuture<ResponseEntity<String>> future = SecuredRestHelper.sendRequest(executor, this.uri(),
				null, null, HttpMethod.GET, this.tenantContext(), true);
		future.addCallback(this);
	}

	public String getCurrencyPair() {
		return this.currencyPair;
	}

}
