package com.privemanagers.b2b.controller.stress.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.field.CalculationMethod;

/**
 * Stress api v2 request
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class StressRequestV2 extends StressRequestBase {

	@JsonProperty("current-portfolio")
	private List<PortfolioItemV2> currentPortfolio;

	@JsonProperty("proposed-portfolio")
	private List<PortfolioItemV2> proposedPortfolio;

	@JsonProperty("ror-method")
	private CalculationMethod rorMethod = CalculationMethod.INSTRUMENT;

	@JsonProperty("volatility-method")
	private CalculationMethod volatilityMethod = CalculationMethod.INSTRUMENT;

	public List<PortfolioItemV2> getCurrentPortfolio() {
		return currentPortfolio;
	}

	public void setCurrentPortfolio(List<PortfolioItemV2> currentPortfolio) {
		this.currentPortfolio = currentPortfolio;
	}

	public List<PortfolioItemV2> getProposedPortfolio() {
		return proposedPortfolio;
	}

	public void setProposedPortfolio(List<PortfolioItemV2> proposedPortfolio) {
		this.proposedPortfolio = proposedPortfolio;
	}

	public CalculationMethod getRorMethod() {
		return rorMethod;
	}

	public void setRorMethod(CalculationMethod rorMethod) {
		this.rorMethod = rorMethod;
	}

	public CalculationMethod getVolatilityMethod() {
		return volatilityMethod;
	}

	public void setVolatilityMethod(CalculationMethod volatilityMethod) {
		this.volatilityMethod = volatilityMethod;
	}

}
