package com.privemanagers.b2b.service;

import java.net.URI;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.api.API;
import com.privemanagers.api.AsyncTransaction;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.api.config.tenant.TenantConfigEnum;
import com.privemanagers.api.config.tenant.TenantServiceConfigUtil;
import com.privemanagers.api.config.tenant.TenantServiceEnum;
import com.privemanagers.api.util.MixpanelUtil;
import com.privemanagers.api.util.RestHelper;
import com.privemanagers.b2b.controller.dual.model.AssetIdentifier;
import com.privemanagers.b2b.controller.dual.model.DualSeriesRequest;
import com.privemanagers.b2b.controller.dual.model.QuantDualSeriesRequest;
import com.privemanagers.b2b.controller.dual.model.Shift;
import com.privemanagers.b2b.controller.stress.model.DateRange;
import com.privemanagers.b2b.exception.AssetsNotFoundException;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.b2b.service.common.CommonService;
import com.privemanagers.b2b.service.stress.model.Asset;
import com.privemanagers.b2b.transaction.JsonContent;
import com.privemanagers.b2b.transaction.JsonNode;
import com.privemanagers.b2b.txn.OptTransaction;
import com.privemanagers.b2b.txn.QuantPortfolioSeriesTransaction;
import com.privemanagers.model.mds.AssetScheme;
import com.privemanagers.model.quant.response.DualSeriesAsset;
import com.privemanagers.model.quant.response.DualSeriesResponse;
import com.privemanagers.sc.service.impl.ExternalAuthAPIService;
import com.privemanagers.sc.util.SecuredRestHelper;

@Service
public class B2BService implements IB2BService {

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * A replacement for JsonArrayItem since we need to include the benchmark
	 * id.
	 *
	 */
	public static class JsonBenchmark extends JsonNode {

		private final String key;

		public JsonBenchmark(final String key) {
			super();
			this.key = key;
		}

		@Override
		public void build(final JsonObjectBuilder builder, final JsonBuilderFactory factory) {
		}

		@Override
		public void build(final JsonArrayBuilder builder, final JsonBuilderFactory factory) {
			final JsonObjectBuilder self = factory.createObjectBuilder();
			self.add(FieldName.BENCHMARK, this.key);
			for (final JsonContent content : this.list) {
				content.build(self, factory);
			}
			builder.add(self);
		}

	}

	private final String rebalancer;

	/**
	 * The base URL, comprising the host and port, for the assets microservice.
	 */
	private final String assets;

	/**
	 * The base URL, comprising the host and port, for the quant microservice.
	 */
	private final String quant;

	/**
	 * The base URL, comprising the host and port, for the opt microservice.
	 */
	private final String opt;

	/** Base URL for xasset service */
	private final String xasseturi;

	/**
	 * The number of threads for processing with the AsyncRestTemplate.
	 */
	private final int threads;

	/**
	 * The timeout duration, in seconds, for waiting for requests of other
	 * microservices.
	 */
	private final int timeout;

	/**
	 * The default number of months between rebalancing.
	 */
	private final int defaultRebalanceEvery;

	private final String cashScheme;

	private final int quantLookBackYears;

	private final TenantContext tenantContext;

	private MixpanelUtil mixpanelUtil;

	private final ExternalAuthAPIService externalAuthAPIService;

	private final CommonService commonService;

	@Autowired
	public B2BService(@Value("${prive.rebalancer}") final String rebalancer,
			@Value("${prive.assets}") final String assets, @Value("${prive.quant}") final String quant,
			@Value("${prive.opt}") final String opt, @Value("${prive.xassets}") final String xasseturi,
			@Value("${prive.threads}") final int threads, @Value("${prive.timeout}") final int timeout,
			@Value("${prive.default-rebalance-every}") final int defaultRebalanceEvery,
			@Value("${prive.cash-scheme}") final String cashScheme,
			@Value("${prive.quant.lookback-years}") final int quantLookBackYears, final TenantContext tenantContext,
			MixpanelUtil mixpanelUtil, @Autowired final ExternalAuthAPIService externalAuthAPIService,
			@Autowired final CommonService commonService) {
		this.rebalancer = rebalancer;
		this.assets = assets;
		this.quant = quant;
		this.opt = opt;
		this.xasseturi = xasseturi;
		this.threads = threads;
		this.timeout = timeout;
		this.defaultRebalanceEvery = defaultRebalanceEvery;
		this.cashScheme = cashScheme;
		this.quantLookBackYears = quantLookBackYears;
		this.tenantContext = tenantContext;
		this.mixpanelUtil = mixpanelUtil;
		this.externalAuthAPIService = externalAuthAPIService;
		this.commonService = commonService;
	}

	/**
	 * We use a predefined exception to make it easier to handle bad requests
	 * without incurring the cost of a stack trace.
	 */
	private static final IllegalArgumentException BAD_REQUEST_EXCEPTION = new IllegalArgumentException();

	/**
	 * To parse date parameters of the form YYYY-MM to local dates.
	 */
	private static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * A specific thread pool for handling callbacks for the AsyncRestTemplate
	 * requests. Without this a new thread is created, then destroyed, for each
	 * async request.
	 */
	private ThreadPoolTaskExecutor executor;

	@PostConstruct
	public void init() {
		this.executor = new ThreadPoolTaskExecutor();
		this.executor.setThreadNamePrefix("prive-");
		this.executor.setAllowCoreThreadTimeOut(false);
		this.executor.setCorePoolSize(this.threads);
		this.executor.setDaemon(true);
		this.executor.initialize();
	}

	@Override
	public ResponseEntity<String> optimise(final String tenant, final String body) {

		try {
			final JsonBuilderFactory factory = API.makeJsonBuilderFactory();

			final JsonArrayBuilder jab = factory.createArrayBuilder();

			final JsonObject parameters = API.parseObject(body);

			mixpanelUtil.trackEvent(tenant, "b2b-optimise", body);
			
			/*
			 * validate the request parameters
			 */
			this.validateOptimiserRequest(parameters);
			
			/*
			 * extract the request parameters
			 */
			final JsonObject session = parameters.getJsonObject(FieldName.SESSION);
			final String sessionId = session.getString(FieldName.ID);
			final String sessionCurrency = session.getString(FieldName.CURRENCY);
			JsonArray eligibleAssets = parameters.getJsonArray(FieldName.ASSETS);
			final JsonArray fitnessFunctions = parameters.getJsonArray(FieldName.FITNESS);
			final JsonArray preferredCurrencies = session.getJsonArray(FieldName.PREFERRED_CURRENCIES);
			final JsonArray concentrationThreshold = session.getJsonArray(FieldName.CONCENTRATION_THRESHOLDS);
			final int riskProfile = session.containsKey("risk-profile") ? session.getInt("risk-profile") : 0;
			final double expectedReturn = session.containsKey("expected-return")
					? session.getJsonNumber("expected-return").doubleValue() / 100.0
					: 0.0;

			final JsonArray requestGoals = parameters.getJsonArray(FieldName.GOALS);

			final Map<String, List<JsonObject>> zeroCashMap = new HashMap<>(requestGoals.size());
			requestGoals.stream().map(goal -> (JsonObject) goal).forEach(goal -> {
				
				final JsonObjectBuilder goalJob = factory.createObjectBuilder();
				goalJob.add(FieldName.GOAL_ID, goal.getString(FieldName.GOAL_ID));
				goalJob.add(FieldName.GOAL, goal.getString(FieldName.GOAL));
				goalJob.add(FieldName.OPTIMISE, goal.getBoolean(FieldName.OPTIMISE, false));
				goalJob.add(FieldName.RISK, goal.containsKey(FieldName.RISK) ? goal.getInt(FieldName.RISK) : 0);
				if (goal.containsKey(FieldName.MODEL) && goal.getString(FieldName.MODEL, null) != null) {
					goalJob.add(FieldName.MODEL, goal.getString(FieldName.MODEL));
				}

				final JsonArrayBuilder portfolioJab = factory.createArrayBuilder();

				List<JsonObject> zeroCashList = new ArrayList<>(1);
				goal.getJsonArray(FieldName.CURRENT_PORTFOLIO).stream().map(pf -> (JsonObject) pf).forEach(holding -> {

					if (this.cashScheme.equals(holding.getString(FieldName.ASSET_CODE_SCHEME))
							&& holding.getJsonNumber(FieldName.VALUE).doubleValue() <= 0.0) {
						zeroCashList.add(holding);
						return;
					}

					final JsonObjectBuilder pfjob = factory.createObjectBuilder();

					pfjob.add(FieldName.ASSET_CODE, holding.getString(FieldName.ASSET_CODE));
					pfjob.add(FieldName.ASSET_CODE_SCHEME, holding.getString(FieldName.ASSET_CODE_SCHEME));
					pfjob.add(FieldName.VALUE, holding.getJsonNumber(FieldName.VALUE).doubleValue());
					pfjob.add(FieldName.ASSET_CURRENCY, holding.getString(FieldName.ASSET_CURRENCY));
					pfjob.add(FieldName.ASSET_PRICE, holding.getJsonNumber(FieldName.ASSET_PRICE).doubleValue());
					pfjob.add(FieldName.FX_RATE, holding.getJsonNumber(FieldName.FX_RATE).doubleValue());
					pfjob.add(FieldName.FROZEN,
							null != holding.getJsonNumber(FieldName.FROZEN)
									? holding.getJsonNumber(FieldName.FROZEN).doubleValue()
									: 0.0);

					if (this.cashScheme.equals(holding.getString(FieldName.ASSET_CODE_SCHEME))) {
						pfjob.add(FieldName.ACCOUNT_ID, holding.getString(FieldName.ACCOUNT_ID));
						pfjob.add(FieldName.ELIGIBLE_CASH, holding.getBoolean(FieldName.ELIGIBLE_CASH, false));
					}

					portfolioJab.add(pfjob);

				});
				goalJob.add(FieldName.CURRENT_PORTFOLIO, portfolioJab);
				zeroCashMap.put(goal.getString(FieldName.GOAL_ID), zeroCashList);

				jab.add(goalJob);

			});

			final JsonArray customerGoals = jab.build();
			
			/*
			 * Extract all assets
			 */
			final List<JsonObject> totalAssetsInCodes = new ArrayList<>();

			final List<JsonObject> fxData = new ArrayList<>();
			JsonObjectBuilder job = factory.createObjectBuilder();

			final Set<String> modelCodes = new HashSet<>(customerGoals.size());
			customerGoals.stream().map(goal -> (JsonObject) goal).forEach(goal -> {
				goal.getJsonArray(FieldName.CURRENT_PORTFOLIO).stream().map(pf -> (JsonObject) pf).forEach(asset -> {
					totalAssetsInCodes.add(asset);

					if (asset.containsKey("asset-currency") && asset.containsKey("fx-rate")) {
						job.add(FieldName.CURRENCY, asset.getString("asset-currency"));
						job.add("fx-rate", asset.getJsonNumber("fx-rate").doubleValue());
						fxData.add(job.build());
					}

				});

				if (goal.containsKey(FieldName.MODEL) && goal.getString(FieldName.MODEL, null) != null) {
					modelCodes.add(goal.getString(FieldName.MODEL));

				}

			});

			if (eligibleAssets.isEmpty()) {

				job.add("asset-code-scheme", "cash");
				job.add("asset-code", sessionCurrency);
				job.add("asset-currency", sessionCurrency);
				job.add(FieldName.CASH_CODE, "session-cash");
				job.add("fx-rate", 1.0);
				job.add("price", 1.0);
				jab.add(job);
				eligibleAssets = jab.build();
			}

			eligibleAssets.stream().map(pf -> (JsonObject) pf).forEach(asset -> {
				totalAssetsInCodes.add(asset);

				if (asset.containsKey("asset-currency") && asset.containsKey("fx-rate")) {
					job.add(FieldName.CURRENCY, asset.getString("asset-currency"));
					job.add("fx-rate", asset.getJsonNumber("fx-rate").doubleValue());
					fxData.add(job.build());
				}

			});

			/*
			 * Extract unique assets
			 */
			final List<JsonObject> uniqueAssetsInCodes = totalAssetsInCodes.stream()
					.filter(distinctByKey(asset -> asset.getString(FieldName.ASSET_CODE)
							.concat(asset.getString(FieldName.ASSET_CODE_SCHEME))
							.concat(asset.getString(FieldName.ASSET_CURRENCY))))
					.collect(Collectors.toList());

			/*
			 * unique fx data
			 */
			final List<JsonObject> uniqueFXData = fxData.stream()
					.filter(distinctByKey(pair -> pair.getString(FieldName.CURRENCY)))
					.collect(Collectors.toList());

			/*
			 * Build codes array for translating codes to id
			 */
			this.appendCodesForTranslation(uniqueAssetsInCodes, jab, factory);

			modelCodes.forEach(model -> {
				this.appendCodesForModelPortfolio(model, tenant, jab, factory);
			});

			final JsonArray codes = jab.build();

			/*
			 * Execute async codes request for each goal codes and eligible
			 * codes list separately validate the response count for any missing
			 * assets
			 */
			final JsonArray uniqueAssetsInId = this.assetsCodesRequest(tenant, codes.toString());
			if (uniqueAssetsInId.size() != codes.size()) {
				throw new AssetsNotFoundException(AssetsNotFoundException.findMissingCodes(codes, uniqueAssetsInId));
			}

			/*
			 * translate back to goals with asset id frozen amount to frozen
			 * weight
			 */
			customerGoals.stream().map(goal -> (JsonObject) goal).forEach(goal -> {
				final JsonObjectBuilder goalJob = factory.createObjectBuilder();
				goalJob.add(FieldName.GOAL_ID, goal.getString(FieldName.GOAL_ID));
				goalJob.add(FieldName.GOAL, goal.getString(FieldName.GOAL));
				goalJob.add(FieldName.OPTIMISE, goal.getBoolean(FieldName.OPTIMISE, false));
				goalJob.add(FieldName.RISK, goal.containsKey(FieldName.RISK) ? goal.getInt(FieldName.RISK) : 0);
				final JsonArrayBuilder portfolioJab = factory.createArrayBuilder();
				goal.getJsonArray(FieldName.CURRENT_PORTFOLIO).stream().map(asset -> (JsonObject) asset).forEach(
						assetInCodes -> {
							uniqueAssetsInId.stream()
									.map(assets -> (JsonObject) assets)
									.filter(asset -> (asset.getString(FieldName.SCHEME)
											.equals(assetInCodes.getString(FieldName.ASSET_CODE_SCHEME))
											&& asset.getString(FieldName.VALUE)
													.equals(assetInCodes.getString(FieldName.ASSET_CODE))))
									.forEach(assetInId -> {
										final JsonObjectBuilder pfjob = factory.createObjectBuilder();
										pfjob.add(FieldName.VALUE,
												assetInCodes.getJsonNumber(FieldName.VALUE).doubleValue());

										pfjob.add(FieldName.FROZEN, null != assetInCodes.getJsonNumber(FieldName.FROZEN)
												? assetInCodes.getJsonNumber(FieldName.FROZEN).doubleValue()
														/ assetInCodes.getJsonNumber(FieldName.VALUE).doubleValue()
												: 0.0);
										pfjob.add(FieldName.ASSET_ID, assetInId.getString(FieldName.ASSET_ID));

										if ("cash".equals(assetInCodes.getString(FieldName.ASSET_CODE_SCHEME))) {
											pfjob.add(FieldName.CASH_CODE, assetInCodes.getString("account-id"));
											pfjob.add("eligible-cash", assetInCodes.getBoolean("eligible-cash", false));
										}

										pfjob.add("price", assetInCodes.getJsonNumber("price").doubleValue());

										portfolioJab.add(pfjob);
									});
						});
				goalJob.add("holdings", portfolioJab);

				if (goal.containsKey(FieldName.MODEL) && goal.getString(FieldName.MODEL, null) != null) {
					final String modelId = uniqueAssetsInId.stream()
							.map(assets -> (JsonObject) assets)
							.filter(asset -> asset.getString(FieldName.VALUE).equals(goal.getString(FieldName.MODEL)))
							.findFirst()
							.get()
							.getString(FieldName.ASSET_ID);

					goalJob.add(FieldName.MODEL, modelId);
					goalJob.add("model-value", goal.getString(FieldName.MODEL));
				}

				jab.add(goalJob);
			});
			final JsonArray translatedGoals = jab.build();

			/*
			 * translate eligible assets with asset id
			 */
			eligibleAssets.stream().map(eligAssets -> (JsonObject) eligAssets).forEach(eligAsset -> {
				uniqueAssetsInId.stream()
						.map(assets -> (JsonObject) assets)
						.filter(asset -> (asset.getString(FieldName.SCHEME)
								.equals(eligAsset.getString(FieldName.ASSET_CODE_SCHEME))
								&& asset.getString(FieldName.VALUE).equals(eligAsset.getString(FieldName.ASSET_CODE))))
						.forEach(asset -> {
							final JsonObjectBuilder pfjob = factory.createObjectBuilder();
							pfjob.add(FieldName.ASSET_ID, asset.getString(FieldName.ASSET_ID));
							pfjob.add("price", eligAsset.getJsonNumber("price").doubleValue());
							if (eligAsset.containsKey(FieldName.CASH_CODE)) {
								pfjob.add(FieldName.CASH_CODE, eligAsset.getString(FieldName.CASH_CODE));
							}
							jab.add(pfjob);
						});
			});
			final JsonArray translatedEligibleAssets = jab.build();

			/*
			 * FIXME: Get from the product master sync off data.
			 */
			translatedEligibleAssets.stream().map(assets -> (JsonObject) assets).forEach(asset -> {
				jab.add(asset.getString(FieldName.ASSET_ID));
			});
			final JsonArray preferredAssets = jab.build();

			/*
			 * metrics for current goals
			 */
			final CountDownLatch currentGoalLatch = new CountDownLatch(2);

			/*
			 * final LocalDate untilDate = this.endOfLastMonth(); final String
			 * until = untilDate.format(STRING_TO_DATE); final String from =
			 * this.lookback(untilDate).format(STRING_TO_DATE);
			 */

			String fromDate = "";
			String untilDate = "";
			if (session.containsKey("from") && session.containsKey("until")) {
				fromDate = session.getString("from", "");
				untilDate = session.getString("until", "");
			} else {
				LocalDate untilDates = this.endOfLastMonth();
				untilDate = untilDates.format(STRING_TO_DATE);
				fromDate = this.lookback(untilDates).format(STRING_TO_DATE);
			}

			final String from = fromDate;
			final String until = untilDate;

			final List<OptTransaction> curFitnessTxns = new ArrayList<>(translatedGoals.size());
			final List<QuantPortfolioSeriesTransaction> curQuantTxns = new ArrayList<>(translatedGoals.size());

			this.executeFitnessTransactions(tenant, currentGoalLatch, curFitnessTxns, factory, sessionCurrency,
					fitnessFunctions, null, translatedGoals, translatedEligibleAssets, preferredCurrencies,
					preferredAssets, false, uniqueFXData, expectedReturn, session.getString("from", ""),
					session.getString("until", ""), session.getString("model-tier", ""));

			translatedGoals.stream()
					.map(goals -> (JsonObject) goals)
					.filter(p -> p.getBoolean(FieldName.OPTIMISE))
					.forEach(goal -> {

						this.executeQuantPFSeriesTransactions(tenant, currentGoalLatch, curQuantTxns, factory,
								sessionCurrency, goal.getJsonArray("holdings"), from, until);

					});

			/*
			 * execute the optimiser request async
			 */
			final List<OptTransaction> optTxns = new ArrayList<>(1);
			final CountDownLatch optimiserLatch = new CountDownLatch(1);
			this.executeOptimiseTransactions(tenant, optimiserLatch, optTxns, factory, sessionCurrency,
					fitnessFunctions, translatedGoals, translatedEligibleAssets, preferredCurrencies, preferredAssets,
					false, concentrationThreshold, uniqueFXData, riskProfile, expectedReturn,
					session.getString("from", ""), session.getString("until", ""), session.getString("model-tier", ""));
			Boolean ok = this.waitForTxnResponse(optimiserLatch, optTxns);
			if (!ok) {
				throw new Exception();
			}

			/*
			 * execute the fitness and quant request async for optimised goals
			 */
			final CountDownLatch optimisedGoallatch = new CountDownLatch(optTxns.size() * 2);
			final List<OptTransaction> optFitnessTxns = new ArrayList<>(optTxns.size());
			final List<QuantPortfolioSeriesTransaction> optQuantTxns = new ArrayList<>(optTxns.size());

			for (OptTransaction optTxn : optTxns) {
				if (optTxn.body().getJsonObject("scores").containsKey("CONCENTRATION")
						&& optTxn.body().getJsonObject("scores").getJsonNumber("CONCENTRATION").doubleValue() < 100) {
					throw new Exception("Concentration check failure with score: "
							+ optTxn.body().getJsonObject("scores").getJsonNumber("CONCENTRATION").doubleValue());
				}

				this.executeFitnessTransactions(tenant, optimisedGoallatch, optFitnessTxns, factory, sessionCurrency,
						fitnessFunctions, optTxn.body().getJsonArray("goals"), optTxn.goals(), translatedEligibleAssets,
						preferredCurrencies, preferredAssets, true, uniqueFXData, expectedReturn,
						session.getString("from", ""), session.getString("until", ""),
						session.getString("model-tier", ""));

				JsonObject optimisedHoldings = optTxn.body()
						.getJsonArray("goals")
						.stream()
						.map(o -> (JsonObject) o)
						.filter(p -> p.getBoolean(FieldName.OPTIMISE, false))
						.findFirst()
						.get();

				this.executeQuantPFSeriesTransactions(tenant, optimisedGoallatch, optQuantTxns, factory,
						sessionCurrency, optimisedHoldings.getJsonArray("holdings"), from, until);
			}

			/*
			 * wait for all pending requests to complete before building
			 * response
			 */
			ok &= this.waitForTxnResponse(currentGoalLatch, curFitnessTxns)
					&& this.waitForTxnResponse(currentGoalLatch, curQuantTxns)
					&& this.waitForTxnResponse(optimisedGoallatch, optFitnessTxns)
					&& this.waitForTxnResponse(optimisedGoallatch, optQuantTxns);
			if (!ok) {
				throw new Exception();
			}

			// call rebalancer service
			final JsonObjectBuilder rebalancerReq = factory.createObjectBuilder();
			this.createRebalancerRequest(factory, rebalancerReq, sessionId, sessionCurrency, customerGoals,
					curFitnessTxns, optFitnessTxns, uniqueAssetsInId, totalAssetsInCodes, uniqueFXData);
			final JsonObject rebalancerResp = this.rebalancerRequest(tenant, rebalancerReq.build().toString());

			/*
			 * optimizer response
			 */
			final JsonObjectBuilder optimiserResp = factory.createObjectBuilder();

			final boolean proposedTxMode = TenantServiceConfigUtil.getConfigBooleanValue(tenantContext,
					TenantServiceEnum.B2B, TenantConfigEnum.REBALANCER_PROPOSED_TRANSACTIONS, true);

			this.createOptimiserResponse(factory, jab, optimiserResp, rebalancerResp, sessionId, curFitnessTxns,
					curQuantTxns, optFitnessTxns, optQuantTxns, uniqueAssetsInId, proposedTxMode, zeroCashMap);

			this.logger.debug(HttpStatus.OK.getReasonPhrase());

			return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(optimiserResp.build().toString());
		} catch (final IllegalArgumentException iae) {
			this.logger.warn("{} body {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), body);
			return ResponseEntity.badRequest().body("");
		} catch (final AssetsNotFoundException assetsNotFoundException) {
			this.logger.error(HttpStatus.NOT_FOUND.getReasonPhrase(), assetsNotFoundException);
			return new ResponseEntity<>(assetsNotFoundException.getCodesMissingAssets().toString(),
					HttpStatus.NOT_FOUND);
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<String>("", httpException.getStatusCode());
		} catch (final Exception e) {

			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);

		}

	}

	/**
	 * appends a list of codes for translation and the single benchmark code for
	 * dual series request
	 *
	 * @param portfolio
	 * @param singleBenchmarkCode
	 * @param array
	 * @param factory
	 */
	private void appendCodesForTranslation(final List<AssetIdentifier> portfolio, final JsonObject singleBenchmarkCode,
			final JsonArrayBuilder array, final JsonBuilderFactory factory) {
		if (singleBenchmarkCode != null) {
			final JsonObjectBuilder job = factory.createObjectBuilder();
			this.appendCodeForTranslation(singleBenchmarkCode, job);
			array.add(job);
		}
		this.appendPojoCodesForTranslation(portfolio, array, factory);
	}

	/**
	 * appends a list of codes for translation
	 *
	 * @param portfolio
	 * @param array
	 * @param factory
	 */
	private void appendPojoCodesForTranslation(final List<AssetIdentifier> portfolio, final JsonArrayBuilder array,
			final JsonBuilderFactory factory) {
		if (portfolio != null && !portfolio.isEmpty()) {
			for (final AssetIdentifier assetIdentifier : portfolio) {
				final JsonObjectBuilder holding = factory.createObjectBuilder()
						.add(FieldName.ASSET_CODE_SCHEME, assetIdentifier.getScheme())
						.add(FieldName.ASSET_CODE, assetIdentifier.getCode())
						.add(FieldName.ASSET_CURRENCY, assetIdentifier.getCurrency());
				final JsonObjectBuilder job = factory.createObjectBuilder();
				this.appendCodeForTranslation(holding.build(), job);
				array.add(job);
			}
		}
	}

	/**
	 * appends a single code for translation
	 *
	 * @param inAsset
	 * @param inObjectBuilder
	 */
	private void appendCodeForTranslation(final JsonObject inAsset, final JsonObjectBuilder inObjectBuilder) {
		String assetCodeScheme = inAsset.getString(FieldName.ASSET_CODE_SCHEME);
		String assetCode = inAsset.getString(FieldName.ASSET_CODE);
		if (assetCodeScheme.equalsIgnoreCase(AssetScheme.SYMBOL.toString())) {
			// symbol needs to strip 0, xignite no leading 0
			assetCode = StringUtils.stripStart(assetCode, "0");
		}

		inObjectBuilder.add(FieldName.SCHEME, assetCodeScheme);
		inObjectBuilder.add(FieldName.VALUE, assetCode);
		if (inAsset.containsKey(FieldName.ASSET_CURRENCY)) {
			inObjectBuilder.add(FieldName.CURRENCY, inAsset.getString(FieldName.ASSET_CURRENCY));
		}
	}

	/**
	 * Construct the code for the specified model portfolio.
	 *
	 * @param codes
	 * @param factory
	 * @param modelName
	 * @param tenant
	 */
	private void appendCodesForModelPortfolio(final String modelName, final String tenant, final JsonArrayBuilder codes,
			final JsonBuilderFactory factory) {

		final String tenantScheme = API.getTenantCodeScheme(tenant);
		final JsonObjectBuilder code = factory.createObjectBuilder().add(FieldName.SCHEME, tenantScheme).add(
				FieldName.VALUE, modelName);

		codes.add(code);
	}

	/**
	 * Query assets service to get assets id from codes.
	 *
	 * @param tenant
	 * @param body
	 * @return
	 */
	private JsonArray assetsCodesRequest(final String tenant, final String body) {
		JsonArray res = null;
		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.assets, EndPoints.ASSETS_1_CODES,
				tenant, body, HttpMethod.POST, this.tenantContext, true);

		// check if the request succeed
		if (response.getStatusCode().is2xxSuccessful()) {
			final String assets = response.getBody();

			res = API.parseArray(assets);
		} else {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		return res;
	}

	private JsonObject rebalancerRequest(final String tenant, final String body) {
		JsonObject res = null;
		final URI uri = UriComponentsBuilder.fromUriString(this.rebalancer)
				.path(EndPoints.REBALANCER_1)
				.buildAndExpand(tenant)
				.encode()
				.toUri();

		this.logger.info("{}", uri);
		this.logger.info("{}", body);

		// build the request
		final ResponseEntity<String> response = SecuredRestHelper.sendRequest(this.rebalancer, EndPoints.REBALANCER_1,
				tenant, body, HttpMethod.POST, this.tenantContext, true);
		// check if the request succeed
		if (response.getStatusCode().is2xxSuccessful()) {
			res = API.parseObject(response.getBody());
		} else {
			throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
		}

		return res;
	}

	/**
	 * Loop through the array and determine if the system can attempt to create
	 * asset on the fly. This would require (isin or symbol) and currency for
	 * eligible asset
	 *
	 * @param assetArray
	 */
	private void searchAndCreateAssetRequest(final JsonArray assetArray) {

		if (assetArray == null || assetArray.isEmpty()) {
			return;
		}

		for (int i = 0; i < assetArray.size(); i++) {
			final JsonObject asset = assetArray.getJsonObject(i);
			final String scheme = asset.getString(FieldName.ASSET_CODE_SCHEME, null);

			if (StringUtils.isBlank(scheme) || (!scheme.equalsIgnoreCase(AssetScheme.ISIN.toString())
					&& !scheme.equalsIgnoreCase(AssetScheme.SYMBOL.toString()))) {
				continue;
			}

			final String identifier = asset.getString(FieldName.ASSET_CODE, null);
			final String currency = asset.getString(FieldName.ASSET_CURRENCY, null);

			if (StringUtils.isBlank(identifier) || StringUtils.isBlank(currency)) {
				continue;
			}

			if (scheme.equalsIgnoreCase(AssetScheme.ISIN.toString())) {
				final URI requestURI = UriComponentsBuilder.fromUriString(this.xasseturi)
						.path(EndPoints.XASSETS_1_SEARCH_CREATE)
						.queryParam("isin", identifier)
						.queryParam(FieldName.CURRENCY, currency)
						.build()
						.encode()
						.toUri();

				this.searchAndCreateAssetRequest(requestURI, identifier, "ISIN", currency);

			} else if (scheme.equalsIgnoreCase(AssetScheme.SYMBOL.toString())) {
				String[] symbol = identifier.split("\\.");
				if (symbol.length != 2) {
					logger.warn("invalid symbol:{}, skipped", identifier);
					continue;
				}

				final URI requestURI = UriComponentsBuilder.fromUriString(this.xasseturi)
						.path(EndPoints.XASSETS_1_SEARCH_CREATE_BY_SYMBOL)
						.queryParam("symbol", symbol[0])
						.queryParam("mic", symbol[1])
						.queryParam(FieldName.CURRENCY, currency)
						.build()
						.encode()
						.toUri();
				this.searchAndCreateAssetRequest(requestURI, identifier, "SYMBOL", currency);
			}
		}
	}

	/**
	 * Fire a call to xasset for creating a new asset using the given isin and
	 * currency
	 *
	 * @param requestURI
	 * @param identifier
	 * @param identifierType
	 * @param currency
	 */
	private void searchAndCreateAssetRequest(URI requestURI, String identifier, String identifierType,
			String currency) {

		if (StringUtils.isBlank(identifier) || StringUtils.isBlank(currency)) {
			return;
		}

		this.logger.info("Calling xasset to create asset with identifier {}  identifierType {} currency {}", identifier,
				identifierType, currency);

		final String adminToken = externalAuthAPIService.getOAuth2AuthenticationToken("admin", null, null, null);

		try {
			if (adminToken == null) {
				this.logger.error(
						"Error getting admin token for searchAndCreateAssetRequest identifierType {} identifierType {} currency {}",
						identifier, identifierType, currency);
				throw new Exception("Error getting admin token for searchAndCreateAssetRequest");
			}

			this.logger.info("Firing call to xasset: {}", requestURI);

			final ResponseEntity<String> response = RestHelper.sendRequest(requestURI, null, null, HttpMethod.GET,
					adminToken, this.tenantContext, true);

			// check if the request succeed
			if (!response.getStatusCode().is2xxSuccessful()) {
				this.logger.error("Error calling xasset statusCode={} with URL: {}", response.getStatusCodeValue(),
						requestURI);
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Validates the request parameters for optimisation.
	 *
	 * @param parameters
	 * @throws Exception
	 */
	private void validateOptimiserRequest(final JsonObject parameters) throws Exception {

		if (parameters == null) {
			throw BAD_REQUEST_EXCEPTION;
		}

		/*
		 * session details
		 */
		API.validateJsonRequest(parameters, FieldName.SESSION);
		final JsonObject session = parameters.getJsonObject(FieldName.SESSION);
		API.validateJsonRequest(session, FieldName.ID);
		API.validateJsonRequest(session, FieldName.CURRENCY);
		if (!API.validateCurrencyCode(session.getString(FieldName.CURRENCY))) {
			throw BAD_REQUEST_EXCEPTION;
		}

		/*
		 * fitness functions
		 */
		API.validateJsonRequest(parameters, FieldName.FITNESS);
		final JsonArray fitnessFunctions = parameters.getJsonArray(FieldName.FITNESS);
		if (fitnessFunctions.isEmpty()) {
			throw BAD_REQUEST_EXCEPTION;
		} else {
			fitnessFunctions.stream().map(obj -> (JsonObject) obj).forEach(fitness -> {
				try {
					API.validateJsonRequest(fitness, FieldName.FUNCTION);
					API.validateJsonRequest(fitness, FieldName.WEIGHT);
				} catch (final Exception e) {
					throw BAD_REQUEST_EXCEPTION;
				}
			});
		}

		/*
		 * asset universe
		 */
		API.validateJsonRequest(parameters, FieldName.ASSETS);
		final JsonArray eligibleAssets = parameters.getJsonArray(FieldName.ASSETS);
		if (!eligibleAssets.isEmpty()) {
			this.validateGivenPortfolio(eligibleAssets, false);
		}

		/*
		 * goals
		 */
		API.validateJsonRequest(parameters, FieldName.GOALS);
		final JsonArray customerGoals = parameters.getJsonArray(FieldName.GOALS);
		if (customerGoals.isEmpty()) {
			throw BAD_REQUEST_EXCEPTION;
		} else {
			customerGoals.stream().map(o -> (JsonObject) o).forEach(goal -> {
				try {
					API.validateJsonRequest(goal, FieldName.GOAL_ID);
					API.validateJsonRequest(goal, FieldName.GOAL);
					API.validateJsonRequest(goal, FieldName.CURRENT_PORTFOLIO);
					this.validateGivenPortfolio(goal.getJsonArray(FieldName.CURRENT_PORTFOLIO), true);
				} catch (final Exception e) {
					throw BAD_REQUEST_EXCEPTION;
				}
			});
		}

	}

	/**
	 * Validates a given portfolio object.
	 *
	 * @param portfolio
	 * @throws Exception
	 */
	private void validateGivenPortfolio(final JsonArray portfolio, final boolean hasHoldingValues) throws Exception {

		if (portfolio.isEmpty()) {
			throw BAD_REQUEST_EXCEPTION;
		} else {
			portfolio.stream().map(o -> (JsonObject) o).forEach(holding -> {
				try {
					API.validateJsonRequest(holding, FieldName.ASSET_CODE);
					API.validateJsonRequest(holding, FieldName.ASSET_CODE_SCHEME);
					if (!this.cashScheme.equals(holding.getString(FieldName.ASSET_CODE_SCHEME))) {
						API.validateJsonRequest(holding, FieldName.ASSET_CURRENCY);
						if (!API.validateCurrencyCode(holding.getString(FieldName.ASSET_CURRENCY))) {
							throw BAD_REQUEST_EXCEPTION;
						}
					}

					if (hasHoldingValues) {
						if (holding.getJsonNumber(FieldName.VALUE) == null) {
							throw BAD_REQUEST_EXCEPTION;
						}
						if (!this.cashScheme.equals(holding.getString(FieldName.ASSET_CODE_SCHEME))
								&& holding.getJsonNumber(FieldName.VALUE).doubleValue() <= 0.0) {
							throw BAD_REQUEST_EXCEPTION;
						}

						if (holding.containsKey(FieldName.FROZEN)
								&& (holding.getJsonNumber(FieldName.FROZEN).doubleValue()
										/ holding.getJsonNumber(FieldName.VALUE).doubleValue() > 1.0)) {
							throw BAD_REQUEST_EXCEPTION;
						}

					}

				} catch (final Exception e) {
					throw BAD_REQUEST_EXCEPTION;
				}
			});
		}

	}

	/**
	 * Invokes opt optimise service and get the optimised portfolio.
	 *
	 * @param tenant
	 * @param portfolio
	 * @param assetsCodeTxn
	 * @param factory
	 * @param latch
	 * @throws Exception
	 */
	private void executeOptimiseTransactions(final String tenant, final CountDownLatch latch,
			final List<OptTransaction> optTxns, final JsonBuilderFactory factory, final String sessionCurrency,
			final JsonArray fitness, final JsonArray goals, final JsonArray eligibleAssets,
			final JsonArray preferredCurrencies, final JsonArray preferredAssets, final boolean checkForReference,
			final JsonArray concentrationThreshold, final List<JsonObject> fxData, final int riskProfile,
			final double expectedReturn, final String from, final String until, final String modelTier)
			throws Exception {

		// goals.stream().map(o -> (JsonObject) o).forEach(goal -> {
		final OptTransaction optTxn = new OptTransaction(this.opt, EndPoints.OPT_1_OPTIMISE, tenant, latch, factory,
				sessionCurrency, fitness, goals, null, eligibleAssets, preferredCurrencies, preferredAssets,
				checkForReference, concentrationThreshold, this.tenantContext, fxData, riskProfile, expectedReturn,
				from, until, modelTier);
		optTxns.add(optTxn);
		optTxn.send(this.executor);

		// });

	}

	/**
	 * Invokes opt optimise service and get the fitness score.
	 *
	 * @param tenant
	 * @param portfolio
	 * @param assetsCodeTxn
	 * @param factory
	 * @param latch
	 * @throws Exception
	 */
	private void executeFitnessTransactions(final String tenant, final CountDownLatch latch,
			final List<OptTransaction> fitTxns, final JsonBuilderFactory factory, final String sessionCurrency,
			final JsonArray fitness, final JsonArray proposedGoals, final JsonArray goals,
			final JsonArray eligibleAssets, final JsonArray preferredCurrencies, final JsonArray preferredAssets,
			final boolean checkForReference, final List<JsonObject> fxData, final double expectedReturn,
			final String from, final String until, final String modelTier) {

		final OptTransaction fitTxn = new OptTransaction(this.opt, EndPoints.OPT_1_FITNESS, tenant, latch, factory,
				sessionCurrency, fitness, goals, proposedGoals, eligibleAssets, preferredCurrencies, preferredAssets,
				checkForReference, null, this.tenantContext, fxData, 0, expectedReturn, from, until, modelTier);
		fitTxns.add(fitTxn);
		fitTxn.send(this.executor);

	}

	/**
	 * Invokes quant portfolio series and get the statistics.
	 *
	 * @param tenant
	 * @param latch
	 * @param quantTxns
	 * @param factory
	 * @param sessionCurrency
	 * @param optResult
	 * @param from
	 * @param until
	 * @throws Exception
	 */
	private void executeQuantPFSeriesTransactions(final String tenant, final CountDownLatch latch,
			final List<QuantPortfolioSeriesTransaction> quantTxns, final JsonBuilderFactory factory,
			final String sessionCurrency, final JsonArray portfolio, final String from, final String until) {

		final int rebalanceEvery = TenantServiceConfigUtil.getConfigIntValue(tenantContext, TenantServiceEnum.B2B,
				TenantConfigEnum.REBALANCE_EVERY, defaultRebalanceEvery);

		final QuantPortfolioSeriesTransaction quantTxn = new QuantPortfolioSeriesTransaction(this.quant, tenant, from,
				until, sessionCurrency, rebalanceEvery, factory, portfolio, latch, this.tenantContext);
		quantTxns.add(quantTxn);
		quantTxn.send(this.executor);

	}

	/**
	 * Wait for all the async responses and return the overall success.
	 *
	 * @param latch
	 * @param txns
	 * @return boolean
	 */
	private final boolean waitForTxnResponse(final CountDownLatch latch, final List<? extends AsyncTransaction> txns)
			throws Exception {

		try {
			latch.await(this.timeout, TimeUnit.SECONDS);
		} catch (final InterruptedException e) {
			this.logger.warn("Interrupted exception when waiting response {}", e);
		}
		/*
		 * Verify all responses are OK.
		 */
		boolean truth = true;
		for (final AsyncTransaction txn : txns) {
			final boolean success = HttpStatus.OK == txn.status();
			if (!success) {
				this.logger.warn("{} {}", txn.status().getReasonPhrase(), txn.uri());
			}
			truth &= success;
		}

		return truth;

	}

	/**
	 * Util to filter a collection by distinct key
	 *
	 * @param keyExtractor
	 * @return
	 */
	private static <T> Predicate<T> distinctByKey(final Function<? super T, Object> keyExtractor) {

		final Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;

	}

	/**
	 * Prepare json array for codes translation
	 *
	 * @param portfolio
	 * @param array
	 * @param factory
	 */
	private void appendCodesForTranslation(final List<JsonObject> portfolio, final JsonArrayBuilder array,
			final JsonBuilderFactory factory) {

		portfolio.forEach(asset -> {
			final JsonObjectBuilder job = factory.createObjectBuilder();
			job.add(FieldName.SCHEME, asset.getString(FieldName.ASSET_CODE_SCHEME));
			job.add(FieldName.VALUE, asset.getString(FieldName.ASSET_CODE));
			if (asset.containsKey(FieldName.ASSET_CURRENCY)) {
				job.add(FieldName.CURRENCY, asset.getString(FieldName.ASSET_CURRENCY));
			}
			array.add(job);
		});

	}

	private LocalDate lookback(final LocalDate until) {
		return until.minusYears(this.quantLookBackYears).withDayOfMonth(1);
	}

	private LocalDate endOfLastMonth() {
		return LocalDate.now().withDayOfMonth(1).minusDays(1);
	}

	private void createRebalancerRequest(final JsonBuilderFactory factory, final JsonObjectBuilder rebalancerReq,
			final String sessionId, final String sessionCurrency, final JsonArray customerGoals,
			final List<OptTransaction> curFitnessTxns, final List<OptTransaction> optFitnessTxns,
			final JsonArray uniqueAssetsInId, final List<JsonObject> totalAssetsInCodes,
			final List<JsonObject> uniqueFXData) throws Exception {

		final JsonArrayBuilder lotSizeValue = factory.createArrayBuilder();

		// ---------------------- EXISTING POSITIONS SUMMARY
		final JsonArrayBuilder existingPositionsSummaryBuilder = factory.createArrayBuilder();
		customerGoals.stream().map(goal -> (JsonObject) goal).forEach(goal -> {
			final JsonObjectBuilder positionBuilder = factory.createObjectBuilder();
			positionBuilder.add(FieldName.REBALANCER_ASSET_TYPE, "vFund");
			positionBuilder.add(FieldName.REBALANCER_ASSET_ID, goal.getString(FieldName.GOAL_ID));
			positionBuilder.add(FieldName.REBALANCER_SCHEME, FieldName.REBALANCER_VFUND_ID);
			existingPositionsSummaryBuilder.add(positionBuilder.build());

		});

		final JsonObjectBuilder existingPortfoliosValue = factory.createObjectBuilder();
		existingPortfoliosValue.add("id", "main");
		existingPortfoliosValue.add("positions", existingPositionsSummaryBuilder.build());

		// --------------------- EXISTING POSITIONS DETAILS --------------
		final JsonArrayBuilder existingPortfoliosDetailsValue = factory.createArrayBuilder();
		customerGoals.stream().map(goal -> (JsonObject) goal).forEach(goal -> {

			final JsonArrayBuilder positionsDetailsBuilder = factory.createArrayBuilder();
			goal.getJsonArray(FieldName.CURRENT_PORTFOLIO).stream().map(pos -> (JsonObject) pos).forEach(pos -> {

				final JsonObjectBuilder positionDetailsBuilder = factory.createObjectBuilder();

				final JsonObject assetCodes = totalAssetsInCodes.stream()
						.filter(asset -> asset.getString(FieldName.ASSET_CODE)
								.equals(pos.getString(FieldName.ASSET_CODE)))
						.findFirst()
						.get();

				// Request to get eventual lot size parameters
				final JsonObject assetCodesByValue = uniqueAssetsInId.stream()
						.map(assets -> (JsonObject) assets)
						.filter(asset -> asset.getString(FieldName.VALUE).equals(pos.getString(FieldName.ASSET_CODE)))
						.findFirst()
						.get();

				if (pos.getString(FieldName.ASSET_CODE_SCHEME).toLowerCase().equals("cash")) {
					positionDetailsBuilder.add(FieldName.REBALANCER_ASSET_TYPE, "cash");
					positionDetailsBuilder.add(FieldName.REBALANCER_SCHEME, FieldName.CURRENCY);
				} else {
					positionDetailsBuilder.add(FieldName.REBALANCER_ASSET_TYPE, "security");
					positionDetailsBuilder.add(FieldName.REBALANCER_SCHEME,
							pos.getString(FieldName.ASSET_CODE_SCHEME).toLowerCase());

					createRebalancerRequestLotSize(factory, lotSizeValue, assetCodesByValue);
				}

				positionDetailsBuilder.add(FieldName.REBALANCER_ASSET_ID, pos.getString(FieldName.ASSET_CODE));

				positionDetailsBuilder.add(FieldName.CURRENCY, pos.getString(FieldName.ASSET_CURRENCY));
				positionDetailsBuilder.add("close-px", assetCodes.getJsonNumber(FieldName.ASSET_PRICE));

				JsonObject fxData = uniqueFXData.stream()
						.filter(p -> p.getString(FieldName.CURRENCY).equals(pos.getString(FieldName.ASSET_CURRENCY)))
						.findFirst()
						.orElse(null);

				if (fxData != null) {
					positionDetailsBuilder.add("fxrate", fxData.getJsonNumber(FieldName.FX_RATE));
				}

				positionDetailsBuilder.add("valueType", "marketvalue");
				positionDetailsBuilder.add(FieldName.VALUE, pos.getJsonNumber(FieldName.VALUE));

				if (pos.containsKey(FieldName.ACCOUNT_ID)) {
					positionDetailsBuilder.add(FieldName.REBALANCER_ACCOUNT_ID,
							pos.getJsonString(FieldName.ACCOUNT_ID));
				}

				positionsDetailsBuilder.add(positionDetailsBuilder.build());
			});

			final JsonObjectBuilder tmp = factory.createObjectBuilder();
			tmp.add("id", goal.getString(FieldName.GOAL_ID));
			tmp.add("optimise", goal.getBoolean(FieldName.OPTIMISE));
			tmp.add("positions", positionsDetailsBuilder.build());
			existingPortfoliosDetailsValue.add(tmp.build());
		});

		// ---------------------- TARGET POSITIONS SUMMARY
		final JsonArrayBuilder targetPositionsSummaryBuilder = factory.createArrayBuilder();
		optFitnessTxns.forEach(txn -> {
			txn.goals().stream().map(goal -> (JsonObject) goal).forEach(goal -> {
				final JsonObjectBuilder targetPositionSummaryBuilder = factory.createObjectBuilder();
				targetPositionSummaryBuilder.add("assetType", "vFund");
				targetPositionSummaryBuilder.add("assetId", goal.getString(FieldName.GOAL_ID));
				targetPositionSummaryBuilder.add("scheme", "vFundID");
				targetPositionSummaryBuilder.add(FieldName.CURRENCY, sessionCurrency);
				targetPositionsSummaryBuilder.add(targetPositionSummaryBuilder.build());

			});
		});

		final JsonObjectBuilder targetAllocationValue = factory.createObjectBuilder();
		targetAllocationValue.add("id", "main");
		targetAllocationValue.add("positions", targetPositionsSummaryBuilder.build());

		// --------------------- TARGET POSITIONS DETAILS --------------

		final JsonArrayBuilder targetHoldingDetailsValue = factory.createArrayBuilder();

		final JsonArrayBuilder positionsDetailsBuilder = factory.createArrayBuilder();
		optFitnessTxns.forEach(txn -> {

			txn.proposedGoals().stream().map(goal -> (JsonObject) goal).forEach(goal -> {

				goal.getJsonArray("holdings").stream().map(pos -> (JsonObject) pos).forEach(pos -> {

					final JsonObjectBuilder positionDetailsBuilder = factory.createObjectBuilder();

					final JsonObject assetCodes = uniqueAssetsInId.stream()
							.map(assets -> (JsonObject) assets)
							.filter(asset -> asset.getString(FieldName.ASSET_ID)
									.equals(pos.getString(FieldName.ASSET_ID)))
							.findFirst()
							.get();

					final JsonObject assetCodesPrice = totalAssetsInCodes.stream()
							.filter(asset -> asset.getString(FieldName.ASSET_CODE)
									.equals(assetCodes.getString(FieldName.VALUE)))
							.findFirst()
							.get();

					positionDetailsBuilder.add("assetId", assetCodes.getString(FieldName.VALUE));

					if (pos.containsKey(FieldName.CASH_CODE)) {
						positionDetailsBuilder.add(FieldName.REBALANCER_ASSET_TYPE, "cash");
						positionDetailsBuilder.add(FieldName.REBALANCER_SCHEME, FieldName.CURRENCY);
						positionDetailsBuilder.add(FieldName.REBALANCER_ACCOUNT_ID, pos.getString(FieldName.CASH_CODE));
					} else {
						positionDetailsBuilder.add(FieldName.REBALANCER_ASSET_TYPE, "security");
						positionDetailsBuilder.add(FieldName.REBALANCER_SCHEME,
								assetCodes.getString(FieldName.SCHEME).toLowerCase());

						createRebalancerRequestLotSize(factory, lotSizeValue, assetCodes);
					}

					positionDetailsBuilder.add(FieldName.CURRENCY, assetCodes.getString(FieldName.CURRENCY));
					positionDetailsBuilder.add("close-px", assetCodesPrice.getJsonNumber(FieldName.ASSET_PRICE));

					JsonObject fxData = uniqueFXData.stream()
							.filter(p -> p.getString(FieldName.CURRENCY)
									.equals(assetCodes.getString(FieldName.CURRENCY)))
							.findFirst()
							.orElse(null);

					if (fxData != null) {
						positionDetailsBuilder.add("fxrate", fxData.getJsonNumber(FieldName.FX_RATE));
					}

					positionDetailsBuilder.add("valueType", "marketvalue");
					positionDetailsBuilder.add(FieldName.VALUE,
							null != pos.getJsonNumber(FieldName.VALUE)
									? pos.getJsonNumber(FieldName.VALUE).doubleValue()
									: 0.0);
					positionsDetailsBuilder.add(positionDetailsBuilder.build());

				});

				final JsonObjectBuilder tmp = factory.createObjectBuilder();
				tmp.add("id", goal.getString(FieldName.GOAL_ID));
				tmp.add(FieldName.OPTIMISE, goal.getBoolean(FieldName.OPTIMISE));
				tmp.add("positions", positionsDetailsBuilder.build());

				targetHoldingDetailsValue.add(tmp.build());

			});
		});

		// --------------------- ADD ASSETS LOT PARAMETERS --------------

		// -------------------- FINAL JSON -----------------------
		// Config rebalancer to switch on "netting cash" feature
		rebalancerReq.add("nettingCash", "true");

		rebalancerReq.add("portfolioCurrency", sessionCurrency.toLowerCase());// toLowerCase
		rebalancerReq.add("existingPortfolios", factory.createArrayBuilder().add(existingPortfoliosValue.build()));
		rebalancerReq.add("existingPortfoliosDetails", existingPortfoliosDetailsValue.build());
		rebalancerReq.add("targetAllocation", factory.createArrayBuilder().add(targetAllocationValue.build()));
		rebalancerReq.add("targetAllocationDetails", targetHoldingDetailsValue.build());

		rebalancerReq.add("lotSize", lotSizeValue.build());

	}

	private void createRebalancerRequestLotSize(final JsonBuilderFactory factory, final JsonArrayBuilder lotsSizeValue,
			final JsonObject assetCodes) {

		final JsonObjectBuilder lotParameterDetails = factory.createObjectBuilder();

		final JsonObjectBuilder lotParameterAsset = factory.createObjectBuilder();

		lotParameterAsset.add("assetId", assetCodes.getString(FieldName.VALUE));
		lotParameterAsset.add(FieldName.REBALANCER_ASSET_TYPE, "security");
		lotParameterAsset.add(FieldName.REBALANCER_SCHEME, assetCodes.getString(FieldName.SCHEME).toLowerCase());
		lotParameterDetails.add("asset", lotParameterAsset);

		if (assetCodes.containsKey(FieldName.ASSET_MIN_REDEMPTION_HOLDING_UNITS)) {
			lotParameterDetails.add(FieldName.REBALANCER_MIN_HOLDING_QTY,
					assetCodes.getJsonNumber(FieldName.ASSET_MIN_REDEMPTION_HOLDING_UNITS));
		}
		if (assetCodes.containsKey(FieldName.ASSET_MIN_REDEMPTION_UNITS)) {
			lotParameterDetails.add(FieldName.REBALANCER_MIN_SELL_QTY,
					assetCodes.getJsonNumber(FieldName.ASSET_MIN_REDEMPTION_UNITS));
		}

		if (assetCodes.containsKey(FieldName.ASSET_MIN_INVESTMENT)) {
			lotParameterDetails.add(FieldName.REBALANCER_MIN_INITIAL_BUY_VALUE,
					assetCodes.getJsonNumber(FieldName.ASSET_MIN_INVESTMENT));
		}
		if (assetCodes.containsKey(FieldName.ASSET_MIN_SUB_INVESTMENT)) {
			lotParameterDetails.add(FieldName.REBALANCER_MIN_SUBSEQUENT_BUY_VALUE,
					assetCodes.getJsonNumber(FieldName.ASSET_MIN_SUB_INVESTMENT));
		}

		lotsSizeValue.add(lotParameterDetails.build());
	}

	/**
	 * Builds the client response object for the optimiser call.
	 *
	 * @param factory
	 * @param jab
	 * @param optimiserResp
	 * @param sessionId
	 * @param curFitnessTxns
	 * @param curQuantTxns
	 * @param optFitnessTxns
	 * @param optQuantTxns
	 * @param uniqueAssetsInId
	 * @throws Exception
	 */
	private void createOptimiserResponse(final JsonBuilderFactory factory, final JsonArrayBuilder jab,
			final JsonObjectBuilder optimiserResp, final JsonObject rebalancerResp, final String sessionId,
			final List<OptTransaction> curFitnessTxns, final List<QuantPortfolioSeriesTransaction> curQuantTxns,
			final List<OptTransaction> optFitnessTxns, final List<QuantPortfolioSeriesTransaction> optQuantTxns,
			final JsonArray uniqueAssetsInId, boolean proposedTxMode, final Map<String, List<JsonObject>> zeroCashMap)
			throws Exception {

		/*
		 * Session related info
		 */
		final JsonObjectBuilder sessionResp = factory.createObjectBuilder();
		sessionResp.add(FieldName.ID, sessionId);
		sessionResp.add(FieldName.REBALANCE_STATUS, "Success");
		optimiserResp.add(FieldName.SESSION, sessionResp);
		/*
		 * Current goal info
		 */
		curFitnessTxns.forEach(txn -> {
			final JsonObjectBuilder goalResp = factory.createObjectBuilder();
			goalResp.add(FieldName.GOAL_ID, txn.goal().getString(FieldName.GOAL_ID));
			final JsonObject quantResp = curQuantTxns.get(curFitnessTxns.indexOf(txn)).body();
			goalResp.add(FieldName.RETURN, quantResp.getJsonNumber(FieldName.ANNUALIZED_RETURN).doubleValue());
			goalResp.add(FieldName.VOLATILITY, quantResp.getJsonNumber(FieldName.VOLATILITY).doubleValue());
			goalResp.add(FieldName.SHARPE, quantResp.getJsonNumber(FieldName.SHARPE).doubleValue());
			final double totalFitness = txn.body()
					.getJsonArray(FieldName.FITNESS)
					.stream()
					.map(fitness -> (JsonObject) fitness)
					.mapToDouble(fitness -> fitness.getJsonNumber(FieldName.SCORE).doubleValue())
					.sum();
			goalResp.add(FieldName.TOTAL_FITNESS_SCORE, API.toBigDecimal(totalFitness, 4));
			goalResp.add(FieldName.FITNESS, txn.body().getJsonArray(FieldName.FITNESS));
			jab.add(goalResp);
		});
		optimiserResp.add(FieldName.CURRENT_GOALS, jab.build());
		/*
		 * Optimised goal info
		 */
		optFitnessTxns.forEach(txn -> {

			final JsonObjectBuilder goalResp = factory.createObjectBuilder();

			JsonArray proposedGoals = txn.body().getJsonArray("goals");

			proposedGoals.stream().map(o -> (JsonObject) o).forEach(proposedGoal -> {
				goalResp.add(FieldName.GOAL_ID, proposedGoal.getString(FieldName.GOAL_ID));

				if (proposedGoal.getBoolean(FieldName.OPTIMISE, false)) {

					final JsonObject quantResp = optQuantTxns.get(optFitnessTxns.indexOf(txn)).body();
					goalResp.add(FieldName.RETURN, quantResp.getJsonNumber(FieldName.ANNUALIZED_RETURN).doubleValue());
					goalResp.add(FieldName.VOLATILITY, quantResp.getJsonNumber(FieldName.VOLATILITY).doubleValue());
					goalResp.add(FieldName.SHARPE, quantResp.getJsonNumber(FieldName.SHARPE).doubleValue());
					final double totalFitness = txn.body()
							.getJsonArray(FieldName.FITNESS)
							.stream()
							.map(fitness -> (JsonObject) fitness)
							.mapToDouble(fitness -> fitness.getJsonNumber(FieldName.SCORE).doubleValue())
							.sum();
					goalResp.add(FieldName.TOTAL_FITNESS_SCORE, API.toBigDecimal(totalFitness, 4));
					goalResp.add(FieldName.FITNESS, txn.body().getJsonArray(FieldName.FITNESS));
					final JsonArrayBuilder proposedTransactions = factory.createArrayBuilder();

					JsonArrayBuilder allRebalTxArr = factory.createArrayBuilder();
					if (rebalancerResp.getJsonArray(FieldName.REBALANCER_TRANSACTIONS) != null) {

						rebalancerResp.getJsonArray(FieldName.REBALANCER_TRANSACTIONS).forEach(order -> {
							allRebalTxArr.add(order);
						});

					}
					if (rebalancerResp.getJsonArray(FieldName.REBALANCER_ASSIGNMENTS) != null) {

						rebalancerResp.getJsonArray(FieldName.REBALANCER_ASSIGNMENTS).forEach(assign -> {
							allRebalTxArr.add(assign);

						});
					}

					JsonArray allRebalTx = allRebalTxArr.build();
					allRebalTx.stream().map(rebalTx -> (JsonObject) rebalTx).forEach(rebalTx -> {
						final JsonObject rebalAsset = rebalTx.getJsonObject("asset");
						final JsonObjectBuilder proposedTransaction = factory.createObjectBuilder();
						proposedTransaction.add(FieldName.ASSET_CODE, rebalAsset.getString("assetId"));
						proposedTransaction.add(FieldName.ASSET_CODE_SCHEME, rebalAsset.getString(FieldName.SCHEME));
						proposedTransaction.add(FieldName.ASSET_CURRENCY, rebalAsset.getString(FieldName.CURRENCY));

						if (rebalTx.containsKey("quantityAdjusted") && !rebalTx.isNull("quantityAdjusted")) {
							proposedTransaction.add(FieldName.AMOUNT,
									API.toBigDecimal(rebalTx.getJsonNumber("quantityAdjusted").doubleValue(), 4));
						} else {
							proposedTransaction.add(FieldName.AMOUNT,
									API.toBigDecimal(rebalTx.getJsonNumber("quantityIdeal").doubleValue(), 4));
						}

						if (rebalTx.containsKey("valueAdjusted") && !rebalTx.isNull("valueAdjusted")) {
							proposedTransaction.add(FieldName.VALUE,
									API.toBigDecimal(rebalTx.getJsonNumber("valueAdjusted").doubleValue(), 4));
						} else {
							proposedTransaction.add(FieldName.VALUE,
									API.toBigDecimal(rebalTx.getJsonNumber("valueIdeal").doubleValue(), 4));
						}

						// Common transaction recommendations
						if (rebalTx.containsKey("side")) {
							proposedTransaction.add("action", rebalTx.getString("side"));
						} else if (rebalTx.containsKey("direction")) {
							proposedTransaction.add("action", rebalTx.getString("direction"));
						}

						// transaction recommendations logic may be overridden
						// for some client.
						if (proposedTxMode) {
							String goalType = proposedGoal.getString(FieldName.GOAL);
							if (goalType.equalsIgnoreCase("customergoal")) {
								if (rebalTx.getString("side").equals("sell")) {
									proposedTransaction.add("action", "remove");
								}
							} else if (goalType.equalsIgnoreCase("generalinvestmentgoal")) {
								if (rebalTx.containsKey("direction")
										&& rebalTx.getString("direction").equals("remove")) {
									proposedTransaction.add("action", "sell");
								}
							}
						}

						// FIXME : get the value from feed map
						// proposedTransaction.add(FieldName.ASSET_TYPE,
						// rebalAsset.getString("assetType"));
						proposedTransaction.add(FieldName.ASSET_TYPE, "");
						// FIXME : NA for MVP1 only

						proposedTransaction.add(FieldName.ACCOUNT_ID, rebalTx.getString("securitySubAccount", "N/A"));
						proposedTransactions.add(proposedTransaction);

					});

					goalResp.add(FieldName.PROPOSED_TRANSACTIONS, proposedTransactions);

					final JsonArrayBuilder proposedHoldings = factory.createArrayBuilder();

					if (rebalancerResp.getJsonArray(FieldName.REBALANCER_RESP_HOLDINGS).size() > 0) {
						JsonObject adjustedHolding = rebalancerResp.getJsonArray(FieldName.REBALANCER_RESP_HOLDINGS)
								.getJsonObject(0);

						adjustedHolding.getJsonArray(FieldName.REBALANCER_RESP_POSITIONS)
								.stream()
								.map(position -> (JsonObject) position)
								.forEach(proposedPosition -> {
									final JsonObjectBuilder proposedHolding = factory.createObjectBuilder();

									proposedHolding.add(FieldName.ASSET_CODE,
											proposedPosition.getString(FieldName.REBALANCER_ASSET_ID));
									proposedHolding.add(FieldName.ASSET_CODE_SCHEME,
											proposedPosition.getString(FieldName.REBALANCER_SCHEME).toUpperCase());
									proposedHolding.add(FieldName.ASSET_CURRENCY,
											proposedPosition.getString(FieldName.REBALANCER_ASSET_CCY));
									proposedHolding.add(FieldName.VALUE, null != proposedPosition.getJsonNumber("value")
											? proposedPosition.getJsonNumber(FieldName.REBALANCER_VALUE).doubleValue()
											: 0.0);
									proposedHolding.add(FieldName.ASSET_TYPE, "");
									if (!proposedPosition.isNull(FieldName.REBALANCER_ACCOUNT_ID)) {
										proposedHolding.add(FieldName.ACCOUNT_ID,
												proposedPosition.getString(FieldName.REBALANCER_ACCOUNT_ID));
									} else {
										proposedHolding.add(FieldName.ACCOUNT_ID, "NA");
									}
									proposedHoldings.add(proposedHolding);
								});
						
					} else {
						this.logger.warn("no rolled up holding generated");
					}
					
					if (zeroCashMap != null && !zeroCashMap.isEmpty()
							&& zeroCashMap.containsKey(proposedGoal.getString(FieldName.GOAL_ID))) {

						List<JsonObject> zeroCashList = zeroCashMap.get(proposedGoal.getString(FieldName.GOAL_ID));
						zeroCashList.forEach(cash -> {

							final JsonObjectBuilder cashjob = factory.createObjectBuilder();

							cash.entrySet().forEach(entry -> cashjob.add(entry.getKey(), entry.getValue()));

							proposedHoldings.add(cashjob);

						});
					}
					
					goalResp.add(FieldName.PROPOSED_HOLDINGS, proposedHoldings);
					jab.add(goalResp);
				}

				/*
				 * translate asset-id back to codes
				 */
				if (!proposedGoal.getBoolean(FieldName.OPTIMISE, false)) {
					final JsonArrayBuilder proposedHoldings = factory.createArrayBuilder();
					proposedGoal.getJsonArray("holdings").stream().map(portfolio -> (JsonObject) portfolio).forEach(
							proposedAsset -> {
								final JsonObjectBuilder proposedHolding = factory.createObjectBuilder();
								final JsonObject assetCodes = uniqueAssetsInId.stream()
										.map(assets -> (JsonObject) assets)
										.filter(asset -> asset.getString(FieldName.ASSET_ID)
												.equals(proposedAsset.getString(FieldName.ASSET_ID)))
										.findFirst()
										.get();
								proposedHolding.add(FieldName.ASSET_CODE, assetCodes.getString(FieldName.VALUE));
								proposedHolding.add(FieldName.ASSET_CODE_SCHEME,
										assetCodes.getString(FieldName.SCHEME));
								proposedHolding.add(FieldName.ASSET_CURRENCY, assetCodes.getString(FieldName.CURRENCY));
								/*proposedHolding.add(FieldName.VALUE,
										null != proposedAsset.getJsonNumber(FieldName.VALUE)
												? API.toBigDecimal(proposedAsset.getJsonNumber(FieldName.VALUE).doubleValue(), 4)
												: 0.0);*/
								
								proposedHolding.add(FieldName.VALUE,
										API.toBigDecimal(proposedAsset.getJsonNumber(FieldName.VALUE).doubleValue(), 4)
												);
								// FIXME : get the value from feed map
								proposedHolding.add(FieldName.ASSET_TYPE, "");
								// FIXME : NA for MVP1 only
								if (proposedAsset.containsKey(FieldName.CASH_CODE)) {
									proposedHolding.add(FieldName.ACCOUNT_ID,
											proposedAsset.getString(FieldName.CASH_CODE));
								} else {
									proposedHolding.add(FieldName.ACCOUNT_ID, "NA");
								}
								proposedHoldings.add(proposedHolding);
							});
					
					if (zeroCashMap != null && !zeroCashMap.isEmpty()
							&& zeroCashMap.containsKey(proposedGoal.getString(FieldName.GOAL_ID))) {
						
						List<JsonObject> zeroCashList = zeroCashMap.get(proposedGoal.getString(FieldName.GOAL_ID));
						zeroCashList.forEach(cash -> {

							final JsonObjectBuilder cashjob = factory.createObjectBuilder();

							cash.entrySet().forEach(entry -> cashjob.add(entry.getKey(), entry.getValue()));

							proposedHoldings.add(cashjob);

						});
					}

					goalResp.add(FieldName.PROPOSED_HOLDINGS, proposedHoldings);
					jab.add(goalResp);
				}
			});

		});
		optimiserResp.add(FieldName.PROPOSED_GOALS, jab.build());

	}

	@Override
	public ResponseEntity<String> dualSeries(final String inTenant, final DualSeriesRequest request) {
		ResponseEntity<String> res = null;
		try {
			String requestBodyStr = objectMapper.writeValueAsString(request);
			mixpanelUtil.trackEvent(inTenant, "b2b-dualSeries", requestBodyStr);

			final JsonBuilderFactory factory = API.makeJsonBuilderFactory();

			final JsonArrayBuilder assetCodesArrayBuilder = factory.createArrayBuilder();
			JsonObject benchmarkJsonObject = null;
			if (request.getBenchmark() != null) {
				benchmarkJsonObject = factory.createObjectBuilder()
						.add(FieldName.ASSET_CODE_SCHEME, request.getBenchmark().getScheme())
						.add(FieldName.ASSET_CODE, request.getBenchmark().getCode())
						.add(FieldName.ASSET_CURRENCY, request.getBenchmark().getCurrency())
						.build();
			}

			this.appendCodesForTranslation(request.getAssets(), benchmarkJsonObject, assetCodesArrayBuilder, factory);

			/*
			 * Query codes from assets.
			 */
			final JsonArray assetCodes = assetCodesArrayBuilder.build();
			final JsonArray requestAssetsArray = this.assetsCodesRequest(inTenant, assetCodes.toString());

			/*
			 * Missing assets?
			 */
			if (assetCodes.size() != requestAssetsArray.size()) {
				final JsonArray notFoundAssetsArray = AssetsNotFoundException.findMissingCodes(assetCodes,
						requestAssetsArray);
				if (isMissingBenchmark(notFoundAssetsArray, benchmarkJsonObject)) {
					this.logger.warn("Benchmark not found {} {}", HttpStatus.NOT_FOUND.getReasonPhrase(),
							requestBodyStr);
				}

				this.searchAndCreateAssetRequest(notFoundAssetsArray);
				throw new AssetsNotFoundException(notFoundAssetsArray);
			}
			if (requestAssetsArray != null && !requestAssetsArray.isEmpty()) {
				final Map<String, JsonObject> assetIDToAssetMap = this.generateAssetCodeMap(requestAssetsArray);

				String from = request.getFrom();
				String until = request.getUntil();

				if (request.getUseEarliestCommonDate() || request.getUseLatestCommonDate()) {
					String[] commonDateRange = getCommonDateRange(inTenant, requestAssetsArray, request.getFrom(),
							request.getUntil(), request.getUseEarliestCommonDate(), request.getUseLatestCommonDate());
					if (commonDateRange != null && commonDateRange.length == 2) {
						from = commonDateRange[0];
						until = commonDateRange[1];
					}
				}

				final String requestBody = this.buildDualSeriesRequest(requestAssetsArray, benchmarkJsonObject, from,
						until, request.getShift());

				res = SecuredRestHelper.sendRequest(this.quant, EndPoints.QUANT_1_DUAL_SERIES, inTenant, requestBody,
						HttpMethod.POST, this.tenantContext, true);

				if (res != null && res.getStatusCode().is2xxSuccessful()) {
					DualSeriesResponse quantDualSeriesResponse = objectMapper.readValue(res.getBody(),
							DualSeriesResponse.class);

					this.mapDualSeriesResponse(quantDualSeriesResponse, assetIDToAssetMap);
					if (quantDualSeriesResponse != null) {
						res = new ResponseEntity<>(objectMapper.writeValueAsString(quantDualSeriesResponse),
								HttpStatus.OK);
					}
				}

			}

		} catch (final IllegalArgumentException illegalArgumentException) {

			this.logger.error(HttpStatus.BAD_REQUEST.getReasonPhrase(), illegalArgumentException);
			return new ResponseEntity<>("", HttpStatus.BAD_REQUEST);

		} catch (final AssetsNotFoundException assetsNotFoundException) {

			this.logger.error(HttpStatus.NOT_FOUND.getReasonPhrase(), assetsNotFoundException);
			return new ResponseEntity<>(assetsNotFoundException.getCodesMissingAssets().toString(),
					HttpStatus.NOT_FOUND);

		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			if (httpException.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
				this.logger.error(HttpStatus.UNAUTHORIZED.getReasonPhrase(), httpException);
				return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
			}
			this.logger.error(httpException.getStatusCode().getReasonPhrase(), httpException);
			return new ResponseEntity<>("", httpException.getStatusCode());
		} catch (final Exception e) {

			this.logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			return new ResponseEntity<>("", HttpStatus.INTERNAL_SERVER_ERROR);

		}
		return res;
	}

	private final boolean isMissingBenchmark(final JsonArray inMissingAssetsArray, final JsonObject inBenchmarkObject) {
		final String benchmarkCode = API.getStringValue(inBenchmarkObject, FieldName.ASSET_CODE);
		final String benchmarkScheme = API.getStringValue(inBenchmarkObject, FieldName.ASSET_CODE_SCHEME);
		for (JsonValue missingAsset : inMissingAssetsArray) {
			final JsonObject missingAssetObject = (JsonObject) missingAsset;
			final String assetCode = API.getStringValue(missingAssetObject, FieldName.ASSET_CODE);
			final String assetScheme = API.getStringValue(missingAssetObject, FieldName.ASSET_CODE_SCHEME);
			if (assetCode.equalsIgnoreCase(benchmarkCode) && assetScheme.equalsIgnoreCase(benchmarkScheme)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * massage the response from quant to include the asset details, namely
	 * asset-code, asset-code-scheme, and currency
	 *
	 * @param inResponseBody
	 * @param assetIDToAssetMap
	 * @param dateStringFrom
	 * @param dateStringUntil
	 * @param jsonFactory
	 * @return
	 */
	private final void mapDualSeriesResponse(final DualSeriesResponse quantDualSeriesResponse,
			final Map<String, JsonObject> assetIDToAssetMap) {
		List<DualSeriesAsset> dualSeriesAssetList = quantDualSeriesResponse.getAssets();

		if (dualSeriesAssetList != null && !dualSeriesAssetList.isEmpty()) {

			for (DualSeriesAsset dualSeriesAsset : dualSeriesAssetList) {

				final JsonObject assetDetailsObject = assetIDToAssetMap.get(dualSeriesAsset.getAssetID());
				if (assetDetailsObject != null) {
					final String assetCode = API.getStringValue(assetDetailsObject, FieldName.VALUE);
					final String assetScheme = API.getStringValue(assetDetailsObject, FieldName.SCHEME);
					final String currency = API.getStringValue(assetDetailsObject, FieldName.CURRENCY);

					dualSeriesAsset.setCode(assetCode);
					dualSeriesAsset.setScheme(assetScheme);
					dualSeriesAsset.setCurrency(currency);
				}
			}
		}
	}

	/**
	 * generate a asset-mongo-id to asset-details map which will be used for
	 * mapping the quant response
	 *
	 * @param assetsArray
	 * @return
	 */
	private final Map<String, JsonObject> generateAssetCodeMap(final JsonArray assetsArray) {
		Map<String, JsonObject> map = null;

		if (assetsArray != null && !assetsArray.isEmpty()) {
			map = new HashMap<>();
			for (JsonValue assetValue : assetsArray) {
				final JsonObject assetObject = (JsonObject) assetValue;
				final String assetID = API.getStringValue(assetObject, FieldName.ASSET_ID);
				map.put(assetID, assetObject);
			}
		}

		return map;
	}

	private String[] getCommonDateRange(final String tenant, final JsonArray assetsArray, final String from,
			final String until, final boolean useEarliestCommonDate, final boolean useLatestCommonDate) {

		if (assetsArray == null || assetsArray.isEmpty())
			return null;

		List<Asset> assetList = new ArrayList<>();
		for (JsonValue assetValue : assetsArray) {
			final JsonObject assetObject = (JsonObject) assetValue;
			final String assetID = API.getStringValue(assetObject, FieldName.ASSET_ID);
			final String inceptionDate = API.getStringValue(assetObject, FieldName.INCEPTION_DATE);

			Asset asset = new Asset();
			asset.setAssetId(assetID);
			asset.setInceptionDate(inceptionDate);
			assetList.add(asset);
		}
		DateRange dateRange = new DateRange();
		dateRange.setFrom(from);
		dateRange.setUntil(until);
		return commonService.preProcessDate(tenant, dateRange, assetList, useEarliestCommonDate, useLatestCommonDate);
	}

	/**
	 * Builds the dual series request for quant service.
	 *
	 * @param assetsArray
	 * @param benchmarkObject
	 * @param from
	 * @param until
	 * @param factory
	 * @return
	 * @throws JsonProcessingException
	 */
	private final String buildDualSeriesRequest(final JsonArray assetsArray, final JsonObject benchmarkObject,
			final String from, final String until, final Shift shift) throws JsonProcessingException {

		String benchmarkID = null;
		boolean benchmarkIsSet = false;
		String benchmarkCode = null;
		String benchmarkScheme = null;
		if (benchmarkObject != null) {
			benchmarkCode = API.getStringValue(benchmarkObject, FieldName.ASSET_CODE);
			benchmarkScheme = API.getStringValue(benchmarkObject, FieldName.ASSET_CODE_SCHEME);
		}

		List<String> assetIDList = new ArrayList<>();
		for (JsonValue assetValue : assetsArray) {
			final JsonObject assetObject = (JsonObject) assetValue;
			final String assetID = API.getStringValue(assetObject, FieldName.ASSET_ID);
			final String assetCode = API.getStringValue(assetObject, FieldName.VALUE);
			final String assetScheme = API.getStringValue(assetObject, FieldName.SCHEME);

			if (assetID != null && assetCode != null && assetScheme != null) {
				if (assetCode.equalsIgnoreCase(benchmarkCode) && assetScheme.equalsIgnoreCase(benchmarkScheme)) {
					if (benchmarkIsSet) {
						continue;
					}
					benchmarkID = assetID;
					benchmarkIsSet = true;
				} else {
					assetIDList.add(assetID);
				}
			}
		}

		QuantDualSeriesRequest request = new QuantDualSeriesRequest();
		request.setAssets(assetIDList);
		request.setBenchmarkID(benchmarkID);
		request.setFrom(from);
		request.setUntil(until);
		request.setShift(shift);

		return objectMapper.writeValueAsString(request);
	}
}
