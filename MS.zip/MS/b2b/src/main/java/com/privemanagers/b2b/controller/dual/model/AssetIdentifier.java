package com.privemanagers.b2b.controller.dual.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * asset identifier object used in b2b dual series request
 *
 * @author wzhang
 * @date 25 Oct 2018
 * @company Prive Financial
 */
public class AssetIdentifier {

	@NotNull(message = "invalidAssetSchema")
	@NotEmpty(message = "invalidAssetSchema")
	@JsonProperty("asset-code")
	private String code;

	@NotNull(message = "invalidAssetSchema")
	@NotEmpty(message = "invalidAssetSchema")
	@JsonProperty("asset-code-scheme")
	private String scheme;

	@NotNull(message = "invalidAssetSchema")
	@NotEmpty(message = "invalidAssetSchema")
	@JsonProperty("asset-currency")
	private String currency;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
}
