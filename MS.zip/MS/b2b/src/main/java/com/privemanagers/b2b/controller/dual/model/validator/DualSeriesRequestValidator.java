package com.privemanagers.b2b.controller.dual.model.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.privemanagers.api.API;
import com.privemanagers.b2b.controller.dual.model.DualSeriesRequest;
import com.privemanagers.model.quant.ShiftType;

/**
 * custom validator for b2b dual series requests
 *
 * @author wzhang
 * @date 25 Oct 2018
 * @company Prive Financial
 */
public class DualSeriesRequestValidator implements ConstraintValidator<DualSeriesRequestValid, DualSeriesRequest> {

	@Override
	public boolean isValid(DualSeriesRequest value, ConstraintValidatorContext context) {
		boolean isAdaquate = isAdaquateRequest(value);
		boolean isValidVarianceRequest = validateVarianceRequest(value);
		boolean isValidDateRange = validateDate(value, context);
		if (!isAdaquate) {
			buildContext(context, "missingBenchmarkShift");
		} else if (!isValidVarianceRequest) {
			buildContext(context, "missingBenchmarkInBenchmarkShift");
		} else if (!isValidDateRange) {
			buildContext(context, "invalidDateRange");
		}
		return isAdaquate && isValidVarianceRequest && isValidDateRange;
	}

	/**
	 * the request must contain either one of the followings or it can contain
	 * both if it is for benchmark sensitivity analysis:
	 *
	 * @benchmarkObject
	 * @sensitivityShiftObject
	 */
	private boolean isAdaquateRequest(DualSeriesRequest value) {
		return (value.getShift() != null || value.getBenchmark() != null);
	}

	/**
	 * if the request demands benchmark sensitivity analysis, then the
	 * benchmarkID or reference assetID must not be null
	 */
	private boolean validateVarianceRequest(DualSeriesRequest value) {
		if (value.getShift() != null && value.getShift().getType().equals(ShiftType.BENCHMARK))
			return (value.getBenchmark() != null);
		return true;
	}

	/**
	 * validates the date range
	 */
	private boolean validateDate(DualSeriesRequest value, ConstraintValidatorContext context) {
		try {
			return API.validateDates(value.getFrom(), value.getUntil());
		} catch (Exception e) {
			buildContext(context, e.getMessage());
			return false;
		}
	}

	private void buildContext(ConstraintValidatorContext context, String message) {
		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(message).addConstraintViolation();

	}

}
