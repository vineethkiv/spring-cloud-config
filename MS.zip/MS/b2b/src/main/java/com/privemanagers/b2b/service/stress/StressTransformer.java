package com.privemanagers.b2b.service.stress;

import java.util.List;

import org.springframework.stereotype.Component;

import com.privemanagers.b2b.controller.model.PortfolioItemV2;
import com.privemanagers.b2b.controller.stress.model.StressRequestV1;
import com.privemanagers.b2b.controller.stress.model.StressRequestV2;
import com.privemanagers.b2b.service.common.PerformanceStressCommonTransformer;

/**
 * Stress Request transformer
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@Component
public class StressTransformer extends PerformanceStressCommonTransformer {

	/**
	 * Transform v1 request to v2 request
	 *
	 * @param v1
	 * @return
	 */
	public StressRequestV2 transform(StressRequestV1 v1) {
		if (v1 == null) {
			return null;
		}

		StressRequestV2 v2 = new StressRequestV2();
		v2.setBenchmarks(v1.getBenchmarks());
		v2.setCrisis(v1.getCrisis());
		v2.setModel(v1.getModel());
		v2.setRecovery(v1.getRecovery());
		v2.setReferenceCurrency(v1.getReferenceCurrency());
		v2.setStatistics(v1.getStatistics());
		v2.setUseEarliestCommonDate(v1.getUseEarliestCommonDate());
		v2.setUseLatestCommonDate(v1.getUseLatestCommonDate());
		v2.setValueCurrency(v1.getValueCurrency());

		List<PortfolioItemV2> currentPortfolio = transform(v1.getCurrentPortfolio());
		v2.setCurrentPortfolio(currentPortfolio);

		List<PortfolioItemV2> proposedPortfolio = transform(v1.getProposedPortfolio());
		v2.setProposedPortfolio(proposedPortfolio);

		return v2;
	}

}
