package com.privemanagers.b2b.field;

/**
 * @author Vineeth Kiv
 * @date 28 Jun 2018
 * @company Prive Financial
 */
public enum CalculationMethod {
	
	INSTRUMENT,

	ASSET_CLASS;
	
}