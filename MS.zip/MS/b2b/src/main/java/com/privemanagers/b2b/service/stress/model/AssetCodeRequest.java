package com.privemanagers.b2b.service.stress.model;

import java.util.List;

/**
 * Asset code request calling asset codes api
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
public class AssetCodeRequest {
    List<AssetCode> assetCodes;

    public List<AssetCode> getAssetCodes() {
        return assetCodes;
    }

    public void setAssetCodes(List<AssetCode> assetCodes) {
        this.assetCodes = assetCodes;
    }
}
