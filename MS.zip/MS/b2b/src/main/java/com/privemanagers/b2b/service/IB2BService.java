package com.privemanagers.b2b.service;

import org.springframework.http.ResponseEntity;

import com.privemanagers.b2b.controller.dual.model.DualSeriesRequest;
import com.privemanagers.b2b.exception.AssetsNotFoundException;

/**
 * @author nteck
 * @date : 19 Apr, 2017
 * @company Prive Financial
 */
public interface IB2BService {

	/**
	 * Request and optimised portfolio with fitness scores
	 *
	 * @param tenant
	 * @param body
	 * @return
	 */
	public ResponseEntity<String> optimise(final String tenant, final String body);

	/**
	 * Request a dual series analysis on a list of assets based on a benchmark
	 *
	 * @param tenant
	 * @param body
	 * @return
	 * @throws AssetsNotFoundException
	 */
	public ResponseEntity<String> dualSeries(final String inTenant, final DualSeriesRequest request);
}
