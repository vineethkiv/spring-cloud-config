package com.privemanagers.b2b.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.privemanagers.api.ValueCurrencyType;
import com.privemanagers.b2b.service.QuantTransaction;
import com.privemanagers.exception.ApplicationExceptionItem;
import com.privemanagers.exception.ApplicationMultiLevelException;
import com.privemanagers.model.error.ApplicationErrorItem;

/**
 * Helper functions for performance and stress used commonly
 *
 * @author Kay Ip
 * @date 30 Apr 2018
 * @company Prive Financial
 */
@Component
public class PerformanceStressCommonUtil {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private final int timeout;
	private final String appName;

	private static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	@Autowired
	public PerformanceStressCommonUtil(@Value("${prive.timeout}") final int timeout,
			@Value("${prive.resource.id}") final String appName) {
		this.timeout = timeout;
		this.appName = appName;
	}

	public ValueCurrencyType resolveValueCurrencyType(String valueCurrencyStr) {
		ValueCurrencyType valueCurrency = ValueCurrencyType.ASSET;
		if (StringUtils.isBlank(valueCurrencyStr)) {
			return valueCurrency;
		}
		return ValueCurrencyType.parseType(valueCurrencyStr);
	}

	public String formatDate(String input) {
		LocalDate date = LocalDate.parse(input, STRING_TO_DATE);
		return date.format(STRING_TO_DATE);
	}

	/**
	 * Wait for all the async responses and return the overall success.
	 *
	 * @param latch
	 * @param transactions
	 * @return boolean
	 */
	public boolean waitForResponses(final CountDownLatch latch, final List<QuantTransaction> transactions) {
		try {
			latch.await(timeout, TimeUnit.SECONDS);
		} catch (final InterruptedException e) {
		}

		/*
		 * Verify all responses are OK.
		 */
		boolean truth = true;
		for (final QuantTransaction trx : transactions) {
			final boolean success = HttpStatus.OK == trx.status();
			if (!success) {
				if (!CollectionUtils.isEmpty(trx.getErrors())) {
					// response errorItem to exception errorItem, then throw
					ArrayList<ApplicationExceptionItem> exceptionItems = new ArrayList<>();
					for (ApplicationErrorItem errorItem : trx.getErrors()) {
						ApplicationExceptionItem exceptionItem = new ApplicationExceptionItem();
						exceptionItem.setErrorCode(errorItem.getErrorCode());
						exceptionItem.setErrorMessage(errorItem.getErrorMessage());

						exceptionItems.add(exceptionItem);
					}
					throw new ApplicationMultiLevelException(appName, MDC.get("request"),
							HttpStatus.INTERNAL_SERVER_ERROR, exceptionItems);
				}
				if (trx.status() != null) {
					logger.warn("{} {}", trx.status().getReasonPhrase(), trx.uri());
				}
			}
			truth = truth && success;
		}
		return truth;
	}

	public JsonObjectBuilder jsonObjectToBuilder(JsonObject jo) {
		JsonObjectBuilder job = Json.createObjectBuilder();

		for (Map.Entry<String, JsonValue> entry : jo.entrySet()) {
			job.add(entry.getKey(), entry.getValue());
		}

		return job;
	}
}
