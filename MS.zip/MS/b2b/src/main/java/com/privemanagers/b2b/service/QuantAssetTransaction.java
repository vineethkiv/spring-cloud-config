package com.privemanagers.b2b.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.DataConstants;
import com.privemanagers.api.EndPoints;
import com.privemanagers.api.TenantContext;
import com.privemanagers.b2b.field.FieldName;
import com.privemanagers.sc.util.SecuredRestHelper;

public class QuantAssetTransaction extends QuantTransaction {

	/**
	 * The required statistics as a query string.
	 */
	public static final String QUANT_PARAMETERS;
	private List<String> statisticsList;

	static {
		final StringBuilder x = new StringBuilder();
		x.append("relative=100&statistics=");
		for (int i = 0; i < QUANT_STATISTICS.length; i++) {
			switch (i) {
			case 0:
				break;
			default:
				x.append(",");
			}
			x.append(QUANT_STATISTICS[i]);
		}
		QUANT_PARAMETERS = x.toString();
	}

	private String constructParameters() {
		final StringBuilder x = new StringBuilder();
		x.append("relative=100&statistics=");
		x.append(StringUtils.join(this.statisticsList, ","));

		return x.toString();
	}

	/** Month between from and until date */
	private final long monthBetween;

	public QuantAssetTransaction(final String baseURL, final String tenant, final String assetID, final String from,
			final String until, final String currency, final CountDownLatch latch, final TenantContext tenantContext,
			final List<String> statistics) {
		super(latch, tenantContext);
		this.statisticsList = statistics;
		final UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseURL);
		builder.path(EndPoints.QUANT_1_ASSET_SERIES);
		builder.queryParam(FieldName.FROM, from);
		builder.queryParam(FieldName.UNTIL, until);
		builder.queryParam(FieldName.CURRENCY, currency);
		if (this.getStatisticsList() != null && !this.getStatisticsList().isEmpty()) {
			builder.query(this.constructParameters());
		} else {
			builder.query(QUANT_PARAMETERS);
		}
		this.uri(builder.buildAndExpand(tenant, assetID).toUri());

		final LocalDate fromDate = LocalDate.parse(from);
		final LocalDate untilDate = LocalDate.parse(until);
		this.monthBetween = ChronoUnit.MONTHS.between(fromDate, untilDate);
	}

	@Override
	public void send(final ThreadPoolTaskExecutor executor) {
		final ListenableFuture<ResponseEntity<String>> future = SecuredRestHelper.sendRequest(executor, this.uri(),
				null, null, HttpMethod.GET, this.tenantContext(), true);
		future.addCallback(this);
	}

	/**
	 * Dirty fix for SLYAWS-10934 to replace the return value by the
	 * annualized-return value. It should be a temporary fix as we planned to
	 * have a v2 of our APIs to retire the return field and include explicitly
	 * the annualized-return and cumulative-return fields.
	 *
	 * Hack again for SLYAWS-10948. We will need to display cum-return when the
	 * range is less than 1 year and ann-return when it's greater than 1 year
	 */
	@Override
	protected void constructStats(final String field, final JsonObjectBuilder stats, final JsonObject response) {
		if (response.containsKey(field)) {
			switch (field) {
			case DataConstants.STATISTIC_RETURN:
				if (this.monthBetween < 12) {
					stats.add(DataConstants.STATISTIC_RETURN, response.get(field));
				}
				break;
			case DataConstants.STATISTIC_ANNUALIZED_RETURN:
				if (this.monthBetween >= 12) {
					stats.add(DataConstants.STATISTIC_RETURN, response.get(field));
				}
				break;
			default:
				super.constructStats(field, stats, response);
			}
		}
	}

	/**
	 * @return the statisticsList
	 */
	public List<String> getStatisticsList() {
		return this.statisticsList;
	}

	/**
	 * @param statisticsList
	 *            the statisticsList to set
	 */
	public void setStatisticsList(final List<String> statisticsList) {
		this.statisticsList = statisticsList;
	}

}
