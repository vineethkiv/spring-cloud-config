package com.privemanagers.b2b.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.api.util.SlackUtil;
import com.privemanagers.model.common.slack.AttachmentField;
import com.privemanagers.model.common.slack.SlackAlertLevel;
import com.privemanagers.model.common.slack.SlackAttachment;
import com.privemanagers.model.common.slack.SlackMessage;

/**
 * util to create and send information to slack
 *
 * @author Kay Ip
 * @date 18 July 2018
 * @company Prive Financial
 */
@Component
public class AlertUtil {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private SlackUtil slackUtil;

	@Autowired
	private Environment environment;

	@Value("${prive.slack.alert.b2b.error}")
	private String b2bWebhook;

	@Value("${prive.resource.id}")
	private String resourceId;

	/**
	 * send alert for 0 value for get model portfolio last NAV
	 *
	 * @param tenant
	 * @param modelRef
	 * @throws JsonProcessingException
	 */
	public void logGetModelPortfolioLastNavZero(final String tenant, final String modelRef) {
		// SLYAWS-12618: currently fubon needs only alert to slack
		if (!"fubon-tw".equals(tenant)) {
			logger.info("tenant:{}, modelRef:{} has 0 for last NAV, does not alert to slack", tenant, modelRef);
			return;
		}

		List<AttachmentField> attachmentFields = getBasicInfoAttachmentFields(tenant);
		attachmentFields.add(0, new AttachmentField("modelRef", modelRef, false));

		String title = "Get model portfolio, last record of NAV is zero";
		SlackMessage message = buildSlackMessage(title, SlackAlertLevel.ERROR, attachmentFields);

		sendMessage(message);
	}

	/**
	 * set basic info for message alert
	 *
	 * @return
	 */
	private List<AttachmentField> getBasicInfoAttachmentFields(String tenant) {

		List<AttachmentField> attachmentFields = new ArrayList<>();
		attachmentFields.add(new AttachmentField("Application", resourceId, true));
		attachmentFields.add(new AttachmentField("Tenant", tenant, true));
		attachmentFields.add(new AttachmentField("Springboot Profile",
				StringUtils.join(environment.getActiveProfiles(), ","), true));
		return attachmentFields;
	}

	private SlackMessage buildSlackMessage(String title, SlackAlertLevel alertLevel,
			List<AttachmentField> attachmentFields) {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		SlackAttachment slackAttachment = new SlackAttachment();
		slackAttachment.setFields(attachmentFields);
		slackAttachment.setTitle(title);
		slackAttachment.setFooter("Server Date time: " + now.format(formatter));
		slackAttachment.setColor(alertLevel.getSlackMessageColor());

		SlackMessage slackMessage = new SlackMessage();
		slackMessage.setAttachments(Arrays.asList(slackAttachment));
		return slackMessage;
	}

	/**
	 * Send slackMessage to slack webhook
	 *
	 * @param slackMessage
	 */
	private void sendMessage(final SlackMessage slackMessage) {
		try {
			String messageJson = objectMapper.writeValueAsString(slackMessage);
			slackUtil.postRichMessage(b2bWebhook, messageJson);
			logger.info("sent alert to slack");
		} catch (JsonProcessingException e) {
			logger.error("fail to parse message", e);
		}
	}
}
