package com.privemanagers.sce.fsm;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.web.client.HttpClientErrorException;

import com.privemanagers.sc.shared.CommonStrings;
import com.privemanagers.sce.util.RequestWrapper;

/**
 * Request fitler to handle different type of authentication
 *
 * @author Gavy Lau
 */
public class StatefulPreAuthenticationFilter extends AbstractPreAuthenticatedProcessingFilter {

	private static final Logger log = LoggerFactory.getLogger(StatefulPreAuthenticationFilter.class);

	@Autowired
	TokenStore tokenStore;

	@Override
	@Autowired
	public void setAuthenticationManager(final AuthenticationManager authenticationManager) {
		super.setAuthenticationManager(authenticationManager);
	}

	/**
	 * Do preauth filter to handle different methodlogy (New token, Legacy
	 * Token, Username/Password or SkipToken - Developor bypass) and start off
	 * the state machine from the initial state
	 */
	@Override
	public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
			throws IOException, ServletException {

		RequestWrapper request = null;
		HttpServletResponse response = (HttpServletResponse) res;
		try {

			request = new RequestWrapper((HttpServletRequest) req);

			String token = null;
			final String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
			boolean isDeprecatedToken = false;
			if (authHeader != null && authHeader.startsWith(CommonStrings.BEARER_TOKEN_PREFIX.getStringValue())
					&& authHeader.length() >= 8) {
				token = authHeader.substring(7);
				log.debug("token from header: {}", token);
				isDeprecatedToken = isDeprecatedToken(token);
			}

			/*
			 * if it was not developer bypass and the token in header is null or
			 * opaque, outside of these conditions should be a new valid token
			 * so all these can be skipped
			 */
			if (token == null || isDeprecatedToken) {
				String tenant = null;
				final String uri = request.getRequestURI();

				final String[] pathArray = uri.split("/");
				if (pathArray.length >= 4) {
					Pattern pattern = Pattern.compile("(?<=\\d+/)(.*?)(?=/)");
					Matcher matcher = pattern.matcher(uri);

					if (matcher.find()) {
						tenant = matcher.group(1);
					}

					if (tenant == null) {
						tenant = pathArray[3];
					}
				}

				final String username = request.getHeader(CommonStrings.HEADER_KEY_API_USERNAME.getStringValue());
				final String password = request.getHeader(CommonStrings.HEADER_KEY_API_PASSWORD.getStringValue());

				/*
				 * continues to process until state becomes null
				 * (PreAuthenticationState.DEVELOPER_BYPASS) if its
				 * unauthorized, the delegated state would throw
				 * HttpClientErrorException
				 */
				PreAuthenticationState state = PreAuthenticationState.DEVELOPER_BYPASS;
				while (state != null) {
					state = state.process(request, tenant, username, password, token, isDeprecatedToken);
				}
			}

		} catch (HttpClientErrorException e1) {
			response.setStatus(e1.getStatusCode().value());
		}
		chain.doFilter(request, response);
	}

	@Override
	protected Object getPreAuthenticatedPrincipal(final HttpServletRequest req) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return auth.getPrincipal();
	}

	@Override
	protected Object getPreAuthenticatedCredentials(final HttpServletRequest request) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return ((OAuth2AccessToken) auth.getDetails()).getValue();
	}

	private final boolean isDeprecatedToken(final String inToken) {
		try {
			tokenStore.readAccessToken(inToken);
			return false;
		} catch (Exception e) {
			return true;
		}
	}
}
