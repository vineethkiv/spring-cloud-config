package com.privemanagers.sce.fsm;

import java.util.EnumSet;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.privemanagers.sc.service.impl.ExternalAuthAPIService;
import com.privemanagers.sc.shared.CommonStrings;
import com.privemanagers.sce.util.RequestWrapper;

/**
 * Handles the following scenarios before spring security kicks in. The initial
 * state should always be {@link PreAuthenticationState#DEVELOPER_BYPASS}
 *
 * 1. developer bypass <br/>
 * 2. token generated from the previous algorithm <br/>
 * 3. request without authorization header but has user credentials in the
 * header
 *
 * @author Gavy Lau
 *
 */
public enum PreAuthenticationState {

	DEVELOPER_BYPASS {
		@Override
		public PreAuthenticationState process(final RequestWrapper request, final String tenant, final String username,
				final String password, final String tokenFromHeader, final boolean isDeprecatedToken) {
			logger.debug("in STATE: {}", this.name());
			if (CommonStrings.DEVELOPER_BYPASS_CHECK.getStringValue().equalsIgnoreCase(this.getSkipTokenCheck())) {
				logger.debug("trying to authenticate in {}", this.name());

				String generatedAccessToken = this.getExternalAuthAPIService().getOAuth2AuthenticationToken(tenant,
						null, null, null);

				if (generatedAccessToken != null) {
					AUTHENTICATED.setAccessToken(generatedAccessToken);
					return AUTHENTICATED;
				}
			} else if (isDeprecatedToken) {
				return LEGACY_TOKEN;
			} else {
				return USER_CREDENTIALS;
			}

			return UNAUTHORIZED;
		}

	},
	LEGACY_TOKEN {
		@Override
		public PreAuthenticationState process(final RequestWrapper request, final String tenant, final String username,
				final String password, final String tokenFromHeader, final boolean isDeprecatedToken) {
			logger.debug("in STATE: {}", this.name());

			if (isDeprecatedToken) {
				logger.debug("trying to authenticate in {} with {}:", this.name(), isDeprecatedToken);

				String generatedAccessToken = this.getExternalAuthAPIService().getOAuth2AuthenticationToken(tenant,
						null, null, tokenFromHeader);

				if (generatedAccessToken != null) {
					AUTHENTICATED.setAccessToken(generatedAccessToken);
					return AUTHENTICATED;
				}
			} else {
				return USER_CREDENTIALS;
			}

			return UNAUTHORIZED;
		}

	},
	USER_CREDENTIALS {
		@Override
		public PreAuthenticationState process(final RequestWrapper request, final String tenant, final String username,
				final String password, final String tokenFromHeader, final boolean isDeprecatedToken) {
			logger.debug("in STATE: {}", this.name());

			if (username != null && password != null) {
				logger.debug("trying to authenticate in {}", this.name());

				String generatedAccessToken = this.getExternalAuthAPIService().getOAuth2AuthenticationToken(tenant,
						username, password, null);

				if (generatedAccessToken != null) {
					AUTHENTICATED.setAccessToken(generatedAccessToken);
					return AUTHENTICATED;
				}
			}

			return UNAUTHORIZED;
		}

	},
	AUTHENTICATED {
		@Override
		public PreAuthenticationState process(final RequestWrapper request, final String tenant, final String username,
				final String password, final String tokenFromHeader, final boolean isDeprecatedToken) {
			logger.debug("in STATE: {}", this.name());

			String generatedAccessToken = this.getAccessToken();
			if (generatedAccessToken == null) {
				// this should not happen
				return UNAUTHORIZED;
			}

			logger.debug("setting new acccess token {} to security context", generatedAccessToken);
			final OAuth2Authentication auth = this.getTokenStore().readAuthentication(generatedAccessToken);
			auth.setAuthenticated(true);

			OAuth2AccessToken oauth2Token = this.getTokenStore().readAccessToken(generatedAccessToken);
			auth.setDetails(oauth2Token);
			request.setToken(CommonStrings.BEARER_TOKEN_PREFIX.getStringValue() + oauth2Token.getValue());

			SecurityContextHolder.getContext().setAuthentication(auth);

			return null;
		}

	},
	UNAUTHORIZED {
		@Override
		public PreAuthenticationState process(final RequestWrapper request, final String tenant, final String username,
				final String password, final String tokenFromHeader, final boolean isDeprecatedToken) {
			logger.error("in STATE: {}", this.name());
			throw new HttpClientErrorException(HttpStatus.UNAUTHORIZED);
		}

	};

	private static final Logger logger = LoggerFactory.getLogger(PreAuthenticationState.class);

	private String skipTokenCheck;
	private ExternalAuthAPIService externalAuthAPIService;
	private TokenStore tokenStore;

	/** Storing the current access token to be used in other state */
	private String accessToken = null;

	/**
	 * Process the requerst and return the next {@link PreAuthenticationState}
	 *
	 * @param request
	 * @param tenant
	 * @param username
	 * @param password
	 * @param tokenFromHeader
	 * @param isDeprecatedToken
	 * @return
	 */
	public abstract PreAuthenticationState process(final RequestWrapper request, final String tenant,
			final String username, final String password, final String tokenFromHeader,
			final boolean isDeprecatedToken);

	/**
	 * Injecting service and variable from Spring
	 *
	 * @param skipTokenCheck
	 * @param externalAuthAPIService
	 * @param tokenStore
	 */
	public void setup(final String skipTokenCheck, final ExternalAuthAPIService externalAuthAPIService,
			final TokenStore tokenStore) {
		this.skipTokenCheck = skipTokenCheck;
		this.externalAuthAPIService = externalAuthAPIService;
		this.tokenStore = tokenStore;
	}

	// injects beans into enum class
	@Component
	public static class BeanInjector {

		@Value("${PRIVE_SKIPTOKENCHECK:#{null}}")
		private String skipTokenCheck;

		@Autowired
		private ExternalAuthAPIService externalAuthAPIService;

		@Autowired
		TokenStore tokenStore;

		@PostConstruct
		public void postConstruct() {
			for (PreAuthenticationState state : EnumSet.allOf(PreAuthenticationState.class))
				state.setup(skipTokenCheck, externalAuthAPIService, tokenStore);
		}
	}

	public String getSkipTokenCheck() {
		return skipTokenCheck;
	}

	public ExternalAuthAPIService getExternalAuthAPIService() {
		return externalAuthAPIService;
	}

	public TokenStore getTokenStore() {
		return tokenStore;
	}

	public String getAccessToken() {
		return accessToken;
	}

	protected void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
}
