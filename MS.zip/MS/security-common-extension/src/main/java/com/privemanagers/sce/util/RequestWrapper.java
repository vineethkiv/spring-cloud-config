package com.privemanagers.sce.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.springframework.http.HttpHeaders;

/**
 * class to override the getHeader methods in order to replace header in
 * self-authenticated requests
 *
 * @author Gavy Lau
 *
 */
public class RequestWrapper extends HttpServletRequestWrapper {

	private String token;

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public Enumeration<String> getHeaders(String name) {
		if (name.equalsIgnoreCase(HttpHeaders.AUTHORIZATION) && this.token != null) {
			List<String> temp = new ArrayList<>();
			temp.add(this.token);
			return Collections.enumeration(temp);
		}
		return super.getHeaders(name);
	}

	@Override
	public String getHeader(String name) {
		if (HttpHeaders.AUTHORIZATION.equalsIgnoreCase(name) && this.token != null) {
			return this.token;

		}
		final String value = this.getParameter(name);
		if (value != null) {
			return value;
		}
		return super.getHeader(name);
	}

	public RequestWrapper(HttpServletRequest request) {
		super(request);

	}
}
