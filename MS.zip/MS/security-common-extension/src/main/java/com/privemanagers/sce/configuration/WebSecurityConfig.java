package com.privemanagers.sce.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.privemanagers.api.EndPoints;

/**
 * @author William Zhang
 * @date 4 Dec 2017
 * @company Prive Financial
 */

@Configuration
@ConditionalOnProperty(value = "prive.security.frontend.enabled", havingValue = "false", matchIfMissing = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(HttpMethod.GET, EndPoints.HEALTH).and().ignoring().antMatchers(
				EndPoints.ERROR + "/**");
	}

}
