package com.privemanagers.sce.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

import com.privemanagers.api.EndPoints;
import com.privemanagers.sc.configuration.ResourceServerConfiguration;
import com.privemanagers.sce.fsm.StatefulPreAuthenticationFilter;

/**
 * Extending the generic configuration from security-common since b2b requires
 * special logic new configs are configure(HttpSecurity http),
 * AbstractPreAuthenticatedProcessingFilter, and AuthenticationProvider
 *
 * @author Gavy Lau
 */
@Configuration
public class ExtendedResourceServerConfiguration extends ResourceServerConfiguration {

	@Autowired
	@Qualifier("authenticationManagerBean")
	private AuthenticationManager authenticationManagerBean;

	@Value("${prive.resource.id:missing-resource.id}")
	private String resourceID;

	/**
	 * Adding PreAuthenticationFilter to authenticate and authorize users in our
	 * own ways before passing on to further authorization with spring security
	 */
	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.csrf()
				.disable()
				.anonymous()
				.and()
				.authorizeRequests()
				.antMatchers(HttpMethod.GET, EndPoints.HEALTH)
				.permitAll()
				.antMatchers(EndPoints.ERROR + "/**")
				.permitAll()
				.antMatchers("/" + resourceID + "/**")
				.authenticated()
				.and()
				.exceptionHandling()
				.authenticationEntryPoint((request, response, e) -> {
					response.setStatus(HttpStatus.UNAUTHORIZED.value());
				})
				.and()
				.addFilterBefore(preAuthenticationFilter(), AbstractPreAuthenticatedProcessingFilter.class);

	}

	/**
	 * pre authentication filter to perform custom authentication before spring
	 * security
	 *
	 * @return
	 */
	@Bean
	public AbstractPreAuthenticatedProcessingFilter preAuthenticationFilter() {
		return new StatefulPreAuthenticationFilter();
	}

	/**
	 * spring automatically registers any filter declared as a bean, so in our
	 * case we will need to disable the auto registration to avoid the filter
	 * being invoked twice per request
	 *
	 * @return
	 */
	@Bean
	public FilterRegistrationBean<AbstractPreAuthenticatedProcessingFilter> registration() {
		FilterRegistrationBean<AbstractPreAuthenticatedProcessingFilter> registration = new FilterRegistrationBean<AbstractPreAuthenticatedProcessingFilter>(
				preAuthenticationFilter());
		registration.setEnabled(false);
		return registration;
	}

}
