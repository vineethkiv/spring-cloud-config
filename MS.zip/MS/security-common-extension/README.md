# security-common-extension jar

import this to enable spring security in your service, this will validate tokens on any incoming http requests, if extra permission is needed, check expression based access control (i.e. @PreAuthorize)

this will also add a special PreAuth filter before spring security kicks in to allow special conditions like legacy token, user credentials, and developer bypass


## Environment variables (already defined in application-sharaed.properties)

The environment variable assignments below are intended for desktop development only.

`prive.auth.public.cert.filename:public_key.cert`

the filename of the public_key stored under src/main/resources

`prive.auth=http://localhost:8099`

the url of the auth service

`prive.auth.admin.secret=c|+|3nQu!Eh`

the client secret for the admin user

### how to configure the newly secured service (check b2b for example)

add shared properties config to Application class:

add this annotation to the Application class
@Import(SharedAutoConfiguration.class)

add the following in application.properties:
`prive.resource.id=your_service_name`