/*
 * mongo --shell init_admin_user.js
 * use prive
 * db.users.find().pretty()
 */


/*
 * Auth
 */
var mongo = new Mongo('127.0.0.1:27017');
var db = mongo.getDB('admin');
db.auth("root", "3v1rP_42");

db = mongo.getDB('prive');

/*
 * Create users collection
 */

db.users.drop();
db.createCollection("users");
db.users.createIndex({"name":1},{unique: true});
// create default admin user
// default password is chelski_849 BCrypted
db.users.insert({"name":"priveadmin", "password":"$2a$10$.UGHUHw1xwoEpC0nP7nVyusptlYveHYlj5fmQjUhaEKREgG4btIN6"});
db.users.insert({"name" : "SlyAWS", "password" : "$2a$10$nsEiz3EIalKWEsF8NFTrx.TLtnO6b7c9MJLA08qkOY6uqGMUstq4K"});




