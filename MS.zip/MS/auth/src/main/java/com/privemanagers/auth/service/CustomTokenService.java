package com.privemanagers.auth.service;

public interface CustomTokenService {

	/**
	 * Generates an oauth2 token based on different set of input, returns a
	 * filtered json string
	 *
	 * @param tenant
	 * @param inDeprecatedToken
	 * @param inUsername
	 * @param inPassword
	 * @param clientSecret
	 * @return
	 */
	public String getOAuth2Token(final String tenant, final String inDeprecatedToken, final String inUsername,
			final String inPassword, final String clientSecret, final boolean accessTokenOnly);

	/**
	 * Refresh an expiried token
	 *
	 * @param inTenant
	 * @param inRefreshToken
	 * @return
	 */
	public String refreshToken(final String inRefreshToken, final boolean accessTokenOnly);
}
