package com.privemanagers.auth.shared;

/**
 * Common string used by the service
 *
 * @author Gavy Lau
 */
public enum CommonStrings {

	COMMON_KEY_USERNAME("username"),
	COMMON_KEY_PASSWORD("password"),
	DOCUMENT_KEY_ROLES("roles"),
	DOCUMENT_KEY_RESOURCES("resources"),
	DOCUMENT_KEY_USER_GROUP("user-group"),
	DOCUMENT_KEY_USER_SECRET("user-secret"),
	DOCUMENT_KEY_DEPRECATED_TOKEN("deprecated-token"),
	PARAMETER_KEY_GRANT_TYPE("grant_type"),
	PARAMETER_KEY_CLIENT_ID("client_id"),
	PARAMETER_KEY_CLIENT_SECRET("client_secret"),
	RESPONSE_KEY_ACCESS_TOKEN("access_token"),
	RESPONSE_KEY_REFRESH_TOKEN("refresh_token"),
	RESPONSE_KEY_TOKEN_TYPE("token_type"),
	RESPONSE_KEY_EXPIRES_IN("expires_in"),
	RESPONSE_KEY_EXPIRATION_TIME("expiration_time"),
	DOCUMENT_KEY_ACCOUNT_NON_EXPIRED("accountNonExpired"),
	DOCUMENT_KEY_ACCOUNT_NON_LOCKED("accountNonLocked"),
	DOCUMENT_KEY_CREDENTIALS_NON_EXPIRED("credentialsNonExpired"),
	DOCUMENT_KEY_ENABLED("enabled"),
	TENANT("tenant");

	private String stringValue;

	CommonStrings(final String stringValue) {
		this.stringValue = stringValue;
	}

	public final String getStringValue() {
		return stringValue;
	}
}
