package com.privemanagers.auth.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

import com.privemanagers.auth.domain.CustomUser;
import com.privemanagers.auth.shared.CommonStrings;

/**
 * Custom token converter to add resources info into the jwt token claim
 *
 * @author Gavy Lau
 */
public class CustomTokenConverter extends JwtAccessTokenConverter {

	/**
	 * Enhances an {@link OAuth2AccessToken} to add resources under resources
	 * key in the claims
	 */
	@Override
	public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
		CustomUser user = (CustomUser) authentication.getPrincipal();

		final Map<String, Object> additionalInfo = new HashMap<>();

		additionalInfo.put(CommonStrings.DOCUMENT_KEY_RESOURCES.getStringValue(), user.getResources());

		((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);

		return super.enhance(accessToken, authentication);
	}
}
