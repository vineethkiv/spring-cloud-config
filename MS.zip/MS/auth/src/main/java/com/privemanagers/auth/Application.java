package com.privemanagers.auth;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.privemanagers.db.MongoDBConfiguration;

@SpringBootApplication(scanBasePackages = "com.privemanagers")
public class Application implements MongoDBConfiguration {

	public static void main(final String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Value("${prive.mongodb.uri:missing-prive.mongodb.uri}")
	private String uri;

	@Value("${prive.mongodb.db:missing-prive.mongodb.db}")
	private String db;

	@Override
	public String uri() {
		return this.uri;
	}

	@Override
	public String db() {
		return this.db;
	}

}
