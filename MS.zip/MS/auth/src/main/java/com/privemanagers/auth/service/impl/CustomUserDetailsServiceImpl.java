package com.privemanagers.auth.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.privemanagers.auth.domain.CustomUser;
import com.privemanagers.auth.repository.UserRepository;

/**
 * @author William Zhang
 * @date 4 Dec 2017
 * @company Prive Financial
 */
@Service
public class CustomUserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	/**
	 * overrides spring UserDetailsService method to find an user based on the
	 * username
	 *
	 */
	@Override
	public CustomUser loadUserByUsername(String username) throws UsernameNotFoundException {
		CustomUser user = userRepository.findByUsername(username);

		if (user == null) {
			throw new UsernameNotFoundException(username);
		}

		return user;
	}
}