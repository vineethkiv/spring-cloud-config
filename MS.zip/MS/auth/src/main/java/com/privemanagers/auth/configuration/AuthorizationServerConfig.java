package com.privemanagers.auth.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.client.BaseClientDetails;
import org.springframework.security.oauth2.provider.client.InMemoryClientDetailsService;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.oauth2.provider.token.store.KeyStoreKeyFactory;
import org.springframework.util.StringUtils;

import com.privemanagers.api.EndPoints;
import com.privemanagers.auth.service.impl.CustomUserDetailsServiceImpl;

/**
 * @author William Zhang
 * @date 5 Dec 2017
 * @company Prive Financial
 */
@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

	@Autowired
	@Qualifier("authenticationManagerBean")
	private AuthenticationManager authenticationManager;

	@Autowired
	private CustomUserDetailsServiceImpl userDetailsService;

	@Value("${prive.auth.granttype.refreshtoken:missing-auth.granttype.refreshtoken}")
	private String grantTypeRefreshToken;

	@Value("${prive.auth.granttype.password:missing-auth.granttype.password}")
	private String grantTypePassword;

	@Value("${prive.auth.granttype.client.credientials:missing-auth.granttype.client.credientials}")
	private String grantTypeClientCredentials;

	@Value("${prive.auth.scope.api:missing-auth.scope.api}")
	private String scopeAPI;

	@Value("${prive.auth.admin.user.group:missing-auth.admin.user.group}")
	private String adminUsername;

	@Value("${prive.auth.tenant.user.group:missing-auth.tenant.user.group}")
	private String tenantUsername;

	@Value("${prive.auth.admin.secret:missing-auth.admin.secret}")
	private String adminSecret;

	@Value("${prive.auth.admin.token.validity.seconds:missing-auth.admin.token.validity.seconds}")
	private int adminTokenValiditySeconds;

	@Value("${prive.auth.tenant.token.validity.seconds:missing-auth.tenant.token.validity.seconds}")
	private int tenantTokenValiditySeconds;

	@Value("${prive.auth.privatekey.password:missing-auth.privatekey.password}")
	private String privateKeyPass;

	@Value("${prive.auth.privatekey.name:missing-auth.privatekey.name}")
	private String privateKeyName;

	@Value("${prive.auth.privatekey.filename:missing-auth.privatekey.filename}")
	private String privateKeyFilename;

	/**
	 * configures client details service, it will only be updated at service
	 * startups
	 *
	 */
	@Override
	public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
		// TODO: use jdbc to allow dynamic data source
		clients.withClientDetails(getClientDetailsService());
	}

	/**
	 * authenticates the client using the form parameters instead of basic auth
	 *
	 */
	@Override
	public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
		oauthServer.allowFormAuthenticationForClients();
	}

	/**
	 * Configures the spring authorization endpoints to map to our custom
	 * endpoint
	 */
	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
		endpoints.pathMapping("/oauth/authorize", EndPoints.AUTH_1_AUTHORIZE)
				.pathMapping("/oauth/token", EndPoints.AUTH_1_TOKEN)
				.pathMapping("/oauth/check_token", EndPoints.AUTH_1_CHECK_TOKEN)
				.pathMapping("/oauth/confirm_access", EndPoints.AUTH_1_CONFIRM_ACCESS)
				.pathMapping("/oauth/token_key", EndPoints.AUTH_1_TOKEN_KEY)
				.pathMapping("/oauth/error", EndPoints.AUTH_1_ERROR)
				.tokenStore(tokenStore())
				.tokenEnhancer(jwtTokenEnhancer())
				.authenticationManager(authenticationManager)
				.userDetailsService(userDetailsService);
	}

	/**
	 * Constrcut a spring {@link TokenStore}
	 *
	 * @return
	 */
	@Bean
	public TokenStore tokenStore() {
		return new JwtTokenStore(jwtTokenEnhancer());
	}

	/**
	 * Creates a token enchancer to use stored private key. This use a custom
	 * token converter {@link CustomTokenConverter}
	 */
	@Bean
	protected JwtAccessTokenConverter jwtTokenEnhancer() {
		KeyStoreKeyFactory keyStoreKeyFactory = new KeyStoreKeyFactory(new ClassPathResource(privateKeyFilename),
				privateKeyPass.toCharArray());
		JwtAccessTokenConverter converter = new CustomTokenConverter();
		converter.setKeyPair(keyStoreKeyFactory.getKeyPair(privateKeyName));
		return converter;
	}

	/**
	 * creates client details service in memory
	 *
	 */
	@Bean
	protected ClientDetailsService getClientDetailsService() {
		// only 2 types of client details services: inmemory or jdbc
		// for dynamic clients we will have to use jdbc
		// inmemory clients are created in memory at startup
		InMemoryClientDetailsService clientDetailsService = new InMemoryClientDetailsService();
		Map<String, ClientDetails> clientDetailsMap = new HashMap<>();

		String grantTypes = grantTypePassword + "," + grantTypeRefreshToken + "," + grantTypeClientCredentials;

		// we do not set the resourceIDs here into the client since we want that
		// to be on the user level
		BaseClientDetails tenantUserClientDetails = new BaseClientDetails(tenantUsername, null, scopeAPI, grantTypes,
				null);
		tenantUserClientDetails.setAccessTokenValiditySeconds(tenantTokenValiditySeconds);
		tenantUserClientDetails.setAutoApproveScopes(StringUtils.commaDelimitedListToSet(scopeAPI));
		clientDetailsMap.put(tenantUsername, tenantUserClientDetails);

		BaseClientDetails adminUserClientDetails = new BaseClientDetails(adminUsername, null, scopeAPI, grantTypes,
				null);

		adminUserClientDetails.setAccessTokenValiditySeconds(adminTokenValiditySeconds);
		adminUserClientDetails.setAutoApproveScopes(StringUtils.commaDelimitedListToSet(scopeAPI));
		adminUserClientDetails.setClientSecret(adminSecret);
		clientDetailsMap.put(adminUsername, adminUserClientDetails);

		clientDetailsService.setClientDetailsStore(clientDetailsMap);

		return clientDetailsService;
	}
}
