package com.privemanagers.auth.repository;

import com.privemanagers.auth.domain.CustomUser;

/**
 * Repository for User
 *
 * @author Gavy Lau
 */
public interface UserRepository {

	/**
	 * Find {@link CustomUser} based on the given username
	 *
	 * @param inUsername
	 * @return
	 */
	CustomUser findByUsername(final String inUsername);

	/**
	 * Get {@link CustomUser} based on the given legacy token
	 *
	 * @param inToken
	 * @return
	 */
	CustomUser getByDeprecatedToken(final String inToken);
}
