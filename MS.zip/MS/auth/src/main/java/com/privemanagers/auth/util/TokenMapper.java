package com.privemanagers.auth.util;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import javax.json.JsonBuilderFactory;
import javax.json.JsonObjectBuilder;

import org.springframework.security.oauth2.common.OAuth2AccessToken;

import com.privemanagers.api.API;
import com.privemanagers.auth.shared.CommonStrings;

/**
 * Utils class to for {@link OAuth2AccessToken}
 *
 * @author Gavy Lau
 */
public class TokenMapper {

	private static final JsonBuilderFactory factory = API.makeJsonBuilderFactory();

	/**
	 * maps an OAuth2AccessToken to a watered down version to hide some info
	 * from the user
	 */
	public static final String mapOAuth2Token(final OAuth2AccessToken inAccessToken, final boolean inAccessTokenOnly) {

		if (inAccessToken != null) {
			final JsonObjectBuilder builder = factory.createObjectBuilder();
			builder.add(CommonStrings.RESPONSE_KEY_ACCESS_TOKEN.getStringValue(), inAccessToken.getValue());

			if (!inAccessTokenOnly) {
				builder.add(CommonStrings.RESPONSE_KEY_REFRESH_TOKEN.getStringValue(),
						inAccessToken.getRefreshToken().getValue());
				builder.add(CommonStrings.RESPONSE_KEY_TOKEN_TYPE.getStringValue(), inAccessToken.getTokenType());
				builder.add(CommonStrings.RESPONSE_KEY_EXPIRES_IN.getStringValue(), inAccessToken.getExpiresIn());
				ZonedDateTime utcExpirationDate = ZonedDateTime.ofInstant(inAccessToken.getExpiration().toInstant(),
						ZoneId.of("UTC"));
				builder.add(CommonStrings.RESPONSE_KEY_EXPIRATION_TIME.getStringValue(),
						utcExpirationDate.toEpochSecond());
			}
			return builder.build().toString();
		}

		return null;
	}

	private TokenMapper() {
	};
}
