package com.privemanagers.auth;

import javax.json.JsonObject;
import javax.json.JsonValue.ValueType;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.privemanagers.api.API;
import com.privemanagers.api.EndPoints;
import com.privemanagers.auth.service.impl.CustomTokenServiceImpl;
import com.privemanagers.auth.shared.CommonStrings;

@RestController
public class Controller {
	@Autowired
	private CustomTokenServiceImpl tokenService;

	@RequestMapping(path = EndPoints.AUTH_1_LOGIN, method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<String> login(final HttpServletRequest request, @RequestBody String inBody,
			@RequestParam(defaultValue = "false") final boolean accessTokenOnly) {
		String token = null;
		final String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
		if (authHeader != null && authHeader.length() >= 8) {
			token = authHeader.substring(7);
		}

		String username = null;
		String password = null;
		String clientSecret = null;
		String tenant = null;

		if (inBody != null && inBody.length() > 0) {
			final JsonObject object = API.parseObject(inBody);

			if (object.get(CommonStrings.TENANT.getStringValue()) != null
					&& object.get(CommonStrings.TENANT.getStringValue()).getValueType().equals(ValueType.STRING)) {
				tenant = object.getString(CommonStrings.TENANT.getStringValue());
			}

			if (object.get(CommonStrings.COMMON_KEY_USERNAME.getStringValue()) != null
					&& object.get(CommonStrings.COMMON_KEY_USERNAME.getStringValue())
							.getValueType()
							.equals(ValueType.STRING)) {
				username = object.getString(CommonStrings.COMMON_KEY_USERNAME.getStringValue());
			}
			if (object.get(CommonStrings.COMMON_KEY_PASSWORD.getStringValue()) != null
					&& object.get(CommonStrings.COMMON_KEY_PASSWORD.getStringValue())
							.getValueType()
							.equals(ValueType.STRING)) {
				password = object.getString(CommonStrings.COMMON_KEY_PASSWORD.getStringValue());
			}
			if (object.get(CommonStrings.PARAMETER_KEY_CLIENT_SECRET.getStringValue()) != null
					&& object.get(CommonStrings.PARAMETER_KEY_CLIENT_SECRET.getStringValue())
							.getValueType()
							.equals(ValueType.STRING)) {
				clientSecret = object.getString(CommonStrings.PARAMETER_KEY_CLIENT_SECRET.getStringValue());
			}
		}

		final String accessToken = tokenService.getOAuth2Token(tenant, token, username, password, clientSecret,
				accessTokenOnly);

		if (accessToken == null) {
			return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<>(accessToken, HttpStatus.OK);
	}

	@RequestMapping(path = EndPoints.AUTH_1_REFRESH_TOKEN, method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<String> refresh(final HttpServletRequest request, @RequestBody String inBody,
			@RequestParam(defaultValue = "false") final boolean accessTokenOnly) {
		String accessToken = null;

		if (inBody != null && inBody.length() > 0) {
			final JsonObject object = API.parseObject(inBody);

			if (object.get(CommonStrings.RESPONSE_KEY_REFRESH_TOKEN.getStringValue()) != null
					&& object.get(CommonStrings.RESPONSE_KEY_REFRESH_TOKEN.getStringValue())
							.getValueType()
							.equals(ValueType.STRING)) {
				final String refreshToken = object.getString(CommonStrings.RESPONSE_KEY_REFRESH_TOKEN.getStringValue());
				accessToken = tokenService.refreshToken(refreshToken, accessTokenOnly);
			}
		}
		if (accessToken == null) {
			return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<>(accessToken, HttpStatus.OK);
	}
}
