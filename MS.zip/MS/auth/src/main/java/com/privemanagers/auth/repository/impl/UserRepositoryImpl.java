package com.privemanagers.auth.repository.impl;

import javax.annotation.PostConstruct;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.mongodb.client.MongoCollection;
import com.privemanagers.auth.domain.CustomUser;
import com.privemanagers.auth.repository.UserRepository;
import com.privemanagers.auth.shared.CommonStrings;
import com.privemanagers.db.MongoDBConnection;

@Repository
public class UserRepositoryImpl implements UserRepository {

	private final MongoDBConnection connection;
	private final String usersCollectionName;

	private MongoCollection<Document> usersCollection;

	@Autowired
	public UserRepositoryImpl(final MongoDBConnection connection,
			@Value("${prive.mongodb.collection.users:missing-prive.mongodb.collection.users}") final String usersCollectionName) {
		this.connection = connection;
		this.usersCollectionName = usersCollectionName;
	}

	@PostConstruct
	public void init() {
		this.usersCollection = connection.database().getCollection(usersCollectionName);
	}

	/**
	 * construct a single condition find query and returns the document
	 *
	 */
	private Document findBySingleQuery(MongoCollection<Document> collection, String inQueryKey, String inQueryValue) {
		final Document criteria = new Document(inQueryKey, inQueryValue);

		return collection.find(criteria).first();
	}

	@Override
	public CustomUser findByUsername(String inUsername) {
		final Document user = findBySingleQuery(this.usersCollection,
				CommonStrings.COMMON_KEY_USERNAME.getStringValue(), inUsername);
		return CustomUser.constructUserBasedOnDocument(user);
	}

	@Override
	public CustomUser getByDeprecatedToken(String inToken) {
		final Document user = findBySingleQuery(this.usersCollection,
				CommonStrings.DOCUMENT_KEY_DEPRECATED_TOKEN.getStringValue(), inToken);
		return CustomUser.constructUserBasedOnDocument(user);
	}

}
