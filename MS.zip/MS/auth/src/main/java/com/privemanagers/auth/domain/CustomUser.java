package com.privemanagers.auth.domain;

import java.util.List;
import java.util.stream.Collectors;

import org.bson.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.privemanagers.auth.shared.CommonStrings;

/**
 * @author wzhang
 * @date 21 Sep 2017
 * @company Prive Financial
 *
 *          extends Spring User object for custom logic
 */
public class CustomUser extends User {

	private static final long serialVersionUID = 4726013762122427953L;

	// @NotNull
	/** Role of the user. This would normally be the tenant id e.g. citi-hk */
	private List<String> roles;

	// @NotNull
	/**
	 * Resource the user can access. This would noramlly be the service name
	 * e.g. b2b, quant
	 */
	private List<String> resources;

	// @NotNull
	/** Spring related field. This shuold either be tenant_user or admin_user */
	private String userGroup;

	/** Spring related field. Only admin_user have value */
	private String userGroupSecret;

	/**
	 * Create {@link CustomUser} base on the give document
	 *
	 * @param document
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static CustomUser constructUserBasedOnDocument(Document document) {
		if (document != null) {
			String name = document.getString(CommonStrings.COMMON_KEY_USERNAME.getStringValue());
			String password = document.getString(CommonStrings.COMMON_KEY_PASSWORD.getStringValue());
			List<String> roles = (List<String>) document.get(CommonStrings.DOCUMENT_KEY_ROLES.getStringValue());
			List<String> resources = (List<String>) document.get(CommonStrings.DOCUMENT_KEY_RESOURCES.getStringValue());
			String userGroup = document.getString(CommonStrings.DOCUMENT_KEY_USER_GROUP.getStringValue());
			String userGroupSecret = document.getString(CommonStrings.DOCUMENT_KEY_USER_SECRET.getStringValue());

			final boolean accountNonExpired = document
					.getBoolean(CommonStrings.DOCUMENT_KEY_ACCOUNT_NON_EXPIRED.getStringValue());

			final boolean accountNonLocked = document
					.getBoolean(CommonStrings.DOCUMENT_KEY_ACCOUNT_NON_LOCKED.getStringValue());

			final boolean credentialsNonExpired = document
					.getBoolean(CommonStrings.DOCUMENT_KEY_CREDENTIALS_NON_EXPIRED.getStringValue());

			final boolean enabled = document.getBoolean(CommonStrings.DOCUMENT_KEY_ENABLED.getStringValue());

			return new CustomUser(name, password, roles, resources, userGroup, userGroupSecret, enabled,
					accountNonExpired, accountNonLocked, credentialsNonExpired);
		}
		return null;
	}

	public CustomUser(String username, String password, List<String> roles, List<String> resources, String userGroup,
			String userGroupSecret, boolean enabled, boolean accountNonExpired, boolean accountNonLocked,
			boolean credentialsNonExpired) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked,
				roles.stream().map(role -> (GrantedAuthority) () -> role).collect(Collectors.toList()));

		this.resources = resources;
		this.roles = roles;
		this.userGroup = userGroup;
		this.userGroupSecret = userGroupSecret;
	}

	/**
	 * User is consider enabled if it's account is not exepired, not locked and
	 * is enabled
	 *
	 * @return
	 */
	public boolean isUserEnabled() {
		return this.isAccountNonExpired() && this.isAccountNonLocked() && this.isEnabled();
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getResources() {
		return resources;
	}

	public void setResources(List<String> resources) {
		this.resources = resources;
	}

	public String getUserGroup() {
		return userGroup;
	}

	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	public String getUserGroupSecret() {
		return userGroupSecret;
	}

	public void setUserGroupSecret(String userGroupSecret) {
		this.userGroupSecret = userGroupSecret;
	}

}
