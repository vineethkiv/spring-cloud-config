package com.privemanagers.auth.service.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Service;

import com.privemanagers.auth.domain.CustomUser;
import com.privemanagers.auth.repository.UserRepository;
import com.privemanagers.auth.service.CustomTokenService;
import com.privemanagers.auth.shared.CommonStrings;
import com.privemanagers.auth.util.TokenMapper;

@Service
public class CustomTokenServiceImpl implements CustomTokenService {

	@Value("${prive.auth.granttype.password:missing-auth.granttype.password}")
	private String grantTypePassword;

	@Value("${prive.auth.scope.api:missing-auth.scope.api}")
	private String apiScope;

	@Value("${prive.auth.admin.username:missing-auth.admin.username}")
	private String adminUserName;

	@Value("${prive.auth.admin.secret:missing-auth.admin.secret}")
	private String adminSecret;

	/**
	 * Static key to grant access to all tenant {@link CustomUser#getRoles()}.
	 * Only Admin user should have this
	 */
	private static final String ALL_TENANTS_AUTHORITY = "ROLE_ADMIN";

	private static final Logger logger = LoggerFactory.getLogger(CustomTokenServiceImpl.class);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	private PasswordEncoder passwordEncoder;

	private final AuthorizationServerTokenServices tokenService;

	private final AuthorizationServerEndpointsConfiguration configuration;

	public CustomTokenServiceImpl(@Autowired AuthorizationServerEndpointsConfiguration configuration) {
		this.configuration = configuration;
		this.tokenService = this.configuration.getEndpointsConfigurer().getTokenServices();
	}

	@Override
	public String refreshToken(final String inRefreshToken, final boolean accessTokenOnly) {
		OAuth2AccessToken accessToken = null;

		final OAuth2RefreshToken oauth2RefreshToken = tokenStore.readRefreshToken(inRefreshToken);
		if (oauth2RefreshToken != null) {
			OAuth2Authentication authentication = tokenStore.readAuthenticationForRefreshToken(oauth2RefreshToken);
			if (authentication == null) {
				logger.error("could not read authentication from refresh token: {}", inRefreshToken);
				return null;
			}
			final CustomUser user = userRepository.findByUsername(authentication.getName());
			if (user == null || !user.isEnabled()) {
				logger.error("refreshing token failed for: {}", inRefreshToken);
				return null;
			}
			Map<String, String> requestParameters = null;
			if (user.getUserGroupSecret() != null) {
				requestParameters = new HashMap<>();
				requestParameters.put(CommonStrings.PARAMETER_KEY_CLIENT_SECRET.getStringValue(),
						user.getUserGroupSecret());
			}
			final TokenRequest request = new TokenRequest(requestParameters,
					authentication.getOAuth2Request().getClientId(), null,
					CommonStrings.RESPONSE_KEY_REFRESH_TOKEN.getStringValue());
			accessToken = tokenService.refreshAccessToken(inRefreshToken, request);
		}

		return TokenMapper.mapOAuth2Token(accessToken, accessTokenOnly);
	}

	/**
	 * generates an oauth2 token based on different set of input, returns a
	 * filtered json string
	 */
	@Override
	public String getOAuth2Token(final String tenant, String inDeprecatedToken, final String inUsername,
			final String inPassword, final String clientSecret, final boolean accessTokenOnly) {
		OAuth2AccessToken accessToken = null;

		if (inUsername != null && inPassword != null) {
			accessToken = this.generateToken(tenant, inUsername, inPassword, null, false);
		} else if (inDeprecatedToken != null) {
			accessToken = this.generateToken(tenant, inDeprecatedToken);
		} else if (clientSecret != null) {
			accessToken = this.generateTokenForAdminUser(tenant);
		}

		return TokenMapper.mapOAuth2Token(accessToken, accessTokenOnly);
	}

	/**
	 * Generates an oauth2 token for the admin user
	 */
	private final OAuth2AccessToken generateTokenForAdminUser(final String tenant) {
		final CustomUser user = userRepository.findByUsername(adminUserName);
		// handles negative cases
		if (user == null || !user.isUserEnabled() || !adminSecret.equalsIgnoreCase(user.getUserGroupSecret())) {
			logger.error("could not get admin token for admin user: {}", adminUserName);
			return null;
		}
		return this.generateToken(tenant, user.getUsername(), null, user.getUserGroupSecret(), true);

	}

	/**
	 * Generates an oauth2 token using old token. e.g. this would be the legacy
	 * token given to Citi
	 */
	private final OAuth2AccessToken generateToken(final String tenant, final String inDeprecatedToken) {
		if (inDeprecatedToken != null) {
			final CustomUser user = userRepository.getByDeprecatedToken(inDeprecatedToken);

			// handles negative cases
			if (user == null || !user.isEnabled()) {
				logger.error("invalid legacy token: {}", inDeprecatedToken);
				return null;
			}
			return this.generateToken(tenant, user.getUsername(), null, user.getUserGroupSecret(), true);
		}
		return null;
	}

	/**
	 * Generates an OAuth2AccessToken using user credentials by user username
	 * and password
	 */
	private final OAuth2AccessToken generateToken(final String tenant, final String inUsername, final String inPassword,
			final String clientSecret, final boolean isPreAuthenticated) {
		if (inUsername != null) {
			final CustomUser user = userRepository.findByUsername(inUsername);
			// handles negative cases
			if (user == null || !user.isEnabled() || !isAuthorizedTenant(tenant, user)) {
				logger.error("generating token failed for user: {}", inUsername);
				return null;
			}
			final boolean isValidated = isPreAuthenticated || passwordEncoder.matches(inPassword, user.getPassword());

			// handles invalid password/legacy token/admin secret
			if (!isValidated) {
				logger.error("invalid credentials for user: {}", inUsername);
				return null;
			}
			Map<String, String> authorizationParameters = new HashMap<>();
			authorizationParameters.put(CommonStrings.COMMON_KEY_USERNAME.getStringValue(), user.getUsername());
			authorizationParameters.put(CommonStrings.PARAMETER_KEY_GRANT_TYPE.getStringValue(), grantTypePassword);
			authorizationParameters.put(CommonStrings.PARAMETER_KEY_CLIENT_ID.getStringValue(), user.getUserGroup());
			if (clientSecret != null) {
				authorizationParameters.put(CommonStrings.PARAMETER_KEY_CLIENT_SECRET.getStringValue(), clientSecret);
			}
			Set<String> scopes = new HashSet<>();
			scopes.add(apiScope);

			Set<String> responseTypes = new HashSet<>();
			responseTypes.add(CommonStrings.COMMON_KEY_PASSWORD.getStringValue());

			final OAuth2Authentication oauth2Authentiction = generateOAuth2Authentication(authorizationParameters,
					user.getUserGroup(), null, isValidated, scopes, null, null, responseTypes, null, user);

			return (OAuth2AccessToken) oauth2Authentiction.getDetails();

		}
		return null;
	}

	/**
	 * generates the OAuth2Authentication using tokenservices
	 *
	 */
	private final OAuth2Authentication generateOAuth2Authentication(final Map<String, String> requestParameters,
			final String clientId, final Collection<? extends GrantedAuthority> authorities, final boolean approved,
			final Set<String> scope, final Set<String> resourceIds, final String redirectUri,
			final Set<String> responseTypes, final Map<String, Serializable> extensionProperties,
			final CustomUser user) {

		final OAuth2Request authorizationRequest = new OAuth2Request(requestParameters, clientId, authorities, approved,
				scope, resourceIds, redirectUri, responseTypes, extensionProperties);

		final UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(user,
				user.getPassword(), user.getAuthorities());

		final OAuth2Authentication oauth2Authentication = new OAuth2Authentication(authorizationRequest,
				authenticationToken);
		oauth2Authentication.setAuthenticated(true);

		final OAuth2AccessToken token = tokenService.createAccessToken(oauth2Authentication);
		oauth2Authentication.setDetails(token);

		return oauth2Authentication;
	}

	/**
	 * checks to see if the user is authorized to access information of the
	 * given tenant
	 *
	 */
	private final boolean isAuthorizedTenant(String tenant, final CustomUser user) {
		if (user.getRoles() != null && !user.getRoles().isEmpty()) {
			final List<String> allowedTenants = user.getRoles();

			if (allowedTenants.contains(ALL_TENANTS_AUTHORITY))
				return true;

			if (tenant == null) {
				/*
				 * to cater to regular login/refresh flow where tenant is not in
				 * the path in legacy and special cases, the tenant is parsed
				 * from the original requests' url
				 */
				tenant = allowedTenants.get(0);
			}

			for (final String allowedTenant : allowedTenants) {
				if (allowedTenant.equalsIgnoreCase(tenant)) {
					return true;
				}
			}
		}
		return false;
	}

}
