package com.privemanagers.auth.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.privemanagers.api.EndPoints;
import com.privemanagers.auth.service.impl.CustomUserDetailsServiceImpl;

/**
 * @author William Zhang
 * @date 4 Dec 2017
 * @company Prive Financial
 */
@Order(-1)
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private CustomUserDetailsServiceImpl userDetailsService;

	@Value("${prive.resource.id:missing-resource.id}")
	private String resourceID;

	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authProvider());
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public DaoAuthenticationProvider authProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService);
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}

	/**
	 * Cconfigures endpoint access rights, permit public anonymous access to
	 * certain endpoints and require authentication for everything under the
	 * resourcesID/path
	 */
	@Override
	public void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity.csrf()
				.disable()
				.anonymous()
				.and()
				.authorizeRequests()
				.antMatchers(HttpMethod.GET, EndPoints.HEALTH)
				.permitAll()
				.antMatchers(EndPoints.ERROR + "/**")
				.permitAll()
				.antMatchers(HttpMethod.POST, EndPoints.AUTH_1_LOGIN)
				.permitAll()
				.antMatchers(HttpMethod.POST, EndPoints.AUTH_1_REFRESH_TOKEN)
				.permitAll()
				.antMatchers("/" + resourceID + "/**")
				.denyAll();
	}

}
