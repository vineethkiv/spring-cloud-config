# Auth microservice

Auth is the de facto authorization server used to create jwt tokens with a private key while all the other underlying services are resources servers that have the ability to validate tokens based on a shared public key. the setup follows the guidelines of spring security.


## Environment variables

The environment variable assignments below are intended for desktop development only.

`PRIVE_MONGODB_URI=mongodb://username:pwd@localhost:27017`

Specifies the connection string for MongoDB. Read and write concern options should be specified here.
See [MongoDB documentation](https://docs.mongodb.com/manual/reference/connection-string/) for details.

`PRIVE_MONGODB_DB=prive`

Specifies the database this service uses.

### How to generate private public key pairs (only if you need to, dev, uat, and prod certs are already in place)

Using CLI:

for private key (used in authorization server):
keytool -genkeypair -alias private_key -keyalg RSA -dname "CN=private_key, L=Hong Kong, S=Hong Kong, C=HK" -keypass changeit -keystore private_key.jks -storepass changeit


for public cert (used in resources servers)
keytool -list -rfc --keystore private_key.jks | openssl x509 -inform pem -pubkey

this will prompt you for the private keystore password, once that is verified, copy the public key from -----BEGIN PUBLIC KEY----- to -----END PUBLIC KEY----- and save it in a text file as your_public_key.cert
