package com.privemanagers.model.asset;

/**
 * Price types
 *
 * @author Kay Ip
 * @date 6 July 2018
 * @company Prive Financial
 */
public enum PriceDataType {
	RAW,
	ADJUSTED;

	public static final String FIELD = "priceDataType";
}
