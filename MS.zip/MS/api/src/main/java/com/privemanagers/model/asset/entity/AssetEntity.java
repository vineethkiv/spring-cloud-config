package com.privemanagers.model.asset.entity;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.privemanagers.api.ObjectIdSerializer;
import com.privemanagers.model.asset.AssetClass;
import com.privemanagers.model.asset.Sector;
import com.privemanagers.model.asset.SettingsFrequency;
import com.privemanagers.model.asset.ShareClass;
import com.privemanagers.model.common.Region;

/**
 * Entity class for Asset
 *
 * @author Kay Ip
 * @date 24 Oct 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssetEntity {

	// common fields
	@Id
	@JsonProperty("_id")
	@JsonSerialize(using = ObjectIdSerializer.class)
	private ObjectId id;
	private Map<String, String> name;
	private String currency;
	@JsonProperty("cfi-code")
	private String cfiCode;
	private String type;
	private Region region;
	private String country;
	private AssetClass assetclass;
	private Sector sector;
	private Boolean hedgefund;
	@JsonProperty("custom-asset")
	private Boolean customAsset;
	@JsonProperty("data-source")
	private String dataSource;
	private Map<String, String> description;
	@JsonProperty("inception-date")
	private String inceptionDate;
	@JsonProperty("inception-price")
	private Double inceptionPrice;
	@JsonProperty("benchmark-id")
	@JsonSerialize(using = ObjectIdSerializer.class)
	private ObjectId benchmarkId;
	private Boolean mirrorFund;
	private List<UnderlyingAsset> underlying;
	private Date createTime;
	private Date lastUpdateTime;

	// public codes
	@JsonProperty("ISIN")
	private String isin;
	@JsonProperty("WKN")
	private String wkn;
	@JsonProperty("SYMBOL")
	private String symbol;

	@JsonProperty("CSDCC")
	private String csdcc;

	@JsonProperty("CUSIP")
	private String cusip;
	@JsonProperty("SEDOL")
	private String sedol;
	@JsonProperty("FX")
	private String fx;
	@JsonProperty("MS-SEC-ID")
	private String msSecId;
	@JsonProperty("MS-PERFORMANCE-ID")
	private String msPerformanceId;
	@JsonProperty("RIC")
	private String ric;
	@JsonProperty("SYSJUST-ID")
	private String sysjustId;

	@JsonProperty("THAI-FUND-CODE")
	private String thaiFundCode;

	@JsonProperty("BLOOMBERG-ID")
	private String bloombergId;
	private String prive;

	// private codes
	private String citi;
	private String fubon;

	// don't know which group
	@JsonProperty("min-investment")
	private Double minInvestment;
	@JsonProperty("min-sub-investment")
	private Double minSubInvestment;
	@JsonProperty("risk-level")
	private String riskLevel;
	@JsonProperty("lipper-code")
	private Integer lipperCode;
	private String cash;
	private Double earningsYield;
	private Double pegRatio;
	private Double roa;
	private Double marketCapital;
	@JsonProperty("min-qty")
	private Double minQty;
	@JsonProperty("basket-operator")
	private Double basketOperator;
	private Double visibility;
	private String customAssetCategory;

	// breakdown
	@JsonProperty("assetclass-breakdown")
	private Map<AssetClass, Double> assetclassBreakdown;
	@JsonProperty("indian-custom-assetclass-breakdown")
	private Map<String, Double> indianCustomAssetclassBreakdown;
	@JsonProperty("regional-assetclass-breakdown")
	private Map<String, Double> regionalAssetclassBreakdown;
	@JsonProperty("region-breakdown")
	private Map<String, Double> regionBreakdown;
	@JsonProperty("equities-region-breakdown")
	private Map<String, Double> equitiesRegionBreakdown;
	@JsonProperty("fixedincome-region-breakdown")
	private Map<String, Double> fixedincomeRegionBreakdown;
	@JsonProperty("sector-breakdown")
	private Map<Sector, Double> sectorBreakdown;

	// bond
	@JsonProperty("maturity-date")
	private String maturityDate;
	@JsonProperty("credit-ratings")
	private List<CreditRating> creditRatings;

	@JsonProperty("bond-stylebox")
	private String bondStylebox;
	@JsonProperty("bond-effective-duration")
	private Double bondEffectiveDuration;
	@JsonProperty("bond-effective-maturity")
	private Double bondEffectiveMaturity;
	@JsonProperty("bond-average-coupon")
	private Double bondAverageCoupon;
	@JsonProperty("bond-average-credit-quality")
	private Integer bondAverageCreditQuality;
	@JsonProperty("bond-average-price")
	private Double bondAveragePrice;
	@JsonProperty("bond-yield-to-maturity")
	private Double bondYieldToMaturity;
	private Double bondYield;
	private Double bondYieldToWorst;
	private Double bondYieldToWorstCall;
	private Boolean bondCallable;
	@JsonProperty("bond-current-yield")
	private Double bondCurrentYield;
	@JsonProperty("bond-credit-quality-breakdown")
	private Map<String, Double> bondCreditQualityBreakdown;
	@JsonProperty("bond-maturity-range-breakdown")
	private Map<String, Double> bondMaturityRangeBreakdown;
	@JsonProperty("bond-coupon-range-breakdown")
	private Map<String, Double> bondCouponRangeBreakdown;
	@JsonProperty("bond-type-develop-region-breakdown")
	private Map<String, Double> bondTypeDevelopRegionBreakdown;

	// fund explorer
	private Double fundAUM;
	private String fundAUMCurrency;
	private ShareClass shareClass;
	private Double shareClassAUM;
	private Double shareClassCurrency;
	private SettingsFrequency pricingFrequency;
	private SettingsFrequency dividendDistributionFrequency;
	private Integer morningStarRating;
	@JsonProperty("SRRI")
	private Integer srri;
	private List<TopHoldingAsset> topHoldings;
	private String domicile;
	private String legalStructure;
	private Map<String, String> provider;

	/*
	 * StrategyMetrics statistics, e.g. return, annualized-return, volatility,
	 * sharpeRatio, maxDrawdown
	 *
	 * Inside this map, it can be another map or generic value, thus using
	 * Object
	 */
	private Map<String, Object> statistics;

	// fubon fields
	@JsonProperty("fubon-sector-main")
	private String fubonSectorMain;
	@JsonProperty("fubon-sector-sub")
	private String fubonSectorSub;
	@JsonProperty("fubon-asset-type")
	private String fubonAssetType;
	@JsonProperty("fubon-asset-type-sub")
	private String fubonAssetTypeSub;
	@JsonProperty("fubon-name-tw")
	private String fubonNameTw;

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Map<String, String> getName() {
		return name;
	}

	public void setName(Map<String, String> name) {
		this.name = name;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCfiCode() {
		return cfiCode;
	}

	public void setCfiCode(String cfiCode) {
		this.cfiCode = cfiCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public ShareClass getShareClass() {
		return shareClass;
	}

	public void setShareClass(ShareClass shareClass) {
		this.shareClass = shareClass;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public AssetClass getAssetclass() {
		return assetclass;
	}

	public void setAssetclass(AssetClass assetclass) {
		this.assetclass = assetclass;
	}

	public Sector getSector() {
		return sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public Boolean getHedgefund() {
		return hedgefund;
	}

	public void setHedgefund(Boolean hedgefund) {
		this.hedgefund = hedgefund;
	}

	public Boolean getCustomAsset() {
		return customAsset;
	}

	public void setCustomAsset(Boolean customAsset) {
		this.customAsset = customAsset;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public Map<String, String> getDescription() {
		return description;
	}

	public void setDescription(Map<String, String> description) {
		this.description = description;
	}

	public String getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(String inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public Double getInceptionPrice() {
		return inceptionPrice;
	}

	public void setInceptionPrice(Double inceptionPrice) {
		this.inceptionPrice = inceptionPrice;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public String getIsin() {
		return isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getCusip() {
		return cusip;
	}

	public void setCusip(String cusip) {
		this.cusip = cusip;
	}

	public String getSedol() {
		return sedol;
	}

	public void setSedol(String sedol) {
		this.sedol = sedol;
	}

	public String getFx() {
		return fx;
	}

	public void setFx(String fx) {
		this.fx = fx;
	}

	public String getMsSecId() {
		return msSecId;
	}

	public void setMsSecId(String msSecId) {
		this.msSecId = msSecId;
	}

	public String getMsPerformanceId() {
		return msPerformanceId;
	}

	public void setMsPerformanceId(String msPerformanceId) {
		this.msPerformanceId = msPerformanceId;
	}

	public String getRic() {
		return ric;
	}

	public void setRic(String ric) {
		this.ric = ric;
	}

	public String getSysjustId() {
		return sysjustId;
	}

	public void setSysjustId(String sysjustId) {
		this.sysjustId = sysjustId;
	}

	public String getBloombergId() {
		return bloombergId;
	}

	public void setBloombergId(String bloombergId) {
		this.bloombergId = bloombergId;
	}

	public String getPrive() {
		return prive;
	}

	public void setPrive(String prive) {
		this.prive = prive;
	}

	public String getCiti() {
		return citi;
	}

	public void setCiti(String citi) {
		this.citi = citi;
	}

	public String getFubon() {
		return fubon;
	}

	public void setFubon(String fubon) {
		this.fubon = fubon;
	}

	public Double getMinInvestment() {
		return minInvestment;
	}

	public void setMinInvestment(Double minInvestment) {
		this.minInvestment = minInvestment;
	}

	public Double getMinSubInvestment() {
		return minSubInvestment;
	}

	public void setMinSubInvestment(Double minSubInvestment) {
		this.minSubInvestment = minSubInvestment;
	}

	public String getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(String riskLevel) {
		this.riskLevel = riskLevel;
	}

	public Integer getLipperCode() {
		return lipperCode;
	}

	public void setLipperCode(Integer lipperCode) {
		this.lipperCode = lipperCode;
	}

	public String getCash() {
		return cash;
	}

	public void setCash(String cash) {
		this.cash = cash;
	}

	public Double getEarningsYield() {
		return earningsYield;
	}

	public void setEarningsYield(Double earningsYield) {
		this.earningsYield = earningsYield;
	}

	public Double getPegRatio() {
		return pegRatio;
	}

	public void setPegRatio(Double pegRatio) {
		this.pegRatio = pegRatio;
	}

	public Double getRoa() {
		return roa;
	}

	public void setRoa(Double roa) {
		this.roa = roa;
	}

	public Double getMarketCapital() {
		return marketCapital;
	}

	public void setMarketCapital(Double marketCapital) {
		this.marketCapital = marketCapital;
	}

	public Double getMinQty() {
		return minQty;
	}

	public void setMinQty(Double minQty) {
		this.minQty = minQty;
	}

	public Map<AssetClass, Double> getAssetclassBreakdown() {
		return assetclassBreakdown;
	}

	public void setAssetclassBreakdown(Map<AssetClass, Double> assetclassBreakdown) {
		this.assetclassBreakdown = assetclassBreakdown;
	}

	public Map<String, Double> getIndianCustomAssetclassBreakdown() {
		return indianCustomAssetclassBreakdown;
	}

	public void setIndianCustomAssetclassBreakdown(Map<String, Double> indianCustomAssetclassBreakdown) {
		this.indianCustomAssetclassBreakdown = indianCustomAssetclassBreakdown;
	}

	public Map<String, Double> getRegionalAssetclassBreakdown() {
		return regionalAssetclassBreakdown;
	}

	public void setRegionalAssetclassBreakdown(Map<String, Double> regionalAssetclassBreakdown) {
		this.regionalAssetclassBreakdown = regionalAssetclassBreakdown;
	}

	public Map<String, Double> getRegionBreakdown() {
		return regionBreakdown;
	}

	public void setRegionBreakdown(Map<String, Double> regionBreakdown) {
		this.regionBreakdown = regionBreakdown;
	}

	public Map<String, Double> getEquitiesRegionBreakdown() {
		return equitiesRegionBreakdown;
	}

	public void setEquitiesRegionBreakdown(Map<String, Double> equitiesRegionBreakdown) {
		this.equitiesRegionBreakdown = equitiesRegionBreakdown;
	}

	public Map<String, Double> getFixedincomeRegionBreakdown() {
		return fixedincomeRegionBreakdown;
	}

	public void setFixedincomeRegionBreakdown(Map<String, Double> fixedincomeRegionBreakdown) {
		this.fixedincomeRegionBreakdown = fixedincomeRegionBreakdown;
	}

	public Map<Sector, Double> getSectorBreakdown() {
		return sectorBreakdown;
	}

	public void setSectorBreakdown(Map<Sector, Double> sectorBreakdown) {
		this.sectorBreakdown = sectorBreakdown;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public List<CreditRating> getCreditRatings() {
		return creditRatings;
	}

	public void setCreditRatings(List<CreditRating> creditRatings) {
		this.creditRatings = creditRatings;
	}

	public String getBondStylebox() {
		return bondStylebox;
	}

	public void setBondStylebox(String bondStylebox) {
		this.bondStylebox = bondStylebox;
	}

	public Double getBondEffectiveDuration() {
		return bondEffectiveDuration;
	}

	public void setBondEffectiveDuration(Double bondEffectiveDuration) {
		this.bondEffectiveDuration = bondEffectiveDuration;
	}

	public Double getBondEffectiveMaturity() {
		return bondEffectiveMaturity;
	}

	public void setBondEffectiveMaturity(Double bondEffectiveMaturity) {
		this.bondEffectiveMaturity = bondEffectiveMaturity;
	}

	public Double getBondAverageCoupon() {
		return bondAverageCoupon;
	}

	public void setBondAverageCoupon(Double bondAverageCoupon) {
		this.bondAverageCoupon = bondAverageCoupon;
	}

	public Integer getBondAverageCreditQuality() {
		return bondAverageCreditQuality;
	}

	public void setBondAverageCreditQuality(Integer bondAverageCreditQuality) {
		this.bondAverageCreditQuality = bondAverageCreditQuality;
	}

	public Double getBondAveragePrice() {
		return bondAveragePrice;
	}

	public void setBondAveragePrice(Double bondAveragePrice) {
		this.bondAveragePrice = bondAveragePrice;
	}

	public Double getBondYieldToMaturity() {
		return bondYieldToMaturity;
	}

	public void setBondYieldToMaturity(Double bondYieldToMaturity) {
		this.bondYieldToMaturity = bondYieldToMaturity;
	}

	public Double getBondCurrentYield() {
		return bondCurrentYield;
	}

	public void setBondCurrentYield(Double bondCurrentYield) {
		this.bondCurrentYield = bondCurrentYield;
	}

	public Map<String, Double> getBondCreditQualityBreakdown() {
		return bondCreditQualityBreakdown;
	}

	public void setBondCreditQualityBreakdown(Map<String, Double> bondCreditQualityBreakdown) {
		this.bondCreditQualityBreakdown = bondCreditQualityBreakdown;
	}

	public Map<String, Double> getBondMaturityRangeBreakdown() {
		return bondMaturityRangeBreakdown;
	}

	public void setBondMaturityRangeBreakdown(Map<String, Double> bondMaturityRangeBreakdown) {
		this.bondMaturityRangeBreakdown = bondMaturityRangeBreakdown;
	}

	public Map<String, Double> getBondCouponRangeBreakdown() {
		return bondCouponRangeBreakdown;
	}

	public void setBondCouponRangeBreakdown(Map<String, Double> bondCouponRangeBreakdown) {
		this.bondCouponRangeBreakdown = bondCouponRangeBreakdown;
	}

	public Map<String, Double> getBondTypeDevelopRegionBreakdown() {
		return bondTypeDevelopRegionBreakdown;
	}

	public void setBondTypeDevelopRegionBreakdown(Map<String, Double> bondTypeDevelopRegionBreakdown) {
		this.bondTypeDevelopRegionBreakdown = bondTypeDevelopRegionBreakdown;
	}

	public String getFubonSectorMain() {
		return fubonSectorMain;
	}

	public void setFubonSectorMain(String fubonSectorMain) {
		this.fubonSectorMain = fubonSectorMain;
	}

	public String getFubonSectorSub() {
		return fubonSectorSub;
	}

	public void setFubonSectorSub(String fubonSectorSub) {
		this.fubonSectorSub = fubonSectorSub;
	}

	public String getFubonAssetType() {
		return fubonAssetType;
	}

	public void setFubonAssetType(String fubonAssetType) {
		this.fubonAssetType = fubonAssetType;
	}

	public String getFubonAssetTypeSub() {
		return fubonAssetTypeSub;
	}

	public void setFubonAssetTypeSub(String fubonAssetTypeSub) {
		this.fubonAssetTypeSub = fubonAssetTypeSub;
	}

	public String getFubonNameTw() {
		return fubonNameTw;
	}

	public void setFubonNameTw(String fubonNameTw) {
		this.fubonNameTw = fubonNameTw;
	}

	public ObjectId getBenchmarkId() {
		return benchmarkId;
	}

	public void setBenchmarkId(ObjectId benchmarkId) {
		this.benchmarkId = benchmarkId;
	}

	public Double getBasketOperator() {
		return basketOperator;
	}

	public void setBasketOperator(Double basketOperator) {
		this.basketOperator = basketOperator;
	}

	public Double getVisibility() {
		return visibility;
	}

	public void setVisibility(Double visibility) {
		this.visibility = visibility;
	}

	public String getWkn() {
		return wkn;
	}

	public void setWkn(String wkn) {
		this.wkn = wkn;
	}

	public Double getFundAUM() {
		return fundAUM;
	}

	public void setFundAUM(Double fundAUM) {
		this.fundAUM = fundAUM;
	}

	public Double getShareClassAUM() {
		return shareClassAUM;
	}

	public void setShareClassAUM(Double shareClassAUM) {
		this.shareClassAUM = shareClassAUM;
	}

	public SettingsFrequency getPricingFrequency() {
		return pricingFrequency;
	}

	public void setPricingFrequency(SettingsFrequency pricingFrequency) {
		this.pricingFrequency = pricingFrequency;
	}

	public SettingsFrequency getDividendDistributionFrequency() {
		return dividendDistributionFrequency;
	}

	public void setDividendDistributionFrequency(SettingsFrequency dividendDistributionFrequency) {
		this.dividendDistributionFrequency = dividendDistributionFrequency;
	}

	public Integer getMorningStarRating() {
		return morningStarRating;
	}

	public void setMorningStarRating(Integer morningStarRating) {
		this.morningStarRating = morningStarRating;
	}

	public Integer getSrri() {
		return srri;
	}

	public void setSrri(Integer srri) {
		this.srri = srri;
	}

	public List<TopHoldingAsset> getTopHoldings() {
		return topHoldings;
	}

	public void setTopHoldings(List<TopHoldingAsset> topHoldings) {
		this.topHoldings = topHoldings;
	}

	public Map<String, Object> getStatistics() {
		return statistics;
	}

	public void setStatistics(Map<String, Object> statistics) {
		this.statistics = statistics;
	}

	public String getFundAUMCurrency() {
		return fundAUMCurrency;
	}

	public void setFundAUMCurrency(String fundAUMCurrency) {
		this.fundAUMCurrency = fundAUMCurrency;
	}

	public Double getShareClassCurrency() {
		return shareClassCurrency;
	}

	public void setShareClassCurrency(Double shareClassCurrency) {
		this.shareClassCurrency = shareClassCurrency;
	}

	public String getCustomAssetCategory() {
		return customAssetCategory;
	}

	public void setCustomAssetCategory(String customAssetCategory) {
		this.customAssetCategory = customAssetCategory;
	}

	public Boolean getMirrorFund() {
		return mirrorFund;
	}

	public void setMirrorFund(Boolean mirrorFund) {
		this.mirrorFund = mirrorFund;
	}

	public List<UnderlyingAsset> getUnderlying() {
		return underlying;
	}

	public void setUnderlying(List<UnderlyingAsset> underlying) {
		this.underlying = underlying;
	}

	public Double getBondYield() {
		return bondYield;
	}

	public void setBondYield(Double bondYield) {
		this.bondYield = bondYield;
	}

	public Double getBondYieldToWorst() {
		return bondYieldToWorst;
	}

	public void setBondYieldToWorst(Double bondYieldToWorst) {
		this.bondYieldToWorst = bondYieldToWorst;
	}

	public Double getBondYieldToWorstCall() {
		return bondYieldToWorstCall;
	}

	public void setBondYieldToWorstCall(Double bondYieldToWorstCall) {
		this.bondYieldToWorstCall = bondYieldToWorstCall;
	}

	public Boolean getBondCallable() {
		return bondCallable;
	}

	public void setBondCallable(Boolean bondCallable) {
		this.bondCallable = bondCallable;
	}

	public String getThaiFundCode() {
		return thaiFundCode;
	}

	public void setThaiFundCode(String thaiFundCode) {
		this.thaiFundCode = thaiFundCode;
	}

	public String getCsdcc() {
		return csdcc;
	}

	public void setCsdcc(String csdcc) {
		this.csdcc = csdcc;
	}

	public String getDomicile() {
		return domicile;
	}

	public void setDomicile(String domicile) {
		this.domicile = domicile;
	}

	public String getLegalStructure() {
		return legalStructure;
	}

	public void setLegalStructure(String legalStructure) {
		this.legalStructure = legalStructure;
	}

	public Map<String, String> getProvider() {
		return provider;
	}

	public void setProvider(Map<String, String> provider) {
		this.provider = provider;
	}
}
