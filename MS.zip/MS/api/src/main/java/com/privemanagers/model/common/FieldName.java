package com.privemanagers.model.common;

/**
 * @author nteck
 * @date : 23 Mar, 2017
 * @company Prive Financial
 */
public final class FieldName {

	/**
	 * Fields name for codes collection.
	 */
	public static final String SCHEME = "scheme";
	public static final String VALUE = "value";
	public static final String ASSETS_ID = "assets-id";

	/**
	 * Fields name for assets collection.
	 */
	public static final String CFI_CODE = "cfi-code";
	public static final String CURRENCY = "currency";
	public static final String BENCHMARK_ID = "benchmark-id";
	public static final String ALLOCATION = "allocation";
	public static final String EFFECTIVE_ALLOCATION = "effective-allocation";
	public static final String UNDERLYING = "underlying";
	public static final String ASSET_CLASS = "assetclass";
	public static final String SECTOR = "sector";
	public static final String TYPE = "type";
	public static final String CUSTOM_ASSET = "custom-asset";
	public static final String CUSTOM_ASSET_CATEGORY = "customAssetCategory";
	public static final String MIRROR_FUND = "mirrorFund";
	public static final String DATA_SOURCE = "data-source";
	public static final String CREATE_TIME = "createTime";
	public static final String LAST_UPDATE_TIME = "lastUpdateTime";
	public static final String RISK_LEVEL = "risk-level";
	public static final String RETURN = "return";
	public static final String ANNUALIZED_RETURN = "annualized-return";
	public static final String VOLATILITY = "volatility";
	public static final String DOWNSIDE_VOLATILITY = "downsideVolatility";
	public static final String SHARPE_RATIO = "sharpeRatio";
	public static final String MAX_DRAWDOWN = "maxDrawdown";
	public static final String NEGATIVE_MONTHS_PERCENTAGE = "negativeMonthsPercentage";
	public static final String MONTHLY_RETURN = "monthlyReturn";

	/**
	 * Fields name for prices collection.
	 */
	public static final String LOCAL_DATE = "local-date";
	public static final String CLOSE_PX = "close-px";
	public static final String ASSET_ID = "asset-id";
	public static final String PRICE_TYPE = "price-type";
	public static final String PRICE_DATA_TYPE = "priceDataType";
	public static final String FX_RATE = "fx-rate";

	/**
	 * Fields name for dividend, split collection.
	 */
	public static final String exDate = "exDate";
	public static final String value = "value";

	/**
	 * Fields name for tenants collection.
	 */
	public static final String NAME = "name";
	public static final String REGION = "region";

	/**
	 * Fields name from db query / 3rd party API.
	 */
	public static final String ACCESS_TOKEN = "access-token";
	public static final String ASSETS = "assets";
	public static final String FX = "fx";
	public static final String OFFSET = "offset";
	public static final String LIMIT = "limit";
	public static final String CODES = "codes";
	public static final String PRICES = "prices";
	public static final String PRICE = "price";
	public static final String TENANTS = "tenants";
	public static final String TENANT = "tenant";
	public static final String BENCHMARKS = "benchmarks";
	public static final String BASE_BENCHMARK = "base-benchmark";
	public static final String MODEL_PORTFOLIO = "mp";
	public static final String KEYS = "keys";
	public static final String SEDOL = "SEDOL";
	public static final String CUSIP = "CUSIP";
	public static final String SYMBOL = "SYMBOL";
	public static final String PRIVE = "prive";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password"; // NOSONAR

	/**
	 * Fields name for formatted model portfolio
	 */
	public static final String ASSET = "asset";
	public static final String PORTFOLIO = "portfolio";
	public static final String WEIGHT = "weight";
	public static final String EFFECTIVE_WEIGHT = "effective-weight";
	public static final String ASSET_CODES = "asset-codes";
	public static final String ISIN = "isin";
	public static final String TENANT_CODE = "tenant-code";
	public static final String ASSET_ALLOCATION = ASSET + "-" + ALLOCATION;
	public static final String CFI_CODE_MODEL_PORTFOLIO = "TBXXXX";
	public static final String INCEPTION_DATE = "inception-date";

	private FieldName() {

	}
}
