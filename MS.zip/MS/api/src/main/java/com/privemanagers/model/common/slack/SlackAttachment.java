package com.privemanagers.model.common.slack;

import java.util.List;

/**
 * Slack attachment message POJO, the structure is following to slack api
 *
 * https://api.slack.com/docs/message-attachments
 *
 * @author Kay Ip
 * @date 14 Sep 2018
 * @company Prive Financial
 */
public class SlackAttachment {
	private String title;
	private List<AttachmentField> fields;
	private String color;
	private String footer;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<AttachmentField> getFields() {
		return fields;
	}

	public void setFields(List<AttachmentField> fields) {
		this.fields = fields;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}
}
