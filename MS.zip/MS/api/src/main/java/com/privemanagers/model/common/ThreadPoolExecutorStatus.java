package com.privemanagers.model.common;

/**
 * Information of threads for monitoring
 *
 * https://docs.oracle.com/javase/7/docs/api/java/util/concurrent/
 * ThreadPoolExecutor.html
 *
 * @author Kay Ip
 * @date 28 Sep 2018
 * @company Prive Financial
 */
public class ThreadPoolExecutorStatus {
	/*
	 * Returns the approximate number of threads that are actively executing
	 * tasks.
	 */
	private int activeCount;
	private int remainingCapacity;
	private long completedTaskCount;

	/*
	 * Returns the approximate total number of tasks that have ever been
	 * scheduled for execution.
	 */
	private long taskCount;

	// task count - completed task count
	private long pendingTaskCount;

	public int getActiveCount() {
		return activeCount;
	}

	public void setActiveCount(int activeCount) {
		this.activeCount = activeCount;
	}

	public int getRemainingCapacity() {
		return remainingCapacity;
	}

	public void setRemainingCapacity(int remainingCapacity) {
		this.remainingCapacity = remainingCapacity;
	}

	public long getCompletedTaskCount() {
		return completedTaskCount;
	}

	public void setCompletedTaskCount(long completedTaskCount) {
		this.completedTaskCount = completedTaskCount;
	}

	public long getTaskCount() {
		return taskCount;
	}

	public void setTaskCount(long taskCount) {
		this.taskCount = taskCount;
	}

	public long getPendingTaskCount() {
		return pendingTaskCount;
	}

	public void setPendingTaskCount(long pendingTaskCount) {
		this.pendingTaskCount = pendingTaskCount;
	}
}
