package com.privemanagers.model.error;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Error items under ApplicationErrorResponse
 *
 * @author Kay Ip
 * @date 19 Dec 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationErrorItem {

	private String errorCode;

	private String errorMessage;

	public ApplicationErrorItem() {
	}

	public ApplicationErrorItem(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
