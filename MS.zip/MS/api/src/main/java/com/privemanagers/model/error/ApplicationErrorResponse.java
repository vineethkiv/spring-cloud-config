package com.privemanagers.model.error;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Application Error response for all of our api
 *
 * @author Kay Ip
 * @date 19 Dec 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplicationErrorResponse {

	private String appName;
	private String requestId;
	private List<ApplicationErrorItem> errors;

	public ApplicationErrorResponse() {
	}

	public ApplicationErrorResponse(String appName, String requestId, List<ApplicationErrorItem> errors) {
		this.appName = appName;
		this.requestId = requestId;
		this.errors = errors;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public List<ApplicationErrorItem> getErrors() {
		return errors;
	}

	public void setErrors(List<ApplicationErrorItem> errors) {
		this.errors = errors;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}
}
