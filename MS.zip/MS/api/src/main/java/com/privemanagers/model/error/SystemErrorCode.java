package com.privemanagers.model.error;

/**
 * Error code for quant
 *
 * @author Kay Ip
 * @date 27 Dec 2018
 * @company Prive Financial
 */
public enum SystemErrorCode implements AppErrorCode {

	INVALID_REQUEST("000001"),
	MISSING_FIELD("000002"),
	INVALID_LENGTH("000003"),
	LOGIN_FAILED("000004");

	private String code;

	private SystemErrorCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public String getAppName() {
		return "SYSTEM";
	}
}
