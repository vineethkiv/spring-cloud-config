package com.privemanagers.api;

import java.io.IOException;

import org.bson.types.ObjectId;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * JsonSerializer for ObjectId
 *
 * @author Kay Ip
 * @date 9 July 2018
 * @company Prive Financial
 */
public class ObjectIdSerializer extends JsonSerializer<ObjectId> {

	@Override
	public void serialize(ObjectId objid, JsonGenerator jsonGenerator, SerializerProvider provider) throws IOException {
		if (objid == null) {
			jsonGenerator.writeNull();
		} else {
			jsonGenerator.writeString(objid.toString());
		}
	}

}
