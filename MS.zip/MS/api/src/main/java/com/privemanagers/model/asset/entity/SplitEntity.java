package com.privemanagers.model.asset.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Entity class for Dividend
 *
 * @author Kay Ip
 * @date 9 July 2018
 * @company Prive Financial
 */
public class SplitEntity {
	private String _id;

	@JsonProperty("asset-id")
	private String assetId;

	private Integer exDate;

	private Double value;

	private String dataSource;

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public Integer getExDate() {
		return exDate;
	}

	public void setExDate(Integer exDate) {
		this.exDate = exDate;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
}
