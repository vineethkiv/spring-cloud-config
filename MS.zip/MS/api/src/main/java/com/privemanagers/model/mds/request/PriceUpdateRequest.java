package com.privemanagers.model.mds.request;

import java.util.List;

import com.privemanagers.model.asset.PriceDataType;
import com.privemanagers.model.mds.rawData.AssetPriceSeries;

/**
 * update request for price
 *
 * @author Kay Ip
 * @date 11 July 2018
 * @company Prive Financial
 */
public class PriceUpdateRequest extends RawDataUpdateRequest {

	private List<AssetPriceSeries> assetPriceSeriesList;
	private PriceDataType priceDataType;

	public PriceDataType getPriceDataType() {
		return priceDataType;
	}

	public void setPriceDataType(PriceDataType priceDataType) {
		this.priceDataType = priceDataType;
	}

	public List<AssetPriceSeries> getAssetPriceSeriesList() {
		return assetPriceSeriesList;
	}

	public void setAssetPriceSeriesList(List<AssetPriceSeries> assetPriceSeriesList) {
		this.assetPriceSeriesList = assetPriceSeriesList;
	}
}
