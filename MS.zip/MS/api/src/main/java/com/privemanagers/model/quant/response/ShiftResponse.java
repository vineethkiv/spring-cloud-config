package com.privemanagers.model.quant.response;

import java.util.List;

import com.privemanagers.model.quant.ShiftType;

/**
 * sensitivity analysis field object being used in dual series response by b2b
 * and quant
 *
 * @author wzhang
 * @date 31 Oct 2018
 * @company Prive Financial
 */
public class ShiftResponse {

	private ShiftType type;
	private List<ShiftValue> values;

	public ShiftType getType() {
		return type;
	}

	public void setType(ShiftType type) {
		this.type = type;
	}

	public List<ShiftValue> getValues() {
		return values;
	}

	public void setValues(List<ShiftValue> values) {
		this.values = values;
	}
}
