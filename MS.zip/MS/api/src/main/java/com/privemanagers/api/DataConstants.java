package com.privemanagers.api;

/**
 * @author William Zhang
 * @date 10 Nov 2017
 * @company Prive Financial
 */
public class DataConstants {
	public static final String SERIES_PRICES = "prices";
	public static final String SERIES_RETURNS = "returns";

	public static final String STATISTIC_COUNT_GAINS = "count-gains";
	public static final String STATISTIC_COUNT_LOSSES = "count-losses";
	public static final String STATISTIC_MAX_DRAWDOWN = "max-drawdown";
	public static final String STATISTIC_MAX_DRAWDOWN_FROM = "max-drawdown-from";
	public static final String STATISTIC_MAX_DRAWDOWN_RELATIVE = "max-drawdown-relative";
	public static final String STATISTIC_MAX_DRAWDOWN_UNTIL = "max-drawdown-until";
	public static final String STATISTIC_MAX_DRAWUP = "max-drawup";
	public static final String STATISTIC_MAX_DRAWUP_FROM = "max-drawup-from";
	public static final String STATISTIC_MAX_DRAWUP_RELATIVE = "max-drawup-relative";
	public static final String STATISTIC_MAX_DRAWUP_UNTIL = "max-drawup-until";
	public static final String STATISTIC_MAX_RETURN = "max-return";
	public static final String STATISTIC_MEAN_GAIN = "mean-gain";
	public static final String STATISTIC_MEAN_LOSS = "mean-loss";
	public static final String STATISTIC_MIN_RETURN = "min-return";
	public static final String STATISTIC_MEAN_RETURN = "mean-return";
	public static final String STATISTIC_RETURN = "return";
	public static final String STATISTIC_SHARPE = "sharpe";
	public static final String STATISTIC_VOLATILITY = "volatility";
	public static final String STATISTIC_ANNUALIZED_RETURN = "annualized-return";
	public static final String STATISTIC_NEGATIVE_VOLATILITY = "negative-volatility";
	public static final String STATISTIC_ANNUALIZED_NEGATIVE_VOLATILITY = "annualized-negative-volatility";
	public static final String STATISTIC_CORRELATION = "correlation";
	public static final String STATISTIC_YIELD_TO_MATURITY = "yield-to-maturity";
	public static final String STATISTIC_YIELD_TO_WORST = "yield-to-worst";
	public static final String STATISTIC_YIELD_TO_CALL = "yield-to-call";
	public static final String STATISTIC_EFFECTIVE_DURATION = "effective-duration";
	public static final String JSON_ASSET_ID = "asset-id";
	public static final String JSON_CLOSE_PX = "close-px";
	public static final String JSON_CURRENCY = "currency";
	public static final String JSON_LOCAL_DATE = "local-date";
	public static final String JSON_PRICES = "prices";
	public static final String JSON_VALUE = "value";
	public static final String JSON_CFI_CODE = "cfi-code";

	public static final String STRUCTURE_PRODUCT_CFI_CODE = "DSXXXX";
}
