package com.privemanagers.model.asset.transformer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.privemanagers.model.asset.request.AssetCodesGraphQLRequest;
import com.privemanagers.model.asset.request.AssetCodesRequest;

/**
 * Transformer for assets related request and response
 *
 * @author Kay Ip
 * @date 14 Feb 2019
 * @company Prive Financial
 */
public class AssetRequestTransformer {

	/**
	 * Transform list of AssetCodesGraphQLRequest to list of AssetCodesRequest
	 * 
	 * @param fromList
	 * @return
	 */
	public static List<AssetCodesRequest> transform(List<AssetCodesGraphQLRequest> fromList) {
		if (CollectionUtils.isEmpty(fromList)) {
			return Collections.emptyList();
		}

		List<AssetCodesRequest> toList = new ArrayList<>();
		for (AssetCodesGraphQLRequest from : fromList) {
			AssetCodesRequest to = transform(from);
			if (to != null) {
				toList.add(to);
			}
		}
		return toList;
	}

	/**
	 * Transform AssetCodesGraphQLRequest to AssetCodesRequest
	 *
	 * @param from
	 * @return
	 */
	public static AssetCodesRequest transform(AssetCodesGraphQLRequest from) {
		if (from == null) {
			return null;
		}
		AssetCodesRequest to = new AssetCodesRequest();
		to.setScheme(from.getScheme());
		to.setValue(from.getValue());
		to.setCurrency(from.getCurrency());
		to.setCfiCode(from.getCfiCode());
		to.setDataSource(from.getDataSource());
		return to;
	}
}
