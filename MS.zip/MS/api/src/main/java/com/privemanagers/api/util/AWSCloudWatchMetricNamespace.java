package com.privemanagers.api.util;

/**
 * AWS CloudWatch Metric namespace mapping
 *
 * @author Kay Ip
 * @date 10 Dec 2018
 * @company Prive Financial
 */
public enum AWSCloudWatchMetricNamespace {

	// mds related namespace
	MDS_NAMESPACE("MDS");

	private final String namespace;

	private AWSCloudWatchMetricNamespace(final String namespace) {
		this.namespace = namespace;
	}

	public String getNamespace() {
		return namespace;
	}

}
