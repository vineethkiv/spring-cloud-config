package com.privemanagers.model.common.slack;

import java.util.List;

/**
 * Slack message POJO, the structure is following to slack api
 *
 * https://api.slack.com/docs/message-formatting
 *
 * @author Kay Ip
 * @date 14 Sep 2018
 * @company Prive Financial
 */
public class SlackMessage {
	private String text;
	private List<SlackAttachment> attachments;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<SlackAttachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<SlackAttachment> attachments) {
		this.attachments = attachments;
	}
}
