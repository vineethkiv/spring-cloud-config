package com.privemanagers.model.asset.transformer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import com.privemanagers.model.asset.dto.graphql.AssetDTO;
import com.privemanagers.model.asset.dto.graphql.CreditRatingDTO;
import com.privemanagers.model.asset.dto.graphql.StatisticDTO;
import com.privemanagers.model.asset.dto.graphql.TopHoldingAssetDTO;
import com.privemanagers.model.asset.dto.graphql.UnderlyingAssetDTO;
import com.privemanagers.model.asset.entity.AssetEntity;
import com.privemanagers.model.asset.entity.CreditRating;
import com.privemanagers.model.asset.entity.TopHoldingAsset;
import com.privemanagers.model.asset.entity.UnderlyingAsset;
import com.privemanagers.model.common.FieldName;

/**
 * Transformer for assets related DTOs and entities
 *
 * @author Kay Ip
 * @date 14 Feb 2019
 * @company Prive Financial
 */
public class AssetDTOTransformer {

	/**
	 * Transform list of AssetEntity to list of AssetDTO
	 *
	 * @param fromList
	 * @return
	 */
	public static List<AssetDTO> transform(List<AssetEntity> fromList) {
		if (CollectionUtils.isEmpty(fromList)) {
			return Collections.emptyList();
		}

		List<AssetDTO> toList = new ArrayList<>();
		for (AssetEntity from : fromList) {
			AssetDTO to = transform(from);
			if (to != null) {
				toList.add(to);
			}
		}
		return toList;
	}

	/**
	 * Transform AssetEntity to AssetDTO
	 *
	 * @param from
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static AssetDTO transform(AssetEntity from) {
		if (from == null) {
			return null;
		}

		AssetDTO to = new AssetDTO();
		// shallow copy the fields that are under same class
		BeanUtils.copyProperties(from, to);

		// set ObjectId to String, grpahQL cannot parse ObjectId
		if (from.getId() != null) {
			to.setId(from.getId().toString());
		}
		if (from.getBenchmarkId() != null) {
			to.setBenchmarkId(from.getBenchmarkId().toString());
		}

		// copy different class fields
		if (!CollectionUtils.isEmpty(from.getTopHoldings())) {
			List<TopHoldingAssetDTO> toList = new ArrayList<>();
			for (TopHoldingAsset nestedFrom : from.getTopHoldings()) {
				TopHoldingAssetDTO nestedTo = new TopHoldingAssetDTO();
				BeanUtils.copyProperties(nestedFrom, nestedTo);
				toList.add(nestedTo);
			}
			to.setTopHoldings(toList);
		}

		if (!CollectionUtils.isEmpty(from.getUnderlying())) {
			List<UnderlyingAssetDTO> toList = new ArrayList<>();
			for (UnderlyingAsset nestedFrom : from.getUnderlying()) {
				UnderlyingAssetDTO nestedTo = new UnderlyingAssetDTO();
				BeanUtils.copyProperties(nestedFrom, nestedTo);
				toList.add(nestedTo);
			}
			to.setUnderlying(toList);
		}

		if (!CollectionUtils.isEmpty(from.getCreditRatings())) {
			List<CreditRatingDTO> toList = new ArrayList<>();
			for (CreditRating nestedFrom : from.getCreditRatings()) {
				CreditRatingDTO nestedTo = new CreditRatingDTO();
				BeanUtils.copyProperties(nestedFrom, nestedTo);
				toList.add(nestedTo);
			}
			to.setCreditRatings(toList);
		}

		/*
		 * copy statistics fields
		 *
		 * entity for statistics is a map which able to get all the values
		 *
		 * dto for statistics contains specify fields which allow user to query
		 *
		 */
		if (!CollectionUtils.isEmpty(from.getStatistics())) {
			Map<String, Object> statistics = from.getStatistics();
			StatisticDTO statisticDTO = new StatisticDTO();
			if (statistics.containsKey(FieldName.RETURN)) {
				statisticDTO.setNormalReturn((Map<String, Double>) statistics.get(FieldName.RETURN));
			}
			if (statistics.containsKey(FieldName.ANNUALIZED_RETURN)) {
				statisticDTO.setAnnualizedReturn((Map<String, Double>) statistics.get(FieldName.ANNUALIZED_RETURN));
			}
			if (statistics.containsKey(FieldName.VOLATILITY)) {
				statisticDTO.setVolatility((Map<String, Double>) statistics.get(FieldName.VOLATILITY));
			}
			if (statistics.containsKey(FieldName.DOWNSIDE_VOLATILITY)) {
				statisticDTO.setDownsideVolatility((Map<String, Double>) statistics.get(FieldName.DOWNSIDE_VOLATILITY));
			}
			if (statistics.containsKey(FieldName.SHARPE_RATIO)) {
				statisticDTO.setSharpeRatio((Map<String, Double>) statistics.get(FieldName.SHARPE_RATIO));
			}
			if (statistics.containsKey(FieldName.MONTHLY_RETURN)) {
				statisticDTO.setMonthlyReturn((Map<String, Double>) statistics.get(FieldName.MONTHLY_RETURN));
			}
			if (statistics.containsKey(FieldName.MAX_DRAWDOWN)) {
				statisticDTO.setMaxDrawdown((Double) statistics.get(FieldName.MAX_DRAWDOWN));
			}
			if (statistics.containsKey(FieldName.NEGATIVE_MONTHS_PERCENTAGE)) {
				statisticDTO.setNegativeMonthsPercentage((Double) statistics.get(FieldName.NEGATIVE_MONTHS_PERCENTAGE));
			}
			to.setStatistics(statisticDTO);
		}

		return to;

	}

}
