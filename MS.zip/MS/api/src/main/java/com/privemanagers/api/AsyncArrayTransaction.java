package com.privemanagers.api;

import java.net.URI;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import javax.json.JsonArray;
import javax.json.JsonException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.client.HttpClientErrorException;

public abstract class AsyncArrayTransaction implements ListenableFutureCallback<ResponseEntity<String>> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private final JsonException JSON_EXCEPTION = new JsonException("could not parse body");

	private final CountDownLatch latch;
	private final Map<String, String> mdc;

	private URI uri;
	private HttpStatus status;
	private JsonArray body;
	private TenantContext tenantContext;

	/**
	 * Make a transaction.
	 *
	 * @param latch
	 */
	public AsyncArrayTransaction(final CountDownLatch latch, final TenantContext tenantContext) {
		this.latch = latch;
		this.tenantContext = tenantContext;
		this.mdc = MDC.getCopyOfContextMap();
	}

	/**
	 * Set the URI for this transaction.
	 *
	 * @param uri
	 */
	protected void uri(final URI uri) {
		this.uri = uri;
	}

	/**
	 * Send the request using the given executor to handle the async response.
	 *
	 * @param executor
	 */
	public abstract void send(final ThreadPoolTaskExecutor executor);

	@Override
	public void onSuccess(final ResponseEntity<String> result) {
		try {

			/*
			 * IMPORTANT: This used to set the MDC context using the copy of the
			 * context map set at construction but that caused intermittent
			 * thread hanging when run outside of Docker. Do not attempt to set
			 * the MDC here.
			 */
			this.logger.debug("{} {} {} {}", this.mdc.get("tenant"), this.mdc.get("request"),
					result.getStatusCode().getReasonPhrase(), this.uri);
			/*
			 * Keep the status code and try to parse the response into a
			 * JsonObject.
			 */
			this.status = result.getStatusCode();
			if (HttpStatus.OK == this.status) {

				this.body = API.parseArray(result.getBody());
				if (this.body == null) {
					throw JSON_EXCEPTION;
				}
			} else if (HttpStatus.NO_CONTENT == this.status) {
				this.body = null;
			}

		} catch (final Exception e) {

			this.logger.warn("{} {} {} body {} exception {}", this.mdc.get("tenant"), this.mdc.get("request"), this.uri,
					result.getBody(), e.getMessage());
			this.status = HttpStatus.INTERNAL_SERVER_ERROR;

		} finally {

			this.latch.countDown();

		}
	}

	@Override
	public void onFailure(final Throwable ex) {
		try {

			this.logger.warn("{} {} {} {}", this.mdc.get("tenant"), this.mdc.get("request"), this.uri, ex.getMessage());

			/*
			 * If this is a client exception. Return the correct status code and
			 * body
			 */
			if (ex instanceof HttpClientErrorException) {

				HttpClientErrorException exception = (HttpClientErrorException) ex;
				String respBody = exception.getResponseBodyAsString();

				this.status = exception.getStatusCode();

				if (respBody != null && !respBody.isEmpty()) {
					this.body = API.parseArray(respBody);
				}

			} else {
				this.status = HttpStatus.INTERNAL_SERVER_ERROR;
			}

		} finally {

			this.latch.countDown();

		}
	}

	/**
	 * The URI for this transaction.
	 *
	 * @return URI
	 */
	public URI uri() {
		return this.uri;
	}

	/**
	 * The HTTP status.
	 *
	 * @return HttpStatus
	 */
	public HttpStatus status() {
		return this.status;
	}

	/**
	 * The response.
	 *
	 * @return JsonObject
	 */
	public JsonArray body() {
		return this.body;
	}

	/**
	 * tenant config
	 *
	 * @return TenantContext
	 */
	public TenantContext tenantContext() {
		return this.tenantContext;
	}

}
