package com.privemanagers.model.common;

/**
 * To indicate which region tenant belongs to, mainly use to route the asset
 * update request
 * 
 * @author nteck
 * @date 14 Sep 2017
 * @company Prive Financial
 */
public enum TenantRegion {
	AS,
	EU,
	TW;
}
