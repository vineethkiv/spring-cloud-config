package com.privemanagers.model.mds.rawData;

import java.util.List;

import com.privemanagers.model.asset.Code;

/**
 * Common fields for asset raw series data
 *
 * @author Kay Ip
 * @date 4 July 2018
 * @company Prive Financial
 */
public abstract class RawSeriesData {

	/*
	 * either assetId or primary code, if both has value, assetId will be first
	 * priority.
	 * 
	 * normally only adjusted price will use assetId, raw data will use primary
	 * code
	 */
	private String assetId;
	private Code primaryCode;
	private List<DateValuePair> timeSeries;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public Code getPrimaryCode() {
		return primaryCode;
	}

	public void setPrimaryCode(Code primaryCode) {
		this.primaryCode = primaryCode;
	}

	public List<DateValuePair> getTimeSeries() {
		return timeSeries;
	}

	public void setTimeSeries(List<DateValuePair> timeSeries) {
		this.timeSeries = timeSeries;
	}
}
