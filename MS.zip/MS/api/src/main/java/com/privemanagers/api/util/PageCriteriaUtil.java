package com.privemanagers.api.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.util.CollectionUtils;

import com.mongodb.BasicDBObject;
import com.privemanagers.api.PageCriteria;
import com.privemanagers.api.SortCriteria;

public class PageCriteriaUtil {

	/**
	 * Validate PageCriteria, should not have empty fields
	 *
	 * @param criteria
	 * @return
	 */
	public static boolean validate(PageCriteria criteria) {
		// 0 is first page, cannot < 0
		if (criteria.getPageNumber() < 0) {
			return false;
		}
		if (criteria.getPageSize() <= 0) {
			return false;
		}
		if (CollectionUtils.isEmpty(criteria.getSortCriteria())) {
			return false;
		}
		return true;
	}

	/**
	 * Transform prive PageCriteria to Spring PageRequest
	 *
	 * @param criteria
	 * @return
	 */
	public static PageRequest transform(PageCriteria criteria) {
		List<SortCriteria> scList = criteria.getSortCriteria();
		List<Order> orderList = new ArrayList<>();
		for (SortCriteria sc : scList) {
			orderList.add(new Order(sc.getSortDirection(), sc.getSortBy()));
		}

		Sort sort = Sort.by(orderList);

		PageRequest pg = PageRequest.of(criteria.getPageNumber(), criteria.getPageSize(), sort);
		return pg;
	}

	/**
	 * Transform PageRequest to BasicDBOject, for querying Mongo sorting
	 *
	 * @param pageRequest
	 * @return
	 */
	public static BasicDBObject transform(PageRequest pageRequest) {
		BasicDBObject sort = null;
		Iterator<Order> sortPropertyIter = pageRequest.getSort().iterator();
		while (sortPropertyIter.hasNext()) {
			Order o = sortPropertyIter.next();
			// mongo use 1 or -1 to represent ASC or DESC
			int direction = Direction.ASC.equals(o.getDirection()) ? 1 : -1;
			if (sort == null) {
				sort = new BasicDBObject(o.getProperty(), direction);
			} else {
				sort.append(o.getProperty(), direction);
			}
		}
		return sort;
	}
}
