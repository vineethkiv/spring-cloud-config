package com.privemanagers.model.asset;

/**
 * ShareClass
 *
 * Ref: org.sly.main.shared.data.finance.asset.Ticker SHARECLASS_INCOME
 *
 * @author Kay Ip
 * @date 26 Oct 2018
 * @company Prive Financial
 */
public enum ShareClass {
	INCOME,
	ACCUMULATION;
}
