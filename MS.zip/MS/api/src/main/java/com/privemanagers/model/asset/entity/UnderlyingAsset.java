package com.privemanagers.model.asset.entity;

import org.bson.types.ObjectId;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Underlying asset
 *
 * @author Kay Ip
 * @date 21 Nov 2018
 * @company Prive Financial
 */
public class UnderlyingAsset {

	@JsonProperty("asset-id")
	private ObjectId assetId;

	private Double weight;

	public ObjectId getAssetId() {
		return assetId;
	}

	public void setAssetId(ObjectId assetId) {
		this.assetId = assetId;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}
}
