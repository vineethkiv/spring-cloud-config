package com.privemanagers.model.error;

public interface AppErrorCode {

	public String getCode();

	public String getAppName();

	default String getErrorCode() {
		return this.getAppName() + "-" + this.getCode();
	}

}
