package com.privemanagers.model.quant.response;

import java.util.List;

/**
 * dual series response object for dual series in b2b and quant
 *
 * @author wzhang
 * @date 31 Oct 2018
 * @company Prive Financial
 */

public class DualSeriesResponse {

	private String from;
	private String until;

	private List<DualSeriesAsset> assets;

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getUntil() {
		return until;
	}

	public void setUntil(String until) {
		this.until = until;
	}

	public List<DualSeriesAsset> getAssets() {
		return assets;
	}

	public void setAssets(List<DualSeriesAsset> assets) {
		this.assets = assets;
	}
}
