package com.privemanagers.api.util;

import com.jcraft.jsch.UserInfo;

public class SCPUserInfo implements UserInfo {

	private String passphrase;
	private String password;

	@Override
	public String getPassphrase() {
		return passphrase;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public boolean promptPassphrase(String arg0) {
		return false;
	}

	@Override
	public boolean promptPassword(String arg0) {
		return false;
	}

	@Override
	public boolean promptYesNo(String arg0) {
		return true;
	}

	@Override
	public void showMessage(String arg0) {
	}

}
