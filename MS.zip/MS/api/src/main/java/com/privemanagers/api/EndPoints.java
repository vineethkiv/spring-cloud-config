package com.privemanagers.api;

public class EndPoints {

	public static final String HEALTH = "/health";
	public static final String ERROR = "/error";

	public static final String ASSETS_1_ASSET_SERIES = "/assets/1/{tenant}/assets/{assetid}/series";
	public static final String ASSETS_1_ASSET_PRICE = "/assets/1/{tenant}/assets/{assetid}/price";
	public static final String ASSETS_1_ASSET_DIVIDENDS = "/assets/1/{tenant}/assets/{assetid}/dividends";
	public static final String ASSETS_1_ASSET_SPLITS = "/assets/1/{tenant}/assets/{assetid}/splits";
	public static final String ASSETS_1_ASSET = "/assets/1/{tenant}/assets/{assetid}";
	public static final String ASSETS_1_ASSET_EXPORT = "/assets/1/{tenant}/assets/export/{dataSource}";
	public static final String ASSETS_1_ASSET_EXPORT_WITH_TYPE = "/assets/1/{tenant}/assets/export/{dataSource}/{dataType}";
	public static final String ASSETS_1_UNIVERSE = "/assets/1/{tenant}/universe";
	public static final String ASSETS_1_CODES = "/assets/1/{tenant}/codes";
	public static final String ASSETS_1_ASSET_CREATE = "/assets/1/{tenant}/assets";
	public static final String ASSETS_1_ASSET_VALUATIONS = "/assets/1/{tenant}/assets/{assetid}/valuations";
	public static final String ASSETS_1_ASSETS_VALUATIONS = "/assets/1/{tenant}/valuations";
	public static final String ASSETS_1_CURRENCY_CONVERSION = "/assets/1/{tenant}/currencies/{ISOcurrencypair}";
	public static final String ASSETS_1_SEARCH = "/assets/1/{tenant}/search";
	public static final String ASSETS_1_CRITERIA = "/assets/1/{tenant}/criteria";
	public static final String ASSETS_1_MULTIASSETS = "/assets/1/{tenant}/multiassets";
	public static final String ASSETS_1_FUNDAMENTALS = "/assets/1/{tenant}/fundamentals";
	public static final String ASSETS_1_RAW_PRICE = "/assets/1/{tenant}/raw/price";
	public static final String ASSETS_1_RAW_DIVIDEND = "/assets/1/{tenant}/raw/dividend";
	public static final String ASSETS_1_RAW_SPLIT = "/assets/1/{tenant}/raw/split";
	public static final String ASSETS_1_ADJUSTED_PRICE = "/assets/1/{tenant}/adjusted/price";
	public static final String ASSETS_1_SCHEDULER_MIRROR_FUND = "/assets/1/prive/mirrorFund";
	public static final String ASSETS_1_GRAPHQL = "/assets/1/{tenant}/graphql";

	public static final String B2B_1_DUAL_SERIES = "/b2b/1/{tenant}/series/dual";

	public static final String COST_1 = "/cost/1";

	public static final String BOND_STATS_1 = "/bond-stats/1";

	public static final String EMS_1_ORDERS = "/ems/{broker}/1/{tenant}/orders";
	public static final String EMS_1_ORDERS_REFERENCE = "/ems/{broker}/1/{tenant}/orders/{reference}";

	public static final String OPT_1_OPTIMISE = "opt/1/{tenant}/optimise";
	public static final String OPT_1_FITNESS = "/opt/1/{tenant}/fitness";

	public static final String PRIVE_1_TENANTS = "/prive/1/tenants";
	public static final String PRIVE_1_TENANTS_CONFIG = "/prive/1/{tenant}/config";

	public static final String QUANT_1_ASSET_SERIES = "/quant/1/{tenant}/assets/{assetid}/series";
	public static final String QUANT_1_ASSET_ADJUSTED_PRICES = "/quant/1/{tenant}/assets/{assetid}/adjusted_prices";
	public static final String QUANT_1_SERIES = "/quant/1/{tenant}/series";
	public static final String QUANT_1_PROJECTION = "/quant/1/{tenant}/projection";
	public static final String QUANT_1_DUAL_SERIES = "/quant/1/{tenant}/series/dual";

	public static final String XASSETS_1_UNIVERSE = "/xassets/1/universe";
	public static final String XASSETS_1_UNIVERSE_ROUTE = "/xassets/1/{tenant}/universe/route";
	public static final String XASSETS_1_UNIVERSE_ROUTE_MDS_ASSETS = "/xassets/1/{tenant}/universe/route/mds/assets";
	public static final String XASSETS_1_UNIVERSE_ROUTE_MDS_PRICES = "/xassets/1/{tenant}/universe/route/mds/prices";
	public static final String XASSETS_1_UNIVERSE_ROUTE_MDS_DIVIDENDS = "/xassets/1/{tenant}/universe/route/mds/dividends";
	public static final String XASSETS_1_UNIVERSE_ROUTE_MDS_SPLITS = "/xassets/1/{tenant}/universe/route/mds/splits";
	public static final String XASSETS_1_UPDATE = "/xassets/1/update";
	public static final String XASSETS_1_VALUATIONS = "/xassets/1/valuations";
	public static final String XASSETS_1_SEARCH_CREATE = "/xassets/1/searchCreate";
	public static final String XASSETS_1_SEARCH_CREATE_BY_SYMBOL = "/xassets/1/searchCreateBySymbol";

	@Deprecated
	public static final String AUTH_1 = "/auth/1/{tenant}";
	@Deprecated
	public static final String AUTH_1_TOKEN_USER = "/auth/1/usertoken";
	@Deprecated
	public static final String AUTH_1_TOKEN_TENANT = "/auth/1/token/{tenant}";

	// Spring Security mapped endpoints
	public static final String AUTH_1_AUTHORIZE = "/auth/1/authorize";
	public static final String AUTH_1_TOKEN = "/auth/1/token";
	public static final String AUTH_1_CHECK_TOKEN = "/auth/1/check_token";
	public static final String AUTH_1_CONFIRM_ACCESS = "/auth/1/confirm_access";
	public static final String AUTH_1_ERROR = "/auth/1/error";
	public static final String AUTH_1_TOKEN_KEY = "/auth/1/token_key";

	// Auth endpoints
	public static final String AUTH_1_LOGIN = "/auth/1/login";
	public static final String AUTH_1_REFRESH_TOKEN = "/auth/1/refresh";
	public static final String AUTH_1_USER = "/auth/1/{tenant}/user";

	// SOAP Wrapper end points start
	public static final String ACCOUNTS = "/accounts";
	public static final String ACCOUNTS_1_HOLDINGS = "/1/account/{accountkey}/holdings";
	public static final String ACCOUNTS_1_PERFORMANCE = "/1/account/{accountkey}/performance";
	public static final String ACCOUNTS_1_TRANSACTION = "/1/account/{accountkey}/transactions";
	public static final String ACCOUNTS_1_LIST = "/1/account/{investorkey}/list";
	public static final String ACCOUNTS_1_DETAILS = "/1/account/{accountkey}/details";
	public static final String ACCOUNTS_1_LINK_MODEL_PORTFOLIO = "/1/account/linkmodelportfolio";
	public static final String ACCOUNTS_1_UPDATE = "/1/accounts";
	public static final String ACCOUNTS_1_REBALANCE = "/1/account/submitrebalance";

	public static final String INVESTMENT = "/investment";
	public static final String INVESTMENT_1_DETAILS = "/1/investment/details";
	public static final String INVESTMENT_1_HISTORY = "/1/investment/history";

	public static final String INVESTOR = "/investor";
	public static final String INVESTOR_1_DETAILS = "/1/investor/{investorkey}/details";

	public static final String ADVISOR = "/advisor";
	public static final String ADVISOR_1_DETAILS = "/1/advisor/{advisorkey}/details";

	public static final String USER = "/user";
	public static final String USER_1_UPDATE = "/1/users";

	public static final String COMPANY = "/company";
	public static final String COMPANY_1_UPDATE = "/1/companies";
	// SOAP Wrapper end points end

	public static final String ASSETLOOKUP_1_LOOKUP = "/assetlookup/1/lookup";
	public static final String ASSETLOOKUP_1_SEARCH = "/assetlookup/1/search";
	public static final String ASSETLOOKUP_1_UPDATE_MASTER_DATA = "/assetlookup/1/updateMasterData";

	public static final String WM_1_ASSETS = "/wm/1/assets";
	public static final String WM_1_ASSETS_WM = "/wm/1/assets/wm";
	public static final String WM_1_ASSETS_WM_RELOAD = "/wm/1/assets/wm/reload";

	public static final String FMS_1_FIX_REPORT = "/fms/1/fix/report/{clordlinkid}";

	public static final String OSS_1_ORDERS_UNTRANSMITTED = "/oss/1/orders/untransmitted";
	public static final String OSS_1_ORDERS = "/oss/1/orders";

	public static final String CLASSIFICATION_1_ASSET = "/classification/1/{tenant}/asset/{assetid}";
	public static final String CLASSIFICATION_1_PORTFOLIO = "/classification/1/{tenant}/portfolio";
	public static final String CLASSIFICATION_1_MULTIASSETS = "/classification/1/{tenant}/multiassets";

	public static final String XPARSER_1_UPDATE = "/xparser/1/{tenant}/update";

	public static final String REBALANCER_1 = "/rebalancer/1/{tenant}/rebalancePortfolioGenerateOrders";

	public static final String STRUCTURED_PRODUCT_1_MARKET_ENVIRONMENTS = "/structuredProducts/1/{tenant}/marketEnvironments/{marketEnvironmentId}";
	public static final String STRUCTURED_PRODUCT_1_MARKET_ENVIRONMENT = "/structuredProducts/1/{tenant}/marketEnvironment";

	public static final String MARKET_DATA_PROVIDER_THOMSON_REUTERS_1_MASTER_DATA_UPDATE = "/tr/1/master/data/update";
	public static final String MARKET_DATA_PROVIDER_THOMSON_REUTERS_1_PRICE_UPDATE = "/tr/1/price/update";

	public static final String USERS_BASE_URL = "/users/1";
	public static final String USERS_GET_BY_USERNAME = "/{username}";

}
