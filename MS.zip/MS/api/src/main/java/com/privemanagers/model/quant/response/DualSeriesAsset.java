package com.privemanagers.model.quant.response;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * asset object used in dual series responses sent by quant and b2b
 *
 * @author wzhang
 * @date 31 Oct 2018
 * @company Prive Financial
 */
@JsonInclude(Include.NON_NULL)
public class DualSeriesAsset {

	@JsonProperty("asset-id")
	private String assetID;

	@JsonProperty("asset-code")
	private String code;

	@JsonProperty("asset-code-scheme")
	private String scheme;

	@JsonProperty("tracking-error")
	private Double trackingError;

	@JsonProperty("effective-duration")
	private Double effectiveDuration;

	@JsonProperty("current-value")
	private Double currentValue;

	@JsonProperty("maturity-date")
	private String maturityDate;

	private Map<String, String> name;

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	private String currency;
	private Double beta;
	private Double alpha;
	private Double correlation;
	private ShiftResponse shift;

	public String getAssetID() {
		return assetID;
	}

	public void setAssetID(String assetID) {
		this.assetID = assetID;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Double getBeta() {
		return beta;
	}

	public void setBeta(Double beta) {
		this.beta = beta;
	}

	public Double getAlpha() {
		return alpha;
	}

	public void setAlpha(Double alpha) {
		this.alpha = alpha;
	}

	public Double getTrackingError() {
		return trackingError;
	}

	public void setTrackingError(Double trackingError) {
		this.trackingError = trackingError;
	}

	public Double getCorrelation() {
		return correlation;
	}

	public void setCorrelation(Double correlation) {
		this.correlation = correlation;
	}

	public ShiftResponse getShift() {
		return shift;
	}

	public void setShift(ShiftResponse shift) {
		this.shift = shift;
	}

	public Double getEffectiveDuration() {
		return effectiveDuration;
	}

	public void setEffectiveDuration(Double effectiveDuration) {
		this.effectiveDuration = effectiveDuration;
	}

	public Double getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(Double currentValue) {
		this.currentValue = currentValue;
	}

	public Map<String, String> getName() {
		return name;
	}

	public void setName(Map<String, String> name) {
		this.name = name;
	}

}
