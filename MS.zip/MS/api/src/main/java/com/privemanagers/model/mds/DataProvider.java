package com.privemanagers.model.mds;

/**
 * market data provider
 *
 * @author Kay Ip
 * @date 13 Feb 2018
 * @company Prive Financial
 */
public enum DataProvider {
	/**
	 * Special Data provider type to denote all asset regardless of data source
	 */
	ALL("all"),
	/*
	 * Special Data provider for monolith
	 */
	PRIVE("prive"),
	PRIVE_MODEL("prive-model"),

	BLOOMBERG("bloomberg"),
	FINANCE_BASE("finance-base"),
	GETTEX("gettex"),
	MORNING_STAR("morning-star"),
	SIXT("six-telekurs"),
	SYSJUST("sysjust"),
	THOMSON_REUTERS("thomson-reuters"),
	WM_DATA("wm-data"),
	XIGNITE("xignite"),
	YIELD_BOOK("yield-book");

	private final String stringValue;

	DataProvider(final String stringValue) {
		this.stringValue = stringValue;
	}

	public final String getStringValue() {
		return stringValue;
	}

	public static DataProvider fromString(String text) {
		for (DataProvider dp : DataProvider.values()) {
			if (dp.stringValue.equalsIgnoreCase(text)) {
				return dp;
			}
		}
		throw new IllegalArgumentException("No constant with text " + text + " found");
	}

}
