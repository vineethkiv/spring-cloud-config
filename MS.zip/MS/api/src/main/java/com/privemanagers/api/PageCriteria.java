package com.privemanagers.api;

import java.util.List;

/**
 * To indicate the paging preference, including sorting, paging
 *
 * @author Kay Ip
 *
 */
public class PageCriteria {
	private List<SortCriteria> sortCriteria;
	private int pageSize;
	private int pageNumber;

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public List<SortCriteria> getSortCriteria() {
		return sortCriteria;
	}

	public void setSortCriteria(List<SortCriteria> sortCriteria) {
		this.sortCriteria = sortCriteria;
	}

}
