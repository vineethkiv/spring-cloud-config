package com.privemanagers.model.asset.dto.graphql;

import io.leangen.graphql.annotations.GraphQLQuery;

/**
 * TopHoldingAssetDTO, sub class for AssetDTO
 *
 * @author Kay Ip
 * @date 14 Feb 2019
 * @company Prive Financial
 */
public class TopHoldingAssetDTO {
	@GraphQLQuery
	private String name;
	@GraphQLQuery
	private Double weight;
	@GraphQLQuery
	private String currency;
	@GraphQLQuery
	private String isin;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getIsin() {
		return isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}
}
