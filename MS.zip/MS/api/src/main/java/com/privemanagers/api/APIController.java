package com.privemanagers.api;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
public class APIController implements ErrorController {

	/**
	 * This is copied from the Spring Boot BasicErrorController.
	 */
	private static final String ERROR_PATH_PROPERTY = "${server.error.path:${error.path:/error}}";

	/**
	 * The end point through which AWS will health check this service.
	 */
	private static final String HEALTH_PATH = "/health";

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value(ERROR_PATH_PROPERTY)
	private String path;

	@Override
	public String getErrorPath() {
		return this.path;
	}

	/**
	 * Handle an error redirection due to a bad HTTP method or bad URL. The
	 * policy is never to reveal the cause of the error to an ignorant or
	 * malicious agent.
	 *
	 * @param request
	 * @return ResponseEntity
	 */
	@RequestMapping(ERROR_PATH_PROPERTY)
	public ResponseEntity<String> error(final HttpServletRequest request) {
		this.logger.warn("{} {} {} {}", HttpStatus.BAD_REQUEST.getReasonPhrase(), request.getRemoteAddr(),
				request.getMethod(), request.getAttribute(RequestDispatcher.ERROR_REQUEST_URI));
		return ResponseEntity.badRequest().body("");
	}

	/**
	 * Handle an error redirection due to a bad HTTP method or bad URL. The
	 * policy is never to reveal the cause of the error to an ignorant or
	 * malicious agent.
	 *
	 * @param request
	 * @return ResponseEntity
	 */

	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@RequestMapping(ERROR_PATH_PROPERTY + "/unauthorized")
	public ResponseEntity<String> unauthorized(final HttpServletRequest request) {
		this.logger.warn("{} {} {} {}", HttpStatus.UNAUTHORIZED.getReasonPhrase(), request.getRemoteAddr(),
				request.getMethod(), request.getAttribute(RequestDispatcher.ERROR_REQUEST_URI));
		return new ResponseEntity<>("", HttpStatus.UNAUTHORIZED);
	}

	/**
	 * An endpoint for an AWS ALB to use when checking the health of this
	 * service.
	 *
	 * @return ResponseEntity
	 */
	@RequestMapping(value = HEALTH_PATH, method = RequestMethod.GET)
	public ResponseEntity<String> health() {
		return ResponseEntity.ok("");
	}

}
