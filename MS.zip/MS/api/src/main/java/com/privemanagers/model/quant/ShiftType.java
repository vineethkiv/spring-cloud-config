package com.privemanagers.model.quant;

/**
 * enum for dual series sensitivity analysis type
 *
 * @author wzhang
 * @date 25 Oct 2018
 * @company Prive Financial
 */
public enum ShiftType {
	BENCHMARK,
	INTEREST_RATE;
}
