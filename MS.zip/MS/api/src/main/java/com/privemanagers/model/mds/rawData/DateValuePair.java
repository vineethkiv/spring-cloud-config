package com.privemanagers.model.mds.rawData;

/**
 * DateValuePair
 * 
 * @author Kay Ip
 * @date 14 Feb 2018
 * @company Prive Financial
 */
public class DateValuePair {
	// format for date is yyyyMMdd
	private String date;
	private Double value;

	public DateValuePair() {

	}

	public DateValuePair(String date, Double value) {
		super();
		this.date = date;
		this.value = value;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
