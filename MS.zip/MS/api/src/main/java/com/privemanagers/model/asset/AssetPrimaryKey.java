package com.privemanagers.model.asset;

import java.util.Objects;

/**
 * The fields that can identify a specific asset in our multi assets per data
 * source scheme
 *
 * @author Kay Ip
 * @date 12 July 2018
 * @company Prive Financial
 */
public class AssetPrimaryKey {

	/** Scheme of the code e.g. ISIN */
	private String codeScheme;
	/** Value of the code scheme. e.g. value of ISIN */
	private String codeValue;
	/** Data source e.g. xgnite */
	private String dataSource;

	public AssetPrimaryKey() {
	}

	/**
	 * @param codeScheme
	 * @param codeValue
	 * @param dataSource
	 */
	public AssetPrimaryKey(String codeScheme, String codeValue, String dataSource) {
		this.codeScheme = codeScheme;
		this.codeValue = codeValue;
		this.dataSource = dataSource;
	}

	public String getCodeScheme() {
		return codeScheme;
	}

	public void setCodeScheme(String codeScheme) {
		this.codeScheme = codeScheme;
	}

	public String getCodeValue() {
		return codeValue;
	}

	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		if (getClass() != o.getClass()) {
			return false;
		}

		final AssetPrimaryKey assetPrimaryKey = (AssetPrimaryKey) o;
		if (!Objects.equals(this.dataSource, assetPrimaryKey.getDataSource())) {
			return false;
		}
		if (!Objects.equals(this.codeScheme, assetPrimaryKey.getCodeScheme())) {
			return false;
		}
		if (!Objects.equals(this.codeValue, assetPrimaryKey.getCodeValue())) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codeScheme, codeValue, dataSource);
	}

	@Override
	public String toString() {
		return "AssetPrimaryKey [codeScheme=" + codeScheme + ", codeValue=" + codeValue + ", dataSource=" + dataSource
				+ "]";
	}
}
