package com.privemanagers.model.common.slack;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Slack attachment fields, items under slack attachment
 *
 * https://api.slack.com/docs/message-attachments #fields section
 *
 * @author Kay Ip
 * @date 14 Sep 2018
 * @company Prive Financial
 */
public class AttachmentField {
	private String title;
	private String value;

	@JsonProperty("short")
	private boolean shortMessage;

	public AttachmentField() {
	}

	public AttachmentField(String title, String value, boolean shortMessage) {
		this.title = title;
		this.value = value;
		this.shortMessage = shortMessage;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean isShortMessage() {
		return shortMessage;
	}

	public void setShortMessage(boolean shortMessage) {
		this.shortMessage = shortMessage;
	}
}
