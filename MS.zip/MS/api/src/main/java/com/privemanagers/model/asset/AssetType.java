package com.privemanagers.model.asset;

import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author Ray Lee
 * @date : Oct 16, 2017
 * @company Prive Financial
 */
public enum AssetType {

	TYPE_EQUITY("EQUITY"), //
	TYPE_ETF("ETF"), //
	TYPE_FUTURE("FUTURE"), //
	TYPE_BOND("BOND"), //
	TYPE_FXSPOT("FXSPOT"), //
	TYPE_COMMODITY("COMMODITY"), //
	TYPE_ECONOMIC_DATA("ECONOMIC_DATA"), //
	TYPE_MUTUAL_FUNDS("MUTUAL_FUNDS"), //
	TYPE_STRUCTURED_PRODUCT("STRUCTURED_PRODUCT"), //
	TYPE_CLOSED_END_PRODUCT_PLACEHOLDER("CLOSED_END_PRODUCT_PLACEHOLDER"), //
	TYPE_INDEX("INDEX"), //
	TYPE_WARRANT("WARRANT"), //
	TYPE_CLOSED_END_GENERIC_PRODUCT("CLOSED_END_GENERIC_PRODUCT"), //
	TYPE_MONEY_MARKET("MONEY_MARKET"), //
	TYPE_FX_FORWARD("FX_FORWARD"), //
	TYPE_ALTERNATIVE("ALTERNATIVE"), //
	TYPE_OPTION("OPTION"), //
	TYPE_PROPERTY_AND_LAND("PROPERTY_AND_LAND"), //
	TYPE_AUV_FUND("AUV_FUND"), //
	TYPE_LOAN("LOAN"), //
	TYPE_LOAN_CONTINGENT("LOAN_CONTINGENT"), //
	TYPE_CONVERTIBLE_BOND("CONVERTIBLE_BOND"), //
	TYPE_PROMISSORY_NOTE("PROMISSORY_NOTE"), //
	TYPE_FIXED_RATE("FIXED_RATE"), //
	TYPE_CASH("CASH");

	private static HashMap<String, AssetType> valueMap = new HashMap<String, AssetType>();
	static {
		for (AssetType value : AssetType.values()) {
			valueMap.put(value.toString(), value);
		}
	}

	private final String text;

	private AssetType(final String str) {
		this.text = str;
	}

	@JsonValue
	@Override
	public String toString() {
		return text;
	}

	@JsonCreator
	public static AssetType fromString(String string) {
		return valueMap.get(string);
	}

	public String getText() {
		return text;
	}

}
