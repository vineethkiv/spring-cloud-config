package com.privemanagers.model.common;

/**
 * Enumeration for the geographic region value
 *
 * The values can save to DB directly
 *
 * reference sylaws org.sly.main.shared.enumeration.Region
 *
 * @author Kay Ip
 * @date 29 Aug 2018
 * @company Prive Financial
 */
public enum Region {

	/** regions */
	AFRICA_MIDDLE_EAST,
	ASIA_DEVELOPED,
	EUROPE_DEVELOPED,
	NORTH_AMERICA,
	LATIN_AMERICA,
	ASIA_EMERGING,
	// merged into REGION_AFRICA_MIDDLE_EAST
	// REGION_MIDDLE_EAST = 7;
	GLOBAL,
	OTHER,
	JAPAN,
	AUSTRALASIA,
	UNITED_KINGDOM,
	EUROPE_EMERGING;
}
