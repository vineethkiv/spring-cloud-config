package com.privemanagers.model.asset;

/**
 * SettingsFrequency
 *
 * Ref: org.sly.main.shared.settings.SettingsFrequency
 *
 * @author Kay Ip
 * @date 26 Oct 2018
 * @company Prive Financial
 */
public enum SettingsFrequency {
	DAILY,
	WEEKLY,
	BI_WEEKLY,
	MONTHLY,
	QUARTERLY,
	SEMI_ANNUAL,
	ANNUAL,
	NONE,
	SEMI_MONTHLY,
	BI_MONTHLY;
}
