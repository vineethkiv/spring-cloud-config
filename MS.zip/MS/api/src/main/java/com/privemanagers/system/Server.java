package com.privemanagers.system;

/**
 * @author Gavy Lau
 * @date 20 Sep 2018
 * @company Prive Financial
 */
public class Server {

	/**
	 * True if PRODUCTION flags should be enabled. Please set in environment
	 * variables rather than changing this file.
	 *
	 * On the production environment, {@link System#getenv(String)} was not able
	 * to find the environment variable, PRODUCTION. As a backup, PRODUCTION
	 * should be set as a JVM property.
	 */
	public static final boolean PRODUCTION = (System.getenv("PRODUCTION") != null
			&& System.getenv("PRODUCTION").equals("true"))
			|| (System.getProperty("PRODUCTION") != null && System.getProperty("PRODUCTION").equals("true"));

}
