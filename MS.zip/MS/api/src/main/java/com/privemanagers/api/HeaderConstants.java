package com.privemanagers.api;

/**
 * @author William Zhang
 * @date 31 Oct 2017
 * @company Prive Financial
 */
public class HeaderConstants {
	public static final String PRIVE_TENANT_CONFIG = "prive-tenant-config";
	public static final String PRIVE_REQUEST = "prive-request";
}
