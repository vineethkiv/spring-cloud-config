package com.privemanagers.model.asset.request;

import io.leangen.graphql.annotations.GraphQLQuery;

/**
 * Request for graphql endpoint, it contains the same fields as
 * AssetCodesRequest
 *
 * This reason creating this is graphql field name don't support "-", field
 * names allowed pattern is [_A-Za-z][_0-9A-Za-z]*
 *
 * We cannot have @JsonProperty with "-" name
 *
 * @author Kay Ip
 * @date 31 Jan 2019
 * @company Prive Financial
 */
public class AssetCodesGraphQLRequest {

	@GraphQLQuery
	private String scheme;
	@GraphQLQuery
	private String value;
	@GraphQLQuery
	private String currency;
	@GraphQLQuery
	private String cfiCode;
	@GraphQLQuery
	private String dataSource;

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCfiCode() {
		return cfiCode;
	}

	public void setCfiCode(String cfiCode) {
		this.cfiCode = cfiCode;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
}
