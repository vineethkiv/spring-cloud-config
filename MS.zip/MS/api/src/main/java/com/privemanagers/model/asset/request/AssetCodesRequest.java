package com.privemanagers.model.asset.request;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Request for EndPoints.ASSETS_1_CODES
 *
 * @author Kay Ip
 * @date 25 Jun 2018
 * @company Prive Financial
 */
public class AssetCodesRequest {

	String scheme;
	String value;
	String currency;
	@JsonProperty("cfi-code")
	private String cfiCode;
	@JsonProperty("data-source")
	private String dataSource;

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCfiCode() {
		return cfiCode;
	}

	public void setCfiCode(String cfiCode) {
		this.cfiCode = cfiCode;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
}
