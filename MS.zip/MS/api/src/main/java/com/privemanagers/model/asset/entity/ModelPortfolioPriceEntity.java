package com.privemanagers.model.asset.entity;

import java.util.List;

/**
 * Price entity for model portfolio
 *
 * @author Kay Ip
 * @date 14 Aug 2018
 * @company Prive Financial
 */
public class ModelPortfolioPriceEntity extends PriceEntity {

	List<ModelPortfolioAllocationEntity> allocation;

	public List<ModelPortfolioAllocationEntity> getAllocation() {
		return allocation;
	}

	public void setAllocation(List<ModelPortfolioAllocationEntity> allocation) {
		this.allocation = allocation;
	}
}
