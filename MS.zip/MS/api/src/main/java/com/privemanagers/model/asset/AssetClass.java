package com.privemanagers.model.asset;

/**
 * AssetClass
 *
 * Ref: org.sly.main.shared.enumeration.AssetClass
 *
 * @author Kay Ip
 * @date 26 Oct 2018
 * @company Prive Financial
 */
public enum AssetClass {
	EQUITY,
	FIXEDINCOME,
	FX,
	COMMODITY,
	ALTERNATIVE,
	REALESTATE,
	HYBRID,
	CASH,
	OTHER;
}
