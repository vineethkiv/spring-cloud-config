package com.privemanagers.api.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPClientConfig;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.JSchException;

/**
 * FTP Utils for connecting FTP
 *
 * @author Ray Lee
 * @date 7 Sep 2018
 * @company Prive Financial
 */
public class FTPUtil implements AutoCloseable {
	private static final Logger logger = LoggerFactory.getLogger(FTPUtil.class);

	FTPClient ftp;

	/**
	 * Connect to FTP Server
	 *
	 * @param host
	 * @param port
	 * @param username
	 * @param password
	 * @throws JSchException
	 */
	public void connectFTP(String host, int port, String username, String password) throws JSchException {

		try {
			ftp = new FTPClient();
			FTPClientConfig config = new FTPClientConfig();
			ftp.configure(config);
			int reply;
			ftp.connect(host, port);
			ftp.enterLocalPassiveMode();
			ftp.login(username, password);
			ftp.setFileTransferMode(FTP.STREAM_TRANSFER_MODE);
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			logger.info(String.format("Connected to %s, replyCode: %s", host, ftp.getReplyString()));

			// After connection attempt, you should check the reply code to
			// verify
			// success.
			reply = ftp.getReplyCode();

			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				throw new RuntimeException("FTP server refused connection.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Upload file to FTP
	 *
	 * @param remotePath
	 * @param localFilePath
	 */
	public void putFile(String remotePath, String localFilePath) {
		if (ftp != null) {
			try (InputStream is = new FileInputStream(localFilePath)) {

				boolean success = ftp.storeFile(remotePath, is);
				logger.info(String.format("Uploading file %s, success=%s", localFilePath, success));
			} catch (Exception e) {
				e.printStackTrace();
				logger.info(e.getMessage());
			}
		} else {
			throw new RuntimeException("not connected ftp channel!");
		}
	}

	public void disconnect() {
		if (ftp != null) {
			try {
				ftp.logout();
				ftp.disconnect();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void close() throws Exception {
		disconnect();
	}
}
