package com.privemanagers.api.util;

/**
 * Cronhub Job UUID mapping
 *
 * @author Gavy Lau
 * @date 20 Sep 2018
 * @company Prive Financial
 */
public enum CronhubJob {

	XASSET_MP_FX_SYNC("19e45e10-bc82-11e8-ae8e-35fe6a7c357e"),
	XASSET_ASSET_SYNC("dcaa6f00-bcad-11e8-8c17-01dd9751213e"),

	ASSET_VIRTUAL_MIRROR_FUND("5f40f190-f145-11e8-9f3a-5725d3d71c3b"),

	// mds-sysjust
	MDS_SYSJUST_MASTER_SYNC("9bdc7ec0-ec73-11e8-949e-af22d3919ccd"),
	MDS_SYSJUST_PRICE_SYNC("55e302f0-f143-11e8-8c96-fd0a975885fc"),
	MDS_SYSJUST_DIVIDEND_SYNC("6b3cf340-f143-11e8-8b1c-9910ffea42de"),
	MDS_SYSJUST_HISTORY_SYNC("d47254e0-f143-11e8-910e-4f2393ad2d77"),

	// mds-bloomberg
	MDS_BLOOMBERG_MASTER_SYNC("c6a4c260-f144-11e8-b885-01ad6c5bfb9a"),
	MDS_BLOOMBERG_PRICE_SYNC("f3578630-f144-11e8-b1a5-879e7d2ff8a9"),
	MDS_BLOOMBERG_DIVIDEND_SYNC("1698de90-f145-11e8-a61b-1351897d81bd"),
	MDS_BLOOMBERG_HISTORY_SYNC("dd147540-f144-11e8-b611-7fb781109b1a");

	private final String uuid;

	private CronhubJob(final String uuid) {
		this.uuid = uuid;
	}

	public String uuid() {
		return uuid;
	}

}
