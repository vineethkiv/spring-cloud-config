package com.privemanagers.model.asset.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.model.asset.PriceDataType;

/**
 * Entity class for Price
 *
 * @author Kay Ip
 * @date 6 July 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PriceEntity {
	private String _id;

	@JsonProperty("asset-id")
	private String assetId;

	@JsonProperty("local-date")
	private Integer localDate;

	@JsonProperty("close-px")
	private Double closePx;

	private PriceDataType type;

	@JsonProperty("data-source")
	private String dataSource;

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public Integer getLocalDate() {
		return localDate;
	}

	public void setLocalDate(Integer localDate) {
		this.localDate = localDate;
	}

	public Double getClosePx() {
		return closePx;
	}

	public void setClosePx(Double closePx) {
		this.closePx = closePx;
	}

	public PriceDataType getType() {
		return type;
	}

	public void setType(PriceDataType type) {
		this.type = type;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
}
