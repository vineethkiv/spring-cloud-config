package com.privemanagers.model.mds.request;

import java.util.List;

import org.bson.Document;

/**
 * request to update assets by primary code, mainly using be mds
 *
 * @author Kay Ip
 * @date 20 Jun 2018
 * @company Prive Financial
 */
public class AssetUpdateRequest {
	List<Document> assets;
	String primaryCodeScheme;
	String source;
	boolean updateOnly;

	public List<Document> getAssets() {
		return assets;
	}

	public void setAssets(List<Document> assets) {
		this.assets = assets;
	}

	public String getPrimaryCodeScheme() {
		return primaryCodeScheme;
	}

	public void setPrimaryCodeScheme(String primaryCodeScheme) {
		this.primaryCodeScheme = primaryCodeScheme;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public boolean isUpdateOnly() {
		return updateOnly;
	}

	public void setUpdateOnly(boolean updateOnly) {
		this.updateOnly = updateOnly;
	}
}
