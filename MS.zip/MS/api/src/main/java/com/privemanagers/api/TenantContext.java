package com.privemanagers.api;

import javax.json.JsonObject;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

/**
 * Context to store the current tenant services specific configuration as it
 * needs to be passed across services. With Spring scope = request, a new
 * instance is instantiated for every HTTP request.
 *
 * @author nteck
 * @date 25 Oct 2017
 * @company Prive Financial
 */
@Component
@Scope(value = "request", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class TenantContext {

	private JsonObject servicesConfig;

	public JsonObject getServicesConfig() {
		return this.servicesConfig;
	}

	public void setServicesConfig(final JsonObject servicesConfig) {
		this.servicesConfig = servicesConfig;
	}

}
