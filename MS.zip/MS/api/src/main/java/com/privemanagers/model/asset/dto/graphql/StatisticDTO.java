package com.privemanagers.model.asset.dto.graphql;

import java.util.Map;

import io.leangen.graphql.annotations.GraphQLQuery;

/**
 * StatisticDTO, subClass for AssetsDTO
 *
 * AssetEntity is using Map, but DTO need defines a StatisticDTO for user query
 *
 * @author Kay Ip
 * @date 14 Feb 2019
 * @company Prive Financial
 */
public class StatisticDTO {

	@GraphQLQuery
	private Map<String, Double> volatility;

	@GraphQLQuery
	private Map<String, Double> downsideVolatility;

	@GraphQLQuery
	private Map<String, Double> sharpeRatio;

	@GraphQLQuery
	private Map<String, Double> normalReturn;

	@GraphQLQuery
	private Map<String, Double> annualizedReturn;

	@GraphQLQuery
	private Map<String, Double> monthlyReturn;

	@GraphQLQuery
	private Double maxDrawdown;

	@GraphQLQuery
	private Double negativeMonthsPercentage;

	public Map<String, Double> getVolatility() {
		return volatility;
	}

	public void setVolatility(Map<String, Double> volatility) {
		this.volatility = volatility;
	}

	public Map<String, Double> getSharpeRatio() {
		return sharpeRatio;
	}

	public void setSharpeRatio(Map<String, Double> sharpeRatio) {
		this.sharpeRatio = sharpeRatio;
	}

	public Map<String, Double> getNormalReturn() {
		return normalReturn;
	}

	public void setNormalReturn(Map<String, Double> normalReturn) {
		this.normalReturn = normalReturn;
	}

	public Map<String, Double> getDownsideVolatility() {
		return downsideVolatility;
	}

	public void setDownsideVolatility(Map<String, Double> downsideVolatility) {
		this.downsideVolatility = downsideVolatility;
	}

	public Map<String, Double> getAnnualizedReturn() {
		return annualizedReturn;
	}

	public void setAnnualizedReturn(Map<String, Double> annualizedReturn) {
		this.annualizedReturn = annualizedReturn;
	}

	public Double getMaxDrawdown() {
		return maxDrawdown;
	}

	public void setMaxDrawdown(Double maxDrawdown) {
		this.maxDrawdown = maxDrawdown;
	}

	public Double getNegativeMonthsPercentage() {
		return negativeMonthsPercentage;
	}

	public void setNegativeMonthsPercentage(Double negativeMonthsPercentage) {
		this.negativeMonthsPercentage = negativeMonthsPercentage;
	}

	public Map<String, Double> getMonthlyReturn() {
		return monthlyReturn;
	}

	public void setMonthlyReturn(Map<String, Double> monthlyReturn) {
		this.monthlyReturn = monthlyReturn;
	}
}
