package com.privemanagers.api.config.tenant;

import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonValue.ValueType;

import com.privemanagers.api.TenantContext;

/**
 * Util to validate and get config value for tenantContext
 *
 * @author Kay Ip
 * @date 13 Mar 2018
 * @company Prive Financial
 */
public class TenantServiceConfigUtil {

	/**
	 * get a String config value
	 *
	 * @param tenantContext
	 * @param service
	 * @param config
	 * @return
	 */
	public static String getConfigStringValue(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, final String defaultValue) {

		boolean configAvailable = hasConfigAndValidateType(tenantContext, service, config, ValueType.STRING);
		if (!configAvailable) {
			return defaultValue;
		}

		return getServiceObject(tenantContext, service).getString(config.getDbFieldName());
	}

	/**
	 * get a int config value
	 *
	 * @param tenantContext
	 * @param service
	 * @param config
	 * @return
	 */
	public static int getConfigIntValue(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, final int defaultValue) {

		boolean configAvailable = hasConfigAndValidateType(tenantContext, service, config, ValueType.NUMBER);
		if (!configAvailable) {
			return defaultValue;
		}

		return getServiceObject(tenantContext, service).getJsonNumber(config.getDbFieldName()).intValue();
	}

	/**
	 * get a boolean config value
	 *
	 * @param tenantContext
	 * @param service
	 * @param config
	 * @return
	 */
	public static boolean getConfigBooleanValue(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, boolean defaultValue) {

		boolean hasConfig = hasConfig(tenantContext, service, config);
		if (!hasConfig) {
			return defaultValue;
		}

		return getServiceObject(tenantContext, service).getBoolean(config.getDbFieldName(), defaultValue);
	}

	/**
	 * get a JsonObject config value
	 *
	 * @param tenantContext
	 * @param service
	 * @param config
	 * @return
	 */
	public static JsonObject getConfigJsonValue(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, final JsonObject defaultValue) {

		boolean configAvailable = hasConfigAndValidateType(tenantContext, service, config, ValueType.OBJECT);
		if (!configAvailable) {
			return defaultValue;
		}

		return getServiceObject(tenantContext, service).getJsonObject(config.getDbFieldName());
	}

	/**
	 * Check tenant has service config
	 *
	 * For those cannot check type as some type cannot be checked, e.g. boolean,
	 * date
	 *
	 * @param service
	 * @param config
	 * @return
	 */
	private static boolean hasConfig(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config) {
		JsonObject servicesConfig = tenantContext.getServicesConfig();
		String serviceName = service.getDbFieldName();
		String configName = config.getDbFieldName();
		if (servicesConfig == null || !servicesConfig.containsKey(serviceName)
				|| !servicesConfig.get(serviceName).getValueType().equals(ValueType.OBJECT)) {
			return false;
		}

		return servicesConfig.getJsonObject(serviceName).containsKey(configName);
	}

	/**
	 * Check tenant has service config and the config is expected type
	 *
	 * @param service
	 * @param config
	 * @param type
	 * @return
	 */
	private static boolean hasConfigAndValidateType(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, final ValueType type) {
		JsonObject servicesConfig = tenantContext.getServicesConfig();
		boolean hasConfig = hasConfig(tenantContext, service, config);
		if (!hasConfig) {
			return false;
		}

		String serviceName = service.getDbFieldName();
		String configName = config.getDbFieldName();
		return servicesConfig.getJsonObject(serviceName).get(configName).getValueType().equals(type);
	}

	private static JsonObject getServiceObject(final TenantContext tenantContext, final TenantServiceEnum service) {
		JsonObject servicesConfig = tenantContext.getServicesConfig();
		String serviceName = service.getDbFieldName();
		return servicesConfig.getJsonObject(serviceName);
	}

	/**
	 * get a JsonArray config value
	 *
	 * @param tenantContext
	 * @param service
	 * @param config
	 * @return
	 */
	public static JsonArray getConfigJsonArray(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, final JsonArray defaultValue) {

		boolean configAvailable = hasConfigAndValidateType(tenantContext, service, config, ValueType.ARRAY);
		if (!configAvailable) {
			return defaultValue;
		}

		return getServiceObject(tenantContext, service).getJsonArray(config.getDbFieldName());
	}

	public static double getConfigDoubleValue(final TenantContext tenantContext, final TenantServiceEnum service,
			final TenantConfigEnum config, final double defaultValue) {

		boolean configAvailable = hasConfigAndValidateType(tenantContext, service, config, ValueType.NUMBER);
		if (!configAvailable) {
			return defaultValue;
		}

		return getServiceObject(tenantContext, service).getJsonNumber(config.getDbFieldName()).doubleValue();
	}

}
