package com.privemanagers.api;

import java.io.StringReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Currency;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonValue.ValueType;
import javax.servlet.http.HttpServletRequest;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;

public class API {

	/**
	 * Tenants name should be formatted as NAME-BRANCHNAME. For example Citi
	 * Hong Kong will be citi-hk.
	 */
	public static final String TENANT_NAME_SEPARATOR = "-";

	private static final BigDecimal HUNDRED = new BigDecimal("100");

	public static final DateTimeFormatter STRING_TO_DATE = new DateTimeFormatterBuilder()
			.appendPattern("yyyy[-MM[-dd]]")
			.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
			.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
			.toFormatter();

	/** Convert String to {@link LocalDate} with the format of YYYYMMDD */
	public static final DateTimeFormatter STRING_TO_DATE_NON_DASH = DateTimeFormatter.ofPattern("yyyyMMdd");

	private static final String REQUEST = "request";

	private static final Logger logger = LoggerFactory.getLogger(API.class);

	/**
	 * The given string is a comma separated list of values. Return the values
	 * as a list.
	 *
	 * @param string
	 * @return List&lt;String&gt;
	 */
	public static List<String> list(final String string) {
		return list(string, ",");
	}

	/**
	 * The given string is a list of values each separated by the specified
	 * string. Return the values as a list.
	 *
	 * @param string
	 * @param separator
	 * @return List&lt;String&gt;
	 */
	public static List<String> list(final String string, final String separator) {
		if (string == null) {
			return Collections.emptyList();
		}
		String x = string.trim();
		if (x.isEmpty()) {
			return Collections.emptyList();
		}
		final String[] xs = x.split(separator);
		final List<String> list = new ArrayList<>();
		for (final String s : xs) {
			x = s.trim();
			if (!x.isEmpty()) {
				list.add(x);
			}
		}
		return list;
	}

	/**
	 * Parse the string as a date with the format YYYY, YYYY-MM or YYYY-MM-DD.
	 * If the string is not a reasonable date then return null. Note that the
	 * day of the month defaults to one if missing and likewise the month of the
	 * year.
	 *
	 * @param string
	 * @return LocalDate
	 */
	public static LocalDate date(final String string) {
		return date(string, STRING_TO_DATE);
	}

	/**
	 * Parse the string as a date using the given {@link DateTimeFormatter}
	 *
	 * @param string
	 * @param formatter
	 * @return
	 */
	public static LocalDate date(final String string, final DateTimeFormatter formatter) {
		try {

			if (string == null) {
				return null;
			}
			final LocalDate date = LocalDate.parse(string, formatter);
			final int year = date.getYear();
			if (year < 1900 || year > 2100) {
				return null;
			}
			return date;

		} catch (final DateTimeParseException e) {
			return null;
		}
	}

	/**
	 * Parse the string expecting this to be a {@link JsonObject}. If it cannot
	 * be parsed, return null.
	 *
	 * @param body
	 * @return JsonObject
	 */
	public static JsonObject parseObject(final String body) {
		try (final JsonReader reader = Json.createReader(new StringReader(body))) {

			return reader.readObject();

		} catch (final Exception e) {
			return null;
		}
	}

	/**
	 * Parse the string expecting this to be a {@link JsonArray}. If it cannot
	 * be parsed, return null.
	 *
	 * @param body
	 * @return JsonArray
	 */
	public static JsonArray parseArray(final String body) {
		try (final JsonReader reader = Json.createReader(new StringReader(body));) {

			return reader.readArray();

		} catch (final Exception e) {
			return null;
		}
	}

	/**
	 * Make a default factory.
	 *
	 * @return JsonBuilderFactory
	 */
	public static JsonBuilderFactory makeJsonBuilderFactory() {
		return Json.createBuilderFactory(Collections.<String, Object> emptyMap());
	}

	/**
	 * Convert the number to a BigDecimal with the given number of decimal
	 * places.
	 *
	 * @param number
	 * @param decimals
	 * @return BigDecimal
	 */
	public static BigDecimal toBigDecimal(final double number, final int decimals) {
		if (Double.isInfinite(number) || Double.isNaN(number)) {
			return BigDecimal.ZERO;
		} else {
			// return new BigDecimal(number, MathContext.DECIMAL64)
			return BigDecimal.valueOf(number).setScale(decimals, RoundingMode.HALF_UP);
		}
	}

	/**
	 * Convert the local date to its equivalent integer form YYYYMMDD.
	 *
	 * @param date
	 * @return int
	 */
	public static int toInteger(final LocalDate date) {
		return date.getYear() * 10_000 + date.getMonthValue() * 100 + date.getDayOfMonth();
	}

	/**
	 * Divide the given value by 100 to get a percentage.
	 *
	 * @param value
	 * @return
	 */
	public static BigDecimal toPercentage(final BigDecimal value) {
		return value.divide(HUNDRED);
	}

	/**
	 * Return the tenant code scheme. It is normally the tenant name without the
	 * branch name. Ex: for citi-hk it will be citi.
	 *
	 * @param tenant
	 * @return
	 */
	public static String getTenantCodeScheme(final String tenant) {
		String res = tenant;
		final int index = tenant.indexOf(API.TENANT_NAME_SEPARATOR);

		if (index != -1) {
			res = tenant.substring(0, index);
		}

		return res;
	}

	/**
	 * Produce a list of month end dates for the given period, inclusive.
	 *
	 * @param from
	 * @param until
	 * @return List&lt;LocalDate&gt;
	 */
	public static List<LocalDate> monthEndList(final LocalDate from, final LocalDate until) {
		final List<LocalDate> dates = new ArrayList<>();
		LocalDate d = from.withDayOfMonth(1);
		final LocalDate u = until.withDayOfMonth(1);
		while (!d.isAfter(u)) {
			dates.add(d.plusMonths(1).minusDays(1));
			d = d.plusMonths(1);
		}
		return dates;
	}

	/**
	 * Produce a list of weekly (Monday) dates for the given period, inclusive.
	 *
	 * @param from
	 * @param until
	 * @return List&lt;LocalDate&gt;
	 */
	public static List<LocalDate> weeklyList(final LocalDate from, final LocalDate until) {
		final List<LocalDate> dates = new ArrayList<>();
		LocalDate d = from.with(DayOfWeek.MONDAY);
		final LocalDate u = until.with(DayOfWeek.MONDAY);
		while (!d.isAfter(u)) {
			dates.add(d);
			d = d.plusWeeks(1);
		}
		return dates;
	}

	/**
	 * Produce a list of days for the given period, inclusive.
	 *
	 * @param from
	 * @param until
	 * @return List&lt;LocalDate&gt;
	 */
	public static List<LocalDate> dailyList(final LocalDate from, final LocalDate until) {
		final List<LocalDate> dates = new ArrayList<>();
		LocalDate d = from;
		final LocalDate u = until;
		while (!d.isAfter(u)) {
			dates.add(d);
			d = d.plusDays(1);
		}
		return dates;
	}

	/**
	 * Initialise the logging context. If this request is part of a chain then
	 * the request id in the HTTP header is continued, otherwise a new request
	 * id is created.
	 *
	 * @param tenant
	 * @param request
	 */
	public static void setMDC(final String tenant, final HttpServletRequest request) {
		MDC.put("tenant", tenant);
		final String req = request.getHeader(HeaderConstants.PRIVE_REQUEST);
		MDC.put(REQUEST, req == null ? new ObjectId().toString() : req);
	}

	/**
	 * Get MDC request id
	 *
	 * @return
	 */
	public static String getMDCRequestId() {
		return MDC.get(REQUEST);
	}

	/**
	 * Continue with the request id.
	 *
	 * @param headers
	 */
	public static void continuation(final HttpHeaders headers) {
		headers.set(HeaderConstants.PRIVE_REQUEST, MDC.get(REQUEST));
	}

	/**
	 * Continue with the request id and tenant context.
	 *
	 * @param headers
	 * @param tenantContext
	 */
	public static void continuation(final HttpHeaders headers, final TenantContext tenantContext) {
		headers.set(HeaderConstants.PRIVE_REQUEST, MDC.get(REQUEST));
		if (tenantContext != null && tenantContext.getServicesConfig() != null) {
			headers.set(HeaderConstants.PRIVE_TENANT_CONFIG, tenantContext.getServicesConfig().toString());
		}
	}

	private API() {
	}

	public static void setMDC(final String function, final Map<String, String> headers) {
		MDC.put("function", function);
		final String req = headers.get(HeaderConstants.PRIVE_REQUEST);
		MDC.put(REQUEST, req == null ? new ObjectId().toString() : req);
	}

	public static Map<String, String> getHeaders(final HttpServletRequest request) {

		final Map<String, String> map = new HashMap<>();

		final Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			final String key = headerNames.nextElement();
			final String value = request.getHeader(key);
			map.put(key, value);
		}

		return map;
	}

	/**
	 * Method to validate the input currency code aligns with the ISO 4217 code
	 * standards plus some non-standard currency such as CNH.
	 *
	 * @param currency
	 * @return true for proper currency code, false otherwise
	 */
	public static boolean validateCurrencyCode(final String currency) {
		try {
			return "CNH".equals(currency) || Currency.getInstance(currency) != null;
		} catch (final Exception e) {
			return false;
		}
	}

	/**
	 * Validate ISO 4217 currency pair such as EURUSD, HKDGBP...
	 *
	 * @param isoCurrencyPair
	 * @return
	 */
	public static boolean validateISOCurrencyPair(final String isoCurrencyPair) {
		boolean isValid = false;

		if (StringUtils.hasText(isoCurrencyPair) && isoCurrencyPair.length() == 6) {
			final String fromCurrency = isoCurrencyPair.toUpperCase().substring(0, 3);
			final String toCurrency = isoCurrencyPair.toUpperCase().substring(3, 6);

			if (!API.validateCurrencyCode(fromCurrency)) {
				API.logger.warn("Wrong currency {}", fromCurrency);
			} else if (!API.validateCurrencyCode(toCurrency)) {
				API.logger.warn("Wrong currency {}", toCurrency);
			} else {
				isValid = true;
			}

		} else {
			API.logger.warn("Wrong isoCurrencyPair {}", isoCurrencyPair);
		}

		return isValid;
	}

	/**
	 * Method to validate a field in a given json object
	 *
	 * @param json
	 * @param fieldName
	 * @throws Exception
	 */
	public static void validateJsonRequest(final JsonObject json, final String fieldName) throws Exception {
		if (!json.containsKey(fieldName)) {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * method to try to get int value from an json object for the given field
	 *
	 * @param inDocument
	 * @param inKey
	 * @return -1 if not found in our case since the value cannot be < 0
	 */
	public static String getStringValue(JsonObject inDocument, String inKey) {
		if (inDocument.containsKey(inKey) && inDocument.get(inKey).getValueType().equals(ValueType.STRING)) {
			return inDocument.getString(inKey);
		}
		throw new IllegalArgumentException("JSON String value not found with key: " + inKey);
	}

	/**
	 * method to try to get int value from an json object for the given field
	 *
	 * @param inDocument
	 * @param inKey
	 * @return -1 if not found in our case since the value cannot be < 0
	 */
	public static final int getIntValue(final JsonObject inDocument, final String inKey) {
		if (inDocument.containsKey(inKey) && inDocument.get(inKey).getValueType().equals(ValueType.NUMBER)) {
			return inDocument.getJsonNumber(inKey).intValue();
		}
		throw new IllegalArgumentException("JSON Integer value not found with key: " + inKey);
	}

	/**
	 * method to try to get double value from an json object for the given field
	 *
	 * @param inDocument
	 * @param inKey
	 * @return -1 if not found in our case since the value cannot be < 0
	 */
	public static final double getDoubleValue(final JsonObject inDocument, final String inKey) {
		if (inDocument.containsKey(inKey) && inDocument.get(inKey).getValueType().equals(ValueType.NUMBER)) {
			return inDocument.getJsonNumber(inKey).doubleValue();
		}
		throw new IllegalArgumentException("JSON Double value not found with key: " + inKey);
	}

	/**
	 * method to try to get array value from an json object for the given field
	 *
	 * @param inDocument
	 * @param inKey
	 * @return null if not found
	 */
	public static final JsonArray getJsonArray(final JsonObject inDocument, final String inKey) {
		if (inDocument.containsKey(inKey) && inDocument.get(inKey).getValueType().equals(ValueType.ARRAY)) {
			return inDocument.getJsonArray(inKey);
		}
		throw new IllegalArgumentException("JSON Array not found with key: " + inKey);
	}

	/**
	 * method to add a list of new string data to an existing JsonObject
	 *
	 * @param builder
	 * @param source
	 * @return JsonObjectBuilder
	 */
	public static JsonObjectBuilder addStringData(JsonObjectBuilder builder, JsonObject source,
			Map<String, String> newDataMap) {
		for (Map.Entry<String, String> entry : newDataMap.entrySet()) {
			builder.add(entry.getKey(), entry.getValue());
		}
		source.entrySet().forEach(e -> builder.add(e.getKey(), e.getValue()));
		return builder;
	}

	/**
	 * method to validate start and end dates and ensure from date is before
	 * until date and they are not the same
	 *
	 * @param inFrom
	 * @param inUntil
	 * @return null if not found
	 * @throws Exception
	 */
	public static final boolean validateDates(final String inFrom, final String inUntil) throws Exception {
		try {
			final LocalDate fromDate = LocalDate.parse(inFrom, STRING_TO_DATE);
			final LocalDate untilDate = LocalDate.parse(inUntil, STRING_TO_DATE);
			return untilDate.isAfter(fromDate) && !untilDate.equals(fromDate);
		} catch (Exception e) {
			throw new IllegalArgumentException(e);
		}
	}

}
