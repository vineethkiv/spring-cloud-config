package com.privemanagers.api.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;

/**
 * Util for zipping files
 *
 * @author Kay Ip
 * @date 6 Sep 2018
 * @company Prive Financial
 */
public class ZipFileUtil {

	private ZipFileUtil() {
		throw new IllegalStateException("Utility class");
	}

	/**
	 * Generate zip file ByteArrayOutputStream with files
	 *
	 * @param files
	 * @return
	 * @throws IOException
	 */
	public static ByteArrayOutputStream genZipFileStream(List<File> files) throws IOException {

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(byteArrayOutputStream);
				ZipOutputStream zipOutputStream = new ZipOutputStream(bufferedOutputStream)) {

			// packing files
			for (File file : files) {
				try (FileInputStream fileInputStream = new FileInputStream(file)) {
					/*
					 * new zip entry and copying inputstream with file to
					 * zipOutputStream, after all closing streams
					 */
					zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
					IOUtils.copy(fileInputStream, zipOutputStream);
					zipOutputStream.closeEntry();
				}
			}

			zipOutputStream.finish();
			zipOutputStream.flush();

		}

		return byteArrayOutputStream;
	}
}
