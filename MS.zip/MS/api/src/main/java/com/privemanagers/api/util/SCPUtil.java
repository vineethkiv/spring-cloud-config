package com.privemanagers.api.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;

/**
 * SCP Utils for connecting SFTP
 *
 * @author Ray Lee
 * @date 31 Aug 2018
 * @company Prive Financial
 */
public class SCPUtil implements AutoCloseable {
	private static final Logger logger = LoggerFactory.getLogger(SCPUtil.class);

	ChannelSftp sftpChannel;

	/**
	 * Connect to SFTP Server
	 *
	 * @param host
	 * @param port
	 * @param username
	 * @param password
	 * @throws JSchException
	 */
	public void connectSFTP(String host, int port, String username, String password) throws JSchException {
		JSch jsch = new JSch();

		try {
			Session session = jsch.getSession(username, host, port);
			UserInfo userInfo = new SCPUserInfo();

			session.setConfig("StrictHostKeyChecking", "no");
			session.setUserInfo(userInfo);
			session.setPassword(password);
			session.connect();

			sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();
		} catch (JSchException | RuntimeException e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			throw e;
		}
	}

	public void getFile(String remoteLocation, String localLocation) {
		if (sftpChannel != null) {
			try {
				File file = new File(localLocation);
				Files.createDirectories(file.toPath().getParent());
				Files.createFile(file.toPath());
				sftpChannel.get(remoteLocation, localLocation);
			} catch (SftpException | IOException e) {
				e.printStackTrace();
				logger.info(e.getMessage());
			}
		} else {
			throw new RuntimeException("not connected sftp channel!");
		}
	}

	public void disconnect() {
		if (sftpChannel != null) {
			sftpChannel.disconnect();
		}
	}

	/**
	 * Connect to SFTP Server
	 *
	 * @param host
	 * @param port
	 * @param username
	 * @param privateKeyPath
	 * @param privateKeyPassphase
	 * @throws JSchException
	 */
	public static void connectSFTP(String host, int port, String username, String privateKeyPath,
			String privateKeyPassphase) throws JSchException {
		JSch jsch = new JSch();

		try {
			if (privateKeyPath != null) {
				jsch.addIdentity(privateKeyPath, privateKeyPassphase);
			}
			Session session = jsch.getSession(username, host, port);
			UserInfo userInfo = new SCPUserInfo();

			session.setConfig("StrictHostKeyChecking", "no");
			session.setUserInfo(userInfo);
			session.connect();

			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();
		} catch (JSchException | RuntimeException e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			throw e;
		}
	}

	@Override
	public void close() throws Exception {
		disconnect();
	}
}
