package com.privemanagers.model.asset;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

/**
 * CFI Code related function
 *
 * @author Gavy Lau
 * @date 8 Feb 2019
 * @company Prive Financial
 */
public class CFICode {

	/** AssetType to CFI code mapping */
	private static final Map<AssetType, String> assetTypeCfiMap;
	static {
		final Map<AssetType, String> map = new EnumMap<>(AssetType.class);
		map.put(AssetType.TYPE_EQUITY, "E");
		map.put(AssetType.TYPE_ETF, "E");
		map.put(AssetType.TYPE_FUTURE, "FF");
		map.put(AssetType.TYPE_BOND, "DB");
		map.put(AssetType.TYPE_FXSPOT, "IF");
		map.put(AssetType.TYPE_COMMODITY, "MM");
		map.put(AssetType.TYPE_ECONOMIC_DATA, "TM");
		map.put(AssetType.TYPE_MUTUAL_FUNDS, "CI");
		map.put(AssetType.TYPE_STRUCTURED_PRODUCT, "DS");
		map.put(AssetType.TYPE_CLOSED_END_PRODUCT_PLACEHOLDER, "M");
		map.put(AssetType.TYPE_INDEX, "TI");
		map.put(AssetType.TYPE_WARRANT, "RW");
		map.put(AssetType.TYPE_CLOSED_END_GENERIC_PRODUCT, "M");
		map.put(AssetType.TYPE_MONEY_MARKET, "DY");
		map.put(AssetType.TYPE_FX_FORWARD, "JFR");
		map.put(AssetType.TYPE_ALTERNATIVE, "M");
		map.put(AssetType.TYPE_OPTION, "O");
		map.put(AssetType.TYPE_PROPERTY_AND_LAND, "MMR");
		map.put(AssetType.TYPE_AUV_FUND, "M");
		map.put(AssetType.TYPE_LOAN, "DMB");
		map.put(AssetType.TYPE_LOAN_CONTINGENT, "DM");
		map.put(AssetType.TYPE_CONVERTIBLE_BOND, "DC");
		map.put(AssetType.TYPE_PROMISSORY_NOTE, "DMP");
		map.put(AssetType.TYPE_FIXED_RATE, "TRF");
		map.put(AssetType.TYPE_CASH, "TCM");
		assetTypeCfiMap = Collections.unmodifiableMap(map);
	}

	/**
	 * Get CFI Code by the given {@link AssetType}
	 *
	 * @param type
	 * @return
	 */
	public static String getCodeByAssetType(AssetType type) {
		String prefix = assetTypeCfiMap.get(type);
		if (StringUtils.isBlank(prefix))
			throw new IllegalStateException("CFI Code cannot be determine by AssetType: " + type);
		return pad(prefix);
	}

	/**
	 * pad the given prefix with X so that the result is always 6 charater in
	 * length
	 *
	 * @param prefix
	 * @return
	 */
	private static String pad(final String prefix) {
		final int repeatX = 6 - prefix.length();
		final String code = prefix + StringUtils.repeat("X", repeatX);
		return code;
	}

}
