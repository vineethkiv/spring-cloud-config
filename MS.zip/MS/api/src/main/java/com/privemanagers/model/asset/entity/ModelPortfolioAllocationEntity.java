package com.privemanagers.model.asset.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Entity class for allocation in model portfolio
 * 
 * it reflects the DB structure, for request structure, check
 * MonolithChildAssetWithWeight
 *
 * @author Kay Ip
 * @date 14 Aug 2018
 * @company Prive Financial
 */
public class ModelPortfolioAllocationEntity {

	@JsonProperty("asset-id")
	private String assetId;

	private double weight;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}
}
