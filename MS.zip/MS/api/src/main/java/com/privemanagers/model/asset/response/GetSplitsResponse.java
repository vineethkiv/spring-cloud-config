package com.privemanagers.model.asset.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.model.asset.entity.SplitEntity;

/**
 * Response for get splits
 *
 * @author Kay Ip
 * @date 17 Aug 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetSplitsResponse {
	@JsonProperty("asset-id")
	private String assetId;
	private String currency;
	private List<SplitEntity> splits;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<SplitEntity> getSplits() {
		return splits;
	}

	public void setSplits(List<SplitEntity> splits) {
		this.splits = splits;
	}
}
