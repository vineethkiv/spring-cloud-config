package com.privemanagers.api.asset;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Util class for asset related function
 *
 * @author Gavy Lau
 * @date 7 Nov 2018
 * @company Prive Financial
 */
public class AssetUtil {

	/**
	 * Check the given String is a valid ISIN
	 *
	 * @param str
	 * @return
	 */
	public static boolean isIsin(String str) {

		if (str == null || str.trim().isEmpty()) {
			return false;
		}

		// use regular expression to check if the format is valid
		String regEx = "^([A-Z]{2})((?![A-Z]{10}\b)[A-Z0-9]{10})$";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(str);
		return m.find();
	}

}
