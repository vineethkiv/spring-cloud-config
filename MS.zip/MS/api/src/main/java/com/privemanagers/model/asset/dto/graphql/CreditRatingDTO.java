package com.privemanagers.model.asset.dto.graphql;

import io.leangen.graphql.annotations.GraphQLQuery;

/**
 * CreditRatingDTO, sub class for AssetDTO
 *
 * @author Kay Ip
 * @date 14 Feb 2019
 * @company Prive Financial
 */
public class CreditRatingDTO {

	@GraphQLQuery
	private String organization;
	@GraphQLQuery
	private String rating;

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}
}
