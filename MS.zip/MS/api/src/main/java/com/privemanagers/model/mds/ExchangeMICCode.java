package com.privemanagers.model.mds;

/**
 * Exchange MIC Code
 *
 * Operation MIC Reference
 * http://www.iotafinance.com/en/ISO-10383-Market-Identification-Codes-MIC.html
 *
 * @author Kay Ip
 * @date 2 May 2018
 * @company Prive Financial
 */
public enum ExchangeMICCode {
	/** Hong Kong Stock Exchange */
	XHKG,
	/** Singapore Stock Exchange */
	XSES,
	/** Shanghai Stock Exchange */
	XSHG,
	/** Shenzhen Stock Exchange */
	XSHE,
	/** NASDAQ Stock Exchange */
	XNAS,
	/** New York Stock Exchange */
	XNYS,;
}
