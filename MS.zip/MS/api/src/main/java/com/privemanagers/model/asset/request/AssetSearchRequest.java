package com.privemanagers.model.asset.request;

import java.util.Map;

import com.privemanagers.api.PageCriteria;
import com.privemanagers.model.mds.DataProvider;

/**
 * To indicate the asset search preference
 *
 * @author Kay Ip
 *
 */
public class AssetSearchRequest extends PageCriteria {

	private String keyword;

	private Map<String, String> name;

	private String currency;

	private String assetType;

	private String region;

	private String assetClass;

	private String sector;

	private Boolean mirrorFund;

	/** @see DataProvider */
	private String dataSource;

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getAssetClass() {
		return assetClass;
	}

	public void setAssetClass(String assetClass) {
		this.assetClass = assetClass;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public Map<String, String> getName() {
		return name;
	}

	public void setName(Map<String, String> name) {
		this.name = name;
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public Boolean getMirrorFund() {
		return mirrorFund;
	}

	public void setMirrorFund(Boolean mirrorFund) {
		this.mirrorFund = mirrorFund;
	}
}
