package com.privemanagers.model.common;

/**
 * Time Frequency
 *
 * @author Gavy Lau
 * @date 15 Nov 2018
 * @company Prive Financial
 */
public enum Frequency {

	DAILY,
	WEEKLY,
	MONTHLY;

}
