package com.privemanagers.api.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.converter.AbstractGenericHttpMessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.privemanagers.api.API;
import com.privemanagers.api.TenantContext;

/**
 * Helper class for making REST connection/call
 *
 * @author Gavy Lau
 */
public class RestHelper {

	private static final Logger logger = LoggerFactory.getLogger(RestHelper.class);

	/**
	 * constructs an URI object with one path variable
	 *
	 * @param uriString
	 * @param endpoint
	 * @param tenant
	 * @return URI
	 */
	private static final URI constructUri(final String uriString, final String endpoint, final String tenant) {
		return UriComponentsBuilder.fromUriString(uriString).path(endpoint).buildAndExpand(tenant).encode().toUri();
	}

	/**
	 * check if a request body is required for the specific http method
	 *
	 * @param httpMethod
	 * @return boolean
	 */
	private static boolean shouldIncludeRequestBody(final HttpMethod httpMethod) {
		return httpMethod.equals(HttpMethod.POST) || httpMethod.equals(HttpMethod.PUT)
				|| httpMethod.equals(HttpMethod.PATCH);
	}

	/**
	 * prepares HttpHeader for a rest request
	 *
	 * @param headerMap
	 * @param tenantContext
	 * @param continuation
	 * @return HttpHeaders
	 */
	private static HttpHeaders prepareHeaders(final Map<String, String> headerMap, final TenantContext tenantContext,
			final boolean continuation) {

		final HttpHeaders headers = new HttpHeaders();
		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			headers.set(entry.getKey(), entry.getValue());
		}

		if (continuation) {
			if (tenantContext != null) {
				API.continuation(headers, tenantContext);
			} else {
				API.continuation(headers);
			}
		}

		return headers;

	}

	/**
	 * prepares Http String request
	 *
	 * @param httpMethod
	 * @param headers
	 * @param body
	 * @return HttpEntity<String>
	 */
	private static HttpEntity<String> prepareRequest(final HttpMethod httpMethod, final HttpHeaders headers,
			final String body) {
		HttpEntity<String> request;
		if (shouldIncludeRequestBody(httpMethod)) {
			request = new HttpEntity<>(body, headers);
		} else {
			request = new HttpEntity<>(headers);
		}
		return request;
	}

	/**
	 * prepares Http Object request
	 *
	 * @param httpMethod
	 * @param headers
	 * @param body
	 * @return HttpEntity<String>
	 */
	private static HttpEntity<Object> prepareRequest2(final HttpMethod httpMethod, final HttpHeaders headers,
			final Object body) {
		HttpEntity<Object> request;
		if (shouldIncludeRequestBody(httpMethod)) {
			request = new HttpEntity<>(body, headers);
		} else {
			request = new HttpEntity<>(headers);
		}
		return request;
	}

	/**
	 * creates a header map which will be used to create HttpHeaders add more
	 * params in the future to include more values
	 *
	 * @param inAccessToken
	 * @return Map<String, String>
	 */
	private static Map<String, String> createHeadersMap(final String inAccessToken) {
		Map<String, String> headersMap = new HashMap<>();
		if (inAccessToken != null) {
			headersMap.put(HttpHeaders.AUTHORIZATION, "Bearer " + inAccessToken);
		}
		headersMap.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8.toString());

		return headersMap;
	}

	/**
	 * makes async restful call using the given executor
	 *
	 * @param executor
	 * @param uri
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param inAccessToken
	 * @param tenantContext
	 * @param continuation
	 * @return ListenableFuture<ResponseEntity<String>>
	 */
	public static ListenableFuture<ResponseEntity<String>> sendRequest(final ThreadPoolTaskExecutor executor,
			final URI uri, final String tenant, final String body, final HttpMethod httpMethod,
			final String inAccessToken, final TenantContext tenantContext, final boolean continuation) {

		final AsyncRestTemplate rest = new AsyncRestTemplate(executor);

		final HttpHeaders headers = prepareHeaders(createHeadersMap(inAccessToken), tenantContext, continuation);

		return rest.exchange(uri, httpMethod, prepareRequest(httpMethod, headers, body), String.class);

	}

	/**
	 *
	 * sends a rest request based on the input
	 *
	 * @param uri
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param inAccessToken
	 * @param tenantContext
	 * @param continuation
	 * @return ResponseEntity<Object>
	 */
	public static ResponseEntity<Object> sendRequest2(final URI uri, final String tenant, final Object body,
			final HttpMethod httpMethod, final String inAccessToken, final TenantContext tenantContext,
			final boolean continuation) {
		ResponseEntity<Object> res = null;

		final RestTemplate rest = new RestTemplate();

		final HttpHeaders headers = prepareHeaders(createHeadersMap(inAccessToken), tenantContext, continuation);
		try {
			final ResponseEntity<Object> response = rest.exchange(uri, httpMethod,
					prepareRequest2(httpMethod, headers, body), Object.class);
			if (response.getStatusCode().is2xxSuccessful()) {
				res = response;
			} else {
				logger.error(
						"Error occured when sending {} request for tenant {}.\nHTTP status code={}.\nResponse body={}.\nRequest body={}",
						uri, tenant, response.getStatusCode(), response.getBody(), body);
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody().toString());
			}
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			logger.error("throwing httpException for further handling. Msg: {}  URL: {} ", httpException.getMessage(),
					uri);
			throw httpException;
		} catch (final Exception e) {
			logger.error("throwing Exception for further handling. Msg: {}  URL: {} ", e.getMessage(), uri);
			logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			throw e;
		}

		return res;
	}

	/**
	 *
	 * sends a rest request based on the input
	 *
	 * @param uri
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param inAccessToken
	 * @param tenantContext
	 * @param continuation
	 * @return ResponseEntity<String>
	 */
	public static ResponseEntity<String> sendRequest(final URI uri, final String tenant, final String body,
			final HttpMethod httpMethod, final String inAccessToken, final TenantContext tenantContext,
			final boolean continuation) {
		ResponseEntity<String> res = null;

		final RestTemplate rest = new RestTemplate();

		final HttpHeaders headers = prepareHeaders(createHeadersMap(inAccessToken), tenantContext, continuation);
		try {
			final ResponseEntity<String> response = rest.exchange(uri, httpMethod,
					prepareRequest(httpMethod, headers, body), String.class);
			if (response.getStatusCode().is2xxSuccessful()) {
				res = response;
			} else {
				logger.error(
						"Error occured when sending {} request for tenant {}.\nHTTP status code={}.\nResponse body={}.\nRequest body={}",
						uri, tenant, response.getStatusCode(), response.getBody(), body);
				throw new HttpClientErrorException(response.getStatusCode(), response.getBody());
			}
		} catch (final HttpClientErrorException | HttpServerErrorException httpException) {
			logger.error("throwing httpException for further handling. Msg: {}  URL: {} ", httpException.getMessage(),
					uri);
			throw httpException;
		} catch (final Exception e) {
			logger.error("throwing Exception for further handling. Msg: {}  URL: {} ", e.getMessage(), uri);
			logger.error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), e);
			throw e;
		}

		return res;
	}

	/**
	 *
	 * sends a rest request based on the input
	 *
	 * @param uriString
	 * @param endpoint
	 * @param tenant
	 * @param body
	 * @param httpMethod
	 * @param inAccessToken
	 * @param tenantContext
	 * @param continuation
	 * @return ResponseEntity<String>
	 */
	public static ResponseEntity<String> sendRequest(final String uriString, final String endpoint, final String tenant,
			final String body, final HttpMethod httpMethod, final String inAccessToken,
			final TenantContext tenantContext, final boolean continuation) {

		return sendRequest(constructUri(uriString, endpoint, tenant), tenant, body, httpMethod, inAccessToken,
				tenantContext, continuation);

	}

	/**
	 * @param extractHeaderToken
	 * @return
	 */
	public static RestTemplate requestWithToken(String inAccessToken) {

		final RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new JSONMessageConverter());
		restTemplate.getInterceptors().add(new AddAssetTokenToRequests(inAccessToken));
		return restTemplate;
	}

	private static final class AddAssetTokenToRequests implements ClientHttpRequestInterceptor {
		/** */
		private final String inAccessToken;

		/**
		 * @param inAccessToken
		 */
		private AddAssetTokenToRequests(String inAccessToken) {
			this.inAccessToken = inAccessToken;
		}

		@Override
		public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
				throws IOException {
			for (Map.Entry<String, String> entry : createHeadersMap(inAccessToken).entrySet()) {
				request.getHeaders().set(entry.getKey(), entry.getValue());
			}
			return execution.execute(request, body);
		}
	}

	private static class JSONMessageConverter extends AbstractGenericHttpMessageConverter<JsonObject> {

		public JSONMessageConverter() {
			super(MediaType.APPLICATION_JSON);
		}

		@Override
		public JsonObject read(Type type, Class<?> contextClass, HttpInputMessage inputMessage) throws IOException {
			return readInternal(null, inputMessage);
		}

		@Override
		protected void writeInternal(JsonObject t, Type type, HttpOutputMessage outputMessage) throws IOException {

			try (final JsonWriter writer = Json.createWriter(outputMessage.getBody())) {
				writer.write(t);
			}
		}

		@Override
		protected JsonObject readInternal(Class<? extends JsonObject> clazz, HttpInputMessage inputMessage)
				throws IOException {

			try (final JsonReader reader = Json.createReader(inputMessage.getBody())) {

				return reader.readObject();

			} catch (final Exception e) {
				return null;
			}
		}
	}
}
