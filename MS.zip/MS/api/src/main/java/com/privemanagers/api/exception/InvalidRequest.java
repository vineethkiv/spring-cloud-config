package com.privemanagers.api.exception;

/**
 * @author Vineeth Kiv
 * @date : 11 Sep, 2017
 * @company Prive Financial
 */
public class InvalidRequest extends Exception {

	private static final long serialVersionUID = 433934964938923231L;

	public InvalidRequest(final String message) {
		super(message);

	}

}
