package com.privemanagers.api.util;

import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import com.privemanagers.system.Server;

/**
 * Util to call Cronhub - an cron job monitoring tools
 *
 * @author Gavy Lau
 * @date 20 Sep 2018
 * @company Prive Financial
 */
public class CronhubUtil {

	private static final String URL_PING_START = "https://cronhub.io/start/";

	private static final String URL_PING_FINISH = "https://cronhub.io/finish/";

	/**
	 * Ping Cronhub to indicate a Job has started
	 *
	 * @param job
	 */
	public static void pingJobStart(CronhubJob job) {

		if (!Server.PRODUCTION)
			return;

		try {
			final String urlStr = URL_PING_START + job.uuid();
			URL url = new URL(urlStr);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			con.setRequestProperty("User-Agent", "");
			con.setRequestMethod("GET");
			con.getResponseCode();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Ping Cronhub to indicate a Job has finished
	 *
	 * @param job
	 */
	public static void pingJobFinish(CronhubJob job) {

		if (!Server.PRODUCTION)
			return;

		try {
			final String urlStr = URL_PING_FINISH + job.uuid();
			URL url = new URL(urlStr);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			con.setRequestProperty("User-Agent", "");
			con.setRequestMethod("GET");
			con.getResponseCode();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		pingJobStart(CronhubJob.XASSET_MP_FX_SYNC);
	}

}
