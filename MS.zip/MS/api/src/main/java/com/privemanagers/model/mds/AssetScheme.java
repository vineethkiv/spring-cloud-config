package com.privemanagers.model.mds;

/**
 * Available scheme in asset DB
 *
 * @author Gavy Lau
 * @date 9 May 2018
 * @company Prive Financial
 */
public enum AssetScheme {

	/** China Securities Depository and Clearing Corporation */
	CSDCC("CSDCC"),
	/** CUSIP */
	CUSIP("CUSIP"),
	/** FX. Applicable for FX only */
	FX("FX"),
	/** ISIN */
	ISIN("ISIN"),
	/** Morningstar Performance ID */
	MS_PERFORMANCE_ID("MS-PERFORMANCE-ID"),
	/** SEDOL */
	SEDOL("SEDOL"),
	/** SYMBOL - this is normally tickerCode.MICCode */
	SYMBOL("SYMBOL"),
	/** RIC code - use by TR **/
	RIC("RIC"),
	/** Sysjust id */
	SYSJUST_ID("SYSJUST-ID"),
	/** Thai Fund Code (Morningstar) */
	THAI_FUND_CODE("THAI-FUND-CODE"),
	/** Bloomberg id */
	BLOOMBERG_ID("BLOOMBERG-ID"),
	/** prive private ID */
	PRIVE("prive");

	private String name;

	private AssetScheme(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return this.name;
	}

}
