package com.privemanagers.model.prive.request;

import com.privemanagers.model.common.entity.TenantServicesConfig;

/**
 * request to update tenant services config by primary code
 *
 * @author Matthew WONG
 * @date 20 Nov 2018
 * @company Prive Financial
 */
public class UpdateTenantServicesConfigRequest {

	private TenantServicesConfig servicesConfig;

	public TenantServicesConfig getServicesConfig() {
		return servicesConfig;
	}

	public void setServicesConfig(TenantServicesConfig servicesConfig) {
		this.servicesConfig = servicesConfig;
	}
}
