package com.privemanagers.api.util;

/**
 * AWS CloudWatch Metric metric name mapping
 *
 * @author Kay Ip
 * @date 10 Dec 2018
 * @company Prive Financial
 */
public enum AWSCloudWatchMetricName {

	// mds related metric name
	MDS_MASTER("masterData"),
	MDS_HISTORICAL("historical");

	private final String metricName;

	private AWSCloudWatchMetricName(final String metricName) {
		this.metricName = metricName;
	}

	public String getMetricName() {
		return metricName;
	}

}
