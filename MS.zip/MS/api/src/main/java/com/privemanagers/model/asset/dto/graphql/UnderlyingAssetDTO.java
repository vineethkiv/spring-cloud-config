package com.privemanagers.model.asset.dto.graphql;

import io.leangen.graphql.annotations.GraphQLQuery;

/**
 * Underlying asset for AssetDTO
 *
 * @author Kay Ip
 * @date 14 Feb 2019
 * @company Prive Financial
 */
public class UnderlyingAssetDTO {

	@GraphQLQuery
	private String assetId;

	@GraphQLQuery
	private Double weight;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}
}
