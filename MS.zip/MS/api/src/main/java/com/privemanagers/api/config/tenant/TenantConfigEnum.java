package com.privemanagers.api.config.tenant;

/**
 * Config keys to be used for Tenant service_config
 *
 * @author Kay Ip
 * @date 13 Mar 2018
 * @company Prive Financial
 */
public enum TenantConfigEnum {
	DATA_SOURCE_PRIORITY("data-source-priority"), //
	ENABLE_VIRTUAL_MIRROR_FUND("enable-virtual-mirror-fund"), //
	CUSTOM_REBALANCE("custom-rebalance"), //
	REBALANCE_EVERY("rebalance-every"), //
	SHOW_MISSING_ASSETS_INSTEAD_OF_EXCEPTION("show-missing-assets"), //
	MAP_MIC_CODE("map-mic-code"), //
	MAP_CURRENCY("map-currency"), //
	VFUND_CATEGORY("vfund-category"),
	GENERATIONS("generations"),
	INITIAL_POPULATION("initial-population"),
	SURVIVORS("survivors"),
	OFFSPRINGS("offsprings"),
	MUTATION_RATE("mutation-rate"),
	REBALANCE_INTERVAL("rebalance-interval"),
	DECIMALS("decimals"),
	TYPE("type"),
	FITNESS("fitness"),
	CONSTRAINTS("constraints"),
	MODEL_TIER("model-tier"),
	REBALANCER_PROPOSED_TRANSACTIONS("rebalancer-proposed-transactions"); //

	private String dbFieldName;

	TenantConfigEnum(final String dbFieldName) {
		this.dbFieldName = dbFieldName;
	}

	public String getDbFieldName() {
		return dbFieldName;
	}

}
