package com.privemanagers.api.util;

import javax.json.Json;
import javax.json.JsonObjectBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.privemanagers.model.common.slack.SlackMessage;

/**
 * @author Gavy Lau
 * @date 6 Nov 2017
 * @company Prive Financial
 */
@Component
public class SlackUtil {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ObjectMapper objectMapper;

	public enum Channel {
		MULTI_ASSET_ALERT("https://hooks.slack.com/services/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"),
		OPS_ALERT("https://hooks.slack.com/services/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"),
		RECON_BREAK("https://hooks.slack.com/services/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"),
		ORDER_ALERT("https://hooks.slack.com/services/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");

		private String webHook;

		Channel(String webHook) {
			this.webHook = webHook;
		}

		public String getWebHook() {
			return webHook;
		}
	}

	/**
	 * Post a simple message to a slack channel
	 *
	 * @param channel
	 * @param message
	 */
	public void postMessage(Channel channel, String message) {

		// if (!SettingsProductionServer.PRODUCTION)
		// return;

		JsonObjectBuilder builder = Json.createObjectBuilder();
		builder.add("text", message);

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> requestEntity = new HttpEntity<>(builder.build().toString(), headers);
		restTemplate.postForEntity(channel.getWebHook(), requestEntity, String.class);
	}

	/**
	 * Let program sends dynamic webhook link depends on env
	 *
	 * @param webhook
	 * @param message
	 */
	public void postMessage(String webhook, String message) {
		JsonObjectBuilder builder = Json.createObjectBuilder();
		builder.add("text", message);

		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> requestEntity = new HttpEntity<>(builder.build().toString(), headers);
		restTemplate.postForEntity(webhook, requestEntity, String.class);
	}

	/**
	 * Post a more complex json to slack
	 *
	 * https://api.slack.com/docs/message-attachments
	 *
	 * @param webhook
	 * @param richMessageJson
	 */
	public void postRichMessage(String webhook, String richMessageJson) {
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> requestEntity = new HttpEntity<>(richMessageJson, headers);
		restTemplate.postForEntity(webhook, requestEntity, String.class);
	}

	/**
	 * Send {@link SlackMessage} to slack webhook
	 *
	 * @param channel
	 * @param slackMessage
	 */
	public void postSlackMessage(final Channel channel, final SlackMessage slackMessage) {
		postSlackMessage(channel.getWebHook(), slackMessage);
	}

	/**
	 * Send {@link SlackMessage} to slack webhook
	 *
	 * @param webhook
	 * @param slackMessage
	 */
	public void postSlackMessage(final String webhook, final SlackMessage slackMessage) {
		try {
			String messageJson = objectMapper.writeValueAsString(slackMessage);
			postRichMessage(webhook, messageJson);
		} catch (JsonProcessingException e) {
			logger.error("Fail to parse message to slack", e);
		}
	}

}
