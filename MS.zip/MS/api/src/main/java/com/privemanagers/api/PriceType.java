package com.privemanagers.api;

/**
 * Frequency of a Price series of Asset
 *
 * @author nteck
 * @date 1 Sep 2017
 * @company Prive Financial
 */
public enum PriceType {

	MONTHLY,
	DAILY;

	public static final String FIELD = "type";

	public static PriceType parseType(String type) {
		if (type == null)
			return null;

		if (type.equalsIgnoreCase("DAILY"))
			return PriceType.DAILY;
		else if (type.equalsIgnoreCase("MONTHLY"))
			return PriceType.MONTHLY;
		else
			return null;
	}

}
