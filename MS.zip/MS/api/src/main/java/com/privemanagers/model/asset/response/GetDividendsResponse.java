package com.privemanagers.model.asset.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.privemanagers.model.asset.entity.DividendEntity;

/**
 * Response for get dividends
 *
 * @author Kay Ip
 * @date 17 Aug 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetDividendsResponse {
	@JsonProperty("asset-id")
	private String assetId;
	private String currency;
	private List<DividendEntity> dividends;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<DividendEntity> getDividends() {
		return dividends;
	}

	public void setDividends(List<DividendEntity> dividends) {
		this.dividends = dividends;
	}
}
