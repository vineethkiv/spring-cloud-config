package com.privemanagers.model.quant.response;

/**
 * sensitivity analysis field values used in dual series response for b2b and
 * quant
 *
 * @author wzhang
 * @date 31 Oct 2018
 * @company Prive Financial
 */
public class ShiftValue {

	private Double value;
	private Double change;
	private Double percentageChange;

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public Double getChange() {
		return change;
	}

	public void setChange(Double change) {
		this.change = change;
	}

	public Double getPercentageChange() {
		return percentageChange;
	}

	public void setPercentageChange(Double percentageChange) {
		this.percentageChange = percentageChange;
	}
}
