package com.privemanagers.model.mds.rawData;

/**
 * dividend POJO for update request
 *
 * Dividend specific fields here
 *
 * @author Kay Ip
 * @date 4 July 2018
 * @company Prive Financial
 */
public class AssetDividendSeries extends RawSeriesData {
}
