package com.privemanagers.api;

import org.springframework.data.domain.Sort.Direction;

/**
 * To indicate the sorting preference, sort by which field and direction
 *
 * @author Kay Ip
 *
 */
public class SortCriteria {
	private String sortBy;
	private Direction sortDirection;

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public Direction getSortDirection() {
		return sortDirection;
	}

	public void setSortDirection(Direction sortDirection) {
		this.sortDirection = sortDirection;
	}

}
