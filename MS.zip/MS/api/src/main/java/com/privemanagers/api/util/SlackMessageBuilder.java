package com.privemanagers.api.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import com.privemanagers.model.common.slack.AttachmentField;
import com.privemanagers.model.common.slack.SlackAlertLevel;
import com.privemanagers.model.common.slack.SlackAttachment;
import com.privemanagers.model.common.slack.SlackMessage;

/**
 * Builder for {@link SlackMessage}
 *
 * @author Gavy Lau
 * @date 26 Nov 2018
 * @company Prive Financial
 */
public class SlackMessageBuilder {

	/**
	 * Build slack message pojo with attachment only
	 *
	 * @param title
	 * @param alertLevel
	 * @param attachmentFields
	 * @return
	 */
	public static SlackMessage build(String title, SlackAlertLevel alertLevel, List<AttachmentField> attachmentFields) {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		SlackAttachment slackAttachment = new SlackAttachment();
		slackAttachment.setFields(attachmentFields);
		slackAttachment.setTitle(title);
		slackAttachment.setFooter("Server Date time: " + now.format(formatter));
		slackAttachment.setColor(alertLevel.getSlackMessageColor());

		SlackMessage slackMessage = new SlackMessage();
		slackMessage.setAttachments(Arrays.asList(slackAttachment));
		return slackMessage;
	}

}
