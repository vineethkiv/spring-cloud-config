package com.privemanagers.model.common.slack;

/**
 * Slack attachment color, let the alert message has different color depending
 * on alert level
 *
 * https://api.slack.com/docs/message-attachments #color section
 *
 * @author Kay Ip
 * @date 14 Sep 2018
 * @company Prive Financial
 */
public enum SlackAlertLevel {
	ERROR("danger"),
	WARN("warning"),
	INFO("good");

	private String slackMessageColor;

	private SlackAlertLevel(String slackMessageColor) {
		this.slackMessageColor = slackMessageColor;
	}

	public String getSlackMessageColor() {
		return slackMessageColor;
	}

	public void setSlackMessageColor(String slackMessageColor) {
		this.slackMessageColor = slackMessageColor;
	}
}
