package com.privemanagers.model.mds.request;

import java.util.List;

import com.privemanagers.model.mds.rawData.AssetSplitSeries;

/**
 * update request for split
 *
 * @author Kay Ip
 * @date 11 July 2018
 * @company Prive Financial
 */
public class SplitUpdateRequest extends RawDataUpdateRequest {

	private List<AssetSplitSeries> assetSplitSeriesList;

	public List<AssetSplitSeries> getAssetSplitSeriesList() {
		return assetSplitSeriesList;
	}

	public void setAssetSplitSeriesList(List<AssetSplitSeries> assetSplitSeriesList) {
		this.assetSplitSeriesList = assetSplitSeriesList;
	}

}
