package com.privemanagers.api.config.tenant;

/**
 * Service keys to be used for Tenant service_config
 *
 * @author Kay Ip
 * @date 13 Mar 2018
 * @company Prive Financial
 */
public enum TenantServiceEnum {
	B2B("b2b"), //
	QUANT("quant"), //
	OPT("opt");
	private String dbFieldName;

	TenantServiceEnum(final String dbFieldName) {
		this.dbFieldName = dbFieldName;
	}

	public String getDbFieldName() {
		return dbFieldName;
	}

}
