package com.privemanagers.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

/**
 * Extension to {@link HttpClientErrorException} to include more information
 *
 * @author Gavy Lau
 * @date 27 Nov 2018
 * @company Prive Financial
 */
public class PriveHttpClientErrorException extends HttpClientErrorException {

	/** */
	private static final long serialVersionUID = 4559051502627502503L;

	private final String url;

	private final String requestBody;

	/**
	 * @param statusCode
	 */
	public PriveHttpClientErrorException(final HttpStatus statusCode, final String url, final String requestBody) {
		super(statusCode);
		this.url = url;
		this.requestBody = requestBody;
	}

	public String getUrl() {
		return url;
	}

	public String getRequestBody() {
		return requestBody;
	}

}
