package com.privemanagers.api;

/**
 * @author nteck
 * @date 2 Nov 2017
 * @company Prive Financial
 */
public enum ValueCurrencyType {

	ASSET,
	REFERENCE;

	public static final String FIELD = "value-currency";

	public static ValueCurrencyType parseType(String type) {
		if (type == null)
			return null;

		if (type.equalsIgnoreCase("ASSET"))
			return ValueCurrencyType.ASSET;
		else if (type.equalsIgnoreCase("REFERENCE"))
			return ValueCurrencyType.REFERENCE;
		else
			return null;
	}

}
