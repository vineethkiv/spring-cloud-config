package com.privemanagers.api.util;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mixpanel.mixpanelapi.ClientDelivery;
import com.mixpanel.mixpanelapi.MessageBuilder;
import com.mixpanel.mixpanelapi.MixpanelAPI;
import com.privemanagers.api.config.ApiConfig;

/**
 * To call Mixpanel
 *
 * @author Kay Ip
 * @date 17 Jan 2018
 * @company Prive Financial
 */
@Component
public class MixpanelUtil {
	private static final Logger logger = LoggerFactory.getLogger(MixpanelUtil.class);

	@Autowired
	private ApiConfig apiConfig;

	/**
	 * deliver message to track an event
	 *
	 * @param distinctId
	 * @param eventName
	 * @param jsonString
	 */
	public void trackEvent(String distinctId, String eventName, String jsonString) {
		MessageBuilder messageBuilder = new MessageBuilder(apiConfig.getMixpanelToken());

		JSONObject props = null;
		try {
			props = new JSONObject(jsonString);
			props.put("tenant", distinctId); // to track event per tenant

		} catch (JSONException ex) {
			logger.warn("input request is not a valid json, do not send request to mixpanel");
			return;
		}

		JSONObject event = messageBuilder.event(distinctId, eventName, props);

		ClientDelivery delivery = new ClientDelivery();
		delivery.addMessage(event);

		MixpanelAPI mixpanel = new MixpanelAPI();
		try {
			mixpanel.deliver(delivery);
			logger.debug("mixpanel event sent");
		} catch (IOException e) {
			logger.error("failed to send message to mixpanel", e);
		}
	}
}
