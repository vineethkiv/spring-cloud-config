package com.privemanagers.model.mds.rawData;

/**
 * price POJO for update request
 *
 * price specific fields here
 *
 * @author Kay Ip
 * @date 4 July 2018
 * @company Prive Financial
 */
public class AssetPriceSeries extends RawSeriesData {

	/*- 
	 * Sample JSON serialization:
		{
		  "prive": "Ticker:210567",
		  "assetId": null,
		  "primaryCode": {
		    "scheme": "RIC",
		    "value": "CNP10248"
		  },
		  "timeSeries": [
		    {
		      "date": "20181109",
		      "value": 279.2
		    }
		  ]
		}
	 */

	// Ticker key synced to MS from Monolith (e.g. Ticker:210567)
	private String prive;

	public void setPrive(String prive) {
		this.prive = prive;
	}

	public String getPrive() {
		return prive;
	}
}
