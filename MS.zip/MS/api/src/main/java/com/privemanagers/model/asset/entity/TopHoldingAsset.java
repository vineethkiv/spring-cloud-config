package com.privemanagers.model.asset.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * TopHoldingAsset, sub class for Asset
 *
 * @author Kay Ip
 * @date 26 Oct 2018
 * @company Prive Financial
 */
public class TopHoldingAsset {
	private String name;
	private Double weight;
	private String currency;
	@JsonProperty("ISIN")
	private String isin;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getIsin() {
		return isin;
	}

	public void setIsin(String isin) {
		this.isin = isin;
	}
}
