package com.privemanagers.model.mds.request;

import java.util.List;

import com.privemanagers.model.mds.rawData.AssetDividendSeries;

/**
 * update request for dividend
 *
 * @author Kay Ip
 * @date 11 July 2018
 * @company Prive Financial
 */
public class DividendUpdateRequest extends RawDataUpdateRequest {

	private List<AssetDividendSeries> assetDividendSeriesList;

	public List<AssetDividendSeries> getAssetDividendSeriesList() {
		return assetDividendSeriesList;
	}

	public void setAssetDividendSeriesList(List<AssetDividendSeries> assetDividendSeriesList) {
		this.assetDividendSeriesList = assetDividendSeriesList;
	}

}
