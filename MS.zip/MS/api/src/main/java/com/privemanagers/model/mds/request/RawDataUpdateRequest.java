package com.privemanagers.model.mds.request;

/**
 * base request for raw data update
 *
 * @author Kay Ip
 * @date 11 July 2018
 * @company Prive Financial
 */
public abstract class RawDataUpdateRequest {
	private String dataSource;

	// the update source, mds or manually, or fubon?
	// TODO enum?
	private String source;

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
}
