package com.privemanagers.model.common.entity;

import java.util.Map;

/**
 * Entity for tenant services_config
 *
 * @author Kay Ip
 * @date 1 Nov 2018
 * @company Prive Financial
 */
public class TenantServicesConfig {

	private Map<String, Object> assets;
	private Map<String, Object> b2b;
	private Map<String, Object> quant;
	private Map<String, Object> portfolio;
	private Map<String, Object> opt;

	public Map<String, Object> getAssets() {
		return assets;
	}

	public void setAssets(Map<String, Object> assets) {
		this.assets = assets;
	}

	public Map<String, Object> getB2b() {
		return b2b;
	}

	public void setB2b(Map<String, Object> b2b) {
		this.b2b = b2b;
	}

	public Map<String, Object> getQuant() {
		return quant;
	}

	public void setQuant(Map<String, Object> quant) {
		this.quant = quant;
	}

	public Map<String, Object> getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Map<String, Object> portfolio) {
		this.portfolio = portfolio;
	}

	public Map<String, Object> getOpt() {
		return opt;
	}

	public void setOpt(Map<String, Object> opt) {
		this.opt = opt;
	}
}
