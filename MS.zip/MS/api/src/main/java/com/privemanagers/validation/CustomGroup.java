package com.privemanagers.validation;

/**
 * Interface marker to be use by Custom Validator
 *
 * @author Gavy Lau
 * @date 2 Nov 2018
 * @company Prive Financial
 */
public interface CustomGroup {

}
