package com.privemanagers.api.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloudwatch.AmazonCloudWatch;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchClientBuilder;
import com.amazonaws.services.cloudwatch.model.Dimension;
import com.amazonaws.services.cloudwatch.model.MetricDatum;
import com.amazonaws.services.cloudwatch.model.PutMetricDataRequest;
import com.amazonaws.services.cloudwatch.model.StandardUnit;
import com.privemanagers.system.Server;

/**
 * Util to create and send information to AWS cloudWatch
 *
 * @author Kay Ip
 * @date 5 Dec 2018
 * @company Prive Financial
 */
@Component
public class AWSCloudWatchUtil {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${aws.key.access:missing-aws.key.access}")
	private String accessKey;

	@Value("${aws.key.secret:missing-aws.key.secret}")
	private String secretKey;

	@Value("${deployment.cloud:missing-deployment.cloud}")
	private String deploymentCloud;

	// this value should come from the microservice that using this util
	@Value("${prive.resource.id:missing-prive.resource.id}")
	private String resourceId;

	private static final Region REGION = Region.getRegion(Regions.AP_SOUTHEAST_1);

	private AmazonCloudWatch cloudWatchClient = null;

	@PostConstruct
	private void init() {
		if (!Server.PRODUCTION) {
			return;
		}
		if (StringUtils.isEmpty(accessKey) || accessKey.contains("missing") || StringUtils.isEmpty(secretKey)
				|| secretKey.contains("missing")) {
			logger.debug("AWSCloudWatchUtil, missing config for aws keys");
			return;
		}

		cloudWatchClient = getAwsCloudWatchClient();
		logger.info("AWSCloudWatchUtil initialized");
	}

	/**
	 * Build and push metric
	 * 
	 * @param namespace
	 * @param metricName
	 * @param value
	 */
	public void pushMetricToAWSCloudWatch(final AWSCloudWatchMetricNamespace namespace,
			final AWSCloudWatchMetricName metricName, final double value) {
		if (cloudWatchClient == null || namespace == null || metricName == null) {
			return;
		}

		PutMetricDataRequest request = buildMetricDataRequest(namespace, metricName, value);
		cloudWatchClient.putMetricData(request);
		logger.debug("AWSCloudWatchUtil, pushed PutMetricDataRequest to cloudWatch");
	}

	/**
	 * Build PutMetricDataRequest
	 * 
	 * @param metricName
	 * @param value
	 * @return
	 */
	private PutMetricDataRequest buildMetricDataRequest(final AWSCloudWatchMetricNamespace namespace,
			final AWSCloudWatchMetricName metricName, final double value) {

		Collection<Dimension> dimensions = new ArrayList<>();
		Dimension dimensionCloud = new Dimension();
		dimensionCloud.setName("cloud");
		dimensionCloud.setValue(deploymentCloud);
		dimensions.add(dimensionCloud);

		Dimension dimensionApp = new Dimension();
		dimensionApp.setName("application");
		dimensionApp.setValue(resourceId);
		dimensions.add(dimensionApp);

		MetricDatum datum = new MetricDatum();
		datum.setMetricName(metricName.getMetricName());
		datum.setUnit(StandardUnit.Count);
		datum.setValue(value);
		datum.setDimensions(dimensions);
		datum.setTimestamp(new Date());

		Collection<MetricDatum> metricData = new ArrayList<>();
		metricData.add(datum);

		PutMetricDataRequest putMetricDataRequest = new PutMetricDataRequest();
		putMetricDataRequest.setNamespace(namespace.getNamespace());
		putMetricDataRequest.setMetricData(metricData);
		return putMetricDataRequest;
	}

	/**
	 * Get AwsCloudWatchClient by AWS access and secret key
	 * 
	 * @return
	 */
	private AmazonCloudWatch getAwsCloudWatchClient() {
		BasicAWSCredentials basicAWSCre = new BasicAWSCredentials(accessKey, secretKey);
		AWSStaticCredentialsProvider credential = new AWSStaticCredentialsProvider(basicAWSCre);

		return AmazonCloudWatchClientBuilder.standard()
				.withCredentials(credential)
				.withRegion(REGION.toString())
				.build();
	}

}
