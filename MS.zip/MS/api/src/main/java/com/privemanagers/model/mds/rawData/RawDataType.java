package com.privemanagers.model.mds.rawData;

/**
 * Raw data types
 *
 * @author Kay Ip
 * @date 28 Jun 2018
 * @company Prive Financial
 */
public enum RawDataType {
	PRICE,
	DIVIDEND,
	SPLIT;
}
