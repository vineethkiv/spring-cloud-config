package com.privemanagers.model.asset.response;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Response for get currency conversion
 *
 * @author Kay Ip
 * @date 2 Oct 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCurrencyConversionResponse {

	@JsonProperty("fx-rate")
	private BigDecimal fxRate;

	public BigDecimal getFxRate() {
		return fxRate;
	}

	public void setFxRate(BigDecimal fxRate) {
		this.fxRate = fxRate;
	}
}
