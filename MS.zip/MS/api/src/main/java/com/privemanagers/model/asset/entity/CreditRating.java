package com.privemanagers.model.asset.entity;

/**
 * CreditRating, sub class for Asset
 *
 * @author Kay Ip
 * @date 24 Oct 2018
 * @company Prive Financial
 */
public class CreditRating {

	private String organization;
	private String rating;

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}
}
