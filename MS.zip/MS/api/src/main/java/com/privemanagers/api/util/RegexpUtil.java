package com.privemanagers.api.util;

/**
 * Util to transform user input to program use regexp
 *
 * @author Kay Ip
 * @date 16 Jan 2018
 * @company Prive Financial
 */
public class RegexpUtil {
	private static final String WILDCARD_SYMBOL = "*";

	/**
	 * Currently only support begin and/or end wildcard
	 *
	 * @param userInput
	 * @return
	 */
	public static String wildcardToRegexp(String userInput) {
		String processedInput = userInput.replaceAll("\\" + WILDCARD_SYMBOL, "");

		if (userInput.endsWith(WILDCARD_SYMBOL) && userInput.startsWith(WILDCARD_SYMBOL)) {
			return ".*" + processedInput;
		}

		if (userInput.endsWith(WILDCARD_SYMBOL)) {
			return "^" + processedInput;
		}

		if (userInput.startsWith(WILDCARD_SYMBOL)) {
			return processedInput + "$";
		}

		// no * to replace, exact match
		return userInput;
	}
}
