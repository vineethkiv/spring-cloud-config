package com.privemanagers.api.exception;

/**
 * @author William Zhang
 * @date 27 Nov 2017
 * @company Prive Financial
 */
public class GenericNotFoundException extends Exception {

	/** */
	private static final long serialVersionUID = -1564655056363859696L;

	public GenericNotFoundException(final String msg) {
		super("Not able to produce a result with the following request:\n" + msg);
	}

}
