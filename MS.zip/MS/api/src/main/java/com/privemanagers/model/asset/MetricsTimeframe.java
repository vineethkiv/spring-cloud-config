package com.privemanagers.model.asset;

/**
 * MetricsTimeframe
 *
 * Ref: org.sly.main.shared.data.finance.strategy.statistics.StrategyMetrics
 * timeFrames
 *
 * @author Kay Ip
 * @date 29 Oct 2018
 * @company Prive Financial
 */
public enum MetricsTimeframe {
	MTD,
	QTD,
	M1,
	M2,
	M6,
	M12,
	M24,
	M36,
	M60,
	M120,
	MAX;
}
