package com.privemanagers.model.asset.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Response for create MP
 *
 * @author Kay Ip
 * @date 4 Jan 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateModelPortfolioResponse {

	@JsonProperty("asset-id")
	private String assetId;

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
}
