package com.privemanagers.api.util;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import javax.json.JsonArray;
import javax.json.JsonObject;

import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.ojalgo.array.Array1D;
import org.ojalgo.function.VoidFunction;
import org.ojalgo.random.SampleSet;
import org.ojalgo.series.primitive.DataSeries;
import org.ojalgo.series.primitive.PrimitiveSeries;

import com.privemanagers.api.API;
import com.privemanagers.api.PriceType;

public class Maths {

	/**
	 * Factor for converting monthly volatility into annual volatility.
	 */
	private static final double SQRT_12 = Math.sqrt(12.0);

	/**
	 * Factor for converting daily volatility into annual volatility.
	 */
	private static final double SQRT_255 = Math.sqrt(255);

	/**
	 * Varieties of return computation.
	 *
	 */
	public enum Returns {

		/**
		 * Simple period returns:
		 * <p>
		 * (P<sub>t+1</sub> - P<sub>t</sub>) / P<sub>t</sub>
		 * </p>
		 */
		SIMPLE,

		/**
		 * Continuous compounded or log returns:
		 * <p>
		 * ln P<sub>t+1</sub> - ln P<sub>t</sub>
		 * </p>
		 */
		CONTINUOUS
	}

	/**
	 * The statistical results of filtering a data series.
	 *
	 */
	public interface Filter {

		/**
		 * The number of values in this filtration.
		 *
		 * @return int
		 */
		public int count();

		/**
		 * The mean of the values in this filtration.
		 *
		 * @return double
		 */
		public double mean();

	}

	private abstract static class Filtration implements Filter, VoidFunction<Double> {

		private int count;
		private double sum;

		@Override
		public int count() {
			return this.count;
		}

		@Override
		public double mean() {
			return this.count > 0 ? this.sum / this.count : 0.0;
		}

		@Override
		public void invoke(final Double arg) {
			this.invoke(arg.doubleValue());
		}

		protected final void include(final double arg) {
			this.count++;
			this.sum += arg;
		}

	}

	private static class LossFiltration extends Filtration {

		@Override
		public void invoke(final double arg) {
			if (arg < 0.0) {
				this.include(arg);
			}
		}

	}

	private static class GainFiltration extends Filtration {

		@Override
		public void invoke(final double arg) {
			if (arg > 0.0) {
				this.include(arg);
			}
		}

	}

	/**
	 * Trending, used when calculating maximum drawdown and maximum drawup.
	 *
	 */
	public enum Trend {

		/**
		 * A down trend in prices.
		 */
		DOWN {
			@Override
			double base() {
				return Double.NEGATIVE_INFINITY;
			}

			@Override
			void rebase(final double x, final Draw draw, final int i) {
				if (x > draw.base) {
					if (draw.from >= 0) {
						draw.handleAnyPrior();
						draw.prior = new Draw(draw);
						draw.value = 0;
						draw.until = -1;
					}
					draw.base = x;
					draw.from = i;
				}
			}

			@Override
			double difference(final double x, final Draw draw) {
				return draw.base - x;
			}

		},

		/**
		 * An up trend in prices.
		 */
		UP {

			@Override
			double base() {
				return Double.POSITIVE_INFINITY;
			}

			@Override
			void rebase(final double x, final Draw draw, final int i) {
				if (x < draw.base) {
					if (draw.from >= 0) {
						draw.handleAnyPrior();
						draw.prior = new Draw(draw);
						draw.value = 0;
						draw.until = -1;
					}
					draw.base = x;
					draw.from = i;
				}
			}

			@Override
			double difference(final double x, final Draw draw) {
				return x - draw.base;
			}

		};

		abstract double base();

		abstract void rebase(final double x, Draw draw, int i);

		abstract double difference(final double x, Draw draw);

	}

	/**
	 * Algorithm to insert prices, from the JSON array, into a full time series
	 * of prices, aligned by date. The JSON array is that expected from the
	 * assets service, and is an array of objects, each containing an integer
	 * date and a numeric price.
	 *
	 */
	public static class Align {

		private final JsonArray prices;
		private final String priceKey;
		private final String dateKey;
		private final List<LocalDate> dates;
		private final double[] px;

		private int gapBefore;
		private int gapAfter;

		public Align(final JsonArray prices, final String dateKey, final String priceKey, final List<LocalDate> dates,
				final double[] px) {
			this.prices = prices;
			this.dateKey = dateKey;
			this.priceKey = priceKey;
			this.dates = dates;
			this.px = px;
		}

		public void run() {
			if (this.dates.size() == this.prices.size()) {
				/*
				 * Assume the dates match.
				 */
				for (int i = 0; i < this.prices.size(); i++) {
					this.px[i] = this.getPrice(i);
				}
			} else if (this.prices.isEmpty()) {
				/*
				 * One large gap
				 */
				this.gapBefore = this.dates.size();
			} else {
				/*
				 * The algorithm is stateful.
				 */
				final int PRICE_BEFORE_FIRST_DATE = 0;
				final int PRICE_WITHIN_DATES = 1;
				int state = PRICE_BEFORE_FIRST_DATE;
				/*
				 * The first date in the JSON array.
				 */
				int jsonArrayIndex = 0;
				final int firstDate = ((JsonObject) this.prices.get(jsonArrayIndex)).getInt(this.dateKey);
				/*
				 * Iterate through the *full* date range. These dates are
				 * *strictly* end of month, whereas the dates of prices could be
				 * earlier. Hence we are always comparing the date at i but
				 * operating on the price at i - 1.
				 */
				LOOP: for (int i = 1; i <= this.dates.size(); i++) {
					switch (state) {
					case PRICE_BEFORE_FIRST_DATE:
						if (i == this.dates.size()) {
							/*
							 * Another big gap.
							 */
							this.gapBefore = this.dates.size();
							break;
						}
						if (API.toInteger(this.dates.get(i)) > firstDate) {
							state = PRICE_WITHIN_DATES;
							this.px[i - 1] = this.getPrice(jsonArrayIndex++);
						} else {
							this.gapBefore++;
						}
						break;
					case PRICE_WITHIN_DATES:
						if (jsonArrayIndex < this.prices.size()) {
							this.px[i - 1] = this.getPrice(jsonArrayIndex++);
						} else {
							this.gapAfter = this.dates.size() - (this.gapBefore + this.prices.size());
							break LOOP;
						}
					}
				}
			}
		}

		private double getPrice(final int i) {
			return ((JsonObject) this.prices.get(i)).getJsonNumber(this.priceKey).doubleValue();
		}

		/**
		 * The number of prices missing at the begining of the series.
		 *
		 * @return int
		 */
		public int gapBefore() {
			return this.gapBefore;
		}

		/**
		 * The number of prices missing at the end of the series.
		 *
		 * @return int
		 */
		public int gapAfter() {
			return this.gapAfter;
		}

	}

	public static double negativeVolatility(final DataSeries series) {
		int ref = 0;

		double d = 0.0;
		int n = 0;
		for (int i = 0; i < series.size(); i++) {

			if (series.get(i) < ref) {
				n++;
				d += Math.pow((series.get(i) - ref), 2);
			}

		}

		double result = 0.0;

		if (n > 0) {
			result = Math.sqrt(d / n);
		}
		return result;
	}

	public static double annualisedNegativeVolatility(final double negativeVolatility) {
		return negativeVolatility * SQRT_12;
	}

	/**
	 * Make a copy of the given series which has values relative to the first
	 * data point and then scaled to the given value.
	 *
	 * @param series
	 * @param scale
	 * @return DataSeries
	 */
	public static DataSeries relative(final DataSeries series, final double scale) {

		/*
		 * Avoid possible zeroes in the series.
		 */
		double divisor = 0;
		for (final double value : series) {
			if (value > 0.0) {
				divisor = value;
				break;
			}
		}
		return relativeTo(series, divisor, scale);
	}

	/**
	 * Make a copy of the given series which has values relative to the given
	 * divisor and then multiplied to the given scale.
	 *
	 * @param series
	 * @param divisor
	 * @param scale
	 * @return DataSeries
	 */
	public static DataSeries relativeTo(final DataSeries series, final double divisor, final double scale) {

		final DataSeries copy = DataSeries.copy(series);
		if (copy.size() == 0) {
			return copy;
		}
		PrimitiveSeries x = null;
		if (divisor > 0.0) {
			x = copy.divide(divisor);
			if (scale != 1.0) {
				x = x.multiply(scale);
			}
		} else {
			/*
			 * TODO perhaps we should return all zeroes in this case
			 */
			x = series;
		}
		return x.toDataSeries();
	}

	/**
	 * Calculate the total return for the given series.
	 *
	 * @param series
	 * @param definition
	 * @return double
	 */
	public static double totalReturn(final DataSeries series, final Returns definition) {
		if (series.size() == 0) {
			return 0.0;
		}
		final double p0 = series.value(0);
		final double px = series.value(series.size() - 1);
		switch (definition) {
		case SIMPLE:
			return p0 > 0.0 ? (px - p0) / p0 : 0.0;
		case CONTINUOUS:
			return p0 > 0 && px > 0 ? Math.log(px) - Math.log(p0) : 0.0;
		default:
			throw new IllegalArgumentException();
		}
	}

	/**
	 * Calculate the individual returns for the given series.
	 *
	 * @param series
	 * @param definition
	 * @return DataSeries
	 */
	public static DataSeries returns(final DataSeries series, final Returns definition) {
		switch (definition) {
		case SIMPLE:
			/*
			 * ojalgo 37.1.1 prune works the opposite way to the documentation.
			 */
			final PrimitiveSeries end = series.prune(-1);
			final PrimitiveSeries begin = series.prune(1);
			return end.subtract(begin).divide(begin).toDataSeries();
		case CONTINUOUS:
			return series.log().differences().toDataSeries();
		default:
			throw new IllegalArgumentException();
		}
	}

	/**
	 * The mean of the given series.
	 *
	 * @param series
	 * @return double
	 */
	public static double mean(final DataSeries series) {
		return SampleSet.wrap(series).getMean();
	}

	/**
	 * The annualised volatility of the given monthly price series.
	 *
	 * @see https://sites.google.com/a/wismore.com/privemanagers-developer-wiki/
	 *      development/financial-calculations/online-factsheet-calculations
	 *
	 * @param series
	 * @return double
	 */
	public static double standardDeviation(final DataSeries series, final PriceType priceType) {

		DataSeries s = returns(series, Returns.CONTINUOUS);
		double sd = SampleSet.wrap(s).getStandardDeviation();

		return annualisedStandardDeviation(sd, priceType);
	}

	/**
	 * The annualised return given the simple return and the month count.
	 *
	 * Note this calculation follows the Prive wiki, which uses annualised
	 * 'total' return. That is fundamentally wrong but it's what Citi accepted.
	 *
	 * @param r
	 * @param months
	 * @return
	 */
	public static double annualisedReturn(final double r, final int months) {
		// 12 months in a year
		final double dayCount = (months - 1d) / 12.0;
		final double annRtn = Math.pow(1.0 + r, 1.0 / dayCount) - 1d;
		// return Math.pow(1.0 + r, 12.0 / months) - 1.0;
		return annRtn;

	}

	public static double annualisedStandardDeviation(final double sigma, final PriceType priceType) {
		switch (priceType) {
		case DAILY:
			return sigma * SQRT_255;
		case MONTHLY:
			return sigma * SQRT_12;
		default:
			throw new IllegalStateException("Price type is not supported: " + priceType);
		}
	}

	/**
	 * The annualised Sharpe ratio of the given price and returns series. Note
	 * this calculation follows the Prive wiki, which uses annualised 'total'
	 * return divided by annualised 'lognormal' volatility. That is
	 * fundamentally wrong but it's what Citi accepted.
	 *
	 * @param prices
	 * @param priceType
	 * @see https://sites.google.com/a/wismore.com/privemanagers-developer-wiki/
	 *      development/financial-calculations/online-factsheet-calculations
	 * @return double
	 */
	public static double sharpe(final DataSeries prices) {
		final double annRtn = annualisedReturn(totalReturn(prices, Returns.SIMPLE), prices.size());
		// sharp assumes prices were given on a monthly basis.
		final double annVol = standardDeviation(prices, PriceType.MONTHLY);
		return annRtn / annVol;
	}

	/**
	 * Calculate the correlation between two timeseries
	 *
	 * @param timeseries1
	 * @param timeseries2
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static double calculateCorrelation(final DataSeries series1, DataSeries series2) {

		DataSeries return1 = getLNReturn(series1);
		DataSeries return2 = getLNReturn(series2);

		double covariance = getCorrelation(return1, return2);

		return covariance;
	}

	/** to calculate the correlation */
	private static double getCorrelation(DataSeries scores1, DataSeries scores2) {
		double[] _scores1 = scores1.toRawCopy1D();
		double[] _scores2 = scores2.toRawCopy1D();

		PearsonsCorrelation correl = new PearsonsCorrelation();
		return correl.correlation(_scores1, _scores2);
	}

	/** calculate the LN return */
	public static DataSeries getLNReturn(DataSeries series) {

		double[] rtnArr = new double[series.size() - 1];

		if (series.size() > 0) {

			for (int i = 0; i < series.size() - 1; i++) {
				double val = series.value(i + 1);

				double valPre = series.value(i);

				double lnReturn = Math.log(val / valPre);

				rtnArr[i] = lnReturn;
			}
		}

		return DataSeries.wrap(rtnArr);
	}

	/**
	 * The maximum value of the given series.
	 *
	 * @param series
	 * @return double
	 */
	public static double maximum(final DataSeries series) {
		return SampleSet.wrap(series).getMaximum();
	}

	/**
	 * The minimum value of the given series.
	 *
	 * @param series
	 * @return double
	 */
	public static double minimum(final DataSeries series) {
		return SampleSet.wrap(series).getMinimum();
	}

	/**
	 * Calculate statistics for gains in the given series.
	 *
	 * @param series
	 * @return Filter
	 */
	public static Filter gains(final DataSeries series) {
		final Array1D<Double> array = Array1D.PRIMITIVE64.copy(series);
		final GainFiltration filter = new GainFiltration();
		array.visitAll(filter);
		return filter;
	}

	/**
	 * Calculate statistics for losses in the given series.
	 *
	 * @param series
	 * @return Filter
	 */
	public static Filter losses(final DataSeries series) {
		final Array1D<Double> array = Array1D.PRIMITIVE64.copy(series);
		final LossFiltration filter = new LossFiltration();
		array.visitAll(filter);
		return filter;
	}

	/**
	 * The results of a drawdown or drawup calculation.
	 *
	 */
	public static class Draw {

		private double base;
		private double value;
		private int from;
		private int until;

		private Draw prior;

		private Draw(final Trend trend) {
			this.base = trend.base();
			this.from = -1;
			this.until = -1;
		}

		private Draw(final Draw original) {
			this.base = original.base;
			this.value = original.value;
			this.from = original.from;
			this.until = original.until;
		}

		private void revalue(final double difference, final int i) {
			if (difference > this.value) {
				this.value = difference;
				this.until = i;
			}
		}

		private void handleAnyPrior() {
			if (this.prior != null) {
				final double priorPercent = this.prior.value / this.prior.base;
				final double percent = this.value / this.base;
				if (priorPercent > percent) {
					this.base = this.prior.base;
					this.value = this.prior.value;
					this.from = this.prior.from;
					this.until = this.prior.until;
				}
				this.prior = null;
			}
		}

		/**
		 * The draw value.
		 */
		public double value() {
			this.handleAnyPrior();
			return this.value;
		}

		/**
		 * The draw value relative to the high point (drawdown) or low point
		 * (drawup).
		 */
		public double relative() {
			this.handleAnyPrior();
			return this.value / this.base;
		}

		/**
		 * The index to the start of the draw in the series.
		 */
		public int from() {
			this.handleAnyPrior();
			return this.until == -1 ? -1 : this.from;
		}

		/**
		 * The index to the end of the draw in the series.
		 */
		public int until() {
			this.handleAnyPrior();
			return this.until;
		}

	}

	/**
	 * The maximum drawdown or draw up for the series.
	 *
	 * @param series
	 * @param trend
	 * @return Draw
	 */
	public static Draw draw(final DataSeries series, final Trend trend) {
		final Draw draw = new Draw(trend);
		for (int i = 0; i < series.size(); i++) {
			final double x = series.value(i);
			trend.rebase(x, draw, i);
			final double diff = trend.difference(x, draw);
			draw.revalue(diff, i);
		}
		return draw;
	}

	/**
	 * <p>
	 * Produce a valuation series for a portfolio, using an initial money
	 * allocation plus a price series for each asset. If the rebalance argument
	 * is greater than zero then the portfolio will be rebalanced to the initial
	 * money proportions at the end of the given time period. For example, if
	 * the argument is 3 then the portfolio will be rebalanced at the end of
	 * every third period.
	 * </p>
	 * <p>
	 * Important:
	 * <ol>
	 * <li>All figures must be in the same currency, the portfolio currency
	 * <li>The time periods for the price series must be identical
	 * <li>The initial money allocations must be positive, so short positions
	 * are not allowed
	 * </ol>
	 *
	 * @param money
	 * @param prices
	 * @param rebalanceEvery
	 * @return DataSeries
	 */
	public static DataSeries valuation(final double[] money, final DataSeries[] prices, final int rebalanceEvery) {

		/*
		 * Convert the prices to relative prices.
		 */
		final DataSeries[] relatives = new DataSeries[prices.length];
		int i = prices.length;
		while (i-- > 0) {
			relatives[i] = Maths.relative(prices[i], 1.0);
		}
		return valuationWith(money, relatives, rebalanceEvery);
	}

	/**
	 * A variant of {@link #valuation(double[], DataSeries[], int)} for use when
	 * appending to a valuation from a rebalance point.
	 *
	 * @param money
	 * @param prices
	 * @param base
	 * @param rebalanceEvery
	 * @return DataSeries
	 */
	public static DataSeries valuation(final double[] money, final DataSeries[] prices, final double[] base,
			final int rebalanceEvery) {
		/*
		 * Convert the prices to relative prices.
		 */
		final DataSeries[] relatives = new DataSeries[prices.length];
		int i = prices.length;
		while (i-- > 0) {
			relatives[i] = Maths.relativeTo(prices[i], base[i], 1.0);
		}
		return valuationWith(money, relatives, rebalanceEvery);
	}

	private static DataSeries valuationWith(final double[] money, final DataSeries[] relatives,
			final int rebalanceEvery) {

		double[] v;
		if (rebalanceEvery > 0.0) {
			v = valuationWithRebalancing(money, relatives, rebalanceEvery);
		} else {
			v = valuationWithoutRebalancing(money, relatives);
		}
		return DataSeries.wrap(v);
	}

	/**
	 * Value a portfolio with the given initial money allocation per asset and
	 * the associated relative prices. The portfolio is rebalanced to the
	 * original asset weights after the given number of periods.
	 *
	 * @param money
	 * @param relatives
	 * @param rebalanceEvery
	 * @return double[]
	 */
	private static double[] valuationWithRebalancing(final double[] money, final DataSeries[] relatives,
			final int rebalanceEvery) {

		final int ASSETS = money.length;
		final int PERIODS = relatives[0].size();
		/*
		 * The final portfolio valuation series.
		 */
		final double[] valuation = new double[PERIODS];
		/*
		 * Preserve the initial weights.
		 */
		double[] m = Arrays.copyOf(money, ASSETS);
		double sum = 0.0;
		int asset = ASSETS;
		while (asset-- > 0) {
			sum += money[asset];
		}
		final DataSeries w = DataSeries.wrap(m).divide(sum).toDataSeries();
		/*
		 * Get the double array for each relative price series for more
		 * efficient slicing later.
		 */
		final double[][] rpx = new double[ASSETS][];
		asset = ASSETS;
		while (asset-- > 0) {
			rpx[asset] = relatives[asset].values();
		}
		/*
		 * Each interval between rebalancings is a time slice valued using the
		 * without rebalancing nethod.
		 */
		for (int period = 0; period < PERIODS; period += rebalanceEvery) {

			final int SLICE_END = Math.min(period + rebalanceEvery, PERIODS);
			final int SLICE_LENGTH = Math.min(rebalanceEvery, SLICE_END - period);

			final DataSeries[] slice = new DataSeries[ASSETS];
			asset = ASSETS;
			while (asset-- > 0) {
				slice[asset] = DataSeries.wrap(Arrays.copyOfRange(rpx[asset], period, SLICE_END));
				if (period > 0) {
					/*
					 * Adjust the relative prices to be relative to the last
					 * slice.
					 */
					slice[asset] = slice[asset].divide(rpx[asset][period - 1]).toDataSeries();
				}
			}
			/*
			 * Value the slice and copy the slice into the final valuation
			 * series.
			 */
			final double[] vslice = valuationWithoutRebalancing(m, slice);
			System.arraycopy(vslice, 0, valuation, period, SLICE_LENGTH);
			/*
			 * Reallocate terminal wealth with the original weights.
			 *
			 * TODO this is the point where transaction costs can be deducted
			 * from the terminal wealth, before reweighting.
			 */
			m = DataSeries.copy(w).multiply(vslice[vslice.length - 1]).values();
		}
		return valuation;
	}

	/**
	 * Value a portfolio with the given initial money allocation per asset and
	 * the associated relative prices. The portfolio is not rebalanced.
	 *
	 * @param money
	 * @param relatives
	 * @return double[]
	 */
	private static double[] valuationWithoutRebalancing(final double[] money, final DataSeries[] relatives) {

		final int ASSETS = money.length;
		final int PERIODS = relatives[0].size();
		/*
		 * The final portfolio valuation series.
		 */
		final double[] valuation = new double[PERIODS];
		/*
		 * The valuation for each asset is the product of the initial money and
		 * the relative price series.
		 */
		final PrimitiveSeries[] assetvalue = new PrimitiveSeries[ASSETS];
		int asset = ASSETS;
		while (asset-- > 0) {
			assetvalue[asset] = relatives[asset].multiply(money[asset]);
		}
		/*
		 * Sum the asset values at each period.
		 */
		asset = ASSETS;
		while (asset-- > 0) {
			final PrimitiveSeries av = assetvalue[asset];
			int period = PERIODS;
			while (period-- > 0) {
				valuation[period] += av.get(period);
			}
		}
		return valuation;
	}

	/**
	 * Fill the price array with benchmark values scaled to the prices. The
	 * number of values to fill is given, together with whether the values are
	 * at the beginning or the end of the prices.
	 *
	 * The length of the prices and benchmarks arrays must be equal.
	 *
	 * @param prices
	 * @param benchmarks
	 * @param priceHint
	 * @param number
	 * @param before
	 */
	public static void fill(final double[] prices, final double[] benchmarks, final double priceHint, final int number,
			final boolean before) {
		fill(prices, benchmarks, priceHint, number, before, null);
	}

	/**
	 * Fill the price array with benchmark values scaled to the prices. The
	 * number of values to fill is given, together with whether the values are
	 * at the beginning or the end of the prices.
	 *
	 * The length of the prices and benchmarks arrays must be equal.
	 *
	 * @param prices
	 * @param benchmarks
	 * @param priceHint
	 * @param number
	 * @param before
	 * @param scaleFactor
	 *            Optional, if provided, this will scale the benchmark series
	 *            with the given value
	 */
	public static void fill(final double[] prices, final double[] benchmarks, final double priceHint, final int number,
			final boolean before, final Double scaleFactor) {

		if (number <= 0) {
			return;
		}
		if (number == prices.length) {
			/*
			 * SLYAWS-10720
			 */
			if (!Double.isNaN(priceHint)) {

				/*
				 * Scale the benchmarks using the price hint.
				 */
				final DataSeries ds = DataSeries.wrap(Arrays.copyOf(benchmarks, benchmarks.length));
				final double[] da = ds.multiply(priceHint).divide(benchmarks[benchmarks.length - 1]).values();
				System.arraycopy(da, 0, prices, 0, prices.length);

			} else {
				/*
				 * Preserve this case so at least soemthing is returned.
				 */
				System.arraycopy(benchmarks, 0, prices, 0, prices.length);
			}
			return;
		}
		/*
		 * Extract the relevant benchmarks to a data series.
		 */
		final int benchmarkFrom = before ? 0 : benchmarks.length - number;
		final int benchmarkTo = before ? number : benchmarks.length;
		final DataSeries series = DataSeries.wrap(Arrays.copyOfRange(benchmarks, benchmarkFrom, benchmarkTo));
		/*
		 * Scale that series to the price and benchmark values at the point
		 * where the price is not being filled.
		 */
		double[] px = null;
		if (scaleFactor == null) {
			final int bothAt = before ? number : benchmarks.length - number - 1;
			px = series.multiply(prices[bothAt]).divide(benchmarks[bothAt]).values();
		} else {
			px = series.multiply(scaleFactor).values();
		}
		/*
		 * Copy the values of that series to the appropriate place in the price
		 * array.
		 */
		System.arraycopy(px, 0, prices, benchmarkFrom, px.length);
	}

	/**
	 * Pad the given prices with the given number of values, n, either at the
	 * beginning or the end. The value to pad is either the first/last good
	 * value or zero.
	 *
	 * @param prices
	 * @param n
	 * @param before
	 * @param extend
	 */
	public static void pad(final double[] prices, final int n, final boolean before, final boolean extend) {
		/*
		 * Tolerate padding nothing.
		 */
		if (n <= 0) {
			return;
		}
		final double[] p = new double[n];
		if (before) {
			if (extend) {
				Arrays.fill(p, prices[prices.length - 1]);
			}
			System.arraycopy(p, 0, prices, 0, n);
		} else {
			final int index = prices.length - 1 - n;
			if (extend) {
				Arrays.fill(p, prices[index]);
			}
			System.arraycopy(p, 0, prices, index + 1, n);
		}
	}

	/**
	 * Calculate the projected percentage based on the given input
	 *
	 * @param inInitialPercentage
	 *            initial percentage
	 * @param inReturnRate
	 *            return rate
	 * @param inPeriod
	 *            month period in a year
	 * @param inVolatility
	 * @param inStandardDeviation
	 * @return
	 */
	public static double getProjectedPercentage(final double inInitialPercentage, final double inReturnRate,
			final double inPeriod, final double inVolatility, final double inStandardDeviation) {
		return inInitialPercentage * Math.exp((inReturnRate - 0.5 * Math.pow(inVolatility, 2)) * inPeriod
				+ (inStandardDeviation * inVolatility) * Math.sqrt(inPeriod));
	}

	/**
	 * Calculate the projected value based on the given input
	 *
	 * @param inLastProjectedCapital
	 *            value of the capital from the last period
	 * @param inProjectedPercentage
	 *            projected percentage change
	 * @param inLastProjectedPercentage
	 *            projected percentage change from the last period
	 * @return
	 */
	public static double getProjectedValue(final double inLastProjectedCapital, final double inProjectedPercentage,
			final double inLastProjectedPercentage) {
		return inLastProjectedCapital * inProjectedPercentage / inLastProjectedPercentage;
	}

	/**
	 * Calculate the beta based on the returns of an asset and a benchmark
	 *
	 * @param inReturns
	 * @param inBenchmarkReturns
	 * @return
	 */
	public static double beta(DataSeries inReturns, DataSeries inBenchmarkReturns) {
		return SampleSet.wrap(inReturns).getCovariance(SampleSet.wrap(inBenchmarkReturns))
				/ SampleSet.wrap(inBenchmarkReturns).getVariance();
	}

	/**
	 * Calculates the interest rate sensitivity based on dv01 and the percentage
	 * shift of an asset
	 *
	 * @param dv01
	 * @param percentageShift
	 * @return
	 */
	public static double interestRateSensitivity(final double dv01, final double percentageShift) {
		return dv01 * percentageShift * 10000 * -1;
	}

	/**
	 * Calculates the interest rate sensitivity based on effectiveDuration,
	 * marketValue, and the percentage shift of an asset
	 *
	 * @param effectiveDuration
	 * @param marketValue
	 * @param percentageShift
	 * @return
	 */
	public static double interestRateSensitivity(final double effectiveDuration, final double marketValue,
			final double percentageShift) {
		return interestRateSensitivity(dv01(effectiveDuration, marketValue), percentageShift);
	}

	/**
	 * Calculates the dv01 based on the effectiveDuration and marketValue of an
	 * asset
	 *
	 * @param effectiveDuration
	 * @param marketValue
	 * @return
	 */
	public static double dv01(final double effectiveDuration, final double marketValue) {
		return effectiveDuration * marketValue / 10000;
	}

	/**
	 * Calculates the benchmark sensitivity based on the pricePercentageShift
	 * and marketValue of an asset
	 *
	 * @param pricePercentageShift
	 * @param marketValue
	 * @return
	 */
	public static double benchmarkSensitivity(final double pricePercentageShift, final double marketValue) {
		return pricePercentageShift * marketValue;
	}

	/**
	 * Calculates the benchmark sensitivity
	 *
	 * @param alpha
	 * @param riskFreeRate
	 * @param benchmarkBeta
	 * @param percentageShift
	 * @param marketValue
	 * @return
	 */
	public static double benchmarkSensitivity(final double alpha, final double riskFreeRate, final double benchmarkBeta,
			final double percentageShift, final double marketValue) {
		return benchmarkSensitivity(alpha + riskFreeRate + benchmarkBeta * (percentageShift - riskFreeRate),
				marketValue);
	}

	/**
	 * Calculates percentage change
	 *
	 * @param currentValue
	 * @param valueChange
	 * @return
	 */
	public static double percentageChange(final double currentValue, final double valueChange) {
		return valueChange / currentValue;
	}

	/**
	 * Calculate the alpha based on the prices of an asset and a benchmark, and
	 * the beta, over a period of time
	 *
	 * @param inPrices
	 * @param inBeta
	 * @param inMonths
	 * @return
	 */
	public static double alpha(final DataSeries inPrices, final DataSeries inBenchmarkPrices, final double inBeta,
			final int inMonths) {
		return alpha(inPrices, totalReturn(inBenchmarkPrices, Returns.SIMPLE), inBeta, inMonths);
	}

	/**
	 * Calculate the alpha based on the prices of an asset, and the total
	 * returns of a benchmark, the beta, over a period of time
	 *
	 * @param inPrices
	 * @param inTotalBenchMarkTotalReturns
	 * @param inBeta
	 * @param inMonths
	 * @return
	 */
	public static double alpha(final DataSeries inPrices, final double inTotalBenchMarkTotalReturns,
			final double inBeta, final int inMonths) {
		return annualisedReturn(totalReturn(inPrices, Returns.SIMPLE), inMonths)
				- (inBeta * annualisedReturn(inTotalBenchMarkTotalReturns, inMonths));
	}

	/**
	 * Calculate the tracking error based on the returns of an asset and a
	 * benchmark
	 *
	 * @param inReturns
	 * @param inBenchmarkReturns
	 * @return
	 */
	public static double trackingError(final DataSeries inReturns, final DataSeries inBenchmarkReturns) {
		final double[] returnsArray = inReturns.values();
		final double[] benchmarkReturnsArray = inBenchmarkReturns.values();

		double[] differenceArray = new double[returnsArray.length];
		Arrays.setAll(differenceArray, i -> returnsArray[i] - benchmarkReturnsArray[i]);

		return Math.sqrt(SampleSet.wrap(DataSeries.wrap(differenceArray)).getVariance()) * SQRT_12;
	}

	public static double calculateWeightedStatistics(final double inValue, final double inWeight,
			final double inTotalWeight) {
		return inValue * inWeight / inTotalWeight;
	}

	private Maths() {
	}

}
