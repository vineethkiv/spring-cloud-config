package com.privemanagers.model.common.request;

import java.util.Map;

/**
 * GraphQL request, standard fields that graphQL supports
 *
 * reference com.graphql.Builder
 *
 * @author Kay Ip
 * @date 24 Oct 2018
 * @company Prive Financial
 */
public class GraphQLRequest {

	private String query;

	private String operationName;

	private Map<String, Object> variables;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public Map<String, Object> getVariables() {
		return variables;
	}

	public void setVariables(Map<String, Object> variables) {
		this.variables = variables;
	}
}
