package com.privemanagers.api.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * Properties Configuration
 *
 * @author Kay Ip
 * @date 17 Jan 2018
 * @company Prive Financial
 */
@Configuration
@PropertySource(value = { "classpath:api.properties",
		"classpath:api-${spring.profiles.active:develop}.properties" }, ignoreResourceNotFound = true)
public class ApiConfig {

	@Value("${mixpanel.token}")
	private String mixpanelToken;

	public String getMixpanelToken() {
		return mixpanelToken;
	}

	public void setMixpanelToken(String mixpanelToken) {
		this.mixpanelToken = mixpanelToken;
	}

}
