package com.privemanagers.model.asset;

import java.util.List;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Code document structure
 *
 * @author Kay Ip
 * @date 24 Jan 2018
 * @company Prive Financial
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Code {

	@Id
	private String _id;

	private String scheme;

	private String value;

	@JsonProperty("assets-id")
	private List<String> assetsId;

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public List<String> getAssetsId() {
		return assetsId;
	}

	public void setAssetsId(List<String> assetsId) {
		this.assetsId = assetsId;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}
}
