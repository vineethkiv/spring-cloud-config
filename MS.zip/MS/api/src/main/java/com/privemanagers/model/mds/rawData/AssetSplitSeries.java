package com.privemanagers.model.mds.rawData;

/**
 * split POJO for update request
 *
 * split specific fields here
 * 
 * @author Kay Ip
 * @date 4 July 2018
 * @company Prive Financial
 */
public class AssetSplitSeries extends RawSeriesData {
}
