package com.privemanagers.model.mds;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * @author Matthew WONG
 * @date 16 Nov 2018
 * @company Prive Financial
 */
public class AssetSchemeTest {

	@Test
	public void testAssetScheme() {

		assertAssetSchemeEnum(AssetScheme.CSDCC, "CSDCC", "CSDCC");
		assertAssetSchemeEnum(AssetScheme.CUSIP, "CUSIP", "CUSIP");
		assertAssetSchemeEnum(AssetScheme.FX, "FX", "FX");
		assertAssetSchemeEnum(AssetScheme.ISIN, "ISIN", "ISIN");
		assertAssetSchemeEnum(AssetScheme.MS_PERFORMANCE_ID, "MS_PERFORMANCE_ID", "MS-PERFORMANCE-ID");
		assertAssetSchemeEnum(AssetScheme.SEDOL, "SEDOL", "SEDOL");
		assertAssetSchemeEnum(AssetScheme.SYMBOL, "SYMBOL", "SYMBOL");
		assertAssetSchemeEnum(AssetScheme.RIC, "RIC", "RIC");
		assertAssetSchemeEnum(AssetScheme.SYSJUST_ID, "SYSJUST_ID", "SYSJUST-ID");
		assertAssetSchemeEnum(AssetScheme.THAI_FUND_CODE, "THAI_FUND_CODE", "THAI-FUND-CODE");
		assertAssetSchemeEnum(AssetScheme.BLOOMBERG_ID, "BLOOMBERG_ID", "BLOOMBERG-ID");
		assertAssetSchemeEnum(AssetScheme.PRIVE, "PRIVE", "prive");
	}

	private void assertAssetSchemeEnum(AssetScheme assetScheme, String nameVal, String toStringVal) {
		assertEquals(assetScheme.name(), nameVal);
		assertEquals(assetScheme.toString(), toStringVal);
	}
}
