package com.privemanagers.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

import org.junit.Test;

/**
 * @author nteck
 * @date : 25 Mar, 2017
 * @company Prive Financial
 */
public class APIResponseTest {

	@Test
	public void testFromStringToArray() {
		final String name = "name";
		final String currency = "currency";
		final String codes = "codes";
		final String cfi_code = "cfi_code";
		final String scheme = "scheme";
		final String value = "value";
		final String isin = "ISIN";
		final String value1 = "LU0316493153";
		final String value2 = "LU0114720955";
		final String name1 = "Templeton Global Total Return Fund A(Mdis)GBP-H1";
		final String name2 = "Fidelity Funds - Global Health Care Fund A-EUR";
		final String currency1 = "GBP";
		final String currency2 = "EUR";
		final String cfi_code1 = "A";
		final String cfi_code2 = "B";

		final JsonBuilderFactory factory = API.makeJsonBuilderFactory();
		final JsonArrayBuilder arrayBuilder = factory.createArrayBuilder();
		final JsonObjectBuilder objectBuilder = factory.createObjectBuilder();

		final JsonArray codes1 = arrayBuilder.add(objectBuilder.add(scheme, isin).add(value, value1)).build();

		final JsonArray codes2 = arrayBuilder.add(objectBuilder.add(scheme, isin).add(value, value2)).build();

		final JsonArray assets = arrayBuilder.add(
				objectBuilder.add(name, name1).add(currency, currency1).add(cfi_code, cfi_code1).add(codes, codes1))
				.add(objectBuilder.add(name, name2)
						.add(currency, currency2)
						.add(cfi_code, cfi_code2)
						.add(codes, codes2))
				.build();

		final JsonArray jsonAssets = API.parseArray(assets.toString());

		assertNotNull(jsonAssets);
		assertEquals(2, jsonAssets.size());

		final JsonObject asset1 = jsonAssets.getJsonObject(0);
		assertNotNull(asset1);
		assertEquals(name1, asset1.getString(name));
		assertEquals(currency1, asset1.getString(currency));
		assertEquals(cfi_code1, asset1.getString(cfi_code));
		final JsonArray asset1Codes = asset1.getJsonArray(codes);
		assertNotNull(asset1Codes);
		assertEquals(1, asset1Codes.size());
		final JsonObject asset1Code1 = asset1Codes.getJsonObject(0);
		assertNotNull(asset1Code1);
		assertEquals(isin, asset1Code1.getString(scheme));
		assertEquals(value1, asset1Code1.getString(value));

		final JsonObject asset2 = jsonAssets.getJsonObject(1);
		assertNotNull(asset2);
		assertEquals(name2, asset2.getString(name));
		assertEquals(currency2, asset2.getString(currency));
		assertEquals(cfi_code2, asset2.getString(cfi_code));
		final JsonArray asset2Codes = asset2.getJsonArray(codes);
		assertNotNull(asset2Codes);
		assertEquals(1, asset2Codes.size());
		final JsonObject asset2Code1 = asset2Codes.getJsonObject(0);
		assertNotNull(asset2Code1);
		assertEquals(isin, asset2Code1.getString(scheme));
		assertEquals(value2, asset2Code1.getString(value));
	}

}
