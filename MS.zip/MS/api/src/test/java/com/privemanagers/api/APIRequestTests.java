package com.privemanagers.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

public class APIRequestTests {

	@Test
	public void testUnusual() {
		List<String> x = API.list(null);
		assertNotNull(x);
		assertTrue(x.isEmpty());

		x = API.list("");
		assertNotNull(x);
		assertTrue(x.isEmpty());

		x = API.list(" ");
		assertNotNull(x);
		assertTrue(x.isEmpty());
	}

	@Test
	public void testUsual() {
		final List<String> x = API.list("a,b,  c  ");
		assertNotNull(x);
		assertEquals(3, x.size());
		assertEquals("a", x.get(0));
		assertEquals("b", x.get(1));
		assertEquals("c", x.get(2));
	}

	@Test
	public void testMalformed() {
		List<String> x = API.list("a,b, ,  c  ");
		assertEquals(3, x.size());
		assertEquals("a", x.get(0));
		assertEquals("b", x.get(1));
		assertEquals("c", x.get(2));

		x = API.list(",,,  ,,");
		assertNotNull(x);
		assertTrue(x.isEmpty());
	}

	@Test
	public void testDates() {

		LocalDate date = API.date("2016");
		assertEquals(1, date.getDayOfMonth());
		assertEquals(1, date.getMonthValue());
		assertEquals(2016, date.getYear());

		date = API.date("2016-06");
		assertEquals(1, date.getDayOfMonth());
		assertEquals(6, date.getMonthValue());
		assertEquals(2016, date.getYear());

		date = API.date("2016-06-05");
		assertEquals(5, date.getDayOfMonth());
		assertEquals(6, date.getMonthValue());
		assertEquals(2016, date.getYear());

		assertNull(API.date(null));
		assertNull(API.date(""));
		assertNull(API.date("x"));
		assertNull(API.date("20160101"));
		assertNull(API.date("16"));

		assertEquals(20160605, date.getYear() * 10_000 + date.getMonthValue() * 100 + date.getDayOfMonth());
	}

}
