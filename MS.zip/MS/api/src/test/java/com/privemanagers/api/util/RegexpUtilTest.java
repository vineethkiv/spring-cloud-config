package com.privemanagers.api.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

/**
 * @author Kay Ip
 * @date 16 Jan 2018
 * @company Prive Financial
 */
public class RegexpUtilTest {

	@Test
	public void testWildcardToRegexp() {
		String content = "Goldman Sachs SICAV - Goldman Sachs Europe CORE Equity Portfolio A Inc";

		String input1 = "Gold*";
		Pattern pattern = Pattern.compile(RegexpUtil.wildcardToRegexp(input1), Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(content);
		assertTrue(matcher.find());

		String input2 = "*Inc";
		Pattern pattern2 = Pattern.compile(RegexpUtil.wildcardToRegexp(input2), Pattern.CASE_INSENSITIVE);
		Matcher matcher2 = pattern2.matcher(content);
		assertTrue(matcher2.find());

		String input3 = "*CORE*";
		Pattern pattern3 = Pattern.compile(RegexpUtil.wildcardToRegexp(input3), Pattern.CASE_INSENSITIVE);
		Matcher matcher3 = pattern3.matcher(content);
		assertTrue(matcher3.find());

		String input4 = "CORE";
		Pattern pattern4 = Pattern.compile(RegexpUtil.wildcardToRegexp(input4), Pattern.CASE_INSENSITIVE);
		Matcher matcher4 = pattern4.matcher(content);
		assertFalse(matcher4.matches());

		String input5 = "Goldman Sachs SICAV - Goldman Sachs Europe CORE Equity Portfolio A Inc";
		Pattern pattern5 = Pattern.compile(RegexpUtil.wildcardToRegexp(input5), Pattern.CASE_INSENSITIVE);
		Matcher matcher5 = pattern5.matcher(content);
		assertTrue(matcher5.find());
	}

}
