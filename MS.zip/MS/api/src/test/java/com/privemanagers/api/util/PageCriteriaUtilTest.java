package com.privemanagers.api.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;

import org.junit.Test;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;

import com.mongodb.BasicDBObject;
import com.privemanagers.api.PageCriteria;
import com.privemanagers.api.SortCriteria;

public class PageCriteriaUtilTest {
	@Test
	public void testValidate() {

		// test empty
		PageCriteria pc = new PageCriteria();
		assertFalse(PageCriteriaUtil.validate(pc));

		List<SortCriteria> scList = new ArrayList<>();
		SortCriteria sc = new SortCriteria();
		sc.setSortBy("currency");
		sc.setSortDirection(Direction.ASC);
		scList.add(sc);

		// test wrong page number
		PageCriteria pc1 = new PageCriteria();
		pc1.setPageNumber(-1);
		pc1.setPageSize(10);
		pc1.setSortCriteria(scList);
		assertFalse(PageCriteriaUtil.validate(pc1));

		// test wrong page size
		PageCriteria pc2 = new PageCriteria();
		pc2.setPageNumber(1);
		pc2.setPageSize(0);
		pc2.setSortCriteria(scList);
		assertFalse(PageCriteriaUtil.validate(pc2));

		// test valid
		PageCriteria pc3 = new PageCriteria();
		pc3.setPageNumber(10);
		pc3.setPageSize(10);
		pc3.setSortCriteria(scList);
		assertTrue(PageCriteriaUtil.validate(pc3));
	}

	@Test
	public void testTransformPageRequest() {
		List<SortCriteria> scList = new ArrayList<>();
		SortCriteria sc = new SortCriteria();
		sc.setSortBy("currency");
		sc.setSortDirection(Direction.ASC);
		scList.add(sc);

		PageCriteria pc = new PageCriteria();
		pc.setPageNumber(10);
		pc.setPageSize(10);
		pc.setSortCriteria(scList);

		PageRequest pr = PageCriteriaUtil.transform(pc);
		assertEquals(pc.getPageNumber(), pr.getPageNumber());
		assertEquals(pc.getPageSize(), pr.getPageSize());
		assertEquals(pc.getSortCriteria().size(), StreamSupport.stream(pr.getSort().spliterator(), false).count());
	}

	@Test
	public void testTransformBasicDBObject() {
		List<SortCriteria> scList = new ArrayList<>();
		SortCriteria sc = new SortCriteria();
		sc.setSortBy("currency");
		sc.setSortDirection(Direction.ASC);
		scList.add(sc);
		SortCriteria sc2 = new SortCriteria();
		sc2.setSortBy("assetType");
		sc2.setSortDirection(Direction.DESC);
		scList.add(sc2);

		PageCriteria pc = new PageCriteria();
		pc.setPageNumber(10);
		pc.setPageSize(10);
		pc.setSortCriteria(scList);

		PageRequest pr = PageCriteriaUtil.transform(pc);
		BasicDBObject dbo = PageCriteriaUtil.transform(pr);

		int mongoSortAsc = 1;
		int mongoSortDesc = -1;

		assertEquals(pc.getSortCriteria().size(), dbo.size());
		assertEquals(mongoSortAsc, dbo.get(scList.get(0).getSortBy()));
		assertEquals(mongoSortDesc, dbo.get(scList.get(1).getSortBy()));
	}

}
