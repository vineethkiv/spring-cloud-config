package com.privemanagers.api.util;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.cloudwatch.AmazonCloudWatch;

/**
 * Test for Util to create and send information to AWS cloudWatch
 *
 * @author Kay Ip
 * @date 5 Dec 2018
 * @company Prive Financial
 */
@RunWith(MockitoJUnitRunner.class)
public class AWSCloudWatchUtilTest {

	@Mock
	private AmazonCloudWatch cloudWatchClient;

	@InjectMocks
	private AWSCloudWatchUtil awsCloudWatchUtil;

	@Before
	public void setup() {
		ReflectionTestUtils.setField(awsCloudWatchUtil, "cloudWatchClient", cloudWatchClient);
	}

	@Test
	public void testPushMetricToAWSCloudWatch() {
		ReflectionTestUtils.setField(awsCloudWatchUtil, "accessKey", "1234");
		ReflectionTestUtils.setField(awsCloudWatchUtil, "secretKey", "1234");

		AWSCloudWatchMetricNamespace namespace = AWSCloudWatchMetricNamespace.MDS_NAMESPACE;
		AWSCloudWatchMetricName metricName = AWSCloudWatchMetricName.MDS_MASTER;
		double value = 1.0;

		awsCloudWatchUtil.pushMetricToAWSCloudWatch(namespace, metricName, value);

		Mockito.verify(cloudWatchClient, Mockito.times(1)).putMetricData(Mockito.any());
	}

}
