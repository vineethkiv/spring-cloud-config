package com.privemanagers.api.util;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.ojalgo.series.primitive.DataSeries;

/**
 * Test for Dual series Math function
 *
 * @author Gavy Lau
 * @date 29 Dec 2017
 * @company Prive Financial
 * @see MathDualSeriesTest.ods
 * @see MathsDualSeriesSensitivityAnalysisTest.ods
 */
public class MathDualSeriesTest {

	private static final double EPSILON = 0.001;

	private static final double[] benchmarkPricesArray = new double[] { 451.67, 440.19, 450.19, 450.53, 448.13, 463.56,
			458.93, 467.83, 461.79, 466.45, 481.61, 467.14, 445.77, 450.91, 456.5, 444.27, 458.26, 475.49, 462.71,
			472.35, 453.69, 459.27, 470.42, 487.39, 500.71, 514.71, 533.4, 544.75, 562.06, 561.88, 584.41, 581.5,
			605.37, 615.93, 636.02, 640.43, 645.5, 654.17, 669.12, 670.63, 639.95, 651.99, 687.33, 705.27, 757.02,
			740.74, 786.16, 790.82, 757.12, 801.34, 848.28, 885.14, 954.31, 899.47, 947.28, 914.62, 955.4, 970.43,
			980.28, 1049.34, 1101.75, 1111.75, 1090.82, 1133.84, 1120.67, 957.28, 1017.01, 1098.67, 1163.63, 1229.23,
			1279.64, 1238.33, 1286.37, 1335.18, 1301.84, 1372.71, 1328.72, 1320.41, 1282.71, 1362.93, 1388.91, 1469.25,
			1394.46, 1366.42, 1498.58, 1452.43, 1420.6, 1454.6, 1430.83, 1517.68, 1436.51, 1429.4, 1314.95, 1320.28,
			1366.01, 1239.94, 1160.33, 1249.46, 1255.82, 1224.38, 1211.23, 1133.58, 1040.94, 1059.78, 1139.45, 1148.08,
			1130.2, 1106.73, 1147.39, 1076.92, 1067.14, 989.82, 911.62, 916.07, 815.28, 885.76, 936.31, 879.82, 855.7,
			841.15, 848.18, 916.92, 963.59, 974.5, 990.31, 1008.01, 995.97, 1050.71, 1058.2, 1111.92, 1131.13, 1144.94,
			1126.21, 1107.3, 1120.68, 1140.84, 1101.72, 1104.24, 1114.58, 1130.2, 1173.82, 1211.92, 1181.27, 1203.6,
			1180.59, 1156.85, 1191.5, 1191.33, 1234.18, 1220.33, 1228.81, 1207.01, 1249.48, 1248.29, 1280.08, 1280.66,
			1294.87, 1310.61, 1270.09, 1270.2, 1276.66, 1303.82, 1335.85, 1377.94, 1400.63, 1418.3, 1438.24, 1406.82,
			1420.86, 1482.37, 1530.62, 1503.35, 1455.27, 1473.99, 1526.75, 1549.38, 1481.14, 1468.36, 1378.55, 1330.63,
			1322.7, 1385.59, 1400.38, 1280.0, 1267.38, 1282.83, 1166.36, 968.75, 896.24, 903.25, 825.88, 735.09, 797.87,
			872.81, 919.14, 919.32, 987.48, 1020.62, 1057.08, 1036.19, 1095.63, 1115.1, 1073.87, 1104.49, 1169.43,
			1186.69, 1089.41, 1030.71, 1101.6, 1049.33, 1141.2, 1183.26, 1180.55, 1257.64, 1286.12, 1327.22, 1325.83,
			1363.61, 1345.2, 1320.64, 1292.28, 1218.89, 1131.42, 1253.3, 1246.96, 1257.6, 1312.41, 1324.09 };

	private static final double[] pricesArray = new double[] { 32.42, 31.59, 32.45, 32.53, 32.37, 33.62, 33.37, 34.03,
			33.66, 34.05, 35.24, 34.21, 32.78, 33.15, 33.68, 32.91, 33.97, 35.27, 34.59, 35.57, 34.16, 34.36, 35.51,
			36.97, 38.02, 39.15, 40.7, 41.52, 42.86, 43.05, 44.87, 44.74, 46.73, 47.41, 49.1, 49.26, 50.13, 50.68,
			51.82, 52.26, 49.91, 50.88, 53.44, 55.17, 59.2, 57.76, 61.33, 61.92, 59.21, 62.92, 66.9, 69.64, 75.16,
			71.26, 74.69, 72.86, 75.68, 77.1, 78.09, 83.5, 87.61, 88.72, 86.88, 90.58, 89.35, 76.74, 81.61, 88.23,
			93.14, 99.2, 102.7, 99.4, 103.56, 107.48, 105.02, 110.8, 107.37, 106.81, 104.41, 111.1, 112.95, 119.41,
			113.45, 111.73, 122.56, 118.25, 116.39, 118.68, 116.82, 124.45, 117.63, 117.07, 108.33, 107.73, 112.52,
			101.79, 96.08, 104.29, 103.71, 101.23, 100.2, 94.26, 86.56, 87.69, 94.53, 94.74, 93.81, 92.13, 95.19, 89.65,
			89.12, 82.54, 76.04, 76.56, 68.53, 74.17, 78.74, 74.29, 72.46, 71.48, 71.64, 77.7, 81.96, 82.83, 84.33,
			86.06, 85.13, 89.68, 90.66, 95.22, 97.11, 98.42, 97.12, 95.28, 96.91, 98.71, 95.53, 95.76, 96.72, 97.97,
			102.33, 105.41, 103.05, 105.2, 103.28, 101.34, 104.61, 104.77, 108.77, 107.75, 108.62, 106.05, 110.71,
			110.5, 113.15, 113.8, 115.68, 117.14, 113.61, 113.91, 114.42, 116.92, 120.07, 123.86, 126.32, 128.01,
			129.93, 127.38, 128.86, 134.57, 139.13, 137.1, 132.81, 134.51, 139.72, 141.61, 136.13, 134.6, 126.46,
			123.19, 122.09, 127.91, 129.84, 118.99, 117.92, 119.74, 108.47, 90.55, 84.25, 85.07, 78.09, 69.7, 75.5,
			83.0, 87.85, 87.8, 94.35, 97.83, 101.3, 99.35, 105.47, 107.49, 103.58, 106.81, 112.85, 114.6, 105.49,
			100.03, 106.87, 102.06, 111.2, 115.45, 115.45, 123.17, 126.04, 130.41, 130.43, 134.21, 132.7, 130.46,
			127.85, 120.82, 112.44, 124.71, 124.2, 125.5, 131.32, 132.47 };

	private static final double betaOne = 0.0797;
	private static final double betaTwo = -0.1456;
	private static final double effectiveDurationOne = 0.23686906;
	private static final double effectiveDurationTwo = 2.99797940;

	private static final double marketValueOne = 1.090280;
	private static final double marketValueTwo = 1.067500;

	private static final double alpha = 0.0;
	private static final double riskFreeRate = 0.0;

	private static final DataSeries benchmarkPrices = DataSeries.wrap(benchmarkPricesArray);
	private static final DataSeries prices = DataSeries.wrap(pricesArray);
	private static DataSeries benchmarkReturns;
	private static DataSeries returns;
	private static double beta;

	@Before
	public void setUp() {
		benchmarkReturns = Maths.returns(benchmarkPrices, Maths.Returns.CONTINUOUS);
		returns = Maths.returns(prices, Maths.Returns.CONTINUOUS);
		beta = Maths.beta(returns, benchmarkReturns);
	}

	/**
	 * This follow the test case in MathDualSeriesTest.ods.Step_2
	 */
	@Test
	public void testBeta() {
		assertEquals(0.9902, Maths.beta(returns, benchmarkReturns), EPSILON);
	}

	/**
	 * This follow the test case in MathDualSeriesTest.ods.Step_2
	 */
	@Test
	public void testAlpha() {
		final double totalBenchMarkTotalReturns = Maths.totalReturn(benchmarkPrices, Maths.Returns.SIMPLE);
		assertEquals(0.0196, Maths.alpha(prices, totalBenchMarkTotalReturns, beta, prices.size()), EPSILON);

	}

	/**
	 * This follow the test case in MathDualSeriesTest.ods.Step_2
	 */
	@Test
	public void testAlphaWithPricesOnly() {
		assertEquals(0.0196, Maths.alpha(prices, benchmarkPrices, beta, prices.size()), EPSILON);
	}

	/**
	 * This follow the test case in
	 * MathDualSeriesTest.ods.Tracking_Error_&_Correl
	 */
	@Test
	public void testTrackingError() {
		assertEquals(0.0113, Maths.trackingError(returns, benchmarkReturns), EPSILON);
	}

	/**
	 * This follow the test case in
	 * MathsDualSeriesSensitivityAnalysisTest.ods.Unit Test - Beta
	 */
	@Test
	public void testBenchmarkSensitivityOne() {
		assertEquals(-0.001738, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaOne, -0.02, marketValueOne),
				EPSILON);
		assertEquals(0.003476, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaOne, 0.04, marketValueOne), EPSILON);
		assertEquals(-0.005214, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaOne, -0.06, marketValueOne),
				EPSILON);
		assertEquals(0.006952, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaOne, 0.08, marketValueOne), EPSILON);
		assertEquals(-0.008690, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaOne, -0.1, marketValueOne),
				EPSILON);

	}

	/**
	 * This follow the test case in
	 * MathsDualSeriesSensitivityAnalysisTest.ods.Unit Test - Beta
	 */
	@Test
	public void testBenchmarkSensitivityTwo() {
		assertEquals(0.003110, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaTwo, -0.02, marketValueTwo),
				EPSILON);
		assertEquals(-0.006220, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaTwo, 0.04, marketValueTwo),
				EPSILON);
		assertEquals(0.009330, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaTwo, -0.06, marketValueTwo),
				EPSILON);
		assertEquals(-0.012440, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaTwo, 0.08, marketValueTwo),
				EPSILON);
		assertEquals(0.015550, Maths.benchmarkSensitivity(alpha, riskFreeRate, betaTwo, -0.1, marketValueTwo), EPSILON);

	}

	/**
	 * This follow the test case in
	 * MathsDualSeriesSensitivityAnalysisTest.ods.Unit Test - Effective Duration
	 */
	@Test
	public void testInterestRateSensitivityOne() {
		assertEquals(0.005, Maths.interestRateSensitivity(effectiveDurationOne, marketValueOne, -0.02), EPSILON);
		assertEquals(-0.010, Maths.interestRateSensitivity(effectiveDurationOne, marketValueOne, 0.04), EPSILON);
		assertEquals(0.015, Maths.interestRateSensitivity(effectiveDurationOne, marketValueOne, -0.06), EPSILON);
		assertEquals(-0.021, Maths.interestRateSensitivity(effectiveDurationOne, marketValueOne, 0.08), EPSILON);
		assertEquals(0.026, Maths.interestRateSensitivity(effectiveDurationOne, marketValueOne, -0.1), EPSILON);
	}

	/**
	 * This follow the test case in
	 * MathsDualSeriesSensitivityAnalysisTest.ods.Unit Test - Effective Duration
	 */
	@Test
	public void testInterestRateSensitivityTwo() {
		assertEquals(0.064, Maths.interestRateSensitivity(effectiveDurationTwo, marketValueTwo, -0.02), EPSILON);
		assertEquals(-0.128, Maths.interestRateSensitivity(effectiveDurationTwo, marketValueTwo, 0.04), EPSILON);
		assertEquals(0.192, Maths.interestRateSensitivity(effectiveDurationTwo, marketValueTwo, -0.06), EPSILON);
		assertEquals(-0.256, Maths.interestRateSensitivity(effectiveDurationTwo, marketValueTwo, 0.08), EPSILON);
		assertEquals(0.320, Maths.interestRateSensitivity(effectiveDurationTwo, marketValueTwo, -0.1), EPSILON);
	}

}
