package com.privemanagers.api.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.time.LocalDate;
import java.util.List;

import javax.json.JsonArray;

import org.junit.Test;
import org.ojalgo.series.primitive.DataSeries;

import com.privemanagers.api.API;
import com.privemanagers.api.PriceType;

public class MathsTests {

	private static final double EPSILON = 0.001;

	@Test
	public void testRelative() {

		final double[] p = new double[] { 10, 15, 5 };
		final DataSeries px = DataSeries.wrap(p);
		final DataSeries rx = Maths.relative(px, 1.0);
		assertEquals(1.0, rx.get(0), EPSILON);
		assertEquals(1.5, rx.get(1), EPSILON);
		assertEquals(0.50, rx.get(2), EPSILON);
		/*
		 * px is unchanged.
		 */
		for (int i = 0; i < p.length; i++) {
			assertEquals(p[i], px.get(i), EPSILON);
		}
	}

	@Test
	public void testReturns() {

		final DataSeries v = DataSeries.wrap(new double[] { 10.0, 15.0, 7.5 });

		final DataSeries s = Maths.returns(v, Maths.Returns.SIMPLE);
		assertEquals(0.5, s.get(0), EPSILON);
		assertEquals(-0.5, s.get(1), EPSILON);

		final DataSeries c = Maths.returns(v, Maths.Returns.CONTINUOUS);
		assertEquals(Math.log(v.get(1) / v.get(0)), c.get(0), 0.001);
		assertEquals(0.405, c.get(0), EPSILON);
		assertEquals(-0.693, c.get(1), EPSILON);
	}

	@Test
	public void testGainsAndLosses() {

		final DataSeries r = DataSeries.wrap(new double[] { 1.0, 2.0, 0.0 - 1.0, -2.0 });

		final Maths.Filter g = Maths.gains(r);
		assertEquals(2, g.count());
		assertEquals(1.5, g.mean(), EPSILON);

		final Maths.Filter l = Maths.losses(r);
		assertEquals(2, l.count());
		assertEquals(-1.5, l.mean(), EPSILON);
	}

	@Test
	public void testMaximumDrawDown() {

		DataSeries v = DataSeries.wrap(new double[] { 10.0, 11.0, 10.0, 9.0, 9.0, 10.0, 9.0, 8.0, 8.0, 7.0, 6.0, 8.0 });

		Maths.Draw s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(5.0, s.value(), EPSILON);
		assertEquals(0.4545, s.relative(), EPSILON);
		assertEquals(1, s.from());
		assertEquals(10, s.until());

		v = DataSeries.wrap(new double[] { 10.0, 11.0, 10.0, 9.0, 9.0, 10.0, 9.0, 8.0, 8.0, 7.0, 6.0 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(5.0, s.value(), EPSILON);
		assertEquals(0.4545, s.relative(), EPSILON);
		assertEquals(1, s.from());
		assertEquals(10, s.until());

		v = DataSeries.wrap(new double[] { 10.0, 9.0, 8.0 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(2.0, s.value(), EPSILON);
		assertEquals(0.2, s.relative(), EPSILON);
		assertEquals(0, s.from());
		assertEquals(2, s.until());

		v = DataSeries.wrap(new double[] { 8.0, 9.0, 10.0 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(0.0, s.value(), EPSILON);
		assertEquals(0.0, s.relative(), EPSILON);
		assertEquals(-1, s.from());
		assertEquals(-1, s.until());

		/*
		 * Example from
		 * http://www.investopedia.com/terms/m/maximum-drawdown-mdd.asp
		 */
		v = DataSeries.wrap(new double[] { 500_000, 750_000, 400_000, 600_000, 350_000, 800_000 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(400_000, s.value(), EPSILON);
		assertEquals(0.5333, s.relative(), EPSILON);
		assertEquals(1, s.from());
		assertEquals(4, s.until());

		/*
		 * Test new peak but lower decline.
		 */
		v = DataSeries.wrap(new double[] { 500_000, 750_000, 400_000, 600_000, 350_000, 800_000, 600_000 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(400_000, s.value(), EPSILON);
		assertEquals(0.5333, s.relative(), EPSILON);
		assertEquals(1, s.from());
		assertEquals(4, s.until());

		/*
		 * Test new peak and greater decline.
		 */
		v = DataSeries.wrap(new double[] { 500_000, 750_000, 400_000, 600_000, 350_000, 800_000, 350_000 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(450_000, s.value(), EPSILON);
		assertEquals(0.5625, s.relative(), EPSILON);
		assertEquals(5, s.from());
		assertEquals(6, s.until());

		v = DataSeries.wrap(new double[] { 8.378456888472354E7, 8.177224406351142E7, 7.966388819489145E7,
				7.950800213321766E7, 8.033721858182411E7, 8.303011769643052E7, 8.761675949777159E7, 9.06329474496617E7,
				9.148398586771888E7, 9.024303397071314E7, 9.192705845050988E7, 9.414570227351305E7, 8.930681717864667E7,
				8.476789644579764E7, 9.03843877384278E7, 9.190366414572445E7, 9.247488839975385E7, 8.708773161420067E7,
				8.562862564652352E7, 9.353098516705063E7, 9.770337962658955E7, 9.746848952290133E7, 9.815353094128813E7,
				1.0114133615933691E8, 9.421573520868476E7, 9.883170916532305E7, 9.816851510401574E7, 9.16958926307428E7,
				9.168580830761471E7, 9.606633154808044E7, 9.623915488639367E7, 9.873435029399855E7,
				1.0137147914211535E8, 1.0748844566751684E8, 1.0915293196185544E8, 1.1336753100675483E8,
				1.1557479322790618E8 });
		s = Maths.draw(v, Maths.Trend.DOWN);
		assertEquals(9377805.827715412, s.value(), EPSILON);
		assertEquals(0.0996, s.relative(), EPSILON);
		assertEquals(11, s.from());
		assertEquals(13, s.until());
	}

	@Test
	public void testMaximumDrawUp() {
		final DataSeries v = DataSeries
				.wrap(new double[] { 10.0, 11.0, 10.0, 9.0, 9.0, 10.0, 11.0, 12.0, 13.0, 12.0, 12.0, 12.0 });
		final Maths.Draw s = Maths.draw(v, Maths.Trend.UP);
		assertEquals(4.0, s.value(), EPSILON);
		assertEquals(3, s.from());
		assertEquals(8, s.until());
	}

	@Test
	public void testPortfolioWithoutRebalancing() {

		final double[] money = new double[] { 60_000, 20_000, 20_000 };
		final DataSeries[] prices = new DataSeries[money.length];
		prices[0] = DataSeries.wrap(new double[] { 100, 110, 110 });
		prices[1] = DataSeries.wrap(new double[] { 50, 45, 50 });
		prices[2] = DataSeries.wrap(new double[] { 50, 55, 50 });

		final DataSeries portfolio = Maths.valuation(money, prices, 0);

		double value = money[0] + money[1] + money[2];
		assertEquals(value, portfolio.get(0), EPSILON);
		value = (1.1 * money[0]) + (0.9 * money[1]) + (1.1 * money[2]);
		assertEquals(value, portfolio.get(1), EPSILON);
		assertEquals(106_000.0, portfolio.get(1), EPSILON);
		value = (1.1 * money[0]) + (money[1]) + (money[2]);
		assertEquals(value, portfolio.get(2), EPSILON);
		assertEquals(106_000.0, portfolio.get(2), EPSILON);

	}

	@Test
	public void testPortfolioWithoutRebalancingP360() {
		{
			final double[] money = new double[] { 0.5, 0.5 };
			final DataSeries[] prices = new DataSeries[money.length];
			prices[0] = DataSeries.wrap(new double[] { 6.27, 6.25, 6.9 });
			prices[1] = DataSeries.wrap(new double[] { 7.2657, 7.3757, 7.3032 });

			final DataSeries portfolio = Maths.valuation(money, prices, 0);

			System.out.println(portfolio.toString());
		}

		{
			final double[] money = new double[] { 0.5264099, 0.5264099 };
			final DataSeries[] prices = new DataSeries[money.length];
			prices[0] = DataSeries.wrap(new double[] { 7.34, 6.82, 6.61 });
			prices[1] = DataSeries.wrap(new double[] { 7.2173, 7.2766, 7.2193 });

			final DataSeries portfolio = Maths.valuation(money, prices, 0);

			System.out.println(portfolio.toString());
		}

	}

	@Test
	public void testPortfoliowithRebalancingBeyondSeries() {

		final double[] money = new double[] { 60_000, 20_000, 20_000 };
		final DataSeries[] prices = new DataSeries[money.length];
		prices[0] = DataSeries.wrap(new double[] { 100, 110, 110 });
		prices[1] = DataSeries.wrap(new double[] { 50, 45, 50 });
		prices[2] = DataSeries.wrap(new double[] { 50, 55, 50 });

		final DataSeries portfolio = Maths.valuation(money, prices, 6);
		final DataSeries control = Maths.valuation(money, prices, 0);

		for (int i = 0; i < portfolio.size(); i++) {
			assertEquals(control.value(i), portfolio.value(i), EPSILON);
		}

	}

	@Test
	public void testPortfoliowithRebalancingWithinSeries() {

		final double[] money = new double[] { 60_000, 20_000, 20_000 };
		final DataSeries[] prices = new DataSeries[money.length];
		prices[0] = DataSeries.wrap(new double[] { 100, 110, 110 });
		prices[1] = DataSeries.wrap(new double[] { 50, 45, 50 });
		prices[2] = DataSeries.wrap(new double[] { 50, 55, 50 });

		final DataSeries portfolio = Maths.valuation(money, prices, 2);
		final DataSeries control = Maths.valuation(money, prices, 0);

		/*
		 * First two months are identical.
		 */
		for (int i = 0; i < 2; i++) {
			assertEquals(control.value(i), portfolio.value(i), EPSILON);
		}

		/*
		 * Third month we recalculate money per asset based on original weights
		 * ...
		 */
		final double[] w = new double[] { 0.6, 0.2, 0.2 };
		final double[] m = new double[3];
		for (int i = 0; i < 3; i++) {
			m[i] = w[i] * portfolio.value(1);
		}
		/*
		 * ... and reset price relatives
		 */
		final double[] r = new double[] { 110.0 / 110.0, 50.0 / 45.0, 50.0 / 55.0 };
		/*
		 * ... then apply to calculate final portfolio month.
		 */
		double pv = 0.0;
		for (int i = 0; i < 3; i++) {
			pv += m[i] * r[i];
		}
		assertEquals(106428.2828, pv, EPSILON);
		assertEquals(pv, portfolio.value(2), EPSILON);
	}

	@Test
	public void testPortfoliowithRebalancingWithinSeriesP360() {

		final double[] money = new double[] { 0.5, 0.5 };
		final DataSeries[] prices = new DataSeries[money.length];
		prices[0] = DataSeries.wrap(new double[] { 7.43, 6.55, 6.27, 6.25, 6.9, 7.34 });
		prices[1] = DataSeries.wrap(new double[] { 7.0092, 7.1806, 7.2657, 7.3757, 7.3032, 7.2173 });

		final DataSeries portfolio = Maths.valuation(money, prices, 3);
		System.out.println(portfolio.toString());
	}

	@Test
	public void testPadding() {
		final double[] px = { -1, -1, -1, 3, 4, 5, 6, -1, -1, -1 };
		Maths.pad(px, 3, true, false);
		assertEquals(0, px[0], 0.1);
		assertEquals(0, px[1], 0.1);
		assertEquals(0, px[2], 0.1);
		assertEquals(3, px[3], 0.1);
		Maths.pad(px, 3, true, true);
		assertEquals(-1, px[0], 0.1);
		assertEquals(-1, px[1], 0.1);
		assertEquals(-1, px[2], 0.1);
		assertEquals(3, px[3], 0.1);
		Maths.pad(px, 3, false, false);
		assertEquals(6, px[6], 0.1);
		assertEquals(0, px[7], 0.1);
		assertEquals(0, px[8], 0.1);
		assertEquals(0, px[9], 0.1);
		Maths.pad(px, 3, false, true);
		assertEquals(6, px[6], 0.1);
		assertEquals(6, px[7], 0.1);
		assertEquals(6, px[8], 0.1);
		assertEquals(6, px[9], 0.1);
	}

	@Test
	public void testBackfilling() {
		/*
		 * The required range, 2014-03-31 to 2015-03-31.
		 */
		final List<LocalDate> dates = API.monthEndList(LocalDate.of(2014, 03, 01), LocalDate.of(2015, 03, 01));
		/*
		 * The required full price series.
		 */
		final double[] prices = new double[dates.size()];
		/*
		 * The price series for the asset. Note price points for August,
		 * November and December differ from the generated date range.
		 */
		final String priceResponse = "[{\"local-date\": 20140630, \"close-px\": 140.8},"
				+ "{\"local-date\": 20140731, \"close-px\": 141.64},"
				+ "{\"local-date\": 20140829, \"close-px\": 143.11},"
				+ "{\"local-date\": 20140930, \"close-px\": 142.69},"
				+ "{\"local-date\": 20141031, \"close-px\": 144.71},"
				+ "{\"local-date\": 20141128, \"close-px\": 148.12},"
				+ "{\"local-date\": 20141230, \"close-px\": 148.89}]";
		final JsonArray priceArray = API.parseArray(priceResponse);
		/*
		 * Calculate.
		 */
		final Maths.Align align = new Maths.Align(priceArray, "local-date", "close-px", dates, prices);
		align.run();

		assertEquals(3, align.gapBefore());
		assertEquals(0.0, prices[0], EPSILON);
		assertEquals(0.0, prices[1], EPSILON);
		assertEquals(0.0, prices[2], EPSILON);
		assertEquals(140.8, prices[3], EPSILON);

		assertEquals(148.89, prices[9], EPSILON);
		assertEquals(3, align.gapAfter());
		assertEquals(0.0, prices[10], EPSILON);
		assertEquals(0.0, prices[11], EPSILON);
		assertEquals(0.0, prices[12], EPSILON);
		/*
		 * Mock retrieval of benchmark prices for the WHOLE period.
		 */
		final double[] benchmarks = new double[dates.size()];
		for (int i = 0; i < dates.size(); i++) {
			switch (i) {
			case 0:
				benchmarks[i] = 100.0;
				break;
			default:
				benchmarks[i] = benchmarks[i - 1] * 1.1;
			}
		}
		assertEquals(100.0, benchmarks[0], EPSILON);
		assertEquals(313.8428, benchmarks[12], EPSILON);
		/*
		 * Fill before ...
		 */
		Maths.fill(prices, benchmarks, 0, align.gapBefore(), true);
		/*
		 * Benchmark grows at 10%
		 *
		 * ... 100 110 121 133.1
		 *
		 * multiply by 140.8
		 *
		 * ... 14080 15488 17036.8 18740.48
		 *
		 * divide by 133.1
		 *
		 * ... 105.7851 116.3636 128 140.8
		 */
		assertEquals(105.7851, prices[0], EPSILON);
		assertEquals(116.3636, prices[1], EPSILON);
		assertEquals(128.0000, prices[2], EPSILON);
		/*
		 * The next point is unchanged.
		 */
		assertEquals(140.8, prices[3], EPSILON);
		/*
		 * Fill after ...
		 */
		Maths.fill(prices, benchmarks, 0, align.gapBefore(), false);
		/*
		 * Benchmark grows at 10%
		 *
		 * ... 235.7947 259.3742 285.3116 313.8428
		 *
		 * multiply by 148.89
		 *
		 * ... 35107.4843 38618.2315 42480.0546 46728.0601
		 *
		 * divide by 235.7947
		 *
		 * ... 148.89 163.779 180.1569 198.1726
		 */
		assertEquals(163.7790, prices[10], EPSILON);
		assertEquals(180.1569, prices[11], EPSILON);
		assertEquals(198.1726, prices[12], EPSILON);
		/*
		 * Try again with the smallest number of missing points ...
		 */
		Maths.fill(prices, benchmarks, 0, 1, true);
		assertEquals(105.7851, prices[0], EPSILON);
		Maths.fill(prices, benchmarks, 0, 1, false);
		assertEquals(198.1726, prices[12], EPSILON);
	}

	@Test
	public void testAlignWithoutPriceForMay() {
		/*
		 * The required range, 2017-03-31 to 2017-05-31.
		 */
		final List<LocalDate> dates = API.monthEndList(LocalDate.of(2017, 03, 31), LocalDate.of(2017, 05, 31));
		/*
		 * The required full price series.
		 */
		final double[] prices = new double[dates.size()];
		/*
		 * Available prices.
		 */
		final JsonArray priceArray = API.parseArray(
				"[{\"local-date\": 20170331, \"close-px\": 8.100711},{\"local-date\": 20170428, \"close-px\": 8.11}]");
		assertEquals(2, priceArray.size());
		final Maths.Align align = new Maths.Align(priceArray, "local-date", "close-px", dates, prices);
		align.run();
		assertEquals(0, align.gapBefore());
		assertEquals(1, align.gapAfter());
	}

	@Test
	public void testBackfillEverything() {
		/*
		 * The required range, 2014-03-31 to 2015-03-31.
		 */
		final List<LocalDate> dates = API.monthEndList(LocalDate.of(2014, 03, 01), LocalDate.of(2015, 03, 01));
		/*
		 * The required full price series.
		 */
		final double[] prices = new double[dates.size()];
		/*
		 * The price series for the asset. Note price points for August,
		 * November and December differ from the generated date range.
		 */
		final JsonArray priceArray = API.parseArray("[]");
		/*
		 * Calculate.
		 */
		final Maths.Align align = new Maths.Align(priceArray, "local-date", "close-px", dates, prices);
		align.run();
		assertEquals(prices.length, align.gapBefore());
		/*
		 * Mock retrieval of benchmark prices for the WHOLE period.
		 */
		final double[] benchmarks = new double[dates.size()];
		for (int i = 0; i < dates.size(); i++) {
			switch (i) {
			case 0:
				benchmarks[i] = 100.0;
				break;
			default:
				benchmarks[i] = benchmarks[i - 1] * 1.1;
			}
		}
		/*
		 * Fill before ...
		 */
		Maths.fill(prices, benchmarks, Double.NaN, align.gapBefore(), true);
		assertEquals(100.0, prices[0], EPSILON);
		assertEquals(313.8428, prices[12], EPSILON);
		/*
		 * SLYAWS-10720
		 */
		final double[] px = new double[dates.size()];
		Maths.fill(px, benchmarks, 0.5, align.gapBefore(), true);
		assertEquals(0.1593, px[0], EPSILON);
		assertEquals(0.5, px[px.length - 1], EPSILON);
	}

	@Test
	public void testValuationWithZero() {
		final double[] weight = new double[] { 0.5, 0.5 };
		final DataSeries[] prices = new DataSeries[weight.length];
		prices[0] = DataSeries.wrap(new double[] { 100, 110, 120 });
		prices[1] = DataSeries.wrap(new double[] { 0, 0, 100 });

		final double[] expected = new double[] { 0.5, 0.55, 1.1 };

		DataSeries portfolio = Maths.valuation(weight, prices, 0);

		int i = 0;
		for (final double pv : portfolio.values()) {
			assertFalse(Double.isNaN(pv));
			assertEquals(expected[i++], pv, EPSILON);
		}

		portfolio = Maths.valuation(weight, prices, 6);

		i = 0;
		for (final double pv : portfolio.values()) {
			assertFalse(Double.isNaN(pv));
			assertEquals(expected[i++], pv, EPSILON);
		}
	}

	@Test
	public void testAnnualised() {
		/*
		 * Test basics
		 */
		assertEquals(0.1236, Maths.annualisedReturn(0.06, 7), EPSILON);
		assertEquals(0.2078, Maths.annualisedStandardDeviation(0.06, PriceType.MONTHLY), EPSILON);

	}

	/** Test Case : DualTimeseriesMetricsGeneratorTestCase_20180724.ods */
	@Test
	public void testCorrelation() {

		// 12 months99954976
		{
			double[] values1 = new double[] { 1286.12, 1327.22, 1325.83, 1363.61, 1345.2, 1320.64, 1292.28, 1218.89,
					1131.42, 1253.3, 1246.96, 1257.6, 1312.41 };
			double[] values2 = new double[] { 126.04, 130.41, 130.43, 134.21, 132.7, 130.46, 127.85, 120.82, 112.44,
					124.71, 124.2, 125.5, 131.32 };

			assertEquals(0.99988844, Maths.calculateCorrelation(DataSeries.wrap(values1), DataSeries.wrap(values2)),
					0.00000001);
		}

		// 24 months
		{
			double[] values1 = new double[] { 1073.87, 1104.49, 1169.43, 1186.69, 1089.41, 1030.71, 1101.6, 1049.33,
					1141.2, 1183.26, 1180.55, 1257.64, 1286.12, 1327.22, 1325.83, 1363.61, 1345.2, 1320.64, 1292.28,
					1218.89, 1131.42, 1253.3, 1246.96, 1257.6, 1312.41 };
			double[] values2 = new double[] { 103.58, 106.81, 112.85, 114.6, 105.49, 100.03, 106.87, 102.06, 111.2,
					115.45, 115.45, 123.17, 126.04, 130.41, 130.43, 134.21, 132.7, 130.46, 127.85, 120.82, 112.44,
					124.71, 124.2, 125.5, 131.32 };

			assertEquals(0.99979151, Maths.calculateCorrelation(DataSeries.wrap(values1), DataSeries.wrap(values2)),
					0.00000001);
		}

		// 36 months
		{
			double[] values1 = new double[] { 825.88, 735.09, 797.87, 872.81, 919.14, 919.32, 987.48, 1020.62, 1057.08,
					1036.19, 1095.63, 1115.1, 1073.87, 1104.49, 1169.43, 1186.69, 1089.41, 1030.71, 1101.6, 1049.33,
					1141.2, 1183.26, 1180.55, 1257.64, 1286.12, 1327.22, 1325.83, 1363.61, 1345.2, 1320.64, 1292.28,
					1218.89, 1131.42, 1253.3, 1246.96, 1257.6, 1312.41 };
			double[] values2 = new double[] { 78.09, 69.7, 75.5, 83, 87.85, 87.8, 94.35, 97.83, 101.3, 99.35, 105.47,
					107.49, 103.58, 106.81, 112.85, 114.6, 105.49, 100.03, 106.87, 102.06, 111.2, 115.45, 115.45,
					123.17, 126.04, 130.41, 130.43, 134.21, 132.7, 130.46, 127.85, 120.82, 112.44, 124.71, 124.2, 125.5,
					131.32 };

			assertEquals(0.99954976, Maths.calculateCorrelation(DataSeries.wrap(values1), DataSeries.wrap(values2)),
					0.00000001);
		}

		// Since Inception 227 months
		{
			double[] values1 = new double[] { 438.78, 443.38, 451.67, 440.19, 450.19, 450.53, 448.13, 463.56, 458.93,
					467.83, 461.79, 466.45, 481.61, 467.14, 445.77, 450.91, 456.5, 444.27, 458.26, 475.49, 462.71,
					472.35, 453.69, 459.27, 470.42, 487.39, 500.71, 514.71, 533.4, 544.75, 562.06, 561.88, 584.41,
					581.5, 605.37, 615.93, 636.02, 640.43, 645.5, 654.17, 669.12, 670.63, 639.95, 651.99, 687.33,
					705.27, 757.02, 740.74, 786.16, 790.82, 757.12, 801.34, 848.28, 885.14, 954.31, 899.47, 947.28,
					914.62, 955.4, 970.43, 980.28, 1049.34, 1101.75, 1111.75, 1090.82, 1133.84, 1120.67, 957.28,
					1017.01, 1098.67, 1163.63, 1229.23, 1279.64, 1238.33, 1286.37, 1335.18, 1301.84, 1372.71, 1328.72,
					1320.41, 1282.71, 1362.93, 1388.91, 1469.25, 1394.46, 1366.42, 1498.58, 1452.43, 1420.6, 1454.6,
					1430.83, 1517.68, 1436.51, 1429.4, 1314.95, 1320.28, 1366.01, 1239.94, 1160.33, 1249.46, 1255.82,
					1224.38, 1211.23, 1133.58, 1040.94, 1059.78, 1139.45, 1148.08, 1130.2, 1106.73, 1147.39, 1076.92,
					1067.14, 989.82, 911.62, 916.07, 815.28, 885.76, 936.31, 879.82, 855.7, 841.15, 848.18, 916.92,
					963.59, 974.5, 990.31, 1008.01, 995.97, 1050.71, 1058.2, 1111.92, 1131.13, 1144.94, 1126.21, 1107.3,
					1120.68, 1140.84, 1101.72, 1104.24, 1114.58, 1130.2, 1173.82, 1211.92, 1181.27, 1203.6, 1180.59,
					1156.85, 1191.5, 1191.33, 1234.18, 1220.33, 1228.81, 1207.01, 1249.48, 1248.29, 1280.08, 1280.66,
					1294.87, 1310.61, 1270.09, 1270.2, 1276.66, 1303.82, 1335.85, 1377.94, 1400.63, 1418.3, 1438.24,
					1406.82, 1420.86, 1482.37, 1530.62, 1503.35, 1455.27, 1473.99, 1526.75, 1549.38, 1481.14, 1468.36,
					1378.55, 1330.63, 1322.7, 1385.59, 1400.38, 1280, 1267.38, 1282.83, 1166.36, 968.75, 896.24, 903.25,
					825.88, 735.09, 797.87, 872.81, 919.14, 919.32, 987.48, 1020.62, 1057.08, 1036.19, 1095.63, 1115.1,
					1073.87, 1104.49, 1169.43, 1186.69, 1089.41, 1030.71, 1101.6, 1049.33, 1141.2, 1183.26, 1180.55,
					1257.64, 1286.12, 1327.22, 1325.83, 1363.61, 1345.2, 1320.64, 1292.28, 1218.89, 1131.42, 1253.3,
					1246.96, 1257.6, 1312.41 };
			double[] values2 = new double[] { 31.29, 31.63, 32.42, 31.59, 32.45, 32.53, 32.37, 33.62, 33.37, 34.03,
					33.66, 34.05, 35.24, 34.21, 32.78, 33.15, 33.68, 32.91, 33.97, 35.27, 34.59, 35.57, 34.16, 34.36,
					35.51, 36.97, 38.02, 39.15, 40.7, 41.52, 42.86, 43.05, 44.87, 44.74, 46.73, 47.41, 49.1, 49.26,
					50.13, 50.68, 51.82, 52.26, 49.91, 50.88, 53.44, 55.17, 59.2, 57.76, 61.33, 61.92, 59.21, 62.92,
					66.9, 69.64, 75.16, 71.26, 74.69, 72.86, 75.68, 77.1, 78.09, 83.5, 87.61, 88.72, 86.88, 90.58,
					89.35, 76.74, 81.61, 88.23, 93.14, 99.2, 102.7, 99.4, 103.56, 107.48, 105.02, 110.8, 107.37, 106.81,
					104.41, 111.1, 112.95, 119.41, 113.45, 111.73, 122.56, 118.25, 116.39, 118.68, 116.82, 124.45,
					117.63, 117.07, 108.33, 107.73, 112.52, 101.79, 96.08, 104.29, 103.71, 101.23, 100.2, 94.26, 86.56,
					87.69, 94.53, 94.74, 93.81, 92.13, 95.19, 89.65, 89.12, 82.54, 76.04, 76.56, 68.53, 74.17, 78.74,
					74.29, 72.46, 71.48, 71.64, 77.7, 81.96, 82.83, 84.33, 86.06, 85.13, 89.68, 90.66, 95.22, 97.11,
					98.42, 97.12, 95.28, 96.91, 98.71, 95.53, 95.76, 96.72, 97.97, 102.33, 105.41, 103.05, 105.2,
					103.28, 101.34, 104.61, 104.77, 108.77, 107.75, 108.62, 106.05, 110.71, 110.5, 113.15, 113.8,
					115.68, 117.14, 113.61, 113.91, 114.42, 116.92, 120.07, 123.86, 126.32, 128.01, 129.93, 127.38,
					128.86, 134.57, 139.13, 137.1, 132.81, 134.51, 139.72, 141.61, 136.13, 134.6, 126.46, 123.19,
					122.09, 127.91, 129.84, 118.99, 117.92, 119.74, 108.47, 90.55, 84.25, 85.07, 78.09, 69.7, 75.5, 83,
					87.85, 87.8, 94.35, 97.83, 101.3, 99.35, 105.47, 107.49, 103.58, 106.81, 112.85, 114.6, 105.49,
					100.03, 106.87, 102.06, 111.2, 115.45, 115.45, 123.17, 126.04, 130.41, 130.43, 134.21, 132.7,
					130.46, 127.85, 120.82, 112.44, 124.71, 124.2, 125.5, 131.32 };

			assertEquals(0.99733425, Maths.calculateCorrelation(DataSeries.wrap(values1), DataSeries.wrap(values2)),
					0.00000001);
		}
	}

	@Test
	public void testCalculateWeightedStatistics() {
		assertEquals(0.5701068, Maths.calculateWeightedStatistics(0.950177789, 238482.0, 238482.0 + 158988.0), 0.0001);
		assertEquals(0.013947, Maths.calculateWeightedStatistics(0.02324531, 238482.0, 238482.0 + 158988.0), 0.0001);
	}

}
