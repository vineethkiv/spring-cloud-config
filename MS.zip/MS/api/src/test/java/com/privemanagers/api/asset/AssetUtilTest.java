package com.privemanagers.api.asset;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Test for {@link AssetUtil}
 *
 * @author Gavy Lau
 * @date 7 Nov 2018
 * @company Prive Financial
 */
public class AssetUtilTest {

	@Test
	public void testISIN() {

		assertTrue(AssetUtil.isIsin("US0378331005"));
		assertTrue(AssetUtil.isIsin("AU0000XVGZA3"));
		assertTrue(AssetUtil.isIsin("FR0000988040"));
		assertTrue(AssetUtil.isIsin("IE0000830459"));

		// length test
		assertFalse(AssetUtil.isIsin("FR000098804"));
		assertFalse(AssetUtil.isIsin("FR00009880400"));

		// 2 alphabet leading character
		assertFalse(AssetUtil.isIsin("A00000XVGZA3"));
		assertFalse(AssetUtil.isIsin("0A0000XVGZA3"));

		// null and empty string
		assertFalse(AssetUtil.isIsin(""));
		assertFalse(AssetUtil.isIsin(null));
	}

}
