package com.privemanagers.api;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Tests {

	@Test
	public void testCurrencies() {
		final String[] currencies = new String[] { "EUR", "GBP", "HKD", "KRW", "SGD", "TWD", "USD", "CNY", "CNH" };
		for (final String iso : currencies) {
			assertTrue(API.validateCurrencyCode(iso));
		}
	}

	// useless comment to trigger jenkins

}
