declare const enum contact_educationcode {
  DefaultValue = 1,
}
