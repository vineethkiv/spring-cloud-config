declare const enum msevtmgt_publishstatus {
  Draft = 100000000,
  Readytogolive = 100000001,
  Inprogress = 100000002,
  Live = 100000003,
  Canceled = 100000004,
  Goinglive = 100000005,
}
