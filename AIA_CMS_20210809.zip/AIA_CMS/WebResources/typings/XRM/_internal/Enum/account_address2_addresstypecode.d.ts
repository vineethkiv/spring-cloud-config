declare const enum account_address2_addresstypecode {
  DefaultValue = 1,
}
