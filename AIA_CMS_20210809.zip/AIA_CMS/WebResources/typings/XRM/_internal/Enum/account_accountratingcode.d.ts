declare const enum account_accountratingcode {
  DefaultValue = 1,
}
