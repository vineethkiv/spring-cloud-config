declare const enum contact_shippingmethodcode {
  DefaultValue = 1,
}
