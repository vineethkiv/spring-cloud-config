declare const enum account_territorycode {
  DefaultValue = 1,
}
