declare const enum msevtmgt_yesorno {
  Yes = 100000001,
  No = 100000002,
}
