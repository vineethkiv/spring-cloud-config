declare const enum contact_address1_freighttermscode {
  FOB = 1,
  NoCharge = 2,
}
