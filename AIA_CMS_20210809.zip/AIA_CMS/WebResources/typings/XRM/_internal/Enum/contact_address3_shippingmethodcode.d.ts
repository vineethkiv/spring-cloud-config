declare const enum contact_address3_shippingmethodcode {
  DefaultValue = 1,
}
