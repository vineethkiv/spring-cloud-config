declare const enum connection_statecode {
  Active = 0,
  Inactive = 1,
}
