declare const enum contact_customertypecode {
  DefaultValue = 1,
}
