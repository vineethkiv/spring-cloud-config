declare const enum account_statuscode {
  Active = 1,
  Inactive = 2,
}
