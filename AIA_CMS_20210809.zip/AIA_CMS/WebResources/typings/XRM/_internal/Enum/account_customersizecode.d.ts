declare const enum account_customersizecode {
  DefaultValue = 1,
}
