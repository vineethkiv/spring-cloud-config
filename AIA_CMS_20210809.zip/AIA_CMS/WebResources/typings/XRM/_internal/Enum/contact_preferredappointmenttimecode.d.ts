declare const enum contact_preferredappointmenttimecode {
  Morning = 1,
  Afternoon = 2,
  Evening = 3,
}
