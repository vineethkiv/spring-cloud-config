declare const enum account_address2_shippingmethodcode {
  DefaultValue = 1,
}
