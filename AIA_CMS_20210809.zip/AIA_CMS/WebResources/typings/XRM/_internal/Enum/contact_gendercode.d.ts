declare const enum contact_gendercode {
  Male = 1,
  Female = 2,
}
