declare const enum contact_customersizecode {
  DefaultValue = 1,
}
