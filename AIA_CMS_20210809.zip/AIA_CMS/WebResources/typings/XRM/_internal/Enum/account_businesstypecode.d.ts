declare const enum account_businesstypecode {
  DefaultValue = 1,
}
