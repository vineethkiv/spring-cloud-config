declare const enum account_preferredappointmenttimecode {
  Morning = 1,
  Afternoon = 2,
  Evening = 3,
}
