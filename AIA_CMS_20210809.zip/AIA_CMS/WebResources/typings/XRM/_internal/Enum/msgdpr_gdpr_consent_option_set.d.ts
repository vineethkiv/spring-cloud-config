declare const enum msgdpr_gdpr_consent_option_set {
  _1Consent = 587030001,
  _2Transactional = 587030002,
  _3Subscriptions = 587030003,
  _4Marketing = 587030004,
  _5Profiling = 587030005,
}
