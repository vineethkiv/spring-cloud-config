declare const enum contact_paymenttermscode {
  Net30 = 1,
  _210Net30 = 2,
  Net45 = 3,
  Net60 = 4,
}
