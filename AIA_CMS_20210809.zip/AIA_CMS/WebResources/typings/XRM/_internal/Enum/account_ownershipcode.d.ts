declare const enum account_ownershipcode {
  Public = 1,
  Private = 2,
  Subsidiary = 3,
  Other = 4,
}
