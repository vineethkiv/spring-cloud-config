declare const enum act_msevtmgt_event_act_contesttype {
  KRA = 805140000,
  NB = 805140001,
}
