declare const enum msevtmgt_descriptorsyncstatus {
  Synced = 100000000,
  Goinglive = 100000001,
  Goinglivefailed = 100000002,
  Modifyingcapacity = 100000003,
  Modifyingcapacityfailed = 100000004,
  NotSynced = 100000005,
}
