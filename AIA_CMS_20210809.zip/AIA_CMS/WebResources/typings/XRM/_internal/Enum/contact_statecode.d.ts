declare const enum contact_statecode {
  Active = 0,
  Inactive = 1,
}
