declare const enum msevtmgt_event_statecode {
  Active = 0,
  Inactive = 1,
}
