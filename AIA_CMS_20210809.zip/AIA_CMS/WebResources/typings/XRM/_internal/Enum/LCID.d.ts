declare const enum LCID {
  English = 1033,
}
