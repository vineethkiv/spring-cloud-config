declare const enum msevtmgt_notifyauthoritiesofeventoptionset {
  Notapplicable = 100000001,
  Incomplete = 100000002,
  Complete = 100000003,
}
