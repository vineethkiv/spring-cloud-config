declare const enum account_address1_addresstypecode {
  BillTo = 1,
  ShipTo = 2,
  Primary = 3,
  Other = 4,
}
