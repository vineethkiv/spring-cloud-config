declare const enum act_rollupline_act_orderby {
  Asc = 805140000,
  Desc = 805140001,
}
