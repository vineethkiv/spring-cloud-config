declare const enum contact_address1_shippingmethodcode {
  Airborne = 1,
  DHL = 2,
  FedEx = 3,
  UPS = 4,
  PostalMail = 5,
  FullLoad = 6,
  WillCall = 7,
}
