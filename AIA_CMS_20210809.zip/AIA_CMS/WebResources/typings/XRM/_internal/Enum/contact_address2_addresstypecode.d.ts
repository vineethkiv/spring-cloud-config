declare const enum contact_address2_addresstypecode {
  DefaultValue = 1,
}
