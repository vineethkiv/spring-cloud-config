declare const enum act_rollupline_act_aggregator {
  Exact = 805140000,
  Sum = 805140001,
  Count = 805140002,
}
