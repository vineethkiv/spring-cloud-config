declare const enum msevtmgt_primarygoal {
  Marketing = 100000001,
  Sales = 100000002,
  Education = 100000003,
  Morale = 100000004,
}
