declare const enum contact_address3_freighttermscode {
  DefaultValue = 1,
}
