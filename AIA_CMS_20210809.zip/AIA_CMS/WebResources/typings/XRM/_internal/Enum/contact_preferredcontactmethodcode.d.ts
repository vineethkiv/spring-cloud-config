declare const enum contact_preferredcontactmethodcode {
  Any = 1,
  Email = 2,
  Phone = 3,
  Fax = 4,
  Mail = 5,
}
