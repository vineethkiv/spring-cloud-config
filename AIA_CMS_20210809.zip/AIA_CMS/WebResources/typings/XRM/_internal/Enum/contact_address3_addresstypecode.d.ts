declare const enum contact_address3_addresstypecode {
  DefaultValue = 1,
}
