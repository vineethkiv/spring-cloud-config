declare const enum account_accountclassificationcode {
  DefaultValue = 1,
}
