declare const enum contact_leadsourcecode {
  DefaultValue = 1,
}
