declare const enum account_shippingmethodcode {
  DefaultValue = 1,
}
