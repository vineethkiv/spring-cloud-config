declare const enum msevtmgt_status {
  Notstarted = 100000001,
  Inprogress = 100000002,
  Completed = 100000003,
  Notapplicable = 100000004,
}
