declare const enum account_statecode {
  Active = 0,
  Inactive = 1,
}
