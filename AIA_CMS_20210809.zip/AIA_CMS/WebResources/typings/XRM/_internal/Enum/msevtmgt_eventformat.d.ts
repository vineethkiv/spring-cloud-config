declare const enum msevtmgt_eventformat {
  Onsite = 100000001,
  Webinar = 100000002,
  Hybrid = 100000003,
}
