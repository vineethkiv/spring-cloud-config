declare const enum contact_address2_freighttermscode {
  DefaultValue = 1,
}
