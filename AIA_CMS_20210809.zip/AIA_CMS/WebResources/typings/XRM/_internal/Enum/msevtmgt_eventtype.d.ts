declare const enum msevtmgt_eventtype {
  Executivebriefing = 100000001,
  Conference = 100000002,
  Demonstration = 100000003,
  Training = 100000004,
  Webcast = 100000005,
}
