declare const enum account_accountcategorycode {
  PreferredCustomer = 1,
  Standard = 2,
}
