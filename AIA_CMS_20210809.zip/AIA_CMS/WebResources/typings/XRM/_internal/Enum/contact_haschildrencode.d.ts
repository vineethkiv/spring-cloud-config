declare const enum contact_haschildrencode {
  DefaultValue = 1,
}
