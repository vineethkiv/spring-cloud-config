declare const enum contact_statuscode {
  Active = 1,
  Inactive = 2,
}
