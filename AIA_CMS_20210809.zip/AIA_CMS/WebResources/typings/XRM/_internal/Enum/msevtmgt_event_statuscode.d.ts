declare const enum msevtmgt_event_statuscode {
  Active = 1,
  Inactive = 2,
}
