declare const enum connection_statuscode {
  Active = 1,
  Inactive = 2,
}
