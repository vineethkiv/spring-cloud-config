declare const enum contact_msdyn_orgchangestatus {
  NoFeedback = 0,
  NotatCompany = 1,
  Ignore = 2,
}
