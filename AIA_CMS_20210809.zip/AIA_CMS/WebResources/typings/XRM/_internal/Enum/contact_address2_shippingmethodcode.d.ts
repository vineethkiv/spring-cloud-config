declare const enum contact_address2_shippingmethodcode {
  DefaultValue = 1,
}
