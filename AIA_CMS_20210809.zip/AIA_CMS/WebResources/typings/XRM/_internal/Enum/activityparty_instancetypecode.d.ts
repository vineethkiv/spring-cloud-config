declare const enum activityparty_instancetypecode {
  NotRecurring = 0,
  RecurringMaster = 1,
  RecurringInstance = 2,
  RecurringException = 3,
  RecurringFutureException = 4,
}
