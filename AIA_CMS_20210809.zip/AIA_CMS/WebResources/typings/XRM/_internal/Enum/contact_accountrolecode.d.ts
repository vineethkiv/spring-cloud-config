declare const enum contact_accountrolecode {
  DecisionMaker = 1,
  Employee = 2,
  Influencer = 3,
}
