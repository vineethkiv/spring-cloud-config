declare const enum account_address1_freighttermscode {
  FOB = 1,
  NoCharge = 2,
}
