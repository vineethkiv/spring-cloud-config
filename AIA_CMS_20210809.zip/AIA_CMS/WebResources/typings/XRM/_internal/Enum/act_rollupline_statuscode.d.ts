declare const enum act_rollupline_statuscode {
  Active = 1,
  Inactive = 2,
}
