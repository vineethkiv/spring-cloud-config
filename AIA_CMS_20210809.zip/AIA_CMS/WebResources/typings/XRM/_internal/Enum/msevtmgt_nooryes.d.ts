declare const enum msevtmgt_nooryes {
  No = 100000001,
  Yes = 100000002,
}
