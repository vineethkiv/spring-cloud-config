declare const enum account_address2_freighttermscode {
  DefaultValue = 1,
}
