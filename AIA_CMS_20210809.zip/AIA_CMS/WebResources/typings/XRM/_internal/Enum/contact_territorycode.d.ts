declare const enum contact_territorycode {
  DefaultValue = 1,
}
