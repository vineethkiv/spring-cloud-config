declare const enum contact_familystatuscode {
  Single = 1,
  Married = 2,
  Divorced = 3,
  Widowed = 4,
}
