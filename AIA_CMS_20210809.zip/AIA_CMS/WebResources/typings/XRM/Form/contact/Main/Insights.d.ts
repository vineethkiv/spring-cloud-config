declare namespace Form.contact.Main {
  namespace Insights {
    namespace Tabs {
      interface EmailInteractions extends Xrm.SectionCollectionBase {
        get(name: "EmailInteractions_ActivityBlockedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailBlockedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailClickedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailDeliveredList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailFeedbackLoopList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailForwardedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailHardBouncedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailOpenedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailSentList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailSoftBouncedList"): Xrm.PageSection;
        get(name: "EmailInteractions_EmailSubscriptionSubmitList"): Xrm.PageSection;
        get(name: "EmailInteractions_InsightsFilter"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
      interface EventInteractions extends Xrm.SectionCollectionBase {
        get(name: "EventInteractions_EventCheckInList"): Xrm.PageSection;
        get(name: "EventInteractions_EventRegistrationCanceledList"): Xrm.PageSection;
        get(name: "EventInteractions_EventRegistrationList"): Xrm.PageSection;
        get(name: "EventInteractions_InsightsFilter"): Xrm.PageSection;
        get(name: "EventInteractions_TimelineWidgetControlSection"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
      interface Insights extends Xrm.SectionCollectionBase {
        get(name: "Insights_InsightsFilter"): Xrm.PageSection;
        get(name: "Insights_InteractionsBreakdown"): Xrm.PageSection;
        get(name: "Insights_TimelineWidgetControlSection"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
      interface MarketingFormInteractions extends Xrm.SectionCollectionBase {
        get(name: "MarketingFormInteractions_FormSubmittedList"): Xrm.PageSection;
        get(name: "MarketingFormInteractions_FormVisitedList"): Xrm.PageSection;
        get(name: "MarketingFormInteractions_InsightsFilter"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
      interface OptimalEmailSendingTime extends Xrm.SectionCollectionBase {
        get(name: "OptimalEmailSendingTime_Prediction"): Xrm.PageSection;
        get(name: "OptimalEmailSendingTime_TimeToReact"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
      interface WebInteractions extends Xrm.SectionCollectionBase {
        get(name: "WebInteractions_InsightsFilter"): Xrm.PageSection;
        get(name: "WebInteractions_RedirectLinkClickedList"): Xrm.PageSection;
        get(name: "WebInteractions_WebsiteClickedList"): Xrm.PageSection;
        get(name: "WebInteractions_WebsiteVisitedList"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
      interface insights extends Xrm.SectionCollectionBase {
        get(name: "insights_section"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
    }
    interface Attributes extends Xrm.AttributeCollectionBase {
      get(name: "birthdate"): Xrm.DateAttribute | null;
      get(name: "emailaddress1"): Xrm.Attribute<string> | null;
      get(name: "familystatuscode"): Xrm.OptionSetAttribute<contact_familystatuscode> | null;
      get(name: "firstname"): Xrm.Attribute<string> | null;
      get(name: "industrycode"): Xrm.OptionSetAttribute<number> | null;
      get(name: "lastname"): Xrm.Attribute<string> | null;
      get(name: "middlename"): Xrm.Attribute<string> | null;
      get(name: "mobilephone"): Xrm.Attribute<string> | null;
      get(name: "msdyncrm_insights_placeholder"): Xrm.Attribute<any>;
      get(name: "name"): Xrm.Attribute<string> | null;
      get(name: "parentaccountid"): Xrm.LookupAttribute<"account"> | null;
      get(name: "spousesname"): Xrm.Attribute<string> | null;
      get(name: "telephone1"): Xrm.Attribute<string> | null;
      get(name: "websiteurl"): Xrm.Attribute<string> | null;
      get(name: string): undefined;
      get(): Xrm.Attribute<any>[];
      get(index: number): Xrm.Attribute<any>;
      get(chooser: (item: Xrm.Attribute<any>, index: number) => boolean): Xrm.Attribute<any>[];
    }
    interface Controls extends Xrm.ControlCollectionBase {
      get(name: "ActivityBlockedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "ContactInsightsCtrl"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailBlockedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailClickedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailDeliveredList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailFeedbackLoopList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailForwardedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailHardBouncedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailOpenedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailSentList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailSoftBouncedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EmailSubscriptionSubmitList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EventCheckInList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EventRegistrationCanceledListContact"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "EventRegistrationList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "FormSubmittedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "FormVisitedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "GwennolOptimalEmailSendingTime"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "GwennolTimeToReactControl"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InsightsFilter"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InsightsFilter1"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InsightsFilter2"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InsightsFilter3"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InsightsFilter4"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InteractionsBreakdown"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InteractionsTimeline"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "InteractionsTimelineLeadEvent"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "RedirectLinkClickedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "WebsiteClickedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "WebsiteVisitedList"): Xrm.Control<Xrm.Attribute<any>>;
      get(name: "header_process_birthdate"): Xrm.DateControl | null;
      get(name: "header_process_emailaddress1"): Xrm.StringControl | null;
      get(name: "header_process_familystatuscode"): Xrm.OptionSetControl<contact_familystatuscode> | null;
      get(name: "header_process_firstname"): Xrm.StringControl | null;
      get(name: "header_process_industrycode"): Xrm.OptionSetControl<number> | null;
      get(name: "header_process_lastname"): Xrm.StringControl | null;
      get(name: "header_process_middlename"): Xrm.StringControl | null;
      get(name: "header_process_mobilephone"): Xrm.StringControl | null;
      get(name: "header_process_name"): Xrm.StringControl | null;
      get(name: "header_process_parentaccountid"): Xrm.LookupControl<"account"> | null;
      get(name: "header_process_spousesname"): Xrm.StringControl | null;
      get(name: "header_process_telephone1"): Xrm.StringControl | null;
      get(name: "header_process_websiteurl"): Xrm.StringControl | null;
      get(name: string): undefined;
      get(): Xrm.BaseControl[];
      get(index: number): Xrm.BaseControl;
      get(chooser: (item: Xrm.BaseControl, index: number) => boolean): Xrm.BaseControl[];
    }
    interface Tabs extends Xrm.TabCollectionBase {
      get(name: "EmailInteractions"): Xrm.PageTab<Tabs.EmailInteractions>;
      get(name: "EventInteractions"): Xrm.PageTab<Tabs.EventInteractions>;
      get(name: "Insights"): Xrm.PageTab<Tabs.Insights>;
      get(name: "MarketingFormInteractions"): Xrm.PageTab<Tabs.MarketingFormInteractions>;
      get(name: "OptimalEmailSendingTime"): Xrm.PageTab<Tabs.OptimalEmailSendingTime>;
      get(name: "WebInteractions"): Xrm.PageTab<Tabs.WebInteractions>;
      get(name: "insights"): Xrm.PageTab<Tabs.insights>;
      get(name: string): undefined;
      get(): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
      get(index: number): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>;
      get(chooser: (item: Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>, index: number) => boolean): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
    }
  }
  interface Insights extends Xrm.PageBase<Insights.Attributes,Insights.Tabs,Insights.Controls> {
    getAttribute(attributeName: "birthdate"): Xrm.DateAttribute | null;
    getAttribute(attributeName: "emailaddress1"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "familystatuscode"): Xrm.OptionSetAttribute<contact_familystatuscode> | null;
    getAttribute(attributeName: "firstname"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "industrycode"): Xrm.OptionSetAttribute<number> | null;
    getAttribute(attributeName: "lastname"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "middlename"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "mobilephone"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "msdyncrm_insights_placeholder"): Xrm.Attribute<any>;
    getAttribute(attributeName: "name"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "parentaccountid"): Xrm.LookupAttribute<"account"> | null;
    getAttribute(attributeName: "spousesname"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "telephone1"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: "websiteurl"): Xrm.Attribute<string> | null;
    getAttribute(attributeName: string): undefined;
    getControl(controlName: "ActivityBlockedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "ContactInsightsCtrl"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailBlockedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailClickedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailDeliveredList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailFeedbackLoopList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailForwardedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailHardBouncedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailOpenedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailSentList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailSoftBouncedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EmailSubscriptionSubmitList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EventCheckInList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EventRegistrationCanceledListContact"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "EventRegistrationList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "FormSubmittedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "FormVisitedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "GwennolOptimalEmailSendingTime"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "GwennolTimeToReactControl"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InsightsFilter"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InsightsFilter1"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InsightsFilter2"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InsightsFilter3"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InsightsFilter4"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InteractionsBreakdown"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InteractionsTimeline"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "InteractionsTimelineLeadEvent"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "RedirectLinkClickedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "WebsiteClickedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "WebsiteVisitedList"): Xrm.Control<Xrm.Attribute<any>>;
    getControl(controlName: "header_process_birthdate"): Xrm.DateControl | null;
    getControl(controlName: "header_process_emailaddress1"): Xrm.StringControl | null;
    getControl(controlName: "header_process_familystatuscode"): Xrm.OptionSetControl<contact_familystatuscode> | null;
    getControl(controlName: "header_process_firstname"): Xrm.StringControl | null;
    getControl(controlName: "header_process_industrycode"): Xrm.OptionSetControl<number> | null;
    getControl(controlName: "header_process_lastname"): Xrm.StringControl | null;
    getControl(controlName: "header_process_middlename"): Xrm.StringControl | null;
    getControl(controlName: "header_process_mobilephone"): Xrm.StringControl | null;
    getControl(controlName: "header_process_name"): Xrm.StringControl | null;
    getControl(controlName: "header_process_parentaccountid"): Xrm.LookupControl<"account"> | null;
    getControl(controlName: "header_process_spousesname"): Xrm.StringControl | null;
    getControl(controlName: "header_process_telephone1"): Xrm.StringControl | null;
    getControl(controlName: "header_process_websiteurl"): Xrm.StringControl | null;
    getControl(controlName: string): undefined;
  }
}
