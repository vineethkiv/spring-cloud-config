﻿declare namespace Form.cms_award.Main {
    namespace Information {
        namespace Tabs {
            interface general extends Xrm.SectionCollectionBase {
                get(name: "rollingsection"): Xrm.PageSection;
                get(name: string): undefined;
                get(): Xrm.PageSection[];
                get(index: number): Xrm.PageSection;
                get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
            }
        }
        interface Attributes extends Xrm.AttributeCollectionBase {
            get(name: "cms_aggregate"): Xrm.OptionSetAttribute<boolean>;
            get(name: "cms_aggregator"): Xrm.OptionSetAttribute<cms_rollupline_cms_aggregator>;
            get(name: "cms_cap"): Xrm.NumberAttribute;
            get(name: "cms_distinct"): Xrm.OptionSetAttribute<boolean>;
            get(name: "cms_entity"): Xrm.OptionSetAttribute<cms_entity>;
            get(name: "cms_findnext"): Xrm.OptionSetAttribute<boolean>;
            get(name: "cms_max"): Xrm.NumberAttribute;
            get(name: "cms_name"): Xrm.Attribute<string>;
            get(name: "cms_orderby"): Xrm.OptionSetAttribute<cms_rollupline_cms_orderby>;
            get(name: "cms_relatedfield"): Xrm.OptionSetAttribute<cms_entityfields>;
            get(name: "cms_sortby"): Xrm.Attribute<string>;
            get(name: "cms_valueid"): Xrm.Attribute<string>;
            get(name: "cms_rollupid"): Xrm.LookupAttribute;
            get(name: string): undefined;
            get(): Xrm.Attribute<any>[];
            get(index: number): Xrm.Attribute<any>;
            get(chooser: (item: Xrm.Attribute<any>, index: number) => boolean): Xrm.Attribute<any>[];
        }
        interface Controls extends Xrm.ControlCollectionBase {
            get(name: "RollupCriteria"): Xrm.BaseControl;
            get(name: "cms_aggregate"): Xrm.OptionSetControl<boolean>;
            get(name: "cms_aggregator"): Xrm.OptionSetControl<cms_rollupline_cms_aggregator>;
            get(name: "cms_cap"): Xrm.NumberControl;
            get(name: "cms_distinct"): Xrm.OptionSetControl<boolean>;
            get(name: "cms_entity"): Xrm.OptionSetControl<cms_entity>;
            get(name: "cms_findnext"): Xrm.OptionSetControl<boolean>;
            get(name: "cms_max"): Xrm.NumberControl;
            get(name: "cms_name"): Xrm.StringControl;
            get(name: "cms_orderby"): Xrm.OptionSetControl<cms_rollupline_cms_orderby>;
            get(name: "cms_relatedfield"): Xrm.OptionSetControl<cms_entityfields>;
            get(name: "cms_sortby"): Xrm.StringControl;
            get(name: "cms_valueid"): Xrm.StringControl;
            get(name: string): undefined;
            get(): Xrm.BaseControl[];
            get(index: number): Xrm.BaseControl;
            get(chooser: (item: Xrm.BaseControl, index: number) => boolean): Xrm.BaseControl[];
        }
        interface Tabs extends Xrm.TabCollectionBase {
            get(name: "general"): Xrm.PageTab<Tabs.general>;
            get(name: string): undefined;
            get(): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
            get(index: number): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>;
            get(chooser: (item: Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>, index: number) => boolean): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
        }
    }
    interface Information extends Xrm.PageBase<Information.Attributes, Information.Tabs, Information.Controls> {
        getAttribute(attributeName: "cms_awardstartdate"): Xrm.DateAttribute;
        getAttribute(attributeName: "cms_awardsettlementdate"): Xrm.DateAttribute;
        getAttribute(attributeName: "cms_contestid"): Xrm.LookupAttribute;
        getAttribute(attributeName: "cms_awardperiod"): Xrm.NumberAttribute;
        getAttribute(attributeName: "cms_awardtype"): Xrm.OptionSetAttribute<cms_award_cms_awardtype>;

        getAttribute(attributeName: "cms_monthly"): Xrm.OptionSetAttribute<boolean>;
        getControl(controlName: "cms_monthly"): Xrm.OptionSetControl<boolean>;

        getAttribute(attributeName: "cms_rollinggroup"): Xrm.OptionSetAttribute<cms_award_cms_rollinggroup>;
        getControl(controlName: "cms_rollinggroup"): Xrm.OptionSetControl<cms_award_cms_rollinggroup>;

        getAttribute(attributeName: string): Xrm.DateAttribute;
        getControl(controlName: string): Xrm.DateControl;
    }
}
