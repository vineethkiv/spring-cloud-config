declare namespace Form.fieldValidation {
  namespace Information {
    namespace Tabs {
        interface general extends Xrm.SectionCollectionBase {
            get(name: "agenttitlesection"): Xrm.PageSection;
            get(name: "agenttypesection"): Xrm.PageSection;
            get(name: "mcvlocalsection"): Xrm.PageSection;
            get(name: "doysector"): Xrm.PageSection;
            get(name: "regionsector"): Xrm.PageSection;
            get(name: "teamsector"): Xrm.PageSection;
            get(name: "zonesector"): Xrm.PageSection;

            get(name: "lobsector"): Xrm.PageSection;
            get(name: "productgroupsector"): Xrm.PageSection;
            get(name: "productseriessector"): Xrm.PageSection;
            get(name: "submissionchannelsector"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
    }
    interface Attributes extends Xrm.AttributeCollectionBase {
      get(name: "cms_entity"): Xrm.OptionSetAttribute<cms_entity>;
      get(name: "cms_orderby"): Xrm.OptionSetAttribute<cms_rollupline_cms_orderby>;
      get(name: "cms_relatedfield"): Xrm.OptionSetAttribute<cms_entityfields>;
      get(name: "cms_sortby"): Xrm.Attribute<string>;
      get(name: "cms_valueid"): Xrm.Attribute<string>;
      get(name: "cms_rollupid"): Xrm.LookupAttribute;
      get(name: string): undefined;
      get(): Xrm.Attribute<any>[];
      get(index: number): Xrm.Attribute<any>;
      get(chooser: (item: Xrm.Attribute<any>, index: number) => boolean): Xrm.Attribute<any>[];
    }
    interface Controls extends Xrm.ControlCollectionBase {
      get(name: "cms_entity"): Xrm.OptionSetControl<cms_entity>;
      get(name: "cms_orderby"): Xrm.OptionSetControl<cms_rollupline_cms_orderby>;
      get(name: "cms_relatedfield"): Xrm.OptionSetControl<cms_entityfields>;
      get(name: "cms_sortby"): Xrm.StringControl;
      get(name: "cms_valueid"): Xrm.StringControl;
      get(name: string): undefined;
      get(): Xrm.BaseControl[];
      get(index: number): Xrm.BaseControl;
      get(chooser: (item: Xrm.BaseControl, index: number) => boolean): Xrm.BaseControl[];
    }
    interface Tabs extends Xrm.TabCollectionBase {
        get(name: "general"): Xrm.PageTab<Tabs.general>;
      get(name: string): undefined;
      get(): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
      get(index: number): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>;
      get(chooser: (item: Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>, index: number) => boolean): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
    }
  }
    interface Information extends Xrm.PageBase<Information.Attributes, Information.Tabs, Information.Controls> {
        getAttribute(attributeName: "cms_entity"): Xrm.OptionSetAttribute<cms_entity>;
        getAttribute(attributeName: "cms_orderby"): Xrm.OptionSetAttribute<cms_rollupline_cms_orderby>;
        getAttribute(attributeName: "cms_relatedfield"): Xrm.OptionSetAttribute<cms_entityfields>;
        getAttribute(attributeName: "cms_relatedentity"): Xrm.OptionSetAttribute<cms_entity>;
        getAttribute(attributeName: "cms_rollupentity"): Xrm.OptionSetAttribute<cms_entity>;
        getAttribute(attributeName: "cms_criteria"): Xrm.OptionSetAttribute<cms_entityfields>;
        getAttribute(attributeName: "cms_sortby"): Xrm.Attribute<string>;
        getAttribute(attributeName: "cms_valueid"): Xrm.Attribute<string>;
        getAttribute(attributeName: "cms_value"): Xrm.Attribute<string>;
        getAttribute(attributeName: "cms_operator"): Xrm.OptionSetAttribute<cms_operator>;
        getAttribute(attributeName: string): undefined;
        
        getControl(controlName: "cms_entity"): Xrm.OptionSetControl<cms_entity>;
        getControl(controlName: "cms_orderby"): Xrm.OptionSetControl<cms_rollupline_cms_orderby>;
        getControl(controlName: "cms_relatedfield"): Xrm.OptionSetControl<cms_entityfields>;
        getControl(controlName: "cms_sortby"): Xrm.StringControl;
        getControl(controlName: "cms_valueid"): Xrm.StringControl;
        getControl(controlName: "cms_operator"): Xrm.OptionSetControl<cms_operator>;
        
        /*
        getControl(controlName: "agenttitle"): Xrm.BaseControl;
        getControl(controlName: "agenttype"): Xrm.BaseControl;
        getControl(controlName: "DOY"): Xrm.BaseControl;
        getControl(controlName: "lob"): Xrm.BaseControl;
        getControl(controlName: "MCVlocal"): Xrm.BaseControl;
        getControl(controlName: "Productgroup"): Xrm.BaseControl;
        getControl(controlName: "Productseries"): Xrm.BaseControl;
        getControl(controlName: "Region"): Xrm.BaseControl;
        getControl(controlName: "Submissionchannel"): Xrm.BaseControl;
        getControl(controlName: "Team"): Xrm.BaseControl;
        getControl(controlName: "Zone"): Xrm.BaseControl;
        */
        getControl(controlName: string): Xrm.BaseControl;
  }
}
