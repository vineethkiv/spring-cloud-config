﻿declare namespace Form.cms_awardrankingbreakdown.Main {
    namespace Information {
        namespace Tabs {
            interface tab_2 extends Xrm.SectionCollectionBase {
                get(name: "tab_2_section_1"): Xrm.PageSection;
                get(name: string): undefined;
                get(): Xrm.PageSection[];
                get(index: number): Xrm.PageSection;
                get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
            }
        }
        interface Attributes extends Xrm.AttributeCollectionBase {
            get(name: "cms_aggregate"): Xrm.OptionSetAttribute<boolean>;
            get(name: "cms_aggregator"): Xrm.OptionSetAttribute<cms_rollupline_cms_aggregator>;
            get(name: "cms_cap"): Xrm.NumberAttribute;
            get(name: "cms_distinct"): Xrm.OptionSetAttribute<boolean>;
            get(name: "cms_entity"): Xrm.OptionSetAttribute<cms_entity>;
            get(name: "cms_findnext"): Xrm.OptionSetAttribute<boolean>;
            get(name: "cms_max"): Xrm.NumberAttribute;
            get(name: "cms_name"): Xrm.Attribute<string>;
            get(name: "cms_orderby"): Xrm.OptionSetAttribute<cms_rollupline_cms_orderby>;
            get(name: "cms_relatedfield"): Xrm.OptionSetAttribute<cms_entityfields>;
            get(name: "cms_sortby"): Xrm.Attribute<string>;
            get(name: "cms_valueid"): Xrm.Attribute<string>;
            get(name: "cms_rollupid"): Xrm.LookupAttribute;
            get(name: string): undefined;
            get(): Xrm.Attribute<any>[];
            get(index: number): Xrm.Attribute<any>;
            get(chooser: (item: Xrm.Attribute<any>, index: number) => boolean): Xrm.Attribute<any>[];
        }
        interface Controls extends Xrm.ControlCollectionBase {
            get(name: "RollupCriteria"): Xrm.BaseControl;
            get(name: "cms_aggregate"): Xrm.OptionSetControl<boolean>;
            get(name: "cms_aggregator"): Xrm.OptionSetControl<cms_rollupline_cms_aggregator>;
            get(name: "cms_cap"): Xrm.NumberControl;
            get(name: "cms_distinct"): Xrm.OptionSetControl<boolean>;
            get(name: "cms_entity"): Xrm.OptionSetControl<cms_entity>;
            get(name: "cms_findnext"): Xrm.OptionSetControl<boolean>;
            get(name: "cms_max"): Xrm.NumberControl;
            get(name: "cms_name"): Xrm.StringControl;
            get(name: "cms_orderby"): Xrm.OptionSetControl<cms_rollupline_cms_orderby>;
            get(name: "cms_relatedfield"): Xrm.OptionSetControl<cms_entityfields>;
            get(name: "cms_sortby"): Xrm.StringControl;
            get(name: "cms_valueid"): Xrm.StringControl;
            get(name: string): undefined;
            get(): Xrm.BaseControl[];
            get(index: number): Xrm.BaseControl;
            get(chooser: (item: Xrm.BaseControl, index: number) => boolean): Xrm.BaseControl[];
        }
        interface Tabs extends Xrm.TabCollectionBase {
            get(name: "tab_2"): Xrm.PageTab<Tabs.tab_2>;
            get(name: string): undefined;
            get(): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
            get(index: number): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>;
            get(chooser: (item: Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>, index: number) => boolean): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
        }
    }
    interface Information extends Xrm.PageBase<Information.Attributes, Information.Tabs, Information.Controls> {
        getAttribute(attributeName: "cms_type"): Xrm.MultiSelectOptionSetAttribute<cms_type>;
        getControl(controlName: "cms_type"): Xrm.MultiSelectOptionSetControl<cms_type>;

        getAttribute(attributeName: "cms_dateinput"): Xrm.DateAttribute;
        getControl(controlName: "cms_dateinput"): Xrm.DateControl;

        getAttribute(attribute: "cms_titlelookup"): Xrm.LookupAttribute;
        getControl(controlName: "cms_titlelookup"): Xrm.LookupControl;

        getControl(controlName: string): undefined;
    }
}
