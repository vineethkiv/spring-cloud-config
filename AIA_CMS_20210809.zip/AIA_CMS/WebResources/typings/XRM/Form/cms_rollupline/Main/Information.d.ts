declare namespace Form.cms_rollupline.Main {
  namespace Information {
    namespace Tabs {
      interface tab_2 extends Xrm.SectionCollectionBase {
        get(name: "tab_2_section_1"): Xrm.PageSection;
        get(name: string): undefined;
        get(): Xrm.PageSection[];
        get(index: number): Xrm.PageSection;
        get(chooser: (item: Xrm.PageSection, index: number) => boolean): Xrm.PageSection[];
      }
    }
    interface Attributes extends Xrm.AttributeCollectionBase {
      get(name: "cms_aggregate"): Xrm.OptionSetAttribute<boolean>;
      get(name: "cms_aggregator"): Xrm.OptionSetAttribute<cms_rollupline_cms_aggregator>;
      get(name: "cms_cap"): Xrm.NumberAttribute;
      get(name: "cms_distinct"): Xrm.OptionSetAttribute<boolean>;
      get(name: "cms_entity"): Xrm.OptionSetAttribute<cms_entity>;
      get(name: "cms_findnext"): Xrm.OptionSetAttribute<boolean>;
      get(name: "cms_max"): Xrm.NumberAttribute;
      get(name: "cms_name"): Xrm.Attribute<string>;
      get(name: "cms_orderby"): Xrm.OptionSetAttribute<cms_rollupline_cms_orderby>;
      get(name: "cms_relatedfield"): Xrm.OptionSetAttribute<cms_entityfields>;
      get(name: "cms_sortby"): Xrm.Attribute<string>;
        get(name: "cms_valueid"): Xrm.Attribute<string>;
        get(name: "cms_rollupid"): Xrm.LookupAttribute;
      get(name: string): undefined;
      get(): Xrm.Attribute<any>[];
      get(index: number): Xrm.Attribute<any>;
      get(chooser: (item: Xrm.Attribute<any>, index: number) => boolean): Xrm.Attribute<any>[];
    }
    interface Controls extends Xrm.ControlCollectionBase {
      get(name: "RollupCriteria"): Xrm.BaseControl;
      get(name: "cms_aggregate"): Xrm.OptionSetControl<boolean>;
      get(name: "cms_aggregator"): Xrm.OptionSetControl<cms_rollupline_cms_aggregator>;
      get(name: "cms_cap"): Xrm.NumberControl;
      get(name: "cms_distinct"): Xrm.OptionSetControl<boolean>;
      get(name: "cms_entity"): Xrm.OptionSetControl<cms_entity>;
      get(name: "cms_findnext"): Xrm.OptionSetControl<boolean>;
      get(name: "cms_max"): Xrm.NumberControl;
      get(name: "cms_name"): Xrm.StringControl;
      get(name: "cms_orderby"): Xrm.OptionSetControl<cms_rollupline_cms_orderby>;
      get(name: "cms_relatedfield"): Xrm.OptionSetControl<cms_entityfields>;
      get(name: "cms_sortby"): Xrm.StringControl;
      get(name: "cms_valueid"): Xrm.StringControl;
      get(name: string): undefined;
      get(): Xrm.BaseControl[];
      get(index: number): Xrm.BaseControl;
      get(chooser: (item: Xrm.BaseControl, index: number) => boolean): Xrm.BaseControl[];
    }
    interface Tabs extends Xrm.TabCollectionBase {
      get(name: "tab_2"): Xrm.PageTab<Tabs.tab_2>;
      get(name: string): undefined;
      get(): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
      get(index: number): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>;
      get(chooser: (item: Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>, index: number) => boolean): Xrm.PageTab<Xrm.Collection<Xrm.PageSection>>[];
    }
  }
  interface Information extends Xrm.PageBase<Information.Attributes,Information.Tabs,Information.Controls> {
    getAttribute(attributeName: "cms_aggregate"): Xrm.OptionSetAttribute<boolean>;
    getAttribute(attributeName: "cms_aggregator"): Xrm.OptionSetAttribute<cms_rollupline_cms_aggregator>;
    getAttribute(attributeName: "cms_cap"): Xrm.NumberAttribute;
    getAttribute(attributeName: "cms_distinct"): Xrm.OptionSetAttribute<boolean>;
    getAttribute(attributeName: "cms_entity"): Xrm.OptionSetAttribute<cms_entity>;
    getAttribute(attributeName: "cms_findnext"): Xrm.OptionSetAttribute<boolean>;
    getAttribute(attributeName: "cms_max"): Xrm.NumberAttribute;
    getAttribute(attributeName: "cms_name"): Xrm.Attribute<string>;
    getAttribute(attributeName: "cms_awardstartdate"): Xrm.DateAttribute;
    getAttribute(attributeName: "cms_awardsettlementdate"): Xrm.DateAttribute;
    getAttribute(attributeName: "cms_contestid"): Xrm.LookupAttribute;
    getAttribute(attributeName: "cms_orderby"): Xrm.OptionSetAttribute<cms_rollupline_cms_orderby>;
    getAttribute(attributeName: "cms_relatedfield"): Xrm.OptionSetAttribute<cms_entityfields>;
      getAttribute(attributeName: "cms_relatedentity"): Xrm.OptionSetAttribute<cms_entity>;
      getAttribute(attributeName: "cms_rollupentity"): Xrm.OptionSetAttribute<cms_entity>;
    getAttribute(attributeName: "cms_criteria"): Xrm.OptionSetAttribute<cms_entityfields>;
    getAttribute(attributeName: "cms_sortby"): Xrm.Attribute<string>;
    getAttribute(attributeName: "cms_valueid"): Xrm.Attribute<string>;
    getAttribute(attributeName: string): undefined;
    getControl(controlName: "RollupCriteria"): Xrm.BaseControl;
    getControl(controlName: "cms_aggregate"): Xrm.OptionSetControl<boolean>;
    getControl(controlName: "cms_aggregator"): Xrm.OptionSetControl<cms_rollupline_cms_aggregator>;
    getControl(controlName: "cms_cap"): Xrm.NumberControl;
    getControl(controlName: "cms_distinct"): Xrm.OptionSetControl<boolean>;
    getControl(controlName: "cms_entity"): Xrm.OptionSetControl<cms_entity>;
    getControl(controlName: "cms_findnext"): Xrm.OptionSetControl<boolean>;
    getControl(controlName: "cms_max"): Xrm.NumberControl;
    getControl(controlName: "cms_name"): Xrm.StringControl;
    getControl(controlName: "cms_orderby"): Xrm.OptionSetControl<cms_rollupline_cms_orderby>;
    getControl(controlName: "cms_relatedfield"): Xrm.OptionSetControl<cms_entityfields>;
    getControl(controlName: "cms_sortby"): Xrm.StringControl;
      getControl(controlName: "cms_valueid"): Xrm.StringControl;
      // for Requirement - begin
      getAttribute(attributeName: "cms_rollup"): Xrm.LookupAttribute;
      getAttribute(attributeName: "cms_multiplierperlevel"): Xrm.NumberAttribute;
      getControl(controlName: "cms_multiplierperlevel"): Xrm.NumberControl;
      getAttribute(attributeName: "cms_awardid"): Xrm.LookupAttribute;
      // for Requirement - end
      // for Rollup Line - begin
      getAttribute(attributeName: "cms_rollupid"): Xrm.LookupAttribute;
      // for Rollup Line - end
      // for Rollup Criteria - begin
      getAttribute(attributeName: "cms_rolluplineid"): Xrm.LookupAttribute;
      getAttribute(attributeName: "cms_sequencenumber"): Xrm.Attribute<string>;
      // for Rollup Criteria - end
      // for Result - begin      
      getAttribute(attribute: "cms_settlingfromdate"): Xrm.DateAttribute;
      getControl(controlName: "cms_settlingfromdate"): Xrm.DateControl;
      getAttribute(attribute: "cms_settlingtodate"): Xrm.DateAttribute;
      getAttribute(attribute: "cms_adjustment"): Xrm.OptionSetAttribute<boolean>;
      getAttribute(attribute: "cms_contest"): Xrm.LookupAttribute;
      getAttribute(attribute: "cms_active"): Xrm.OptionSetAttribute<boolean>;
      // for Result - end
      // for Grouping line - begin
      getAttribute(attributeName: "cms_groupingid"): Xrm.LookupAttribute;
      getAttribute(attributeName: "cms_requirement"): Xrm.LookupAttribute;
      getControl(controlName: "cms_requirement"): Xrm.LookupControl;
      getAttribute(attribute: "cms_subgroupid"): Xrm.LookupAttribute;
      getAttribute(attribute: "cms_subgroup"): Xrm.LookupAttribute;
      // for Grouping line - end
      // for speical rule header - begin
      getAttribute(attributeName: "cms_ruletype"): Xrm.OptionSetAttribute<cms_ruletype>;
      getAttribute(attribute: "cms_specialcontest"): Xrm.LookupAttribute;
      getControl(controlName: "cms_specialcontest"): Xrm.LookupControl;
      getAttribute(attribute: "cms_contest"): Xrm.LookupAttribute;
      // for speical rule header - end
      // contest - begin
      getAttribute(attributeName: "cms_contesttype"): Xrm.OptionSetAttribute<cms_contesttype>;

      getAttribute(attributeName: "cms_nblob1"): Xrm.MultiSelectOptionSetAttribute<cms_lob>;
      getControl(controlName: "cms_nblob1"): Xrm.MultiSelectOptionSetControl<cms_lob>;

      getAttribute(attributeName: "cms_nblob2"): Xrm.MultiSelectOptionSetAttribute<cms_lob>;
      getControl(controlName: "cms_nblob2"): Xrm.MultiSelectOptionSetControl<cms_lob>;

      getAttribute(attributeName: "cms_policytxnsubmissionstartdate1"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxnsubmissionstartdate1"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxnsubmissionenddate1"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxnsubmissionenddate1"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxnsubmissionstartdate2"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxnsubmissionstartdate2"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxnsubmissionenddate2"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxnsubmissionenddate2"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxndeliverystartdate1"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxndeliverystartdate1"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxndeliveryenddate1"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxndeliveryenddate1"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxndeliverystartdate2"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxndeliverystartdate2"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxndeliveryenddate2"): Xrm.DateAttribute;
      getControl(controlName: "cms_policytxndeliveryenddate2"): Xrm.DateControl;

      getControl(controlName: "cms_policytxntransactionstartdate"): Xrm.DateControl;
      getControl(controlName: "cms_policytxntransactionenddate"): Xrm.DateControl;

      getAttribute(attributeName: "cms_policytxntransactionstartdate"): Xrm.DateAttribute;
      getAttribute(attributeName: "cms_policytxntransactionenddate"): Xrm.DateAttribute;

      getAttribute(attribute: "cms_nbtemplate"): Xrm.LookupAttribute;
      getControl(controlName: "cms_nbtemplate"): Xrm.LookupControl;
      // contest - end

      getAttribute(attribute: "cms_eligibilitygroup"): Xrm.LookupAttribute;
      getControl(controlName: "cms_eligibility"): Xrm.LookupControl;

      getAttribute(attributeName: "cms_award"): Xrm.LookupAttribute;
      getControl(controlName: "cms_award"): Xrm.LookupControl;

      getAttribute(attributeName: "cms_specialcontestheader"): Xrm.LookupAttribute;
      getControl(controlName: "cms_specialcontestheader"): Xrm.LookupControl;

      getAttribute(attributeName: "cms_operator"): Xrm.OptionSetAttribute<cms_operator>;
      getControl(controlName: "cms_operator"): Xrm.OptionSetControl<cms_operator>;
    getControl(controlName: string): undefined;
  }
}
