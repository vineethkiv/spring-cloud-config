interface act_rollupline_Base extends WebEntity {
  act_aggregate?: boolean | null;
  act_aggregator?: act_rollupline_act_aggregator | null;
  act_cap?: number | null;
  act_distinct?: boolean | null;
  act_entity?: act_entity | null;
  act_findnext?: boolean | null;
  act_max?: number | null;
  act_name?: string | null;
  act_orderby?: act_rollupline_act_orderby | null;
  act_relatedfield?: act_entityfields | null;
  act_rolluplineid?: string | null;
  act_sortby?: string | null;
  act_valueid?: string | null;
  createdon?: Date | null;
  importsequencenumber?: number | null;
  modifiedon?: Date | null;
  overriddencreatedon?: Date | null;
  statecode?: act_rollupline_statecode | null;
  statuscode?: act_rollupline_statuscode | null;
  timezoneruleversionnumber?: number | null;
  utcconversiontimezonecode?: number | null;
  versionnumber?: number | null;
}
interface act_rollupline_Relationships {
}
interface act_rollupline extends act_rollupline_Base, act_rollupline_Relationships {
  act_RollupId_bind$act_rollups?: string | null;
}
interface act_rollupline_Create extends act_rollupline {
}
interface act_rollupline_Update extends act_rollupline {
}
interface act_rollupline_Select {
  act_aggregate: WebAttribute<act_rollupline_Select, { act_aggregate: boolean | null }, {  }>;
  act_aggregator: WebAttribute<act_rollupline_Select, { act_aggregator: act_rollupline_act_aggregator | null }, { act_aggregator_formatted?: string }>;
  act_cap: WebAttribute<act_rollupline_Select, { act_cap: number | null }, {  }>;
  act_distinct: WebAttribute<act_rollupline_Select, { act_distinct: boolean | null }, {  }>;
  act_entity: WebAttribute<act_rollupline_Select, { act_entity: act_entity | null }, { act_entity_formatted?: string }>;
  act_findnext: WebAttribute<act_rollupline_Select, { act_findnext: boolean | null }, {  }>;
  act_max: WebAttribute<act_rollupline_Select, { act_max: number | null }, {  }>;
  act_name: WebAttribute<act_rollupline_Select, { act_name: string | null }, {  }>;
  act_orderby: WebAttribute<act_rollupline_Select, { act_orderby: act_rollupline_act_orderby | null }, { act_orderby_formatted?: string }>;
  act_relatedfield: WebAttribute<act_rollupline_Select, { act_relatedfield: act_entityfields | null }, { act_relatedfield_formatted?: string }>;
  act_rollupid_guid: WebAttribute<act_rollupline_Select, { act_rollupid_guid: string | null }, { act_rollupid_formatted?: string }>;
  act_rolluplineid: WebAttribute<act_rollupline_Select, { act_rolluplineid: string | null }, {  }>;
  act_sortby: WebAttribute<act_rollupline_Select, { act_sortby: string | null }, {  }>;
  act_valueid: WebAttribute<act_rollupline_Select, { act_valueid: string | null }, {  }>;
  createdby_guid: WebAttribute<act_rollupline_Select, { createdby_guid: string | null }, { createdby_formatted?: string }>;
  createdon: WebAttribute<act_rollupline_Select, { createdon: Date | null }, { createdon_formatted?: string }>;
  createdonbehalfby_guid: WebAttribute<act_rollupline_Select, { createdonbehalfby_guid: string | null }, { createdonbehalfby_formatted?: string }>;
  importsequencenumber: WebAttribute<act_rollupline_Select, { importsequencenumber: number | null }, {  }>;
  modifiedby_guid: WebAttribute<act_rollupline_Select, { modifiedby_guid: string | null }, { modifiedby_formatted?: string }>;
  modifiedon: WebAttribute<act_rollupline_Select, { modifiedon: Date | null }, { modifiedon_formatted?: string }>;
  modifiedonbehalfby_guid: WebAttribute<act_rollupline_Select, { modifiedonbehalfby_guid: string | null }, { modifiedonbehalfby_formatted?: string }>;
  organizationid_guid: WebAttribute<act_rollupline_Select, { organizationid_guid: string | null }, { organizationid_formatted?: string }>;
  overriddencreatedon: WebAttribute<act_rollupline_Select, { overriddencreatedon: Date | null }, { overriddencreatedon_formatted?: string }>;
  statecode: WebAttribute<act_rollupline_Select, { statecode: act_rollupline_statecode | null }, { statecode_formatted?: string }>;
  statuscode: WebAttribute<act_rollupline_Select, { statuscode: act_rollupline_statuscode | null }, { statuscode_formatted?: string }>;
  timezoneruleversionnumber: WebAttribute<act_rollupline_Select, { timezoneruleversionnumber: number | null }, {  }>;
  utcconversiontimezonecode: WebAttribute<act_rollupline_Select, { utcconversiontimezonecode: number | null }, {  }>;
  versionnumber: WebAttribute<act_rollupline_Select, { versionnumber: number | null }, {  }>;
}
interface act_rollupline_Filter {
  act_aggregate: boolean;
  act_aggregator: act_rollupline_act_aggregator;
  act_cap: any;
  act_distinct: boolean;
  act_entity: act_entity;
  act_findnext: boolean;
  act_max: any;
  act_name: string;
  act_orderby: act_rollupline_act_orderby;
  act_relatedfield: act_entityfields;
  act_rollupid_guid: XQW.Guid;
  act_rolluplineid: XQW.Guid;
  act_sortby: string;
  act_valueid: string;
  createdby_guid: XQW.Guid;
  createdon: Date;
  createdonbehalfby_guid: XQW.Guid;
  importsequencenumber: number;
  modifiedby_guid: XQW.Guid;
  modifiedon: Date;
  modifiedonbehalfby_guid: XQW.Guid;
  organizationid_guid: XQW.Guid;
  overriddencreatedon: Date;
  statecode: act_rollupline_statecode;
  statuscode: act_rollupline_statuscode;
  timezoneruleversionnumber: number;
  utcconversiontimezonecode: number;
  versionnumber: number;
}
interface act_rollupline_Expand {
}
interface act_rollupline_FormattedResult {
  act_aggregator_formatted?: string;
  act_entity_formatted?: string;
  act_orderby_formatted?: string;
  act_relatedfield_formatted?: string;
  act_rollupid_formatted?: string;
  createdby_formatted?: string;
  createdon_formatted?: string;
  createdonbehalfby_formatted?: string;
  modifiedby_formatted?: string;
  modifiedon_formatted?: string;
  modifiedonbehalfby_formatted?: string;
  organizationid_formatted?: string;
  overriddencreatedon_formatted?: string;
  statecode_formatted?: string;
  statuscode_formatted?: string;
}
interface act_rollupline_Result extends act_rollupline_Base, act_rollupline_Relationships {
  "@odata.etag": string;
  act_rollupid_guid: string | null;
  createdby_guid: string | null;
  createdonbehalfby_guid: string | null;
  modifiedby_guid: string | null;
  modifiedonbehalfby_guid: string | null;
  organizationid_guid: string | null;
}
interface act_rollupline_RelatedOne {
}
interface act_rollupline_RelatedMany {
}
interface WebEntitiesRetrieve {
  act_rolluplines: WebMappingRetrieve<act_rollupline_Select,act_rollupline_Expand,act_rollupline_Filter,act_rollupline_Fixed,act_rollupline_Result,act_rollupline_FormattedResult>;
}
interface WebEntitiesRelated {
  act_rolluplines: WebMappingRelated<act_rollupline_RelatedOne,act_rollupline_RelatedMany>;
}
interface WebEntitiesCUDA {
  act_rolluplines: WebMappingCUDA<act_rollupline_Create,act_rollupline_Update,act_rollupline_Select>;
}
