﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />

namespace ACT.form_SpecialRuleHeader {

    export function ruleTypeControl(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
        var ruletype = formContext.getAttribute("cms_ruletype");
        var specialContest = formContext.getAttribute("cms_specialcontest");
        var specialContestCtl = formContext.getControl("cms_specialcontest");
        var visible = false;

        if (ruletype.getValue() != null) {
            if (ruletype.getValue() == 175650000 /*Exclusion*/) {
                visible = false;
            }
            else {
                visible = true;
            }
        }
        else {
            visible = false;
        }

        specialContestCtl.setVisible(visible);
        if (!visible) {
            specialContest.setValue(null);
        }
    }

    export function speicalContestLookupFilter(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();        
        var specialContestCtl = formContext.getControl("cms_specialcontest")

        specialContestCtl.addPreSearch(function () {
            addLookupFilter(executionContext);
        });
    }

    function addLookupFilter(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
        var specialContestCtl = formContext.getControl("cms_specialcontest")
        var contest = formContext.getAttribute("cms_contest");
        var contestId = "";

        if (contest.getValue() != null) {
            contestId = contest.getValue()[0].id;
        }

        var specContestFilter = "<filter type=\"and\">" +
            "<condition attribute=\"cms_contest\" operator=\"eq\" value=\"" + contestId + "\" />" +
            "</filter>";

        specialContestCtl.addCustomFilter(specContestFilter, "cms_specialcontestheader");
    }
}