﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />

namespace ACT.form_RollupCriteria {
        export function sequenceNumberDefValue(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
        var sequenceNumber = formContext.getAttribute("cms_sequencenumber");
            if (sequenceNumber.getValue() == null && formContext.getAttribute("cms_rolluplineid").getValue() != null) {
            var rolluplineId = formContext.getAttribute("cms_rolluplineid").getValue()[0].id;
                Xrm.WebApi.retrieveMultipleRecords("cms_rollupcriteria", "?$select=cms_sequencenumber&$filter=_cms_rolluplineid_value eq " + rolluplineId).then(
                function success(result) {
                    sequenceNumber.setValue(result.entities.length + 1);
                },
                function (error) {
                    console.log(error.message);
                    // handle error conditions
                }
            );
        }
    }
}