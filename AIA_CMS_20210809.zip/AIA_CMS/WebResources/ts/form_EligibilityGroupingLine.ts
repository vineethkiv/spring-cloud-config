﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />

namespace ACT.form_EligibilityGroupingLine {

    export function eligibilityLookupFilter(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
        var eligibilityGroup = formContext.getAttribute("cms_eligibilitygroup");
        var eligibilityCtl = formContext.getControl("cms_eligibility");

        if (eligibilityGroup.getValue() != null) {
            var eligibilityGroupId = eligibilityGroup.getValue()[0].id;
            Xrm.WebApi.retrieveRecord("cms_eligibilitygroupingheader", eligibilityGroupId).then(
                function success(result) {
                    var awardId = result._cms_awardid_value;
                    eligibilityCtl.addPreSearch(function () {
                        var reqFilter = "<filter type=\"and\">" +
                            "<condition attribute=\"cms_awardid\" operator=\"eq\" value=\"" + awardId + "\" />" +
                            "</filter>";

                        eligibilityCtl.addCustomFilter(reqFilter, "cms_eligibility");

                    }
                    );
                });
        }
    }

    export function initValue(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();

        if (formContext.data.entity.getId() == "") {
            formContext.getAttribute("cms_subgroup").setValue(null);
        }
    }
}