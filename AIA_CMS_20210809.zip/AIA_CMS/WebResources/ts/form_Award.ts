﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_award/main/information.d.ts" />

namespace ACT.form_Award {

    export function defaultStartEndDate(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_award.Main.Information = <Form.cms_award.Main.Information>executionContext.getFormContext();
        var filter = "?$select=cms_contestid,cms_conteststartdate,cms_contestenddate";
        var awardStartDate = formContext.getAttribute("cms_awardstartdate");
        var awardEndDate = formContext.getAttribute("cms_awardsettlementdate");
        var contest = formContext.getAttribute("cms_contestid").getValue();
        if (contest != null) {

            Xrm.WebApi.online.retrieveRecord("cms_contest", contest[0].id, filter).then(
                function sucess(result) {
                    if (result != null) {
                        var startDate = new Date(result.cms_conteststartdate);
                        var endDate = new Date(result.cms_contestenddate);
                        if (awardStartDate.getValue() == null && awardEndDate.getValue() == null) {
                            formContext.getAttribute("cms_awardstartdate").setValue(startDate);
                            formContext.getAttribute("cms_awardsettlementdate").setValue(endDate);
                        }
                    }
                },
                function error(error) {
                    console.log(error.message);
                });
        }
    }

    var isRolling;

    export function rollingControl(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_award.Main.Information = <Form.cms_award.Main.Information>executionContext.getFormContext();
        var filter = "?$select=cms_contestid,cms_rollingcontest,cms_rollingperiod";
        var contest = formContext.getAttribute("cms_contestid").getValue();
        if (contest != null) {
            Xrm.WebApi.online.retrieveRecord("cms_contest", contest[0].id, filter).then(
                function sucess(result) {
                    if (result != null) {
                        var rolling = formContext.ui.tabs.get("general").sections.get("rollingsection");
                        if (result.cms_rollingcontest == true) {
                            isRolling = true;
                            rolling.setVisible(true);

                            var awardPeriod = formContext.getAttribute("cms_awardperiod");
                            if (awardPeriod.getValue() == null) {
                                awardPeriod.setValue(result.cms_rollingperiod);
                            }
                        }
                        else {
                            rolling.setVisible(false);
                            isRolling = false;
                        }
                    }
                },
                function error(error) {
                    console.log(error.message);
                });
        }
    }

    export function awardTypeControl(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_award.Main.Information = <Form.cms_award.Main.Information>executionContext.getFormContext();
        var awardType = formContext.getAttribute("cms_awardtype");
        var monthlyCtl = formContext.getControl("cms_monthly");
        var rollingGroupCtl = formContext.getControl("cms_rollinggroup");     
        var show = true;

        if (isRolling == null) {
            rollingControl(executionContext);
        }

        if (awardType != null) {
            if (awardType.getValue() != 175650001) {
                show = false;
            }

            if (isRolling == false) {
                show = false;
            }
        
            monthlyCtl.setVisible(show);
            rollingGroupCtl.setVisible(show);
        }
    }
}