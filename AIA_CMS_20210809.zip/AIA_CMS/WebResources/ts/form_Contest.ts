﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_contest/main/information.d.ts" />

namespace ACT.form_Contest {

    export function contestTypeControl(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_contest.Main.Information = <Form.cms_contest.Main.Information>executionContext.getFormContext();
        var visible = false;
        var contestType = formContext.getAttribute("cms_contesttype");

        if (contestType.getValue() != null) {
            if (contestType.getValue() == 175650001 /*NB*/)
                visible = true;
        }        

        formContext.ui.tabs.get("general").sections.get("lob1section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob2section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob3section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob4section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob5section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob6section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob7section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob8section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob9section").setVisible(visible);
        formContext.ui.tabs.get("general").sections.get("lob10section").setVisible(visible);
    }

    export function contestTypeModified(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_contest.Main.Information = <Form.cms_contest.Main.Information>executionContext.getFormContext();
        var contestType = formContext.getAttribute("cms_contesttype");

        var contestStartDate = null, contestStartDateTime = null, contestEndDate = null, contestEndDateTime = null;

        if (contestType.getValue() != null) {

            contestStartDate = formContext.getAttribute("cms_conteststartdate").getValue();
            if (contestStartDate != null)
                contestStartDateTime = new Date(contestStartDate.getFullYear(), contestStartDate.getMonth(), contestStartDate.getDate(), 0, 0, 0, 0);

            contestEndDate = formContext.getAttribute("cms_contestenddate").getValue();
            if (contestEndDate != null)
                contestEndDateTime = new Date(contestEndDate.getFullYear(), contestEndDate.getMonth(), contestEndDate.getDate(), 23, 59, 59, 0);
            
            for (var i = 1; i <= 10; i++) {
                var nbTrxStartDateName = "cms_nbtxnstartdate" + i.toString();
                var nbTrxEndDateName = "cms_nbtxnenddate" + i.toString();
                var nbSubmissionStartDateName = "cms_nbsubmissionstartdate" + i.toString();
                var nbSubmissionEndDateName = "cms_nbsubmissionenddate" + i.toString();
                var deliveryEndDateName = "cms_nbdeliveryenddate" + i.toString();
                
                var nbTrxStartDate = formContext.getAttribute(nbTrxStartDateName);
                var nbTrxEndDate = formContext.getAttribute(nbTrxEndDateName);
                var nbSubmissionStartDate = formContext.getAttribute(nbSubmissionStartDateName);
                var nbSubmissionEndDate = formContext.getAttribute(nbSubmissionEndDateName);
                var deliveryEndDate = formContext.getAttribute(deliveryEndDateName);

                if (contestType.getValue() == 175650001 /*NB*/) {
                    nbTrxStartDate.setValue(contestStartDateTime);
                    nbTrxEndDate.setValue(contestEndDateTime);
                    nbSubmissionStartDate.setValue(contestStartDateTime);
                    nbSubmissionEndDate.setValue(contestEndDateTime);
                    deliveryEndDate.setValue(contestEndDateTime);
                }
                else {
                    nbTrxStartDate.setValue(null);
                    nbTrxEndDate.setValue(null);
                    nbSubmissionStartDate.setValue(null);
                    nbSubmissionEndDate.setValue(null);
                    deliveryEndDate.setValue(null);
                }
            }
        }        
    }

}