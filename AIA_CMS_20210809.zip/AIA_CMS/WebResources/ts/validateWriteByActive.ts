﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />

namespace ACT.validateWriteByActive {

    var isSave = false;

    export function validateWrite(executionContext: Xrm.ExecutionContext<any, any>) {
        if (isSave) {
            return;
        }
        else {
            var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
            executionContext.getEventArgs().preventDefault();

            switch (formContext.data.entity.getEntityName()) {
                case "cms_award":
                    var contest = formContext.getAttribute("cms_contestid").getValue();
                    if (contest != null) {
                        retrieveAndCheckContest(formContext, contest[0].id);
                    }
                    break;
                case "cms_requirement":
                case "cms_grouping":
                case "cms_eligibility":
                case "cms_awardrankingbreakdown":
                    var award = formContext.getAttribute("cms_awardid").getValue();
                    if (award != null) {
                        retrieveAward(formContext, award[0].id);
                    }
                    break;
                case "cms_branchoutdistrict":
                    var award = formContext.getAttribute("cms_award").getValue();
                    if (award != null) {
                        retrieveAward(formContext, award[0].id);
                    }
                    break;
                case "cms_groupingline":
                    var grouping = formContext.getAttribute("cms_groupingid").getValue();
                    if (grouping != null) {
                        retrieveGrouping(formContext, grouping[0].id);
                    }
                    break;
            }
        }
    }

    function retrieveGrouping(formContext: Form.cms_rollupline.Main.Information, groupingId: string) {
        Xrm.WebApi.retrieveRecord("cms_grouping", groupingId).then(
            function success(grouping) {
                retrieveAward(formContext, grouping._cms_awardid_value);
            }
        );
    }

    function retrieveAward(formContext: Form.cms_rollupline.Main.Information, awardId: string) {
        Xrm.WebApi.retrieveRecord("cms_award", awardId).then(
            function success(award) {
                retrieveAndCheckContest(formContext, award._cms_contestid_value);
            }
        );
    }

    function retrieveAndCheckContest(formContext: Form.cms_rollupline.Main.Information, contestId: string) {
        Xrm.WebApi.retrieveRecord("cms_contest", contestId, "?$select=cms_active").then(
            function success(result) {
                isSave = result.cms_active == false;

                if (isSave) {
                    formContext.data.save();
                }
                else {
                    formContext.ui.setFormNotification("Contest actived, not allow create/update record", "ERROR", "Actived");
                }
            },
            function (error) {
                console.log(error.message);
                // handle error conditions
            }
        );
    }
}