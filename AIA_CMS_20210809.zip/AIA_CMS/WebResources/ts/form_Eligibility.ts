﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />

namespace ACT.form_Eligibility {

    export function setEntityOption(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
        var entityField = formContext.getControl("cms_entity");

        if (entityField != null) {
            entityField.clearOptions();

            entityField.addOption({ "value": 175650000, "text": "Agent" });
            entityField.addOption({ "value": 175650001, "text": "Agent history " });
            entityField.addOption({ "value": 175650005, "text": "District" });
            entityField.addOption({ "value": 175650011, "text": "MDRT membership" });
        }
    }
}