﻿/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />

namespace ACT.form_GroupingLine {

    export function requirementLookupFilter(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
        var grouping = formContext.getAttribute("cms_groupingid");
        var requirementCtl = formContext.getControl("cms_requirement");

        if (grouping.getValue() != null) {
            var groupingId = grouping.getValue()[0].id;
            Xrm.WebApi.retrieveRecord("cms_grouping", groupingId).then(
                function success(result) {
                    var awardId = result._cms_awardid_value;
                    requirementCtl.addPreSearch(function () {
                        var reqFilter = "<filter type=\"and\">" +
                            "<condition attribute=\"cms_awardid\" operator=\"eq\" value=\"" + awardId + "\" />" +
                            "</filter>";

                        requirementCtl.addCustomFilter(reqFilter, "cms_requirement");

                    }
                );
            });
        }
    }

    export function initValue(executionContext: Xrm.ExecutionContext<any, any>) {
        var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();

        if (formContext.data.entity.getId() == "") {
            formContext.getAttribute("cms_subgroupid").setValue(null);
        }
    }
}