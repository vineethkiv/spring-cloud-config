/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_awardrankingbreakdown/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_AwardRankingBreakdown;
    (function (form_AwardRankingBreakdown) {
        function typeModified(executionContext) {
            var formContext = executionContext.getFormContext();
            var typeValue = null;
            typeValue = formContext.getAttribute("cms_type").getValue();
            var dateInput = formContext.getAttribute("cms_dateinput");
            var dateInputControl = formContext.getControl("cms_dateinput");
            var titleLookup = formContext.getAttribute("cms_titlelookup");
            var titleLookupControl = formContext.getControl("cms_titlelookup");
            if (typeValue != null) {
                switch (typeValue) {
                    case 175650046:
                        dateInputControl.setVisible(true);
                        titleLookupControl.setVisible(false);
                        titleLookup.setValue(null);
                        break;
                    case 175650001:
                        dateInputControl.setVisible(false);
                        dateInput.setValue(null);
                        titleLookupControl.setVisible(true);
                        break;
                }
            }
        }
        form_AwardRankingBreakdown.typeModified = typeModified;
    })(form_AwardRankingBreakdown = ACT.form_AwardRankingBreakdown || (ACT.form_AwardRankingBreakdown = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_AwardRankingBreakdown.js.map