/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/xrm/form/cms_rollup/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_Rollup;
    (function (form_Rollup) {
        function showRelatedRollup(executionContext) {
            var formContext = executionContext.getFormContext();
            var id = formContext.data.entity.getId().toString();
            var displayName = formContext.getAttribute("cms_displayname");
            var relatedRollup = formContext.getAttribute("cms_relatedrollup");
            var relatedRollupValue = "";
            if (displayName.getValue() != null) {
                var displayNameId = displayName.getValue()[0].id;
                Xrm.WebApi.retrieveMultipleRecords("cms_rollup", "?$select=cms_name,cms_rollupid&$orderby=cms_name asc&$filter=_cms_displayname_value eq " + displayNameId).then(function success(result) {
                    for (var i = 0; i < result.entities.length; i++) {
                        var rollup = result.entities[i];
                        var curRollupId = ("{" + rollup.cms_rollupid + "}").toUpperCase();
                        if (curRollupId != id) {
                            if (relatedRollupValue != "")
                                relatedRollupValue += "\n";
                            relatedRollupValue += rollup.cms_name;
                        }
                    }
                    relatedRollup.setValue(relatedRollupValue);
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
        }
        form_Rollup.showRelatedRollup = showRelatedRollup;
    })(form_Rollup = ACT.form_Rollup || (ACT.form_Rollup = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_Rollup.js.map