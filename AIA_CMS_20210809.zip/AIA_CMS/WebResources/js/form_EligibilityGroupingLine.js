/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_EligibilityGroupingLine;
    (function (form_EligibilityGroupingLine) {
        function eligibilityLookupFilter(executionContext) {
            var formContext = executionContext.getFormContext();
            var eligibilityGroup = formContext.getAttribute("cms_eligibilitygroup");
            var eligibilityCtl = formContext.getControl("cms_eligibility");
            if (eligibilityGroup.getValue() != null) {
                var eligibilityGroupId = eligibilityGroup.getValue()[0].id;
                Xrm.WebApi.retrieveRecord("cms_eligibilitygroupingheader", eligibilityGroupId).then(function success(result) {
                    var awardId = result._cms_awardid_value;
                    eligibilityCtl.addPreSearch(function () {
                        var reqFilter = "<filter type=\"and\">" +
                            "<condition attribute=\"cms_awardid\" operator=\"eq\" value=\"" + awardId + "\" />" +
                            "</filter>";
                        eligibilityCtl.addCustomFilter(reqFilter, "cms_eligibility");
                    });
                });
            }
        }
        form_EligibilityGroupingLine.eligibilityLookupFilter = eligibilityLookupFilter;
        function initValue(executionContext) {
            var formContext = executionContext.getFormContext();
            if (formContext.data.entity.getId() == "") {
                formContext.getAttribute("cms_subgroup").setValue(null);
            }
        }
        form_EligibilityGroupingLine.initValue = initValue;
    })(form_EligibilityGroupingLine = ACT.form_EligibilityGroupingLine || (ACT.form_EligibilityGroupingLine = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_EligibilityGroupingLine.js.map