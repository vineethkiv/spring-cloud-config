/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/xrm/form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_RollupLine;
    (function (form_RollupLine) {
        function aggregatorControl(executionContext) {
            var formContext = executionContext.getFormContext();
            var aggregator = formContext.getAttribute("cms_aggregator");
            var sortby = formContext.getAttribute("cms_sortby");
            var sortbyControl = sortby.controls.get(0);
            var orderby = formContext.getAttribute("cms_orderby");
            var orderbyControl = orderby.controls.get(0);
            if (aggregator.getValue() == 175650001 /* Exact */) {
                sortbyControl.setDisabled(false);
                orderbyControl.setDisabled(false);
            }
            else {
                sortby.setValue(null);
                sortbyControl.setDisabled(true);
                orderby.setValue(null);
                orderbyControl.setDisabled(true);
            }
        }
        form_RollupLine.aggregatorControl = aggregatorControl;
        function valueIdDefValue(executionContext) {
            var formContext = executionContext.getFormContext();
            var valueId = formContext.getAttribute("cms_valueid");
            if (valueId.getValue() == null && formContext.getAttribute("cms_rollupid").getValue() != null) {
                var rollupId = formContext.getAttribute("cms_rollupid").getValue()[0].id;
                Xrm.WebApi.retrieveMultipleRecords("cms_rollupline", "?$select=cms_valueid&$filter=_cms_rollupid_value eq " + rollupId).then(function success(result) {
                    var curValueId = "%" + (result.entities.length + 1);
                    valueId.setValue(curValueId);
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
        }
        form_RollupLine.valueIdDefValue = valueIdDefValue;
    })(form_RollupLine = ACT.form_RollupLine || (ACT.form_RollupLine = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_RollupLine.js.map