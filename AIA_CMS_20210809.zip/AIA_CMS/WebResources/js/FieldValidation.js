/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/fieldValidation/main/information.d.ts" />
var contactOption = [{ "value": 175650060, "text": "A&H Rookie’s training " },
    { "value": 175650004, "text": "Aforce" },
    { "value": 175650019, "text": "Agency code" },
    { "value": 175650009, "text": "Agency ContractMain indicator" },
    { "value": 175650001, "text": "Agent title" },
    { "value": 175650006, "text": "Agent type" },
    { "value": 175650007, "text": "AMR control" },
    { "value": 175650003, "text": "AUM/TM" },
    { "value": 175650057, "text": "AUM/TM appointment date" },
    { "value": 175650058, "text": "AUM/TM expiry date" },
    { "value": 175650046, "text": "Contract start date" },
    { "value": 175650021, "text": "District code" },
    { "value": 175650014, "text": "Honor indicator" },
    { "value": 175650011, "text": "Industrial LOU" },
    { "value": 175650002, "text": "IsLeader" },
    { "value": 175650010, "text": "LOU" },
    { "value": 175650012, "text": "MCV/Local" },
    { "value": 175650008, "text": "Personal ContractMain indicator" },
    { "value": 175650044, "text": "Primary agent code" },
    { "value": 175650013, "text": "Re-join indicator" },
    { "value": 175650059, "text": "Region" },
    { "value": 175650052, "text": "Team" },
    { "value": 175650051, "text": "Zone" }];
var agentHistoryOption = [{ "value": 175650004, "text": "Aforce" },
    { "value": 175650019, "text": "Agency code" },
    { "value": 175650001, "text": "Agent title" },
    { "value": 175650006, "text": "Agent type" },
    { "value": 175650003, "text": "AUM/TM" },
    { "value": 175650057, "text": "AUM/TM appointment date" },
    { "value": 175650058, "text": "AUM/TM expiry date" },
    { "value": 175650021, "text": "District code" },
    { "value": 175650011, "text": "Industrial LOU" },
    { "value": 175650005, "text": "Inforce/Terminated" },
    { "value": 175650002, "text": "IsLeader" },
    { "value": 175650069, "text": "License paper 2" },
    { "value": 175650070, "text": "License paper 3" },
    { "value": 175650071, "text": "License paper 4" },
    { "value": 175650072, "text": "License paper 5" },
    { "value": 175650073, "text": "License paper count" },
    { "value": 175650010, "text": "LOU" },
    { "value": 175650044, "text": "Primary agent code" },
    { "value": 175650043, "text": "Start date" },
    { "value": 175650052, "text": "Team" },
    { "value": 175650051, "text": "Zone" }];
var agentKPIOption = [{ "value": 175650000, "text": "Agent code" },
    { "value": 175650015, "text": "Average Life persistency" },
    { "value": 175650016, "text": "Average PA persistency" },
    { "value": 175650017, "text": "Life persistency for contest" },
    { "value": 175650018, "text": "PA persistency for contest" },
    { "value": 175650042, "text": "Period" }];
var agencyOption = [{ "value": 175650019, "text": "Agency code" },
    { "value": 175650053, "text": "Agency name" },
    { "value": 175650020, "text": "Agency status" },
    { "value": 175650021, "text": "District code" }];
var agencyKPIOption = [{ "value": 175650019, "text": "Agency code" },
    { "value": 175650015, "text": "Average Life persistency" },
    { "value": 175650016, "text": "Average PA persistency" },
    { "value": 175650017, "text": "Life persistency for contest" },
    { "value": 175650018, "text": "PA persistency for contest" },
    { "value": 175650042, "text": "Period" }];
var districtOption = [{ "value": 175650021, "text": "District code" },
    { "value": 175650054, "text": "District name" },
    { "value": 175650023, "text": "DOY indicator" },
    { "value": 175650022, "text": "DOY production base" },
    { "value": 175650056, "text": "Dragon's Meeting FYC C&A base" },
    { "value": 175650055, "text": "Summit Club FYC C&A base" }
];
var districtKPIOption = [{ "value": 175650015, "text": "Average Life persistency" },
    { "value": 175650016, "text": "Average PA persistency" },
    { "value": 175650021, "text": "District code" },
    { "value": 175650017, "text": "Life persistency for contest" },
    { "value": 175650018, "text": "PA persistency for contest" },
    { "value": 175650042, "text": "Period" }];
var policyTXNOption = [{ "value": 175650019, "text": "Agency code" },
    { "value": 175650000, "text": "Agent code" },
    { "value": 175650029, "text": "Case count" },
    { "value": 175650034, "text": "Cooloff" },
    { "value": 175650031, "text": "CRM" },
    { "value": 175650048, "text": "Delivery Date" },
    { "value": 175650030, "text": "FYC(HKD)" },
    { "value": 175650035, "text": "iFHC" },
    { "value": 175650032, "text": "Insured Alpha ID" },
    { "value": 175650037, "text": "IVS indicator" },
    { "value": 175650025, "text": "LOB" },
    { "value": 175650028, "text": "Plan code" },
    { "value": 175650024, "text": "Policy number" },
    { "value": 175650050, "text": "Policy prefix" },
    { "value": 175650036, "text": "PPP indicator" },
    { "value": 175650027, "text": "Product series" },
    { "value": 175650038, "text": "Prospect ID" },
    { "value": 175650033, "text": "Submission channel" },
    { "value": 175650049, "text": "Submission date" },
    { "value": 175650047, "text": "Transaction date" }];
// Award quakifiers
var progressAndResultOption = [{ "value": 175650077, "text": "Accumulated value" },
    { "value": 175650045, "text": "Achieved level" },
    { "value": 175650019, "text": "Agency code" },
    { "value": 175650000, "text": "Agent code" },
    { "value": 175650040, "text": "Award" },
    { "value": 175650078, "text": "Award requirement" },
    { "value": 175650061, "text": "Bonus amount" },
    { "value": 175650039, "text": "Contest" },
    { "value": 175650041, "text": "Obtained" }
];
var MDRTIncentive = [{ "value": 175650000, "text": "Agent code" },
    { "value": 175650066, "text": "Incentive (HKD)" },
    { "value": 175650065, "text": "MDRT year" }];
var agentFYP = [{ "value": 175650042, "text": "Period" },
    { "value": 175650067, "text": "YTD FYP (HKD)" }];
var income = [{ "value": 175650042, "text": "Period" },
    { "value": 175650063, "text": "YTD income (HKD)" }];
var MDRTMembership = [{ "value": 175650000, "text": "Agent code" },
    { "value": 175650076, "text": "Life member indicator" },
    { "value": 175650068, "text": "MDRT membership description" },
    { "value": 175650065, "text": "MDRT year" },
    { "value": 175650074, "text": "MDRT member indicator" },
    { "value": 175650075, "text": "Production exemption" }];
var fullOperatorOption = [{ "value": 175650000, "text": "=" },
    { "value": 175650001, "text": "<>" },
    { "value": 175650002, "text": ">=" },
    { "value": 175650003, "text": "<=" },
    { "value": 175650004, "text": ">" },
    { "value": 175650005, "text": "<" }
    //, { "value": 175650006, "text": "Same month" }
];
var exactOperatorOption = [{ "value": 175650000, "text": "=" },
    { "value": 175650001, "text": "<>" }];
var fullOperatorList = [175650015,
    175650016,
    175650017,
    175650018,
    175650022,
    175650029,
    175650030,
    175650042,
    175650043,
    175650045,
    175650046,
    175650047,
    175650048,
    175650049,
    175650055,
    175650056,
    175650057,
    175650058,
    175650061,
    175650063,
    175650066,
    175650067,
    175650073,
    175650077];
var exactOperatorList = [175650000,
    175650001,
    175650002,
    175650003,
    175650004,
    175650005,
    175650006,
    175650007,
    175650008,
    175650009,
    175650010,
    175650011,
    175650012,
    175650013,
    175650014,
    175650019,
    175650020,
    175650021,
    175650023,
    175650024,
    175650025,
    175650026,
    175650027,
    175650028,
    175650031,
    175650032,
    175650033,
    175650034,
    175650035,
    175650036,
    175650037,
    175650038,
    175650039,
    175650040,
    175650041,
    175650044,
    175650051,
    175650052,
    175650053,
    175650054,
    175650059,
    175650060,
    175650065,
    175650068,
    175650069,
    175650070,
    175650071,
    175650072,
    175650074,
    175650075,
    175650076,
    175650078];
var ACT;
(function (ACT) {
    var FieldValidation;
    (function (FieldValidation) {
        function setRelatedFieldOption(executionContext) {
            var formContext = executionContext.getFormContext();
            var entityValue = null;
            var relatedField = null;
            var sortByField = null;
            var currentEntityName = formContext.data.entity.getEntityName();
            switch (currentEntityName) {
                case "cms_rollupline": {
                    entityValue = formContext.getAttribute("cms_entity").getValue();
                    relatedField = formContext.getControl("cms_relatedfield");
                    sortByField = formContext.getControl("cms_sortby");
                    break;
                }
                case "cms_rollupcriteria": {
                    entityValue = formContext.getAttribute("cms_rollupentity").getValue();
                    relatedField = formContext.getControl("cms_criteria");
                    break;
                }
                case "cms_eligibility": {
                    entityValue = formContext.getAttribute("cms_entity").getValue();
                    relatedField = formContext.getControl("cms_field");
                    break;
                }
                case "cms_requirement": {
                    entityValue = formContext.getAttribute("cms_entity").getValue();
                    relatedField = formContext.getControl("cms_field");
                    break;
                }
                case "cms_specialruleline": {
                    entityValue = formContext.getAttribute("cms_entity").getValue();
                    relatedField = formContext.getControl("cms_field");
                    break;
                }
                case "cms_exclusionrule": {
                    entityValue = formContext.getAttribute("cms_entity").getValue();
                    relatedField = formContext.getControl("cms_field");
                    break;
                }
                default: {
                    break;
                }
            }
            if (relatedField != null) {
                relatedField.clearOptions();
                switch (entityValue) {
                    //contact
                    case 175650000: {
                        for (var i = 0; i < contactOption.length; i++) {
                            var option = contactOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //agentHistory
                    case 175650001: {
                        for (var i = 0; i < agentHistoryOption.length; i++) {
                            var option = agentHistoryOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //agentKPI
                    case 175650002: {
                        for (var i = 0; i < agentKPIOption.length; i++) {
                            var option = agentKPIOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //agency
                    case 175650003: {
                        for (var i = 0; i < agencyOption.length; i++) {
                            var option = agencyOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //agencyKPI
                    case 175650004: {
                        for (var i = 0; i < agencyKPIOption.length; i++) {
                            var option = agencyKPIOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //district
                    case 175650005: {
                        for (var i = 0; i < districtOption.length; i++) {
                            var option = districtOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //districtKPI
                    case 175650006: {
                        for (var i = 0; i < districtKPIOption.length; i++) {
                            var option = districtKPIOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //policyTXN
                    case 175650007: {
                        for (var i = 0; i < policyTXNOption.length; i++) {
                            var option = policyTXNOption[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    //progressAndResult
                    case 175650008: {
                        for (var i = 0; i < progressAndResultOption.length; i++) {
                            var option = progressAndResultOption[i];
                            if (currentEntityName != "cms_rollupcriteria" && option.value == 175650078) {
                                continue;
                            }
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    // MDRT Incentive
                    case 175650010: {
                        for (var i = 0; i < MDRTIncentive.length; i++) {
                            var option = MDRTIncentive[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    // Agent FYP
                    case 175650012: {
                        for (var i = 0; i < agentFYP.length; i++) {
                            var option = agentFYP[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    // Income
                    case 175650009: {
                        for (var i = 0; i < income.length; i++) {
                            var option = income[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    // MDRT membership
                    case 175650011: {
                        for (var i = 0; i < MDRTMembership.length; i++) {
                            var option = MDRTMembership[i];
                            relatedField.addOption(option);
                        }
                        break;
                    }
                    default: {
                        //statements; 
                        break;
                    }
                }
            }
            if (sortByField != null) {
                sortByField.clearOptions();
                switch (entityValue) {
                    //contact
                    case 175650000: {
                        for (var i = 0; i < contactOption.length; i++) {
                            var option = contactOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //agentHistory
                    case 175650001: {
                        for (var i = 0; i < agentHistoryOption.length; i++) {
                            var option = agentHistoryOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //agentKPI
                    case 175650002: {
                        for (var i = 0; i < agentKPIOption.length; i++) {
                            var option = agentKPIOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //agency
                    case 175650003: {
                        for (var i = 0; i < agencyOption.length; i++) {
                            var option = agencyOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //agencyKPI
                    case 175650004: {
                        for (var i = 0; i < agencyKPIOption.length; i++) {
                            var option = agencyKPIOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //district
                    case 175650005: {
                        for (var i = 0; i < districtOption.length; i++) {
                            var option = districtOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //districtKPI
                    case 175650006: {
                        for (var i = 0; i < districtKPIOption.length; i++) {
                            var option = districtKPIOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //policyTXN
                    case 175650007: {
                        for (var i = 0; i < policyTXNOption.length; i++) {
                            var option = policyTXNOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    //progressAndResult
                    case 175650008: {
                        for (var i = 0; i < progressAndResultOption.length; i++) {
                            var option = progressAndResultOption[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    // MDRT Incentive
                    case 175650010: {
                        for (var i = 0; i < MDRTIncentive.length; i++) {
                            var option = MDRTIncentive[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    // Agent FYP
                    case 175650012: {
                        for (var i = 0; i < agentFYP.length; i++) {
                            var option = agentFYP[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    // Income
                    case 175650009: {
                        for (var i = 0; i < income.length; i++) {
                            var option = income[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    // MDRT membership
                    case 175650011: {
                        for (var i = 0; i < MDRTMembership.length; i++) {
                            var option = MDRTMembership[i];
                            sortByField.addOption(option);
                        }
                        break;
                    }
                    default: {
                        //statements; 
                        break;
                    }
                }
            }
        }
        FieldValidation.setRelatedFieldOption = setRelatedFieldOption;
        function operatorControl(executionContext) {
            var formContext = executionContext.getFormContext();
            var operatorField = formContext.getControl("cms_operator");
            var operator = formContext.getAttribute("cms_operator");
            var operatorValue = operator.getValue();
            var relatedValue = null;
            var currentEntityName = formContext.data.entity.getEntityName();
            var valueExist = false;
            switch (currentEntityName) {
                case "cms_rollupline": {
                    relatedValue = formContext.getAttribute("cms_relatedfield");
                    break;
                }
                case "cms_rollupcriteria": {
                    relatedValue = formContext.getAttribute("cms_criteria");
                    break;
                }
                case "cms_eligibility": {
                    relatedValue = formContext.getAttribute("cms_field");
                    break;
                }
                case "cms_requirement": {
                    relatedValue = formContext.getAttribute("cms_field");
                    break;
                }
                case "cms_specialruleline": {
                    relatedValue = formContext.getAttribute("cms_field");
                    break;
                }
                case "cms_exclusionrule": {
                    relatedValue = formContext.getAttribute("cms_field");
                    break;
                }
                default: {
                    break;
                }
            }
            operatorField.clearOptions();
            if (relatedValue.getValue() != null) {
                // check full operator entity field list
                var checkEntityField = checkValueExist(fullOperatorList, relatedValue.getValue());
                if (checkEntityField.length > 0) {
                    for (var i = 0; i < fullOperatorOption.length; i++) {
                        var option = fullOperatorOption[i];
                        operatorField.addOption(option);
                    }
                    if (currentEntityName == "cms_rollupcriteria") {
                        operatorField.addOption({ "value": 175650006, "text": "Same month" });
                    }
                }
                else {
                    // check exact operator entity field list
                    checkEntityField = checkValueExist(exactOperatorList, relatedValue.getValue());
                    if (checkEntityField.length > 0) {
                        for (var i = 0; i < exactOperatorOption.length; i++) {
                            var option = exactOperatorOption[i];
                            operatorField.addOption(option);
                            if (operatorValue == option.value) {
                                valueExist = true;
                            }
                        }
                    }
                    if (!valueExist) {
                        operator.setValue(null);
                    }
                }
            }
            else {
                for (var i = 0; i < fullOperatorOption.length; i++) {
                    var option = fullOperatorOption[i];
                    operatorField.addOption(option);
                }
                if (currentEntityName == "cms_rollupcriteria") {
                    operatorField.addOption({ "value": 175650006, "text": "Same month" });
                }
            }
        }
        FieldValidation.operatorControl = operatorControl;
        function relatedFieldControl(executionContext) {
            var formContext = executionContext.getFormContext();
            var currentEntityName = formContext.data.entity.getEntityName();
            var relatedField = null;
            var relatedFieldValue;
            var relatedFieldCtl;
            // Field attribute
            var yesNoInput = null, value = null, dateinput = null, numberinput = null, inforceTerminated = null, contest = null, mdrtMembership = null, rollup = null, entityField;
            // Field control
            var yesNoInputCtl = null, valueCtl = null, dateinputCtl = null, numberinputCtl = null, inforceTerminatedCtl = null, contestCtl = null, mdrtMembershipCtl = null;
            // control
            var agentTitle = null, agentType = null, doy = null, mcvlocal = null, productGroup = null, productSeries = null, region = null, submissionChannel = null, team = null, zone = null, lob = null, award = null, requirement = null;
            var showDate = false, showNoYes = false, showValue = false, showNumber = false, showInforceTerminated = false, showContest = false, showAwardGrid = false, showAgentTitleGrid = false, showAgentTypeGrid = false, showDOYGrid = false, showLOBGrid = false, showMCVLocalGrid = false, showProductGroupGrid = false, showProductSeriesGrid = false, showRegionGrid = false, showSubmissionChannelGrid = false, showTeamGrid = false, showZoneGrid = false, showMDRTMembership = false, showRequirementGrid = false;
            var isGrid = false;
            var agentEnabled = false, agentHistoryEnabled = false, districtEnabled = false, policyTxnEnabled = false, awardQualifierEnabled = false;
            var rollupId = null;
            // set variable - begin
            yesNoInput = formContext.getAttribute("cms_yesnoinput");
            yesNoInputCtl = formContext.getControl("cms_yesnoinput");
            value = formContext.getAttribute("cms_value");
            valueCtl = formContext.getControl("cms_value");
            dateinput = formContext.getAttribute("cms_dateinput");
            dateinputCtl = formContext.getControl("cms_dateinput");
            numberinput = formContext.getAttribute("cms_numberinput");
            numberinputCtl = formContext.getControl("cms_numberinput");
            switch (currentEntityName) {
                case "cms_rollupcriteria":
                    relatedField = formContext.getAttribute("cms_criteria");
                    relatedFieldCtl = formContext.getControl("cms_criteria");
                    inforceTerminated = formContext.getAttribute("cms_inforceterminated");
                    inforceTerminatedCtl = formContext.getControl("cms_inforceterminated");
                    contest = formContext.getAttribute("cms_contest");
                    contestCtl = formContext.getControl("cms_contest");
                    mdrtMembership = formContext.getAttribute("cms_mdrtmembership");
                    mdrtMembershipCtl = formContext.getControl("cms_mdrtmembership");
                    requirement = formContext.getControl("AwardRequirement");
                    isGrid = true;
                    agentEnabled = true;
                    agentHistoryEnabled = true;
                    districtEnabled = true;
                    policyTxnEnabled = true;
                    awardQualifierEnabled = true;
                    break;
                case "cms_specialruleline":
                    relatedField = formContext.getAttribute("cms_field");
                    relatedFieldCtl = formContext.getControl("cms_field");
                    policyTxnEnabled = true;
                    break;
                case "cms_eligibility":
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    rollup = formContext.getAttribute("cms_rollupid");
                    relatedFieldCtl = formContext.getControl("cms_field");
                    inforceTerminated = formContext.getAttribute("cms_inforceterminated");
                    inforceTerminatedCtl = formContext.getControl("cms_inforceterminated");
                    agentEnabled = true;
                    agentHistoryEnabled = true;
                    districtEnabled = true;
                    break;
                case "cms_requirement":
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    rollup = formContext.getAttribute("cms_rollupid");
                    relatedFieldCtl = formContext.getControl("cms_field");
                    inforceTerminated = formContext.getAttribute("cms_inforceterminated");
                    inforceTerminatedCtl = formContext.getControl("cms_inforceterminated");
                    isGrid = true;
                    agentEnabled = true;
                    agentHistoryEnabled = true;
                    districtEnabled = true;
                    policyTxnEnabled = true;
                    break;
                case "cms_exclusionrule":
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    rollup = formContext.getAttribute("cms_rollupid");
                    relatedFieldCtl = formContext.getControl("cms_field");
                    inforceTerminated = formContext.getAttribute("cms_inforceterminated");
                    inforceTerminatedCtl = formContext.getControl("cms_inforceterminated");
                    agentEnabled = true;
                    agentHistoryEnabled = true;
                    districtEnabled = true;
                    policyTxnEnabled = true;
                    break;
                default: {
                    break;
                }
            }
            if (isGrid) {
                if (agentEnabled) {
                    mcvlocal = formContext.getControl("mcvlocal");
                    region = formContext.getControl("region");
                }
                if (agentHistoryEnabled) {
                    agentTitle = formContext.getControl("agenttitle");
                    agentType = formContext.getControl("agenttype");
                    team = formContext.getControl("team");
                    zone = formContext.getControl("zone");
                }
                if (districtEnabled) {
                    doy = formContext.getControl("doy");
                }
                if (policyTxnEnabled) {
                    lob = formContext.getControl("lob");
                    productGroup = formContext.getControl("productgroup");
                    productSeries = formContext.getControl("productseries");
                    submissionChannel = formContext.getControl("submissionchannel");
                }
                if (awardQualifierEnabled) {
                    award = formContext.getControl("award");
                }
            }
            else {
                if (agentEnabled) {
                    mcvlocal = formContext.ui.tabs.get("general").sections.get("mcvlocalsection");
                    region = formContext.ui.tabs.get("general").sections.get("regionsector");
                }
                if (agentHistoryEnabled) {
                    agentTitle = formContext.ui.tabs.get("general").sections.get("agenttitlesection");
                    agentType = formContext.ui.tabs.get("general").sections.get("agenttypesection");
                    team = formContext.ui.tabs.get("general").sections.get("teamsector");
                    zone = formContext.ui.tabs.get("general").sections.get("zonesector");
                }
                if (districtEnabled) {
                    doy = formContext.ui.tabs.get("general").sections.get("doysector");
                }
                if (policyTxnEnabled) {
                    lob = formContext.ui.tabs.get("general").sections.get("lobsector");
                    productGroup = formContext.ui.tabs.get("general").sections.get("productgroupsector");
                    productSeries = formContext.ui.tabs.get("general").sections.get("productseriessector");
                    submissionChannel = formContext.ui.tabs.get("general").sections.get("submissionchannelsector");
                }
            }
            // set variable - end
            // check value - begin
            if (rollup != null) {
                rollupId = rollup.getValue();
            }
            if (rollupId != null) {
                showValue = true;
                if (entityField.getValue() == null) {
                    entityField.setValue(175650000); // Agent
                    setRelatedFieldOption(executionContext);
                }
                relatedFieldCtl.setVisible(false);
                relatedField.setValue(null);
            }
            else {
                relatedFieldCtl.setVisible(true);
                relatedFieldValue = relatedField.getValue();
                switch (relatedFieldValue) {
                    case 175650042:
                    case 175650043:
                    case 175650046:
                    case 175650047:
                    case 175650048:
                    case 175650049:
                    case 175650057:
                    case 175650058:
                        showDate = true;
                        break;
                    case 175650022:
                    case 175650029:
                    case 175650030:
                    case 175650045:
                    case 175650056:
                    case 175650061:
                    case 175650062:
                    case 175650063:
                    case 175650066:
                    case 175650073:
                        showNumber = true;
                        break;
                    case 175650000:
                    case 175650010:
                    case 175650014:
                    case 175650019:
                    case 175650021:
                    case 175650024:
                    case 175650028:
                    case 175650032:
                    case 175650038:
                    case 175650044:
                    case 175650050:
                    case 175650065:
                    case 175650067:
                    case 175650077:
                        showValue = true;
                        break;
                    case 175650002:
                    case 175650003:
                    case 175650004:
                    case 175650007:
                    case 175650008:
                    case 175650009:
                    case 175650011:
                    case 175650013:
                    case 175650031:
                    case 175650034:
                    case 175650035:
                    case 175650036:
                    case 175650037:
                    case 175650041:
                    case 175650060:
                    case 175650069:
                    case 175650070:
                    case 175650071:
                    case 175650072:
                    case 175650074:
                    case 175650075:
                    case 175650076:
                        showNoYes = true;
                        break;
                    case 175650005:
                        showInforceTerminated = true;
                        break;
                    case 175650039:
                        showContest = true;
                        break;
                    case 175650040:
                        showAwardGrid = true;
                        break;
                    case 175650001:
                        showAgentTitleGrid = true;
                        break;
                    case 175650006:
                        showAgentTypeGrid = true;
                        break;
                    case 175650023:
                        showDOYGrid = true;
                        break;
                    case 175650025:
                        showLOBGrid = true;
                        break;
                    case 175650012:
                        showMCVLocalGrid = true;
                        break;
                    case 175650026:
                        showProductGroupGrid = true;
                        break;
                    case 175650027:
                        showProductSeriesGrid = true;
                        break;
                    case 175650059:
                        showRegionGrid = true;
                        break;
                    case 175650033:
                        showSubmissionChannelGrid = true;
                        break;
                    case 175650052:
                        showTeamGrid = true;
                        break;
                    case 175650051:
                        showZoneGrid = true;
                        break;
                    case 175650068:
                        showMDRTMembership = true;
                        break;
                    case 175650078:
                        showRequirementGrid = true;
                        break;
                }
            }
            // check value - end
            // set visible - begin
            yesNoInputCtl.setVisible(showNoYes);
            if (!showNoYes)
                yesNoInput.setValue(null);
            dateinputCtl.setVisible(showDate);
            if (!showDate)
                dateinput.setValue(null);
            valueCtl.setVisible(showValue);
            if (!showValue)
                value.setValue(null);
            numberinputCtl.setVisible(showNumber);
            if (!showNumber)
                numberinput.setValue(null);
            if (inforceTerminatedCtl != null) {
                inforceTerminatedCtl.setVisible(showInforceTerminated);
                if (!showInforceTerminated)
                    inforceTerminated.setValue(null);
            }
            if (contest != null) {
                contestCtl.setVisible(showContest);
                if (!showContest)
                    contest.setValue(null);
            }
            if (mdrtMembership != null) {
                mdrtMembershipCtl.setVisible(showMDRTMembership);
                if (!showMDRTMembership)
                    mdrtMembership.setValue(null);
            }
            if (requirement != null)
                requirement.setVisible(showRequirementGrid);
            if (agentTitle != null)
                agentTitle.setVisible(showAgentTitleGrid);
            if (agentType != null)
                agentType.setVisible(showAgentTypeGrid);
            if (doy != null)
                doy.setVisible(showDOYGrid);
            if (lob != null)
                lob.setVisible(showLOBGrid);
            if (mcvlocal != null)
                mcvlocal.setVisible(showMCVLocalGrid);
            if (productGroup != null)
                productGroup.setVisible(showProductGroupGrid);
            if (productSeries != null)
                productSeries.setVisible(showProductSeriesGrid);
            if (region != null)
                region.setVisible(showRegionGrid);
            if (submissionChannel != null)
                submissionChannel.setVisible(showSubmissionChannelGrid);
            if (team != null)
                team.setVisible(showTeamGrid);
            if (zone != null)
                zone.setVisible(showZoneGrid);
            if (award != null)
                award.setVisible(showAwardGrid);
            // set visible - end
        }
        FieldValidation.relatedFieldControl = relatedFieldControl;
        function checkValueExist(entityFieldList, entityFieldValue) {
            var entityField = entityFieldList.filter(function (setValue) {
                return setValue == entityFieldValue;
            });
            return entityField;
        }
        function valueValidation(executionContext) {
            var formContext = executionContext.getFormContext();
            var entityField = null;
            var relatedField = null;
            var currentEntityName = formContext.data.entity.getEntityName();
            switch (currentEntityName) {
                case "cms_rollupcriteria": {
                    entityField = formContext.getAttribute("cms_rollupentity");
                    relatedField = formContext.getAttribute("cms_criteria");
                    break;
                }
                case "cms_eligibility": {
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    break;
                }
                case "cms_requirement": {
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    break;
                }
                case "cms_specialruleline": {
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    break;
                }
                case "cms_exclusionrule": {
                    entityField = formContext.getAttribute("cms_entity");
                    relatedField = formContext.getAttribute("cms_field");
                    break;
                }
                default: {
                    break;
                }
            }
            if (entityField != null && relatedField != null) {
                var relatedValue = relatedField.getValue();
                if (relatedValue == 175650000 || // Agent code
                    relatedValue == 175650019 || // Agency code
                    relatedValue == 175650021 || // District code
                    relatedValue == 175650044) { // Primary agent code
                    var value = formContext.getAttribute("cms_value");
                    var valueList = formatValidation(value.getValue());
                    formContext.ui.clearFormNotification("FormatError");
                    formContext.ui.clearFormNotification("ValueError");
                    if (valueList == null) {
                        formContext.ui.setFormNotification("Please check the value format", "ERROR", "FormatError");
                    }
                    else {
                        var entityName = null;
                        var keyName = null;
                        var keyValue = null;
                        switch (relatedValue) {
                            case 175650000: // Agent code
                                entityName = "lms_agent";
                                keyName = "lms_agent_code";
                                break;
                            case 175650019: // Agency code
                                entityName = "aia_agency";
                                keyName = "aia_name";
                                break;
                            case 175650021: // District code
                                entityName = "aia_district";
                                keyName = "aia_name";
                                break;
                            case 175650044: // Primary agent code
                                entityName = "lms_agent";
                                keyName = "lms_agent_code";
                                break;
                        }
                        for (var i = 0; i < valueList.length; i++) {
                            keyValue = valueList[i];
                            var queryOption = "?$top=1" +
                                "&$filter=" + keyName + " eq '" + keyValue + "'";
                            Xrm.WebApi.retrieveMultipleRecords(entityName, queryOption).then(function success(result) {
                                if (result.entities.length == 0) {
                                    formContext.ui.setFormNotification("Values filled do not exist", "ERROR", "ValueError");
                                }
                            }, function (error) {
                                console.log(error.message);
                                // handle error conditions
                            });
                        }
                    }
                }
            }
        }
        FieldValidation.valueValidation = valueValidation;
        function formatValidation(value) {
            var pass = true;
            var valueSplit = value.split(",");
            var curValue = null;
            var valueList = [];
            for (var i = 0; i < valueSplit.length; i++) {
                curValue = valueSplit[i];
                for (var n = 0; n < curValue.length; n++) {
                    var curChar = curValue.substring(n, n + 1);
                    if (n == 0 || n == curValue.length - 1) {
                        if (curChar != "\"")
                            pass = false;
                    }
                    else {
                        if (curChar == "\"")
                            pass = false;
                    }
                    if (n == curValue.length - 1 && pass) {
                        valueList[i] = curValue.substring(1, curValue.length - 1);
                    }
                }
            }
            if (!pass)
                valueList = null;
            return valueList;
        }
    })(FieldValidation = ACT.FieldValidation || (ACT.FieldValidation = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=FieldValidation.js.map