/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_ExclusionRule;
    (function (form_ExclusionRule) {
        function setEntityOption(executionContext) {
            var formContext = executionContext.getFormContext();
            var entityField = formContext.getControl("cms_entity");
            if (entityField != null) {
                entityField.clearOptions();
                entityField.addOption({ "value": 175650000, "text": "Agent" });
                entityField.addOption({ "value": 175650001, "text": "Agent history " });
            }
        }
        form_ExclusionRule.setEntityOption = setEntityOption;
    })(form_ExclusionRule = ACT.form_ExclusionRule || (ACT.form_ExclusionRule = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_ExclusionRule.js.map