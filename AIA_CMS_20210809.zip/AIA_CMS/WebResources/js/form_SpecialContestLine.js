/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_SpecialContestLine;
    (function (form_SpecialContestLine) {
        function awardLookupFilter(executionContext) {
            var formContext = executionContext.getFormContext();
            var specialContestHeader = formContext.getAttribute("cms_specialcontestheader");
            var awardCtl = formContext.getControl("cms_award");
            if (specialContestHeader.getValue() != null) {
                var specialContestHeaderId = specialContestHeader.getValue()[0].id;
                Xrm.WebApi.retrieveRecord("cms_specialcontestheader", specialContestHeaderId).then(function success(result) {
                    var contestId = result._cms_contest_value;
                    awardCtl.addPreSearch(function () {
                        var awardFilter = "<filter type=\"and\">" +
                            "<condition attribute=\"cms_contestid\" operator=\"eq\" value=\"" + contestId + "\" />" +
                            "</filter>";
                        awardCtl.addCustomFilter(awardFilter, "cms_award");
                    });
                });
            }
        }
        form_SpecialContestLine.awardLookupFilter = awardLookupFilter;
    })(form_SpecialContestLine = ACT.form_SpecialContestLine || (ACT.form_SpecialContestLine = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_SpecialContestLine.js.map