/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_SpecialRuleHeader;
    (function (form_SpecialRuleHeader) {
        function ruleTypeControl(executionContext) {
            var formContext = executionContext.getFormContext();
            var ruletype = formContext.getAttribute("cms_ruletype");
            var specialContest = formContext.getAttribute("cms_specialcontest");
            var specialContestCtl = formContext.getControl("cms_specialcontest");
            var visible = false;
            if (ruletype.getValue() != null) {
                if (ruletype.getValue() == 175650000 /*Exclusion*/) {
                    visible = false;
                }
                else {
                    visible = true;
                }
            }
            else {
                visible = false;
            }
            specialContestCtl.setVisible(visible);
            if (!visible) {
                specialContest.setValue(null);
            }
        }
        form_SpecialRuleHeader.ruleTypeControl = ruleTypeControl;
        function speicalContestLookupFilter(executionContext) {
            var formContext = executionContext.getFormContext();
            var specialContestCtl = formContext.getControl("cms_specialcontest");
            specialContestCtl.addPreSearch(function () {
                addLookupFilter(executionContext);
            });
        }
        form_SpecialRuleHeader.speicalContestLookupFilter = speicalContestLookupFilter;
        function addLookupFilter(executionContext) {
            var formContext = executionContext.getFormContext();
            var specialContestCtl = formContext.getControl("cms_specialcontest");
            var contest = formContext.getAttribute("cms_contest");
            var contestId = "";
            if (contest.getValue() != null) {
                contestId = contest.getValue()[0].id;
            }
            var specContestFilter = "<filter type=\"and\">" +
                "<condition attribute=\"cms_contest\" operator=\"eq\" value=\"" + contestId + "\" />" +
                "</filter>";
            specialContestCtl.addCustomFilter(specContestFilter, "cms_specialcontestheader");
        }
    })(form_SpecialRuleHeader = ACT.form_SpecialRuleHeader || (ACT.form_SpecialRuleHeader = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_SpecialRuleHeader.js.map