/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var validateWriteByActive;
    (function (validateWriteByActive) {
        var isSave = false;
        function validateWrite(executionContext) {
            if (isSave) {
                return;
            }
            else {
                var formContext = executionContext.getFormContext();
                executionContext.getEventArgs().preventDefault();
                switch (formContext.data.entity.getEntityName()) {
                    case "cms_award":
                        var contest = formContext.getAttribute("cms_contestid").getValue();
                        if (contest != null) {
                            retrieveAndCheckContest(formContext, contest[0].id);
                        }
                        break;
                    case "cms_requirement":
                    case "cms_grouping":
                    case "cms_eligibility":
                    case "cms_awardrankingbreakdown":
                        var award = formContext.getAttribute("cms_awardid").getValue();
                        if (award != null) {
                            retrieveAward(formContext, award[0].id);
                        }
                        break;
                    case "cms_branchoutdistrict":
                        var award = formContext.getAttribute("cms_award").getValue();
                        if (award != null) {
                            retrieveAward(formContext, award[0].id);
                        }
                        break;
                    case "cms_groupingline":
                        var grouping = formContext.getAttribute("cms_groupingid").getValue();
                        if (grouping != null) {
                            retrieveGrouping(formContext, grouping[0].id);
                        }
                        break;
                }
            }
        }
        validateWriteByActive.validateWrite = validateWrite;
        function retrieveGrouping(formContext, groupingId) {
            Xrm.WebApi.retrieveRecord("cms_grouping", groupingId).then(function success(grouping) {
                retrieveAward(formContext, grouping._cms_awardid_value);
            });
        }
        function retrieveAward(formContext, awardId) {
            Xrm.WebApi.retrieveRecord("cms_award", awardId).then(function success(award) {
                retrieveAndCheckContest(formContext, award._cms_contestid_value);
            });
        }
        function retrieveAndCheckContest(formContext, contestId) {
            Xrm.WebApi.retrieveRecord("cms_contest", contestId, "?$select=cms_active").then(function success(result) {
                isSave = result.cms_active == false;
                if (isSave) {
                    formContext.data.save();
                }
                else {
                    formContext.ui.setFormNotification("Contest actived, not allow create/update record", "ERROR", "Actived");
                }
            }, function (error) {
                console.log(error.message);
                // handle error conditions
            });
        }
    })(validateWriteByActive = ACT.validateWriteByActive || (ACT.validateWriteByActive = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=validateWriteByActive.js.map