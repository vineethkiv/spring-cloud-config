/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_Requirement;
    (function (form_Requirement) {
        function multiPerLevelControl(executionContext) {
            var formContext = executionContext.getFormContext();
            var rollupId = formContext.getAttribute("cms_rollupid").getValue();
            var cms_multiplierperlevel = formContext.getAttribute("cms_multiplierperlevel");
            var cms_multiplierperlevelControl = cms_multiplierperlevel.controls.get(0);
            if (rollupId != null) {
                Xrm.WebApi.retrieveRecord("cms_rollup", rollupId[0].id, "?$select=cms_qualification").then(function success(result) {
                    if (result.cms_qualification == 175650000 /*Qualifier*/) {
                        cms_multiplierperlevelControl.setDisabled(false);
                    }
                    else {
                        cms_multiplierperlevel.setValue(null);
                        cms_multiplierperlevelControl.setDisabled(true);
                    }
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
            else {
                cms_multiplierperlevel.setValue(null);
                cms_multiplierperlevelControl.setDisabled(true);
            }
        }
        form_Requirement.multiPerLevelControl = multiPerLevelControl;
    })(form_Requirement = ACT.form_Requirement || (ACT.form_Requirement = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_Requirement.js.map