/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_RollupCriteria;
    (function (form_RollupCriteria) {
        function sequenceNumberDefValue(executionContext) {
            var formContext = executionContext.getFormContext();
            var sequenceNumber = formContext.getAttribute("cms_sequencenumber");
            if (sequenceNumber.getValue() == null && formContext.getAttribute("cms_rolluplineid").getValue() != null) {
                var rolluplineId = formContext.getAttribute("cms_rolluplineid").getValue()[0].id;
                Xrm.WebApi.retrieveMultipleRecords("cms_rollupcriteria", "?$select=cms_sequencenumber&$filter=_cms_rolluplineid_value eq " + rolluplineId).then(function success(result) {
                    sequenceNumber.setValue(result.entities.length + 1);
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
        }
        form_RollupCriteria.sequenceNumberDefValue = sequenceNumberDefValue;
    })(form_RollupCriteria = ACT.form_RollupCriteria || (ACT.form_RollupCriteria = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_RollupCriteria.js.map