/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_Result;
    (function (form_Result) {
        function executeIdDefValue(executionContext) {
            var formContext = executionContext.getFormContext();
            var executeId = formContext.getAttribute("cms_name");
            if (executeId.getValue() == null) {
                Xrm.WebApi.retrieveMultipleRecords("cms_resultheader").then(function success(result) {
                    var curExecuteId = (result.entities.length + 1).toString();
                    var idLength = curExecuteId.length;
                    for (var i = 1; i < 11 - idLength; i++) {
                        curExecuteId = "0" + curExecuteId;
                    }
                    executeId.setValue(curExecuteId);
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
        }
        form_Result.executeIdDefValue = executeIdDefValue;
        /*
        export function setSettlingDate(executionContext: Xrm.ExecutionContext<any, any>) {
            var formContext: Form.cms_rollupline.Main.Information = <Form.cms_rollupline.Main.Information>executionContext.getFormContext();
                    
            var adjustment = formContext.getAttribute("cms_adjustment");
            var settlingFromDate = formContext.getAttribute("cms_settlingfromdate");
            var settlingToDate = formContext.getAttribute("cms_settlingtodate");
            var contest = formContext.getAttribute("cms_contest");
    
            if (settlingFromDate.getValue() == null && settlingToDate.getValue() == null &&
                adjustment.getValue() == true && contest.getValue() != null) {
                var contestId = contest.getValue()[0].id;
                var queryOption = "?$orderby=cms_name desc" +
                                  "&$top=1" +
                                  "&$filter=_cms_contest_value eq " + contestId +
                                  " and cms_active eq " + true;
    
                Xrm.WebApi.retrieveMultipleRecords("cms_resultheader", queryOption).then(
                    function success(result) {
                        var currentDate = new Date(result.entities[0].cms_settlingtodate);
                        settlingFromDate.setValue(currentDate);
                        settlingToDate.setValue(currentDate);
                    },
                    function (error) {
                        console.log(error.message);
                        // handle error conditions
                    }
                );
            }
        }
        */
        function settlingFromDateValidation(executionContext) {
            var formContext = executionContext.getFormContext();
            var pass = true;
            //var adjustment = formContext.getAttribute("cms_adjustment");
            var settlingFromDate = formContext.getAttribute("cms_settlingfromdate");
            var settlingToDate = formContext.getAttribute("cms_settlingtodate");
            var contest = formContext.getAttribute("cms_contest");
            if (settlingFromDate.getValue() != null) {
                if ( //adjustment.getValue() == false &&
                contest.getValue() != null) {
                    var queryOption = getSettlingDateQueryOption(settlingFromDate.getValue(), contest.getValue()[0].id);
                    var resultheaderid = formContext.data.entity.getId();
                    if (resultheaderid != "") {
                        queryOption += " and cms_resultheaderid ne " + resultheaderid;
                    }
                    Xrm.WebApi.retrieveMultipleRecords("cms_resultheader", queryOption).then(function success(result) {
                        if (result.entities.length > 0) {
                            settlingFromDate.setValue(null);
                            formContext.ui.setFormNotification("The Settling from date entered is overlapped with previous executions", "ERROR", "FROMDATEOVERLAP");
                            pass = false;
                        }
                        else {
                            formContext.ui.clearFormNotification("FROMDATEOVERLAP");
                        }
                    }, function (error) {
                        console.log(error.message);
                        // handle error conditions
                    });
                }
                if (pass) {
                    if (!SettlingSameMonthValidation(settlingFromDate.getValue(), settlingToDate.getValue(), formContext)) {
                        settlingFromDate.setValue(null);
                    }
                }
            }
        }
        form_Result.settlingFromDateValidation = settlingFromDateValidation;
        function settlingToDateValidation(executionContext) {
            var formContext = executionContext.getFormContext();
            var pass = true;
            //var adjustment = formContext.getAttribute("cms_adjustment");
            var settlingFromDate = formContext.getAttribute("cms_settlingfromdate");
            var settlingToDate = formContext.getAttribute("cms_settlingtodate");
            var contest = formContext.getAttribute("cms_contest");
            if (settlingToDate.getValue() != null) {
                if (settlingToDate.getValue() < settlingFromDate.getValue()) {
                    settlingToDate.setValue(null);
                    formContext.ui.setFormNotification("Settling to date cannot be earlier than Settling from date.", "ERROR", "TODATEEARLIER");
                    pass = false;
                }
                else {
                    formContext.ui.clearFormNotification("TODATEEARLIER");
                }
                if (pass) {
                    if ( //adjustment.getValue() == false &&
                    contest.getValue() != null) {
                        var queryOption = getSettlingDateQueryOption(settlingToDate.getValue(), contest.getValue()[0].id);
                        var resultheaderid = formContext.data.entity.getId();
                        if (resultheaderid != "") {
                            queryOption += " and cms_resultheaderid ne " + resultheaderid;
                        }
                        Xrm.WebApi.retrieveMultipleRecords("cms_resultheader", queryOption).then(function success(result) {
                            if (result.entities.length > 0) {
                                settlingToDate.setValue(null);
                                formContext.ui.setFormNotification("The Settling to date entered is overlapped with previous executions", "ERROR", "TODATEOVERLAP");
                                pass = false;
                            }
                            else {
                                formContext.ui.clearFormNotification("TODATEOVERLAP");
                            }
                        }, function (error) {
                            console.log(error.message);
                            // handle error conditions
                        });
                    }
                }
                if (pass) {
                    if (!SettlingSameMonthValidation(settlingFromDate.getValue(), settlingToDate.getValue(), formContext)) {
                        settlingToDate.setValue(null);
                    }
                }
            }
        }
        form_Result.settlingToDateValidation = settlingToDateValidation;
        function getSettlingDateQueryOption(_date, _contest) {
            var year = _date.getFullYear();
            var month = (_date.getMonth() + 1).toString();
            var day = (_date.getDate()).toString();
            if (month.length == 1) {
                month = "0" + month;
            }
            if (day.length == 1) {
                day = "0" + day;
            }
            var dateISOFormat = year + "-" + month + "-" + day + "T00:00:00.000Z";
            var queryOption = "?$top=1" +
                "&$filter=_cms_contest_value eq " + _contest +
                " and cms_active eq " + true +
                " and cms_adjustment eq " + false +
                " and cms_simulation eq " + false +
                " and cms_settlingfromdate le " + dateISOFormat +
                " and cms_settlingtodate ge " + dateISOFormat;
            return queryOption;
        }
        function allowEdit(executionContext) {
            var formContext = executionContext.getFormContext();
            var contest = formContext.getAttribute("cms_contest");
            var active = formContext.getAttribute("cms_active");
            if (contest.getValue() != null && active.getValue() == true) {
                var contestid = contest.getValue()[0].id;
                var fromDate = formContext.getAttribute("cms_settlingfromdate").getValue();
                var year = fromDate.getFullYear();
                var month = (fromDate.getMonth() + 1).toString();
                var day = (fromDate.getDate()).toString();
                if (month.length == 1) {
                    month = "0" + month;
                }
                if (day.length == 1) {
                    day = "0" + day;
                }
                var dateISOFormat = year + "-" + month + "-" + day + "T00:00:00.000Z";
                var queryOption = "?$top=1" +
                    "&$filter=_cms_contest_value eq " + contestid +
                    " and cms_active eq " + true +
                    " and cms_settlingfromdate gt " + dateISOFormat;
                Xrm.WebApi.retrieveMultipleRecords("cms_resultheader", queryOption).then(function success(result) {
                    if (result.entities.length > 0) {
                        formContext.ui.controls.forEach(function (control, i) {
                            if (control && !control.getDisabled()) {
                                control.setDisabled(true);
                            }
                        });
                    }
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
        }
        form_Result.allowEdit = allowEdit;
        function SettlingSameMonthValidation(_fromDate, _toDate, formContext) {
            var pass = true;
            if (_fromDate != null && _toDate != null) {
                if (_fromDate.getMonth() != _toDate.getMonth()) {
                    formContext.ui.setFormNotification("Please enter Settling from date and Settling to date of the same month", "ERROR", "SETTLINGSAMEMONTH");
                    pass = false;
                }
                else {
                    formContext.ui.clearFormNotification("SETTLINGSAMEMONTH");
                }
            }
            return pass;
        }
    })(form_Result = ACT.form_Result || (ACT.form_Result = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_Result.js.map