/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_contest_nbcontest/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_Contest_NBContest;
    (function (form_Contest_NBContest) {
        function nbTemplateModified(executionContext) {
            var formContext = executionContext.getFormContext();
            var nbTemplate = formContext.getAttribute("cms_nbtemplate");
            if (nbTemplate.getValue() != null) {
                // clear first
                for (var i = 1; i <= 10; i++) {
                    formContext.getAttribute("cms_lob" + i.toString()).setValue(null);
                    formContext.getAttribute("cms_lobguid" + i.toString()).setValue(null);
                    formContext.getAttribute("cms_submissionchannel" + i.toString()).setValue(null);
                    formContext.getAttribute("cms_submissionchannelguid" + i.toString()).setValue(null);
                }
                var queryOption = "?$top=10" +
                    "&$filter=_cms_nbtemplateheader_value eq " + nbTemplate.getValue()[0].id;
                Xrm.WebApi.retrieveMultipleRecords("cms_nbtemplateline", queryOption).then(function success(result) {
                    for (var i = 0; i < result.entities.length; i++) {
                        var nbTemplateLine = result.entities[i];
                        nbTemplateLineHandling(i + 1, nbTemplateLine.cms_nbtemplatelineid, formContext);
                    }
                }, function (error) {
                    console.log(error.message);
                    // handle error conditions
                });
            }
        }
        form_Contest_NBContest.nbTemplateModified = nbTemplateModified;
        function nbTemplateLineHandling(i, nbTemplateLineId, formContext) {
            var lob, lobGuid, submissionChannel, submissionChannelGuid;
            var query = "?$filter=cms_nbtemplatelineid eq " + nbTemplateLineId;
            Xrm.WebApi.retrieveMultipleRecords("cms_cms_nbtemplateline_cms_lob", query).then(function success(lobSetResult) {
                for (var n = 0; n < lobSetResult.entities.length; n++) {
                    var lobSet = lobSetResult.entities[n];
                    Xrm.WebApi.retrieveRecord("cms_lob", lobSet.cms_lobid).then(function success(lobResult) {
                        lob = formContext.getAttribute("cms_lob" + i.toString());
                        lobGuid = formContext.getAttribute("cms_lobguid" + i.toString());
                        if (lob.getValue() != null)
                            lob.setValue(lob.getValue() + ",\"" + lobResult.cms_name + "\"");
                        else
                            lob.setValue("\"" + lobResult.cms_name + "\"");
                        if (lobGuid.getValue() != null)
                            lobGuid.setValue(lobGuid.getValue() + ",\"" + lobResult.cms_lobid + "\"");
                        else
                            lobGuid.setValue("\"" + lobResult.cms_lobid + "\"");
                    }, function (lobError) {
                        console.log(lobError.message);
                    });
                }
            }, function (lobSetError) {
                console.log(lobSetError.message);
                // handle error conditions
            });
            Xrm.WebApi.retrieveMultipleRecords("cms_cms_nbtemplateline_cms_submissionchanne", query).then(function success(submissionchannelSetResult) {
                for (var n = 0; n < submissionchannelSetResult.entities.length; n++) {
                    var submissionchannelSet = submissionchannelSetResult.entities[n];
                    Xrm.WebApi.retrieveRecord("cms_submissionchannel", submissionchannelSet.cms_submissionchannelid).then(function success(submissionchannelResult) {
                        submissionChannel = formContext.getAttribute("cms_submissionchannel" + i.toString());
                        submissionChannelGuid = formContext.getAttribute("cms_submissionchannelguid" + i.toString());
                        if (submissionChannel.getValue() != null)
                            submissionChannel.setValue(submissionChannel.getValue() + ",\"" + submissionchannelResult.cms_name + "\"");
                        else
                            submissionChannel.setValue("\"" + submissionchannelResult.cms_name + "\"");
                        if (submissionChannelGuid.getValue() != null)
                            submissionChannelGuid.setValue(submissionChannelGuid.getValue() + ",\"" + submissionchannelResult.cms_submissionchannelid + "\"");
                        else
                            submissionChannelGuid.setValue("\"" + submissionchannelResult.cms_submissionchannelid + "\"");
                    }, function (submissionchannelError) {
                        console.log(submissionchannelError.message);
                    });
                }
            }, function (submissionchannelSetError) {
                console.log(submissionchannelSetError.message);
                // handle error conditions
            });
        }
    })(form_Contest_NBContest = ACT.form_Contest_NBContest || (ACT.form_Contest_NBContest = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_Contest_NBContest.js.map