/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_GroupingLine;
    (function (form_GroupingLine) {
        function requirementLookupFilter(executionContext) {
            var formContext = executionContext.getFormContext();
            var grouping = formContext.getAttribute("cms_groupingid");
            var requirementCtl = formContext.getControl("cms_requirement");
            if (grouping.getValue() != null) {
                var groupingId = grouping.getValue()[0].id;
                Xrm.WebApi.retrieveRecord("cms_grouping", groupingId).then(function success(result) {
                    var awardId = result._cms_awardid_value;
                    requirementCtl.addPreSearch(function () {
                        var reqFilter = "<filter type=\"and\">" +
                            "<condition attribute=\"cms_awardid\" operator=\"eq\" value=\"" + awardId + "\" />" +
                            "</filter>";
                        requirementCtl.addCustomFilter(reqFilter, "cms_requirement");
                    });
                });
            }
        }
        form_GroupingLine.requirementLookupFilter = requirementLookupFilter;
        function initValue(executionContext) {
            var formContext = executionContext.getFormContext();
            if (formContext.data.entity.getId() == "") {
                formContext.getAttribute("cms_subgroupid").setValue(null);
            }
        }
        form_GroupingLine.initValue = initValue;
    })(form_GroupingLine = ACT.form_GroupingLine || (ACT.form_GroupingLine = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_GroupingLine.js.map