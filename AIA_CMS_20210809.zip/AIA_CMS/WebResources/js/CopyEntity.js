/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var CopyEntity;
    (function (CopyEntity) {
        function CopyRollup() {            
            var sourceRollup = {};
            sourceRollup.entityType = "cms_rollup";
            sourceRollup.id = Xrm.Page.data.entity.getId();
            var rollupName = Xrm.Page.getAttribute("cms_name").getValue();

            var req = {};
            req.entity = sourceRollup;
            req.getMetadata = function () {
                return {
                    boundParameter: "entity",
                    parameterTypes: {
                        "entity": {
                            typeName: "mscrm.cms_rollup",
                            structuralProperty: 5
                        }
                    },
                    operationType: 0,
                    operationName: "cms_CopyRollupProcess"
                };
            };
            
            Xrm.WebApi.online.execute(req).then(
                function (data) {
                    var e = data;
                    if (e.status == 204) {
                        alert(rollupName + " - COPY is created.", "INFORMATION");
                    }
                    else {
                        alert("Copy rollup failed.", "ERROR");
                    }
                },
                function (error) {
                    alert(error.message, "ERROR");
                }
            );
        }
        CopyEntity.CopyRollup = CopyRollup;

        function CopyContest() {
            var sourceContest = {};
            sourceContest.entityType = "cms_contest";
            sourceContest.id = Xrm.Page.data.entity.getId();
            var contestName = Xrm.Page.getAttribute("cms_name").getValue();

            var req = {};
            req.entity = sourceContest;
            req.getMetadata = function () {
                return {
                    boundParameter: "entity",
                    parameterTypes: {
                        "entity": {
                            typeName: "mscrm.cms_contest",
                            structuralProperty: 5
                        }
                    },
                    operationType: 0,
                    operationName: "cms_CopyContestProcess"
                };
            };

            Xrm.WebApi.online.execute(req).then(
                function (data) {
                    var e = data;
                    if (e.status == 204) {
                        alert(contestName + " - COPY is created.", "INFORMATION");
                    }
                    else {
                        alert("Copy contest failed.", "ERROR");
                    }
                },
                function (error) {
                    alert(error.message, "ERROR");
                }
            );
        }
        CopyEntity.CopyContest = CopyContest;
    })(CopyEntity = ACT.CopyEntity || (ACT.CopyEntity = {}));
})(ACT || (ACT = {}));