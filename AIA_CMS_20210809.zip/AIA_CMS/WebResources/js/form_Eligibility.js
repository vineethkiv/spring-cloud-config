/// <reference path="../typings/xrm/xrm.d.ts" />
/// <reference path="../typings/XRM/Form/cms_rollupline/main/information.d.ts" />
var ACT;
(function (ACT) {
    var form_Eligibility;
    (function (form_Eligibility) {
        function setEntityOption(executionContext) {
            var formContext = executionContext.getFormContext();
            var entityField = formContext.getControl("cms_entity");
            if (entityField != null) {
                entityField.clearOptions();
                entityField.addOption({ "value": 175650000, "text": "Agent" });
                entityField.addOption({ "value": 175650001, "text": "Agent history " });
                entityField.addOption({ "value": 175650005, "text": "District" });
                entityField.addOption({ "value": 175650011, "text": "MDRT membership" });
            }
        }
        form_Eligibility.setEntityOption = setEntityOption;
    })(form_Eligibility = ACT.form_Eligibility || (ACT.form_Eligibility = {}));
})(ACT || (ACT = {}));
//# sourceMappingURL=form_Eligibility.js.map