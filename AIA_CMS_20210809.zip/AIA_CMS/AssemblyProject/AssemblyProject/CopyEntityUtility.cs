﻿using System;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace AIA_CMS
{
    internal class CopyEntityUtility
    {
        private IOrganizationService service;

        internal CopyEntityUtility(IOrganizationService _service)
        {
            service = _service;
        }

        internal IOrganizationService Service
        {
            get { return service; }
            set { service = value; }
        }

        internal void copyRelation(Guid _parentId, Guid _srcId, string _relationEntityName, string _relationName, string _fromEntityName, string _toEntityName)
        {
            QueryExpression query = this.buildQueryByParentId(_relationEntityName, _fromEntityName + "id", _srcId);
            DataCollection<Entity> entities = service.RetrieveMultiple(query).Entities;
            EntityReferenceCollection relatedEntity = new EntityReferenceCollection();

            foreach (Entity srcEntity in entities)
            {
                relatedEntity.Add(new EntityReference(_toEntityName, (Guid)srcEntity[_toEntityName + "id"]));
            }

            if (relatedEntity.Count > 0)
            {
                Relationship relationship = new Relationship(_relationName);
                service.Associate(_fromEntityName, _parentId, relationship, relatedEntity);
            }
        }

        internal void removeRelation(Guid _parentId, string _relationEntityName, string _relationName, string _fromEntityName, string _toEntityName)
        {
            QueryExpression query = this.buildQueryByParentId(_relationEntityName, _fromEntityName + "id", _parentId);
            DataCollection<Entity> entities = service.RetrieveMultiple(query).Entities;
            EntityReferenceCollection relatedEntity = new EntityReferenceCollection();

            foreach (Entity srcEntity in entities)
            {
                relatedEntity.Add(new EntityReference(_toEntityName, (Guid)srcEntity[_toEntityName + "id"]));
            }

            if (relatedEntity.Count > 0)
            {
                Relationship relationship = new Relationship(_relationName);
                service.Disassociate(_fromEntityName, _parentId, relationship, relatedEntity);
            }
        }

        internal Entity copyEntity(Entity _srcEntity, List<string> _excludeList)
        {
            Entity tarEntity = new Entity(_srcEntity.LogicalName);

            foreach (KeyValuePair<string, object> attribute in _srcEntity.Attributes)
            {
                string attributeName = attribute.Key;
                object attributeValue = attribute.Value;

                if (_excludeList.Contains(attributeName.ToLower()))
                    continue;

                if (attributeName.ToLower().StartsWith("cms_"))
                {
                    tarEntity[attributeName] = attributeValue;
                }
            }

            return tarEntity;
        }

        internal QueryExpression buildQueryByParentId(string _entityName, string _parnetKey, Guid _parentId)
        {
            QueryExpression query = new QueryExpression
            {
                EntityName = _entityName,
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions = {
                                    new ConditionExpression{
                                        AttributeName = _parnetKey,
                                        Operator = ConditionOperator.Equal,
                                        Values = { _parentId }
                                    }
                                }
                }
            };

            return query;
        }

        internal void copyChildRecord(string _entityName, string _parentKeyName, string _parentEntityName, Guid _srcParentId, Guid _newParentId, List<string> _excList)
        {
            QueryExpression query;
            Entity tarEntity;
            DataCollection<Entity> entityCollection;

            query = this.buildQueryByParentId(_entityName, _parentKeyName, _srcParentId);
            entityCollection = service.RetrieveMultiple(query).Entities;

            foreach (Entity srcEntity in entityCollection)
            {
                tarEntity = this.copyEntity(srcEntity, _excList);
                tarEntity[_parentKeyName] = new EntityReference(_parentEntityName, _newParentId);
                service.Create(tarEntity);
            }
        }
    }

}
