﻿using System;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using AIA_CMS.Entities;

namespace AIA_CMS
{
    public class validateDeleteByActive : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference entityReference)
            {
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                try
                {
                    Entity entity, award, grouping;
                    EntityReference contestRef, awardRef, groupingRef;
                    Guid contestId = new Guid();

                    entity = service.Retrieve(entityReference.LogicalName, entityReference.Id, new ColumnSet(true));

                    switch (entityReference.LogicalName)
                    {
                        case Award.EntityName:
                            contestRef = (EntityReference)entity[Award.FieldList.ContestId];
                            contestId = contestRef.Id;
                            break;
                        case Requirement.EntityName:
                        case RequirementGrouping.EntityName:
                        case Eligibility.EntityName:
                        case AwardRankingBreakdown.EntityName:
                            awardRef = (EntityReference)entity["cms_awardid"];
                            award = service.Retrieve(Award.EntityName, awardRef.Id, new ColumnSet(true));
                            contestRef = (EntityReference)award[Award.FieldList.ContestId];
                            contestId = contestRef.Id;
                            break;
                        case BranchOutDistrict.EntityName:
                            awardRef = (EntityReference)entity[BranchOutDistrict.FieldList.AwardId];
                            award = service.Retrieve(Award.EntityName, awardRef.Id, new ColumnSet(true));
                            contestRef = (EntityReference)award[Award.FieldList.ContestId];
                            contestId = contestRef.Id;
                            break;
                        case RequirementGroupingLine.EntityName:
                            groupingRef = (EntityReference)entity[RequirementGroupingLine.FieldList.GroupingId];
                            grouping = service.Retrieve(RequirementGrouping.EntityName, groupingRef.Id, new ColumnSet(true));
                            awardRef = (EntityReference)grouping[RequirementGrouping.FieldList.AwardId];
                            award = service.Retrieve(Award.EntityName, awardRef.Id, new ColumnSet(true));
                            contestRef = (EntityReference)award[Award.FieldList.ContestId];
                            contestId = contestRef.Id;
                            break;
                    }

                    Entity contest = service.Retrieve(Contest.EntityName, contestId, new ColumnSet(true));

                    if ((bool)contest[Contest.FieldList.Active] == true)
                    {
                        throw new InvalidPluginExecutionException("Contest actived, not allow delete record");
                    }
                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in validateDeleteByActive.", ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("validateDeleteByActive: {0}", ex.ToString());
                    throw;
                }
            }
        }
    }
}
