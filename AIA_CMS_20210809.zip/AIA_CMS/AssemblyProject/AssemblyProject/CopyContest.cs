﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using AIA_CMS.Entities;

namespace AIA_CMS
{
    public class CopyContest : IPlugin
    {
        CopyEntityUtility copyEntityUtility;
        IOrganizationService service;

        List<string> contestExcList, awardExcList, 
                     eligibilityExcList, eligibilityRefExcList, eligibilityGrpHdrExcList, eligibilityGrpLineExcList, awardRankingBreakdownExcList,
                     requirementExcList, reqContractMainExcList, reqProrataExcList, reqGroupingExcList, reqGroupingLineExcList,
                     specialRuleHeaderExcList, specialRuleLineExcList, specialContestHeaderExcList, specialContestLineExcList,
                     branchOutDistrictExcList;

        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            
            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference entityReference)
            {
                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = serviceFactory.CreateOrganizationService(context.UserId);
                
                copyEntityUtility = new CopyEntityUtility(service);
                this.buildExcludeFieldList();

                // Obtain the target entity from the input parameters.
                Entity entity = service.Retrieve(entityReference.LogicalName, entityReference.Id, new ColumnSet(true));

                Entity tarContest, tarSpecialRuleHeader, tarSpecialRuleLine, tarSpecialContestHeader;
                Guid tarContestId, tarSpecialRuleHeaderId, tarSpecialRuleLineId, tarSpecialContestHeaderId;
                QueryExpression query;
                DataCollection<Entity> awardCollection, specialRuleHeaderCollection, specialRuleLineCollection, specialContestHeaderCollection;

                try
                {
                    tarContest = copyEntityUtility.copyEntity(entity, contestExcList);
                    tarContest[Contest.FieldList.Name] = entity[Contest.FieldList.Name] + " - COPY";
                    tarContest[Contest.FieldList.Active] = false;
                    tarContestId = service.Create(tarContest);

                    #region Award
                    query = copyEntityUtility.buildQueryByParentId(Award.EntityName, Award.FieldList.ContestId, entityReference.Id);
                    awardCollection = service.RetrieveMultiple(query).Entities;

                    foreach (Entity srcAward in awardCollection)
                    {
                        this.copyAward(srcAward, tarContestId);
                    }
                    #endregion

                    #region Special rule
                    query = copyEntityUtility.buildQueryByParentId(SpecialRuleHeader.EntityName, SpecialRuleHeader.FieldList.ContestId, entityReference.Id);
                    specialRuleHeaderCollection = service.RetrieveMultiple(query).Entities;

                    foreach(Entity srcSpecialRuleHeader in specialRuleHeaderCollection)
                    {
                        tarSpecialRuleHeader = copyEntityUtility.copyEntity(srcSpecialRuleHeader, specialRuleHeaderExcList);
                        tarSpecialRuleHeader[SpecialContestHeader.FieldList.ContestId] = new EntityReference(Contest.EntityName, tarContestId);
                        tarSpecialRuleHeaderId = service.Create(tarSpecialRuleHeader);

                        query = copyEntityUtility.buildQueryByParentId(SpecialRuleLine.EntityName, SpecialRuleLine.FieldList.SpecialRuleHeaderId, srcSpecialRuleHeader.Id);
                        specialRuleLineCollection = service.RetrieveMultiple(query).Entities;

                        foreach(Entity srcSpecialRuleLine in specialRuleLineCollection)
                        {
                            tarSpecialRuleLine = copyEntityUtility.copyEntity(srcSpecialRuleLine, specialRuleLineExcList);
                            tarSpecialRuleLine[SpecialRuleLine.FieldList.SpecialRuleHeaderId] = new EntityReference(SpecialRuleHeader.EntityName, tarSpecialRuleHeaderId);
                            tarSpecialRuleLineId = service.Create(tarSpecialRuleLine);

                            #region Relation
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.LOB.RelationEntityName, SpecialRuleLine.Relation.LOB.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.LOB.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.Zone.RelationEntityName, SpecialRuleLine.Relation.Zone.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.Zone.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.Region.RelationEntityName, SpecialRuleLine.Relation.Region.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.Region.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.AgentTitle.RelationEntityName, SpecialRuleLine.Relation.AgentTitle.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.AgentTitle.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.AgentType.RelationEntityName, SpecialRuleLine.Relation.AgentType.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.AgentType.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.DOY.RelationEntityName, SpecialRuleLine.Relation.DOY.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.DOY.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.MCVLocal.RelationEntityName, SpecialRuleLine.Relation.MCVLocal.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.MCVLocal.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.ProductGroup.RelationEntityName, SpecialRuleLine.Relation.ProductGroup.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.ProductGroup.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.ProductSeries.RelationEntityName, SpecialRuleLine.Relation.ProductSeries.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.ProductSeries.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.SubmissionChannel.RelationEntityName, SpecialRuleLine.Relation.SubmissionChannel.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.SubmissionChannel.EntityName);
                            copyEntityUtility.copyRelation(tarSpecialRuleLineId, srcSpecialRuleLine.Id, SpecialRuleLine.Relation.Team.RelationEntityName, SpecialRuleLine.Relation.Team.Name, SpecialRuleLine.EntityName, SpecialRuleLine.Relation.Team.EntityName);
                            #endregion
                        }
                    }
                    #endregion

                    #region Special contest
                    query = copyEntityUtility.buildQueryByParentId(SpecialContestHeader.EntityName, SpecialContestHeader.FieldList.ContestId, entityReference.Id);
                    specialContestHeaderCollection = service.RetrieveMultiple(query).Entities;

                    foreach (Entity srcSpecialContestHeader in specialContestHeaderCollection)
                    {
                        tarSpecialContestHeader = copyEntityUtility.copyEntity(srcSpecialContestHeader, specialContestHeaderExcList);
                        tarSpecialContestHeader[SpecialContestHeader.FieldList.ContestId] = new EntityReference(Contest.EntityName, tarContestId);
                        tarSpecialContestHeaderId = service.Create(tarSpecialContestHeader);

                        copyEntityUtility.copyChildRecord(SpecialContestLine.EntityName, SpecialContestLine.FieldList.SpecialContestHeaderId, SpecialContestHeader.EntityName, srcSpecialContestHeader.Id, tarSpecialContestHeaderId, specialContestLineExcList);
                    }
                    #endregion
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    tracingService.Trace("CopyContest: {0}", ex.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in CopyContest.", ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("CopyContest: {0}", ex.ToString());
                    throw;
                }
            }
            else
            {
                tracingService.Trace("Input parameter count: {0}", context.InputParameters.Count);
                throw new InvalidPluginExecutionException("Cannot get input parameter.");
            }
        }

        private void buildExcludeFieldList()
        {
            contestExcList = new List<string>();
            contestExcList.Add(Contest.FieldList.Id);
            contestExcList.Add(Contest.FieldList.Name);
            contestExcList.Add(Contest.FieldList.ApprovalComment1);
            contestExcList.Add(Contest.FieldList.ApprovalComment2);
            contestExcList.Add(Contest.FieldList.ApprovalStatus1);
            contestExcList.Add(Contest.FieldList.ApprovalStatus2);

            awardExcList = new List<string>();
            awardExcList.Add(Award.FieldList.Id);
            awardExcList.Add(Award.FieldList.ContestId);

            awardRankingBreakdownExcList = new List<string>();
            awardRankingBreakdownExcList.Add(AwardRankingBreakdown.FieldList.Id);
            awardRankingBreakdownExcList.Add(AwardRankingBreakdown.FieldList.AwardId);

            eligibilityExcList = new List<string>();
            eligibilityExcList.Add(Eligibility.FieldList.Id);
            eligibilityExcList.Add(Eligibility.FieldList.AwardId);

            eligibilityRefExcList = new List<string>();
            eligibilityRefExcList.Add(EligibilityReference.FieldList.Id);
            eligibilityRefExcList.Add(EligibilityReference.FieldList.EligibilityId);

            eligibilityGrpHdrExcList = new List<string>();
            eligibilityGrpHdrExcList.Add(EligibilityGroupingHeader.FieldList.Id);
            eligibilityGrpHdrExcList.Add(EligibilityGroupingHeader.FieldList.AwardId);

            eligibilityGrpLineExcList = new List<string>();
            eligibilityGrpLineExcList.Add(EligibilityGroupingLine.FieldList.Id);
            eligibilityGrpLineExcList.Add(EligibilityGroupingLine.FieldList.EligibilityGroupingHeaderId);
            eligibilityGrpLineExcList.Add(EligibilityGroupingLine.FieldList.EligibilityId);
            eligibilityGrpLineExcList.Add(EligibilityGroupingLine.FieldList.SubGroupId);

            requirementExcList = new List<string>();
            requirementExcList.Add(Requirement.FieldList.Id);
            requirementExcList.Add(Requirement.FieldList.AwardId);

            reqContractMainExcList = new List<string>();
            reqContractMainExcList.Add(RequirementContractMain.FieldList.Id);
            reqContractMainExcList.Add(RequirementContractMain.FieldList.RequirementId);

            reqProrataExcList = new List<string>();
            reqProrataExcList.Add(RequirementProrata.FieldList.Id);
            reqProrataExcList.Add(RequirementProrata.FieldList.RequirementId);

            reqGroupingExcList = new List<string>();
            reqGroupingExcList.Add(RequirementGrouping.FieldList.Id);
            reqGroupingExcList.Add(RequirementGrouping.FieldList.AwardId);

            reqGroupingLineExcList = new List<string>();
            reqGroupingLineExcList.Add(RequirementGroupingLine.FieldList.Id);
            reqGroupingLineExcList.Add(RequirementGroupingLine.FieldList.GroupingId);
            reqGroupingLineExcList.Add(RequirementGroupingLine.FieldList.RequirementId);
            reqGroupingLineExcList.Add(RequirementGroupingLine.FieldList.SubGroupId);

            specialRuleHeaderExcList = new List<string>();
            specialRuleHeaderExcList.Add(SpecialRuleHeader.FieldList.Id);
            specialRuleHeaderExcList.Add(SpecialRuleHeader.FieldList.ContestId);

            specialRuleLineExcList = new List<string>();
            specialRuleLineExcList.Add(SpecialRuleLine.FieldList.Id);
            specialRuleLineExcList.Add(SpecialRuleLine.FieldList.SpecialRuleHeaderId);

            specialContestHeaderExcList = new List<string>();
            specialContestHeaderExcList.Add(SpecialContestHeader.FieldList.Id);
            specialContestHeaderExcList.Add(SpecialContestHeader.FieldList.ContestId);

            specialContestLineExcList = new List<string>();
            specialContestLineExcList.Add(SpecialContestLine.FieldList.Id);
            specialContestLineExcList.Add(SpecialContestLine.FieldList.SpecialContestHeaderId);

            branchOutDistrictExcList = new List<string>();
            branchOutDistrictExcList.Add(BranchOutDistrict.FieldList.Id);
            branchOutDistrictExcList.Add(BranchOutDistrict.FieldList.AwardId);
        }

        private void copyAward(Entity _srcAward, Guid _contestId)
        {
            Entity tarAward, tarEligibility, tarEligibilityGrpHdr, tarEligibilityGrpLine, tarRequirement, tarReqGrouping, tarReqGroupingLine;
            Guid tarAwardId, tarEligibilityId, tarEligibilityGrpHdrId, tarRequirementId, tarReqGroupingId;
            Dictionary<Guid, Guid> requiremnetGuidMap = new Dictionary<Guid, Guid>(),
                                   eligibiltyGuidMap = new Dictionary<Guid, Guid>(),
                                   reqGrpMap = new Dictionary<Guid, Guid>(),
                                   eligilityGrpMap = new Dictionary<Guid, Guid>();

            QueryExpression query;
            DataCollection<Entity> eligibilityCollection, eligibilityGrpHdrCollection, eligibilityGrpLineCollection, requirementCollection, reqGroupingCollection, reqGroupingLineCollection;

            tarAward = copyEntityUtility.copyEntity(_srcAward, awardExcList);
            tarAward[Award.FieldList.ContestId] = new EntityReference(Contest.EntityName, _contestId);
            tarAwardId = service.Create(tarAward);

            EntityReference awardRef = new EntityReference(Award.EntityName, tarAwardId);

            copyEntityUtility.copyChildRecord(AwardRankingBreakdown.EntityName, AwardRankingBreakdown.FieldList.AwardId, Award.EntityName, _srcAward.Id, tarAwardId, awardRankingBreakdownExcList);
            copyEntityUtility.copyChildRecord(BranchOutDistrict.EntityName, BranchOutDistrict.FieldList.AwardId, Award.EntityName, _srcAward.Id, tarAwardId, branchOutDistrictExcList);

            #region Eligibility
            query = copyEntityUtility.buildQueryByParentId(Eligibility.EntityName, Eligibility.FieldList.AwardId, _srcAward.Id);
            eligibilityCollection = service.RetrieveMultiple(query).Entities;

            foreach (Entity srcEligibility in eligibilityCollection)
            {
                tarEligibility = copyEntityUtility.copyEntity(srcEligibility, eligibilityExcList);
                tarEligibility[Eligibility.FieldList.AwardId] = awardRef;
                tarEligibilityId = service.Create(tarEligibility);

                eligibiltyGuidMap.Add(srcEligibility.Id, tarEligibilityId);

                #region Relation
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.LOB.RelationEntityName, Eligibility.Relation.LOB.Name, Eligibility.EntityName, Eligibility.Relation.LOB.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.Zone.RelationEntityName, Eligibility.Relation.Zone.Name, Eligibility.EntityName, Eligibility.Relation.Zone.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.Region.RelationEntityName, Eligibility.Relation.Region.Name, Eligibility.EntityName, Eligibility.Relation.Region.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.AgentTitle.RelationEntityName, Eligibility.Relation.AgentTitle.Name, Eligibility.EntityName, Eligibility.Relation.AgentTitle.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.AgentType.RelationEntityName, Eligibility.Relation.AgentType.Name, Eligibility.EntityName, Eligibility.Relation.AgentType.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.DOY.RelationEntityName, Eligibility.Relation.DOY.Name, Eligibility.EntityName, Eligibility.Relation.DOY.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.MCVLocal.RelationEntityName, Eligibility.Relation.MCVLocal.Name, Eligibility.EntityName, Eligibility.Relation.MCVLocal.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.ProductGroup.RelationEntityName, Eligibility.Relation.ProductGroup.Name, Eligibility.EntityName, Eligibility.Relation.ProductGroup.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.ProductSeries.RelationEntityName, Eligibility.Relation.ProductSeries.Name, Eligibility.EntityName, Eligibility.Relation.ProductSeries.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.SubmissionChannel.RelationEntityName, Eligibility.Relation.SubmissionChannel.Name, Eligibility.EntityName, Eligibility.Relation.SubmissionChannel.EntityName);
                copyEntityUtility.copyRelation(tarEligibilityId, srcEligibility.Id, Eligibility.Relation.Team.RelationEntityName, Eligibility.Relation.Team.Name, Eligibility.EntityName, Eligibility.Relation.Team.EntityName);
                #endregion

                copyEntityUtility.copyChildRecord(EligibilityReference.EntityName, EligibilityReference.FieldList.EligibilityId, Eligibility.EntityName, srcEligibility.Id, tarEligibilityId, eligibilityRefExcList);                
            }
            #endregion

            #region Eligibility Grouping Header
            query = copyEntityUtility.buildQueryByParentId(EligibilityGroupingHeader.EntityName, EligibilityGroupingHeader.FieldList.AwardId, _srcAward.Id);
            eligibilityGrpHdrCollection = service.RetrieveMultiple(query).Entities;

            foreach(Entity srcEligibilityGrpHdr in eligibilityGrpHdrCollection)
            {
                tarEligibilityGrpHdr = copyEntityUtility.copyEntity(srcEligibilityGrpHdr, eligibilityGrpHdrExcList);
                tarEligibilityGrpHdr[Eligibility.FieldList.AwardId] = awardRef;
                tarEligibilityGrpHdrId = service.Create(tarEligibilityGrpHdr);

                eligilityGrpMap.Add(srcEligibilityGrpHdr.Id, tarEligibilityGrpHdrId);
            }
            #endregion

            #region Eligibility Grouping Line
            foreach (KeyValuePair<Guid, Guid> keyValuePair in eligilityGrpMap)
            {
                query = copyEntityUtility.buildQueryByParentId(EligibilityGroupingLine.EntityName, EligibilityGroupingLine.FieldList.EligibilityGroupingHeaderId, keyValuePair.Key);
                eligibilityGrpLineCollection = service.RetrieveMultiple(query).Entities;

                foreach (Entity srcEligibilityGrpLine in eligibilityGrpLineCollection)
                {
                    tarEligibilityGrpLine = copyEntityUtility.copyEntity(srcEligibilityGrpLine, eligibilityGrpLineExcList);
                    tarEligibilityGrpLine[EligibilityGroupingLine.FieldList.EligibilityGroupingHeaderId] = new EntityReference(EligibilityGroupingHeader.EntityName, keyValuePair.Value);

                    if (srcEligibilityGrpLine.Contains(EligibilityGroupingLine.FieldList.EligibilityId))
                    {
                        Guid tarEligId;
                        EntityReference srcEligibility = (EntityReference)srcEligibilityGrpLine[EligibilityGroupingLine.FieldList.EligibilityId];
                        if (eligibiltyGuidMap.TryGetValue(srcEligibility.Id, out tarEligId))
                        {
                            tarEligibilityGrpLine[EligibilityGroupingLine.FieldList.EligibilityId] = new EntityReference(Eligibility.EntityName, tarEligId);
                        }
                    }

                    if (srcEligibilityGrpLine.Contains(EligibilityGroupingLine.FieldList.SubGroupId))
                    {
                        Guid tarSubGrpId;
                        EntityReference srcSubGroup = (EntityReference)srcEligibilityGrpLine[EligibilityGroupingLine.FieldList.SubGroupId];
                        if(eligilityGrpMap.TryGetValue(srcSubGroup.Id, out tarSubGrpId))
                        {
                            tarEligibilityGrpLine[EligibilityGroupingLine.FieldList.SubGroupId] = new EntityReference(EligibilityGroupingHeader.EntityName, tarSubGrpId);
                        }
                    }

                    service.Create(tarEligibilityGrpLine);
                }
            }
            #endregion

            #region Requirement
            query = copyEntityUtility.buildQueryByParentId(Requirement.EntityName, Requirement.FieldList.AwardId, _srcAward.Id);
            requirementCollection = service.RetrieveMultiple(query).Entities;

            foreach(Entity srcRequirement in requirementCollection)
            {
                tarRequirement = copyEntityUtility.copyEntity(srcRequirement, requirementExcList);
                tarRequirement[Requirement.FieldList.AwardId] = awardRef;
                tarRequirementId = service.Create(tarRequirement);

                requiremnetGuidMap.Add(srcRequirement.Id, tarRequirementId);

                #region Relation
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.LOB.RelationEntityName, Requirement.Relation.LOB.Name, Requirement.EntityName, Requirement.Relation.LOB.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.Zone.RelationEntityName, Requirement.Relation.Zone.Name, Requirement.EntityName, Requirement.Relation.Zone.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.Region.RelationEntityName, Requirement.Relation.Region.Name, Requirement.EntityName, Requirement.Relation.Region.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.AgentTitle.RelationEntityName, Requirement.Relation.AgentTitle.Name, Requirement.EntityName, Requirement.Relation.AgentTitle.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.AgentType.RelationEntityName, Requirement.Relation.AgentType.Name, Requirement.EntityName, Requirement.Relation.AgentType.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.DOY.RelationEntityName, Requirement.Relation.DOY.Name, Requirement.EntityName, Requirement.Relation.DOY.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.MCVLocal.RelationEntityName, Requirement.Relation.MCVLocal.Name, Requirement.EntityName, Requirement.Relation.MCVLocal.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.ProductGroup.RelationEntityName, Requirement.Relation.ProductGroup.Name, Requirement.EntityName, Requirement.Relation.ProductGroup.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.ProductSeries.RelationEntityName, Requirement.Relation.ProductSeries.Name, Requirement.EntityName, Requirement.Relation.ProductSeries.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.SubmissionChannel.RelationEntityName, Requirement.Relation.SubmissionChannel.Name, Requirement.EntityName, Requirement.Relation.SubmissionChannel.EntityName);
                copyEntityUtility.copyRelation(tarRequirementId, srcRequirement.Id, Requirement.Relation.Team.RelationEntityName, Requirement.Relation.Team.Name, Requirement.EntityName, Requirement.Relation.Team.EntityName);
                #endregion

                copyEntityUtility.copyChildRecord(RequirementContractMain.EntityName, RequirementContractMain.FieldList.RequirementId, Requirement.EntityName, srcRequirement.Id, tarRequirementId, reqContractMainExcList);
                copyEntityUtility.copyChildRecord(RequirementProrata.EntityName, RequirementProrata.FieldList.RequirementId, Requirement.EntityName, srcRequirement.Id, tarRequirementId, reqProrataExcList);
            }
            #endregion

            #region Requirement grouping header
            query = copyEntityUtility.buildQueryByParentId(RequirementGrouping.EntityName, RequirementGrouping.FieldList.AwardId, _srcAward.Id);
            reqGroupingCollection = service.RetrieveMultiple(query).Entities;

            foreach(Entity srcReqGrouping in reqGroupingCollection)
            {
                tarReqGrouping = copyEntityUtility.copyEntity(srcReqGrouping, reqGroupingExcList);
                tarReqGrouping[RequirementGrouping.FieldList.AwardId] = awardRef;
                tarReqGroupingId = service.Create(tarReqGrouping);

                reqGrpMap.Add(srcReqGrouping.Id, tarReqGroupingId);
            }
            #endregion

            #region Requirement grouping line
            foreach (KeyValuePair<Guid, Guid> keyValuePair in reqGrpMap)
            {
                query = copyEntityUtility.buildQueryByParentId(RequirementGroupingLine.EntityName, RequirementGroupingLine.FieldList.GroupingId, keyValuePair.Key);
                reqGroupingLineCollection = service.RetrieveMultiple(query).Entities;

                foreach (Entity srcReqGroupingLine in reqGroupingLineCollection)
                {
                    tarReqGroupingLine = copyEntityUtility.copyEntity(srcReqGroupingLine, reqGroupingLineExcList);
                    tarReqGroupingLine[RequirementGroupingLine.FieldList.GroupingId] = new EntityReference(RequirementGrouping.EntityName, keyValuePair.Value);

                    if (srcReqGroupingLine.Contains(RequirementGroupingLine.FieldList.RequirementId))
                    {
                        Guid tarReqId;
                        EntityReference srcReq = (EntityReference)srcReqGroupingLine[RequirementGroupingLine.FieldList.RequirementId];
                        if (requiremnetGuidMap.TryGetValue(srcReq.Id, out tarReqId))
                        {
                            tarReqGroupingLine[RequirementGroupingLine.FieldList.RequirementId] = new EntityReference(Requirement.EntityName, tarReqId);
                        }
                    }

                    if (srcReqGroupingLine.Contains(RequirementGroupingLine.FieldList.SubGroupId))
                    {
                        Guid tarSubGrpId;
                        EntityReference srcSubGrp = (EntityReference)srcReqGroupingLine[RequirementGroupingLine.FieldList.SubGroupId];
                        if (reqGrpMap.TryGetValue(srcSubGrp.Id, out tarSubGrpId))
                        {
                            tarReqGroupingLine[RequirementGroupingLine.FieldList.SubGroupId] = new EntityReference(RequirementGrouping.EntityName, tarSubGrpId);
                        }
                    }

                    service.Create(tarReqGroupingLine);
                }
            }
            #endregion            
        }
    }
}
