﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using AIA_CMS.Entities;

namespace AIA_CMS
{
    public class CopyRollup : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            
            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // The InputParameters collection contains all the data passed in the message request.  
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference entityReference)
            {
                // Obtain the organization service reference which you will need for  
                // web service calls.  
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                
                CopyEntityUtility copyEntityUtility = new CopyEntityUtility(service);

                // Obtain the target entity from the input parameters.
                Entity entity = service.Retrieve(entityReference.LogicalName, entityReference.Id, new ColumnSet(true));

                Entity tarRollup, tarRollupLine, tarRollupCriteria, tarRollupCriteriaRef, tarActiveMthParm;
                Guid tarRollupId, tarRollupLineId, tarRollupCriteriaId, tarActiveMthParmId;
                QueryExpression query;

                List<string> rollupExcList = new List<string>();
                rollupExcList.Add(Rollup.FieldList.Id);
                rollupExcList.Add(Rollup.FieldList.Name);

                List<string> rollupLineExcList = new List<string>();
                rollupLineExcList.Add(RollupLine.FieldList.RollupId);
                rollupLineExcList.Add(RollupLine.FieldList.Id);

                List<string> rollupCriteriaExcList = new List<string>();
                rollupCriteriaExcList.Add(RollupCriteria.FieldList.RollupLineId);
                rollupCriteriaExcList.Add(RollupCriteria.FieldList.Id);

                List<string> rollupCriteriaRefExcList = new List<string>();
                rollupCriteriaRefExcList.Add(RollupCriteriaReference.FieldList.RollupCriteriaId);
                rollupCriteriaRefExcList.Add(RollupCriteriaReference.FieldList.Id);

                List<string> EstYearEndBonusExcList = new List<string>();
                EstYearEndBonusExcList.Add(EstimatedYearEndBonus.FieldList.RollupLineId);
                EstYearEndBonusExcList.Add(EstimatedYearEndBonus.FieldList.Id);

                List<string> activeMthParmExcList = new List<string>();
                activeMthParmExcList.Add(MDRTActiveMthParm.FieldList.RollupLineId);
                activeMthParmExcList.Add(MDRTActiveMthParm.FieldList.Id);

                try
                {
                    tarRollup = copyEntityUtility.copyEntity(entity, rollupExcList);
                    tarRollup[Rollup.FieldList.Name] = entity[Rollup.FieldList.Name] + " - COPY";
                    tarRollupId = service.Create(tarRollup);

                    query = copyEntityUtility.buildQueryByParentId(RollupLine.EntityName, RollupLine.FieldList.RollupId, entityReference.Id);
                    DataCollection<Entity> rollupLineCollection = service.RetrieveMultiple(query).Entities;

                    foreach (Entity srcRollupLine in rollupLineCollection)
                    {
                        tarRollupLine = copyEntityUtility.copyEntity(srcRollupLine, rollupLineExcList);
                        tarRollupLine[RollupLine.FieldList.RollupId] = new EntityReference(Rollup.EntityName, tarRollupId);
                        tarRollupLineId = service.Create(tarRollupLine);

                        copyEntityUtility.copyChildRecord(EstimatedYearEndBonus.EntityName, EstimatedYearEndBonus.FieldList.RollupLineId, RollupLine.EntityName, srcRollupLine.Id, tarRollupLineId, EstYearEndBonusExcList);

                        #region Rollup Criteria
                        query = copyEntityUtility.buildQueryByParentId(RollupCriteria.EntityName, RollupCriteria.FieldList.RollupLineId, srcRollupLine.Id);
                        DataCollection<Entity> rollupCriteriaCollection = service.RetrieveMultiple(query).Entities;

                        foreach (Entity srcRollupCriteria in rollupCriteriaCollection)
                        {
                            tarRollupCriteria = copyEntityUtility.copyEntity(srcRollupCriteria, rollupCriteriaExcList);
                            tarRollupCriteria[RollupCriteria.FieldList.RollupLineId] = new EntityReference(RollupLine.EntityName, tarRollupLineId);
                            tarRollupCriteriaId = service.Create(tarRollupCriteria);

                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.LOB.RelationEntityName, RollupCriteria.Relation.LOB.Name, RollupCriteria.EntityName, RollupCriteria.Relation.LOB.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.Zone.RelationEntityName, RollupCriteria.Relation.Zone.Name, RollupCriteria.EntityName, RollupCriteria.Relation.Zone.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.Region.RelationEntityName, RollupCriteria.Relation.Region.Name, RollupCriteria.EntityName, RollupCriteria.Relation.Region.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.AgentTitle.RelationEntityName, RollupCriteria.Relation.AgentTitle.Name, RollupCriteria.EntityName, RollupCriteria.Relation.AgentTitle.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.AgentType.RelationEntityName, RollupCriteria.Relation.AgentType.Name, RollupCriteria.EntityName, RollupCriteria.Relation.AgentType.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.DOY.RelationEntityName, RollupCriteria.Relation.DOY.Name, RollupCriteria.EntityName, RollupCriteria.Relation.DOY.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.MCVLocal.RelationEntityName, RollupCriteria.Relation.MCVLocal.Name, RollupCriteria.EntityName, RollupCriteria.Relation.MCVLocal.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.ProductGroup.RelationEntityName, RollupCriteria.Relation.ProductGroup.Name, RollupCriteria.EntityName, RollupCriteria.Relation.ProductGroup.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.ProductSeries.RelationEntityName, RollupCriteria.Relation.ProductSeries.Name, RollupCriteria.EntityName, RollupCriteria.Relation.ProductSeries.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.SubmissionChannel.RelationEntityName, RollupCriteria.Relation.SubmissionChannel.Name, RollupCriteria.EntityName, RollupCriteria.Relation.SubmissionChannel.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.Team.RelationEntityName, RollupCriteria.Relation.Team.Name, RollupCriteria.EntityName, RollupCriteria.Relation.Team.EntityName);
                            copyEntityUtility.copyRelation(tarRollupCriteriaId, srcRollupCriteria.Id, RollupCriteria.Relation.Award.RelationEntityName, RollupCriteria.Relation.Award.Name, RollupCriteria.EntityName, RollupCriteria.Relation.Award.EntityName);

                            #region Rollup criteria reference
                            query = copyEntityUtility.buildQueryByParentId(RollupCriteriaReference.EntityName, RollupCriteriaReference.FieldList.RollupCriteriaId, srcRollupCriteria.Id);
                            DataCollection<Entity> rollupCriteriaRefCollection = service.RetrieveMultiple(query).Entities;

                            foreach (Entity srcRollupCriteriaRef in rollupCriteriaRefCollection)
                            {
                                tarRollupCriteriaRef = copyEntityUtility.copyEntity(srcRollupCriteriaRef, rollupCriteriaRefExcList);
                                tarRollupCriteriaRef[RollupCriteriaReference.FieldList.RollupCriteriaId] = new EntityReference(RollupCriteria.EntityName, tarRollupCriteriaId);
                                service.Create(tarRollupCriteriaRef);
                            }
                            #endregion
                        }
                        #endregion

                        #region MDRT active month parameter
                        query = copyEntityUtility.buildQueryByParentId(MDRTActiveMthParm.EntityName, MDRTActiveMthParm.FieldList.RollupLineId, srcRollupLine.Id);
                        DataCollection<Entity> activeMthParmCollection = service.RetrieveMultiple(query).Entities;

                        foreach (Entity srcActiveMthParm in activeMthParmCollection)
                        {
                            tarActiveMthParm = copyEntityUtility.copyEntity(srcActiveMthParm, activeMthParmExcList);
                            tarActiveMthParm[MDRTActiveMthParm.FieldList.RollupLineId] = new EntityReference(RollupLine.EntityName, tarRollupLineId);
                            tarActiveMthParmId = service.Create(tarActiveMthParm);

                            copyEntityUtility.copyRelation(tarActiveMthParmId, srcActiveMthParm.Id, MDRTActiveMthParm.Relation.LOB.RelationEntityName, MDRTActiveMthParm.Relation.LOB.Name, MDRTActiveMthParm.EntityName, MDRTActiveMthParm.Relation.LOB.EntityName);
                            copyEntityUtility.copyRelation(tarActiveMthParmId, srcActiveMthParm.Id, MDRTActiveMthParm.Relation.ProductGroup.RelationEntityName, MDRTActiveMthParm.Relation.ProductGroup.Name, MDRTActiveMthParm.EntityName, MDRTActiveMthParm.Relation.ProductGroup.EntityName);
                            copyEntityUtility.copyRelation(tarActiveMthParmId, srcActiveMthParm.Id, MDRTActiveMthParm.Relation.ProductSeries.RelationEntityName, MDRTActiveMthParm.Relation.ProductSeries.Name, MDRTActiveMthParm.EntityName, MDRTActiveMthParm.Relation.ProductSeries.EntityName);
                        }
                        #endregion
                    }
                }

                catch (FaultException<OrganizationServiceFault> ex)
                {
                    tracingService.Trace("CopyRollup: {0}", ex.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in CopyRollup.", ex);
                }

                catch (Exception ex)
                {
                    tracingService.Trace("CopyRollup: {0}", ex.ToString());
                    throw;
                }
            }
            else
            {
                tracingService.Trace("Input parameter count: {0}", context.InputParameters.Count);
                throw new InvalidPluginExecutionException("Cannot get input parameter.");
            }
        }
    }
}
