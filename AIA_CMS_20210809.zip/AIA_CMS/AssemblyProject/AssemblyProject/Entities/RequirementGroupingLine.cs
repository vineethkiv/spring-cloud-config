﻿namespace AIA_CMS.Entities
{
    class RequirementGroupingLine
    {
        internal const string EntityName = "cms_groupingline";

        internal static class FieldList
        {
            internal const string Id = "cms_groupinglineid";
            internal const string GroupingId = "cms_groupingid";
            internal const string RequirementId = "cms_requirement";
            internal const string SubGroupId = "cms_subgroupid";
        }
    }
}
