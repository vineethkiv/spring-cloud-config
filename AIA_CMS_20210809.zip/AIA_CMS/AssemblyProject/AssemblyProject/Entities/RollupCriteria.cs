﻿namespace AIA_CMS.Entities
{
    internal class RollupCriteria
    {
        
        internal const string EntityName = "cms_rollupcriteria";

        internal static class FieldList
        {
            internal const string Id = "cms_rollupcriteriaid";
            internal const string RollupLineId = "cms_rolluplineid";
        }

        internal static class Relation
        {
            internal static class AgentTitle
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_agenttitle";
                internal const string EntityName = "cms_agenttitle";
                internal const string Name = "cms_cms_rollupcriteria_cms_agenttitle";
            }

            internal static class AgentType
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_agenttype";
                internal const string EntityName = "cms_agenttype";
                internal const string Name = "cms_cms_rollupcriteria_cms_agenttype";
            }

            internal static class DOY
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_doy";
                internal const string EntityName = "cms_doy";
                internal const string Name = "cms_cms_rollupcriteria_cms_doy";
            }

            internal static class LOB
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_lob";
                internal const string EntityName = "cms_lob";
                internal const string Name = "cms_cms_rollupcriteria_cms_lob";
            }

            internal static class MCVLocal
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_mcvlocal";
                internal const string EntityName = "cms_mcvlocal";
                internal const string Name = "cms_cms_rollupcriteria_cms_mcvlocal";
            }

            internal static class ProductGroup
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_productgroup";
                internal const string EntityName = "cms_productgroup";
                internal const string Name = "cms_cms_rollupcriteria_cms_productgroup";
            }

            internal static class ProductSeries
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_productseries";
                internal const string EntityName = "cms_productseries";
                internal const string Name = "cms_cms_rollupcriteria_cms_productseries";
            }

            internal static class Region
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_region";
                internal const string EntityName = "cms_region";
                internal const string Name = "cms_cms_rollupcriteria_cms_region";
            }

            internal static class SubmissionChannel
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_submissionchanne";
                internal const string EntityName = "cms_submissionchannel";
                internal const string Name = "cms_cms_rollupcriteria_cms_submissionchannel";
            }

            internal static class Team
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_team";
                internal const string EntityName = "cms_team";
                internal const string Name = "cms_cms_rollupcriteria_cms_team";
            }

            internal static class Zone
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_zone";
                internal const string EntityName = "cms_zone";
                internal const string Name = "cms_cms_rollupcriteria_cms_zone";
            }

            internal static class Award
            {
                internal const string RelationEntityName = "cms_cms_rollupcriteria_cms_award";
                internal const string EntityName = "cms_award";
                internal const string Name = "cms_cms_rollupcriteria_cms_award";
            }
        }
    }
}
