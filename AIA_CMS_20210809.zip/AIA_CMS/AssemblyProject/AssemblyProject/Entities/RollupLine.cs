﻿namespace AIA_CMS.Entities
{
    internal class RollupLine
    {
        internal static class FieldList
        {
            internal const string Id = "cms_rolluplineid";
            internal const string RollupId = "cms_rollupid";
        }

        internal const string EntityName = "cms_rollupline";

    }
}
