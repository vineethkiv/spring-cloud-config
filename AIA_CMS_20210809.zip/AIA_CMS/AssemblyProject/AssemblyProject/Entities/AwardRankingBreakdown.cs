﻿namespace AIA_CMS.Entities
{
    class AwardRankingBreakdown
    {
        internal const string EntityName = "cms_awardrankingbreakdown";

        internal static class FieldList
        {
            internal const string Id = "cms_awardrankingbreakdownid";
            internal const string AwardId = "cms_awardid";
        }
    }
}
