﻿namespace AIA_CMS.Entities
{
    internal class RollupCriteriaReference
    {
        internal static class FieldList
        {
            internal const string Id = "cms_rollupcriteriareferenceid";
            internal const string RollupCriteriaId = "cms_rollupcriteria";
        }

        internal const string EntityName = "cms_rollupcriteriareference";

    }
}
