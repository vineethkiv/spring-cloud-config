﻿namespace AIA_CMS.Entities
{
    class MDRTActiveMthParm
    {
        internal const string EntityName = "cms_mdrtactivemonth";

        internal static class FieldList
        {
            internal const string Id = "cms_mdrtactivemonthid";
            internal const string RollupLineId = "cms_rollupline";
        }

        internal static class Relation
        {
            internal static class LOB
            {
                internal const string RelationEntityName = "cms_cms_mdrtactivemonth_cms_lob";
                internal const string EntityName = "cms_lob";
                internal const string Name = "cms_cms_mdrtactivemonth_cms_lob";
            }

            internal static class ProductGroup
            {
                internal const string RelationEntityName = "cms_cms_mdrtactivemonth_cms_productgroup";
                internal const string EntityName = "cms_productgroup";
                internal const string Name = "cms_cms_mdrtactivemonth_cms_productgroup";
            }

            internal static class ProductSeries
            {
                internal const string RelationEntityName = "cms_cms_mdrtactivemonth_cms_productseries";
                internal const string EntityName = "cms_productseries";
                internal const string Name = "cms_cms_mdrtactivemonth_cms_productseries";
            }
        }
    }
}
