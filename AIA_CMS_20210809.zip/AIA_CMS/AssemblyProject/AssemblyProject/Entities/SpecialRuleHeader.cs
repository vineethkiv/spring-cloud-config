﻿namespace AIA_CMS.Entities
{
    class SpecialRuleHeader
    {
        internal const string EntityName = "cms_specialruleheader";

        internal static class FieldList
        {
            internal const string Id = "cms_specialruleheaderid";
            internal const string ContestId = "cms_contest";
        }
    }
}
