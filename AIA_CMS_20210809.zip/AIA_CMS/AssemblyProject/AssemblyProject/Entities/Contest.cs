﻿namespace AIA_CMS.Entities
{
    internal class Contest
    {
        internal const string EntityName = "cms_contest";

        internal static class FieldList
        {
            internal const string Id = "cms_contestid";
            internal const string Active = "cms_active";
            internal const string Name = "cms_name";
            internal const string ApprovalStatus1 = "cms_approvalstatus1";
            internal const string ApprovalStatus2 = "cms_approvalstatus2";
            internal const string ApprovalComment1 = "cms_approvalcomment1";
            internal const string ApprovalComment2 = "cms_approvalcomment2";
        }
    }
}
