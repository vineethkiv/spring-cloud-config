﻿namespace AIA_CMS.Entities
{
    class SpecialContestLine
    {
        internal const string EntityName = "cms_specialcontestline";

        internal static class FieldList
        {
            internal const string Id = "cms_specialcontestlineid";
            internal const string SpecialContestHeaderId = "cms_specialcontestheader";
        }
    }
}
