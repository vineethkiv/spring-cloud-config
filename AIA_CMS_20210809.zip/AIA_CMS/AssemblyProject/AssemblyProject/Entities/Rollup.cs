﻿namespace AIA_CMS.Entities
{
    internal class Rollup
    {
        internal static class FieldList
        {
            internal const string Id = "cms_rollupid";
            internal const string Name = "cms_name";
        }

        internal const string EntityName = "cms_rollup";
        
    }
}
