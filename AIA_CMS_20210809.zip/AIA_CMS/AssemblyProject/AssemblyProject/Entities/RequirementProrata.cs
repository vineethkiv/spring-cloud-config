﻿namespace AIA_CMS.Entities
{
    class RequirementProrata
    {
        internal const string EntityName = "cms_requirementprorata";

        internal static class FieldList
        {
            internal const string Id = "cms_requirementprorataid";
            internal const string RequirementId = "cms_requirementid";
        }
    }
}
