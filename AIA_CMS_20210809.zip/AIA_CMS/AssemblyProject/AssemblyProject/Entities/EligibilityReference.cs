﻿namespace AIA_CMS.Entities
{
    class EligibilityReference
    {
        internal const string EntityName = "cms_eligibilityreference";

        internal static class FieldList
        {
            internal const string Id = "cms_eligibilityreferenceid";
            internal const string EligibilityId = "cms_eligibility";
        }
    }
}
