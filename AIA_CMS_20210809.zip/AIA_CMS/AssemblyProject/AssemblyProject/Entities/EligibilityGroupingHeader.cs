﻿namespace AIA_CMS.Entities
{
    class EligibilityGroupingHeader
    {
        internal const string EntityName = "cms_eligibilitygroupingheader";

        internal static class FieldList
        {
            internal const string Id = "cms_eligibilitygroupingheaderid";
            internal const string AwardId = "cms_awardid";
        }
    }
}
