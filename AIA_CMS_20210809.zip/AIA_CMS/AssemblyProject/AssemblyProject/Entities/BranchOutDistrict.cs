﻿namespace AIA_CMS.Entities
{
    class BranchOutDistrict
    {
        internal const string EntityName = "cms_branchoutdistrict";

        internal static class FieldList
        {
            internal const string Id = "cms_branchoutdistrictid";
            internal const string AwardId = "cms_award";
        }
    }
}
