﻿namespace AIA_CMS.Entities
{
    class RequirementGrouping
    {
        internal const string EntityName = "cms_grouping";

        internal static class FieldList
        {
            internal const string Id = "cms_groupingid";
            internal const string AwardId = "cms_awardid";
        }
    }
}
