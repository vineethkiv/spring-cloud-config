﻿namespace AIA_CMS.Entities
{
    internal class RequirementContractMain
    {
        internal const string EntityName = "cms_requirementcontractmain";

        internal static class FieldList
        {
            internal const string Id = "cms_requirementcontractmainid";
            internal const string RequirementId = "cms_requirementid";
        }
    }
}
