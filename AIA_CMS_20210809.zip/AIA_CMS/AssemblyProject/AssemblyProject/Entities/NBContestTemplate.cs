﻿namespace AIA_CMS.Entities
{
    class NBContestTemplate
    {
        internal const string EntityName = "cms_nbtemplateheader";

        internal static class FieldList
        {
            internal const string Id = "cms_nbtemplateheaderid";
        }
    }
}
