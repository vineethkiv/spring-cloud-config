﻿namespace AIA_CMS.Entities
{
    class SpecialContestHeader
    {
        internal const string EntityName = "cms_specialcontestheader";

        internal static class FieldList
        {
            internal const string Id = "cms_specialcontestheaderid";
            internal const string ContestId = "cms_contest";
        }
    }
}
