﻿namespace AIA_CMS.Entities
{
    class EstimatedYearEndBonus
    {
        internal const string EntityName = "cms_estimatedyearendbonus";

        internal static class FieldList
        {
            internal const string Id = "cms_estimatedyearendbonusid";
            internal const string RollupLineId = "cms_rollupline";
        }
    }
}
