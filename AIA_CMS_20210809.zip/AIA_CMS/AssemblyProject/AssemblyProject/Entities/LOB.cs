﻿namespace AIA_CMS.Entities
{
    class LOB
    {
        internal const string EntityName = "cms_lob";

        internal static class FieldList
        {
            internal const string Id = "cms_lobid";
        }
    }
}
