﻿namespace AIA_CMS.Entities
{
    class NBContestTemplateLine
    {
        internal const string EntityName = "cms_nbtemplateline";

        internal static class FieldList
        {
            internal const string Id = "cms_nbtemplatelineid";
            internal const string NBContestTemplateId = "cms_nbtemplateheader";
        }

        internal static class Relation
        {
            internal static class LOB
            {
                internal const string RelationEntityName = "cms_cms_nbtemplateline_cms_lob";
                internal const string EntityName = "cms_lob";
                internal const string Name = "cms_cms_nbtemplateline_cms_lob";
            }

            internal static class SubmissionChannel
            {
                internal const string RelationEntityName = "cms_cms_nbtemplateline_cms_submissionchanne";
                internal const string EntityName = "cms_submissionchannel";
                internal const string Name = "cms_cms_nbtemplateline_cms_submissionchannel";
            }
        }
    }
}
