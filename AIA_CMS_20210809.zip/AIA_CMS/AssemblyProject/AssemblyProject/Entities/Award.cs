﻿namespace AIA_CMS.Entities
{
    internal class Award
    {
        internal const string EntityName = "cms_award";

        internal static class FieldList
        {
            internal const string Id = "cms_awardid";
            internal const string ContestId = "cms_contestid";
        }
    }
}
