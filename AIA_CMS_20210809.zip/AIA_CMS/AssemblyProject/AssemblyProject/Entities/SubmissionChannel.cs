﻿namespace AIA_CMS.Entities
{
    class SubmissionChannel
    {
        internal const string EntityName = "cms_submissionchannel";

        internal static class FieldList
        {
            internal const string Id = "cms_submissionchannelid";
        }
    }
}
