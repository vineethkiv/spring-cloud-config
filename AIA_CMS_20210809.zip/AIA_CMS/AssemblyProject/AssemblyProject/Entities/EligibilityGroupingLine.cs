﻿namespace AIA_CMS.Entities
{
    class EligibilityGroupingLine
    {
        internal const string EntityName = "cms_eligibilitygroupingline";

        internal static class FieldList
        {
            internal const string Id = "cms_eligibilitygroupinglineid";
            internal const string EligibilityGroupingHeaderId = "cms_eligibilitygroup";
            internal const string EligibilityId = "cms_eligibility";
            internal const string SubGroupId = "cms_subgroup";
        }
    }
}
